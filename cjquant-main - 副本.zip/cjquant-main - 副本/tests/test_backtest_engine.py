# -*- coding: utf-8 -*-
"""回测引擎与费用模型的回归测试（评审 F-9：这些是回测可信度的地基）。

覆盖（合成数据、不联网、秒级完成）：
  1. 阶梯赎回费：4 天 1.5% / 63 天 0.5% / 180 天以上免费
  2. 免申赎费标的（货币基金）：0 申购费 0 赎回费
  3. T+1 确认 / T+3 到账的时间轴
  4. F-3 清盘强制赎回：净值止更后按最后净值清算，损失真实进权益曲线
  5. F-6 末根 bar 下单被显式拒绝（T+1 不退化成 T+0）
  6. F-7 Sortino：下行偏差公式（常量亏损的反例）
  7. F-1 max_drawdown_of 无重复定义（导入冒烟）
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from cjquant.backtest.engine import OTCBacktestEngine            # noqa: E402
from cjquant.backtest.fee import OTCFeeModel                     # noqa: E402
from cjquant.visualizer.metrics import downside_deviation        # noqa: E402
import cjquant.funnel.risk as frisk                              # noqa: E402


def _mk_market(days: int = 40, codes=("000001.OF",)) -> pd.DataFrame:
    idx = pd.date_range("2026-01-05", periods=days, freq="B")
    frames = []
    rng = np.random.default_rng(7)
    for c in codes:
        nav = 1.0 * np.cumprod(1.0 + rng.normal(0.0005, 0.004, days))
        frames.append(pd.DataFrame({"fund_code": c, "adj_nav": nav}, index=idx))
    return pd.concat(frames)


def test_fee_tiers():
    fm = OTCFeeModel()
    assert abs(fm.get_sell_fee_rate(4) - 0.015) < 1e-12       # <7 天惩罚档
    assert abs(fm.get_sell_fee_rate(63) - 0.005) < 1e-12      # 30~180 天
    assert fm.get_sell_fee_rate(200) == 0.0                   # 免费档
    assert fm.get_sell_fee_rate(4, "000009.OF") == 0.0 if fm.is_fee_free("000009.OF") else True
    fm.add_fee_free(["000009.OF"])
    assert fm.get_buy_fee(10000.0, "000009.OF") == 0.0
    assert fm.get_sell_fee_rate(1, "000009.OF") == 0.0
    print("[PASS] 阶梯赎回费 + 免申赎费标的")


def test_t_plus_timeline():
    mkt = _mk_market(20)
    eng = OTCBacktestEngine(market_data=mkt, initial_cash=100_000.0,
                            t_plus_confirm=1, t_plus_settle=3)
    eng.submit_order("000001.OF", "BUY", value=50_000.0)
    # 第 0 天提交 → 确认应在第 1 天
    eng.step()
    assert len(eng.trade_history) == 0, "T+1 确认：提交当天不应有成交"
    eng.step()
    assert len(eng.trade_history) == 1, "T+1 确认：第二天应成交"
    # 到账：买入当即确认份额，无 transit
    assert eng.cash_account.transit_queue == {} or not eng.cash_account.transit_queue
    print("[PASS] T+1 确认时间轴")


def test_settle_t3():
    mkt = _mk_market(30)
    eng = OTCBacktestEngine(market_data=mkt, initial_cash=100_000.0,
                            t_plus_confirm=1, t_plus_settle=3)
    # 先买入并确认
    eng.submit_order("000001.OF", "BUY", value=60_000.0)
    for _ in range(2):
        eng.step()
    assert "000001.OF" in eng.positions and eng.positions["000001.OF"].total_shares > 0
    shares = eng.positions["000001.OF"].total_shares
    # 卖出：T+1 确认、T+3 到账
    eng.submit_order("000001.OF", "SELL", shares=shares)
    eng.step()   # T+0（提交日当晚的下一根 bar，未到确认日）
    eng.step()   # T+1 确认日 → 资金进 transit
    assert eng.cash_account.transit_queue, "赎回资金应在 transit 队列"
    transit_val = sum(eng.cash_account.transit_queue.values())
    assert transit_val > 0
    settle_d = max(eng.cash_account.transit_queue.keys())
    # 口径说明：到账日 = 提交日 + t_plus_settle（= 确认日 + 2 个交易日），
    # 即"提交 T+1 确认、自申请日起 T+3 到账"。断言到账不早于确认日次日即可。
    n_wait = list(eng.trading_dates).index(settle_d) - eng.current_date_idx
    assert n_wait >= 1, f"到账日距确认日过近（{n_wait} 个交易日）"
    # 走到到账日
    while eng.cash_account.transit_queue:
        eng.step()
    assert eng.cash_account.available_cash > 0
    print(f"[PASS] T+3 到账（确认后 {n_wait} 个交易日内到账）")


def test_delisting_force_redeem():
    """F-3：净值序列中途结束的基金必须被强制赎回，损失真实体现。"""
    idx = pd.date_range("2026-01-05", periods=30, freq="B")
    rng = np.random.default_rng(3)
    nav_full = 1.0 * np.cumprod(1.0 + rng.normal(0.0005, 0.004, 30))
    # 骨架基金：完整 30 天净值，撑起交易日历（清盘基金不能决定日历长度）
    mkt_skel = pd.DataFrame({"fund_code": "888888.OF", "adj_nav": 1.0}, index=idx)
    # 清盘基金：从第 22 天起净值不再更新
    nav_dead = pd.Series(nav_full, index=idx)
    nav_dead.loc[idx[22:]] = np.nan
    mkt_dead = pd.DataFrame({"fund_code": "000001.OF", "adj_nav": nav_dead}).dropna()
    mkt = pd.concat([mkt_skel, mkt_dead])
    eng = OTCBacktestEngine(market_data=mkt, initial_cash=100_000.0)
    eng.submit_order("000001.OF", "BUY", value=60_000.0)
    eng.step(); eng.step()
    assert eng.positions["000001.OF"].total_shares > 0
    last_nav = float(mkt_dead["adj_nav"].iloc[-1])
    # 跑过清盘点：日历 30 天，净值末值在 idx21（2026-02-03），
    # 需跑到 idx22（> 末值日）才触发强制赎回
    for _ in range(22):
        eng.step()
    assert eng.positions["000001.OF"].total_shares == 0, "清盘后必须强制赎回（份额清零）"
    assert any("FORCE_REDEEM" == t.order_id for t in eng.trade_history), "应留 FORCE_REDEEM 成交记录"
    # 清算净值必须是"最后有效净值"，而不是冻结到最后一天
    fr_trades = [t for t in eng.trade_history if t.order_id == "FORCE_REDEEM"]
    assert abs(fr_trades[0].confirm_nav - last_nav) < 1e-9
    # 资金最终回到 available（T+3）
    for _ in range(6):
        eng.step()
    assert eng.cash_account.available_cash > 10_000.0
    print(f"[PASS] 清盘强制赎回（按最后净值 {last_nav:.4f} 清算）")


def test_last_bar_rejected():
    """F-6：末根 bar 下单必须被拒绝，而不是 T+1 退化成 T+0。"""
    mkt = _mk_market(6)
    eng = OTCBacktestEngine(market_data=mkt, initial_cash=100_000.0, t_plus_confirm=1)
    for _ in range(5):
        eng.step()
    assert eng.current_date_idx == 5   # 最后一根 bar
    n_hist = len(eng.trade_history)
    r = eng.submit_order("000001.OF", "BUY", value=10_000.0)
    assert r is None, "末根 bar 下单应被拒绝"
    assert len(eng.trade_history) == n_hist
    assert eng.cash_account.available_cash == 100_000.0, "拒绝后资金不得被冻结"
    print("[PASS] 末根 bar 下单显式拒绝（T+1 不退化 T+0）")


def test_sortino_formula():
    """F-7：旧实现（负收益子集 std）在常量亏损下给出 Sortino=0；正确公式应给出有限值。"""
    r = pd.Series([-0.01] * 100)                      # 每天恒定亏 1%
    ds = downside_deviation(r, rf=0.0)
    # 全部为 min(r-0,0)=-0.01 → DS = 0.01*sqrt(252) ≈ 15.87%
    assert abs(ds - 0.01 * np.sqrt(252)) < 1e-9, f"下行偏差错误: {ds}"
    # 全正收益 → DS = 0
    assert downside_deviation(pd.Series([0.001] * 100), rf=0.0) == 0.0
    print(f"[PASS] Sortino 下行偏差（常量亏损 → DS={ds:.2%}，非 0）")


def test_no_duplicate_max_drawdown_of():
    src = open(os.path.join(ROOT, "cjquant", "funnel", "risk.py"),
               encoding="utf-8").read()
    n = sum(1 for line in src.splitlines() if line.startswith("def max_drawdown_of("))
    assert n == 1, f"max_drawdown_of 定义了 {n} 次（评审 F-1：重复定义互相覆盖）"
    print("[PASS] max_drawdown_of 唯一定义")


def main() -> int:
    test_fee_tiers()
    test_t_plus_timeline()
    test_settle_t3()
    test_delisting_force_redeem()
    test_last_bar_rejected()
    test_sortino_formula()
    test_no_duplicate_max_drawdown_of()
    print("\n全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
