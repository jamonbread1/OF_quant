# -*- coding: utf-8 -*-
"""五层漏斗端到端回归测试（合成数据，不联网）。

跑法：
    python tests/test_funnel_smoke.py

覆盖的不变量（都是改代码时极易悄悄破坏的）：
  1. L2 准入后仍有足够样本（准入别写成"全拦"）
  2. 五个子池能被正确识别（关键词顺序：QDII/ALT 必须排在 IDX 前）
  3. 权重 Σ = 1、单只 ≤ w_max、有效持仓 ≥ w_min（§7.3 C1/C2）
  4. **§7.1 的 ERC 类别额度不被 §7.3 的截断改写**（类别内闭环分配）
  5. Pool_IDX 是独立子池但并入 EQ 大类，必须拿到额度（不能被静默丢弃）
  6. H2/H4/H6/H7 的字段级行为（含 H7 的 nan **不能静默通过**）
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from cjquant.funnel.filters import FundFacts, hard_filters  # noqa: E402
from cjquant.funnel.pipeline import (CLASS_OF_POOL, SUBPOOLS, classify_subpool,  # noqa: E402
                                     run_funnel)
from cjquant.funnel.pool import PoolParams  # noqa: E402
from cjquant.funnel.style import STYLE_VECTOR_BY_TYPE, style_vector_for  # noqa: E402

N_DAYS = 800
# (子池, 只数, 日均值, 日波动)
SPEC = [
    ("EQ", 22, 0.0004, 0.014),
    ("BOND", 12, 0.00015, 0.0025),
    ("IDX", 8, 0.0003, 0.012),
    ("ALT", 6, 0.00025, 0.010),
    ("QDII", 7, 0.00035, 0.011),
    ("CASH", 5, 0.00006, 0.0002),
]
TYPE_NAME = {
    "EQ": "偏股混合型", "BOND": "纯债债券型", "IDX": "沪深300指数增强",
    "ALT": "黄金ETF联接", "QDII": "QDII-指数", "CASH": "货币型",
}


def build_panel(seed: int = 20260918):
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2022-01-03", periods=N_DAYS)
    codes, navs, type_of = [], {}, {}
    k = 0
    for sp, n, mu, sd in SPEC:
        for _ in range(n):
            k += 1
            code = f"{100000 + k:06d}.OF"
            nav = 1.0 * np.exp(np.cumsum(rng.normal(mu, sd, N_DAYS)))
            codes.append(code)
            navs[code] = pd.Series(nav, index=idx)
            type_of[code] = TYPE_NAME[sp]
    return pd.DataFrame(navs), type_of


def test_rule_fields():
    """H2/H4/H6/H7 的字段级行为 —— 不联网、不依赖数据库。"""
    nav = pd.Series(np.linspace(1.0, 1.40, 400),
                    index=pd.bdate_range("2023-01-02", periods=400))
    asof = nav.index[-1]
    base = dict(code="T00001.OF", nav=nav, setup_date="2020-01-01",
                fund_type="偏股混合型", scale_yi=10.0)

    def run(**kw):
        return hard_filters(FundFacts(**{**base, **kw}), asof)

    # --- H7：类型映射必须能接住数据源的"大类-子类"形式 ---
    cases = {"混合型-偏股": "偏股混合", "混合型-灵活": "灵活配置",
             "混合型-偏债": "偏债混合", "股票型": "股票型",
             "指数型-股票": "指数型", "指数型-固收": "债券型",
             "债券型-长债": "债券型", "债券型-混合二级": "债券型"}
    for src, want in cases.items():
        got = style_vector_for(src)
        assert got == STYLE_VECTOR_BY_TYPE[want], f"H7 类型映射错: {src} -> {got}"
    for src in ("货币型-普通货币", "FOF-稳健型", "QDII-股票", "", None):
        assert style_vector_for(src) is None, f"H7 不该归一化的类型: {src}"

    # --- 商品类必须豁免风格约束，且判断优先于类型匹配 ---
    # 黄金 ETF 联接的 fund_type 是「指数型-其他」，不豁免的话会被套上**股票**风格向量，
    # 算出 0.03~0.04 的余弦相似度 → 被 H7 误杀 → §7.1 的 ALT（危机对冲）整类消失。
    for nm in ("华安黄金ETF联接A", "国泰黄金ETF联接A", "易方达黄金ETF联接A",
               "南方原油C", "博时黄金ETF联接A"):
        assert style_vector_for("指数型-其他", nm) is None, f"商品类未被豁免: {nm}"
    # 普通指数基金不受影响
    assert style_vector_for("指数型-其他", "某某沪深300指数A") == \
        STYLE_VECTOR_BY_TYPE["指数型"], "普通指数基金被误豁免"
    print(f"[PASS] H7 类型映射（{len(cases)} 个真实取值全部命中 + 商品类豁免）")

    # --- H7 的 nan 必须记「未校验」，绝不能静默通过 ---
    r = run(style_match=float("nan"))
    assert any(u.startswith("H7") for u in r.unverified), "H7 的 nan 被静默通过了"
    assert not any("H7" in x for x in r.reasons), "H7 的 nan 被当成不达标剔除"
    r = run(style_match=0.30)
    assert any("H7" in x for x in r.reasons), "H7 低纯净度未剔除"
    r = run(style_match=0.85)
    assert not any("H7" in x for x in r.reasons), "H7 达标却被剔除"
    print("[PASS] H7 nan/达标/不达标 三分支")

    # --- H2：现任经理任期 ---
    r = run(manager_tenure_days=100)
    assert any("H2" in x for x in r.reasons), "H2 任期不足未剔除"
    r = run(manager_tenure_days=2000)
    assert not any("H2" in x for x in r.reasons), "H2 任期充足却被剔除"
    r = run()
    assert any(u.startswith("H2") for u in r.unverified), "H2 缺数据未记未校验"
    print("[PASS] H2 任期不足/充足/缺数据 三分支")

    # --- H6：机构持有比例 ---
    r = run(inst_ratio=0.95)
    assert any("H6" in x for x in r.reasons), "H6 机构占比过高未剔除"
    r = run(inst_ratio=0.40)
    assert not any("H6" in x for x in r.reasons), "H6 正常占比却被剔除"
    print("[PASS] H6 超标/正常 两分支")

    # --- H4：暂停申购剔除；限大额只打旗标不剔除 ---
    r = run(tradable=False)
    assert any("H4" in x for x in r.reasons), "H4 暂停申购未剔除"
    r = run(tradable=True, limited_purchase=True)
    assert any(f.startswith("Flag_LimitedPurchase") for f in r.flags), "H4 限大额未打旗标"
    assert not any("暂停" in x for x in r.reasons), "H4 限大额被误剔除"
    r = run(tradable=None)
    assert any(u.startswith("H4") for u in r.unverified), "H4 状态缺失未记未校验"
    print("[PASS] H4 暂停/限大额/缺失 三分支")


def main() -> int:
    test_rule_fields()
    panel, type_of = build_panel()

    # --- 子池分类自检：关键词顺序错了这里就会挂 ---
    for code, tname in type_of.items():
        expect = next(sp for sp, *_ in SPEC if TYPE_NAME[sp] == tname)
        got = classify_subpool(tname)
        assert got == expect, f"分类错误: {tname} 期望 {expect} 得到 {got}"
    print(f"[PASS] 子池分类（{len(panel.columns)} 只全部归位）")

    out = run_funnel(panel, asof=panel.index[-1],
                     pool_params=PoolParams(n_target=15),
                     sigma_target=0.11, use_style=False, use_holdings=False,
                     w_max=0.20, w_min=0.02, lam=1.0, to_max=0.35, rf=0.02,
                     type_of=type_of)

    print(f"  候选 {len(out.candidates)} 准入 {len(out.eligible)} "
          f"子池 {({k: len(v) for k, v in out.pools.items()})}")
    assert len(out.eligible) > 3, "准入门槛过严"
    assert out.members, "池为空"

    w = out.final_weights
    assert len(w), "未产出权重"
    s = float(w.sum())
    assert 0.98 < s < 1.02, f"权重和异常 {s}"
    assert float(w.max()) <= 0.2001, f"单只上限被突破 {w.max()}"
    assert float(w[w > 0].min()) >= 0.02 - 1e-9, f"w_min 未生效 {float(w[w>0].min())}"
    print(f"[PASS] 约束（Σ={s:.4f} 最大 {float(w.max()):.4f} 最小 {float(w[w>0].min()):.4f}）")

    # --- 核心不变量：ERC 类别额度守恒 ---
    actual = {}
    for sp, ms in out.pools.items():
        cls = CLASS_OF_POOL.get(sp)
        if cls is None:                      # CASH 不属于 ERC 类别集合
            continue
        actual[cls] = actual.get(cls, 0.0) + sum(float(w.get(c, 0.0)) for c in ms)
    for a, target in out.class_weights.items():
        got = actual.get(a, 0.0)
        assert abs(got - target) < 0.01, f"{a} 额度被改写：目标 {target} 实际 {got}"
        print(f"  {a:5s} 目标 {target:.4f} 实际 {got:.4f}")
    print("[PASS] 类别额度守恒（ERC 未被 §7.3 截断改写）")

    # --- IDX 并入 EQ 大类，必须拿到额度 ---
    idx_members = out.pools.get("IDX", [])
    assert idx_members, "IDX 池为空"
    w_idx = sum(float(w.get(c, 0.0)) for c in idx_members)
    assert w_idx > 0.01, "IDX 池未获得任何额度（EQ 大类合并失效）"
    print(f"[PASS] IDX 子池 {len(idx_members)} 只合计 {w_idx:.4f}")

    print("\n全部通过")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
