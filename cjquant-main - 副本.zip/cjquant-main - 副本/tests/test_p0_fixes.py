# -*- coding: utf-8 -*-
"""P0/P1 修复项的回归护栏（不联网、不依赖数据库）。

这些用例全部对应"已经真实发生过、且当时没人发现"的缺陷。改代码时如果
其中任何一条变红，说明对应的 BUG 又回来了。

跑法：
    python tests/test_p0_fixes.py
或
    python -m pytest tests/test_p0_fixes.py -q
"""
import os
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from cjquant.data.codeutil import norm_code, norm_codes, norm_map  # noqa: E402
from cjquant.backtest.fee import OTCFeeModel  # noqa: E402
from cjquant.backtest.hold_policy import (expected_forward_loss,  # noqa: E402
                                          should_sell_for_loss)
from cjquant.funnel.pipeline import run_funnel  # noqa: E402
from cjquant.funnel.pool import PoolParams  # noqa: E402
from cjquant.funnel.portfolio import apply_group_caps, limit_turnover  # noqa: E402
from cjquant.visualizer.metrics import equal_weight_benchmark  # noqa: E402


# ---------------------------------------------------------------------------
# P0-1：权重不得被归一化拉满、单只上限不得被击穿
# ---------------------------------------------------------------------------
def _panel(with_qdii: bool = True, seed: int = 7, n_days: int = 800):
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2022-01-03", periods=n_days)
    spec = [("EQ", 20, 0.00040, 0.0140), ("BOND", 10, 0.00015, 0.0025),
            ("IDX", 6, 0.00030, 0.0120), ("ALT", 4, 0.00025, 0.0100)]
    if with_qdii:
        spec.append(("QDII", 7, 0.00035, 0.0110))
    tname = {"EQ": "偏股混合型", "BOND": "纯债债券型", "IDX": "沪深300指数增强",
             "ALT": "黄金ETF联接", "QDII": "QDII-指数"}
    navs, typ = {}, {}
    k = 0
    for sp, n, mu, sd in spec:
        for _ in range(n):
            k += 1
            c = f"{100000 + k:06d}.OF"
            navs[c] = pd.Series(1.0 * np.exp(np.cumsum(rng.normal(mu, sd, n_days))), index=idx)
            typ[c] = tname[sp]
    return pd.DataFrame(navs), typ


def test_p0_1_weights_never_exceed_cap():
    """缺一个类别（QDII 全被剔除）时：不得用 `w/w.sum()` 把权重硬拉满。"""
    panel, typ = _panel(with_qdii=False)
    out = run_funnel(panel, asof=panel.index[-1], pool_params=PoolParams(n_target=15),
                     sigma_target=0.11, use_style=False, use_holdings=False,
                     w_max=0.20, w_min=0.02, lam=1.0, to_max=0.35, rf=0.02,
                     type_of=typ)
    assert out.members, "池为空"
    w = out.final_weights
    s = float(w.sum())
    assert s <= 1.0 + 1e-6, f"权重和被拉满到 {s}（P0-1 复发）"
    assert float(w.max()) <= 0.20 + 1e-6, f"单只上限被击穿 {float(w.max())}（P0-1 复发）"
    # 旧实现会把 0.20 放大到 0.20/Σ；这里必须**没有**放大
    print(f"[PASS] P0-1 缺类别场景：Σ={s:.4f} 最大单只={float(w.max()):.4f} underfill="
          f"{out.diagnostics.get('class_underfill')}")


def test_p0_1_limit_turnover_preserves_exposure():
    """换手约束后不得把敞口重新拉回 100%（"不是必须用尽可用资金"）。"""
    new = pd.Series({"A": 0.30, "B": 0.30, "C": 0.20})   # 目标 80%
    old = pd.Series({"A": 0.10, "B": 0.10, "C": 0.10})
    got = limit_turnover(new, old, to_max=0.05, target_sum=0.80)
    assert abs(float(got.sum()) - 0.80) < 1e-6, f"敞口被改写为 {float(got.sum())}"
    print(f"[PASS] P0-1 limit_turnover 保留敞口（Σ={float(got.sum()):.4f}）")


def test_p2_2_group_caps_preserve_sum():
    """分组上限挤出来的部分退回现金，不摊给别人、不拉满。"""
    w = pd.Series({"a1": 0.20, "a2": 0.20, "a3": 0.20,   # A 组 60% > 30% 上限
                   "b1": 0.20, "b2": 0.20})
    g = {"a1": "A", "a2": "A", "a3": "A", "b1": "B", "b2": "B"}
    got = apply_group_caps(w, group_of=g, group_cap=0.30, w_max=0.20, target_sum=1.0)
    assert float(got[["a1", "a2", "a3"]].sum()) <= 0.30 + 1e-6, "A 组上限未生效"
    assert float(got.sum()) <= 1.0 + 1e-6, "总额被拉满"
    print(f"[PASS] P2-2 分组上限 A组={float(got[['a1','a2','a3']].sum()):.3f} Σ={float(got.sum()):.3f}")


# ---------------------------------------------------------------------------
# P0-2：等权基准不得退化成一只货币基金
# ---------------------------------------------------------------------------
def test_p0_2_equal_weight_benchmark_keeps_all_funds():
    """构造"首行只有一只标的有净值"的场景 —— 正是旧实现崩掉的场景。"""
    idx = pd.bdate_range("2025-01-02", periods=60)
    rng = np.random.default_rng(3)
    px = {}
    px["000605"] = pd.Series(np.cumprod(1 + rng.normal(0.00005, 0.00002, 60)), index=idx)
    for i in range(9):                       # 其余 9 只从第 5 个交易日才开始有净值
        s = pd.Series(np.cumprod(1 + rng.normal(0.0008, 0.004, 55)), index=idx[5:])
        px[f"{100001 + i:06d}"] = s
    bm = equal_weight_benchmark(px, n_days=60)
    assert bm["n_funds_used"] == 10, f"基准只用了 {bm['n_funds_used']} 只（P0-2 复发）"
    assert not bm["coverage_warning"]
    # 旧口径：只认第一行 → 仅 1 只参与
    legacy = pd.DataFrame(px).sort_index()
    legacy_n = int(legacy.loc[:, legacy.notna().iloc[0]].shape[1])
    assert legacy_n == 1, "构造失败：旧口径本应只剩 1 只"
    print(f"[PASS] P0-2 等权基准 参与={bm['n_funds_used']} 只"
          f"（旧口径仅 {legacy_n} 只）年化 {bm['annualized']:.2%}")


# ---------------------------------------------------------------------------
# P0-3：交易日历不得含周末
# ---------------------------------------------------------------------------
def test_p0_3_calendar_has_no_weekend():
    from cjquant.data.trading_calendar import trading_days
    cal = trading_days(start="2025-01-01", end="2026-09-24")
    assert len(cal) > 0, "日历为空"
    wk = pd.DatetimeIndex(cal).weekday
    assert int((wk >= 5).sum()) == 0, f"日历含 {int((wk >= 5).sum())} 个周末日期（P0-3 复发）"
    print(f"[PASS] P0-3 交易日历 {len(cal)} 天，周末 0 个")


# ---------------------------------------------------------------------------
# P0-5：代码口径归一化
# ---------------------------------------------------------------------------
def test_p0_5_code_normalization():
    assert norm_code("004401.OF") == "004401"
    assert norm_code("004401") == "004401"
    assert norm_code(" 4401 ") == "004401"
    assert norm_code("000605.OF") == "000605"
    assert norm_codes(["000390.OF", "000390", None, ""]) == ["000390", "000390"]
    m = norm_map({"004401.OF": 1.0, "004401": 2.0})
    assert len(m) == 1, "同一只基金被当成两只"
    # 复现生产事故的判定逻辑：归一化后不应再出现"全额赎回 + 全额申购"
    held = {norm_code(c): v for c, v in {"004401.OF": 868.96}.items()}
    picks = [norm_code(c) for c in ["000370", "004401", "000306"]]
    to_sell = sorted(c for c in held if c not in set(picks))
    to_buy = [c for c in picks if c not in held]
    assert to_sell == [], f"池内标的被误判为需全额赎回：{to_sell}"
    assert "004401" not in to_buy, "已被持有的标的被重复申购"
    print("[PASS] P0-5 代码归一化（不再出现同月全额赎回+全额申购）")


# ---------------------------------------------------------------------------
# P1-2：per-fund 赎回费阶梯 + 灵活的持有/卖出判据
# ---------------------------------------------------------------------------
def test_p1_2_per_fund_redeem_tiers():
    fm = OTCFeeModel()
    assert fm.get_sell_fee_rate(3, "004401") == 0.015, "默认阶梯失效"
    fm.set_sell_tiers([(7, 0.005), (30, 0.0)], fund_code="004401.OF")
    # 归一化后必须命中 per-fund 阶梯（带后缀查、裸码查都要命中）
    assert fm.get_sell_fee_rate(3, "004401.OF") == 0.005
    assert fm.get_sell_fee_rate(3, "004401") == 0.005
    assert fm.get_sell_fee_rate(10, "004401") == 0.0
    assert fm.get_sell_fee_rate(3, "000999") == 0.015, "未落库的标的应退回全局阶梯"
    print("[PASS] P1-2 per-fund 赎回费阶梯（含 .OF 归一化）")


def test_p1_2_sell_gate_both_directions():
    """既不能死扛手续费，也不能一有波动就赎回。"""
    # 还在猛跌 → 该卖（预期续亏 3% > 已亏 1% + 费 0.5% + 垫 0.2%）
    assert should_sell_for_loss(now_loss_pct=-0.01, fee_rate=0.005,
                                expected_fwd_loss=0.03, loss_aversion=1.0,
                                safety_margin=0.002) is True
    # 只是小幅波动 → 不该卖（0.3% < 1% + 0.5% + 0.2%）
    assert should_sell_for_loss(now_loss_pct=-0.01, fee_rate=0.005,
                                expected_fwd_loss=0.003, loss_aversion=1.0,
                                safety_margin=0.002) is False
    # 上涨中 → 不构成卖出理由
    assert should_sell_for_loss(now_loss_pct=0.05, fee_rate=0.005,
                                expected_fwd_loss=0.003, loss_aversion=1.0,
                                safety_margin=0.002) is False
    # 无法估计 → 遵从模型指令（不拖延）
    assert should_sell_for_loss(now_loss_pct=-0.01, fee_rate=0.005,
                                expected_fwd_loss=None) is True
    # 零赎回费的情形由调用方 `_allow_exit` 短路（fee<=0 直接卖），
    # 函数层面：没有预期续亏就没有卖出理由
    assert should_sell_for_loss(now_loss_pct=-0.01, fee_rate=0.0,
                                expected_fwd_loss=0.0) is False
    # 预期亏损的估计：只取亏损侧
    assert expected_forward_loss([0.001] * 60, 30) == 0.0
    fl = expected_forward_loss([-0.001] * 60, 30)
    assert abs(fl - 0.03) < 1e-9, f"预期亏损估计错误 {fl}"
    print("[PASS] P1-2 持有/卖出闸门双向生效")


def main() -> int:
    test_p0_1_weights_never_exceed_cap()
    test_p0_1_limit_turnover_preserves_exposure()
    test_p2_2_group_caps_preserve_sum()
    test_p0_2_equal_weight_benchmark_keeps_all_funds()
    test_p0_3_calendar_has_no_weekend()
    test_p0_5_code_normalization()
    test_p1_2_per_fund_redeem_tiers()
    test_p1_2_sell_gate_both_directions()
    print("\n全部通过")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
