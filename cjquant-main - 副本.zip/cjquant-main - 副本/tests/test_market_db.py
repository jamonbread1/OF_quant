# -*- coding: utf-8 -*-
"""统一数据仓（market.db）回归测试。

覆盖：schema/主外键约束、口径归一化、upsert 幂等、PIT 查询、
回测标的池（含清盘与 PIT 三重过滤）、任务日志、真实库行数冒烟。
"""
import os
import sys
import tempfile
from datetime import datetime

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from cjquant.data.market_db import MarketDB, _c6, _share_class_of, _family_key  # noqa: E402


def _mk() -> MarketDB:
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    os.unlink(path)
    return MarketDB(path, create=True)


def test_schema_and_fk():
    mk = _mk()
    tables = {r[0] for r in mk.conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    need = {"fund", "fund_nav", "fund_fee", "fund_redeem_tier", "fund_scale",
            "fund_manager", "fund_manager_announce", "fund_holder",
            "fund_holdings", "fund_industry", "subscribe_status_daily",
            "sync_task_log", "market_meta"}
    assert need <= tables, f"缺表: {need - tables}"
    # 外键强制：写入无主档的净值必须失败
    mk.conn.execute("PRAGMA foreign_keys=ON")
    try:
        mk.conn.execute(
            "INSERT INTO fund_nav (fund_code, nav_date, unit_nav, updated_at) "
            "VALUES ('999999','2026-01-01',1.0,'x')")
        mk.conn.commit()
        raise AssertionError("外键未生效：孤儿净值行被写入")
    except Exception:
        pass
    assert mk._ensure_fund_row("999999") is None
    mk.conn.execute(
        "INSERT INTO fund_nav (fund_code, nav_date, unit_nav, updated_at) "
        "VALUES ('999999','2026-01-01',1.0,'x')")
    mk.conn.commit()
    print("[PASS] schema 完整 + 外键强制生效")


def test_code_norm():
    assert _c6("000001.OF") == "000001"
    assert _c6("1") == "000001"
    assert _c6("000001") == "000001"
    assert _share_class_of("华夏成长混合A") == "A"
    assert _share_class_of("华夏成长混合C") == "C"
    assert _family_key("华夏成长混合A") == _family_key("华夏成长混合C")
    print("[PASS] 代码归一化 + 份额族识别")


def test_upsert_idempotent():
    mk = _mk()
    mk.upsert_funds([{"fund_code": "000001", "fund_name": "华夏成长混合A",
                      "fund_type": "混合型-偏股", "setup_date": "2001-12-18"}])
    n = 0
    for _ in range(3):
        n = mk.upsert_funds([{"fund_code": "000001.OF",
                              "fund_name": "华夏成长混合A"}])
    assert n == 1
    assert mk.conn.execute("SELECT COUNT(*) FROM fund").fetchone()[0] == 1
    # 净值幂等：同一天写两次只保留一行
    for _ in range(2):
        mk.upsert_nav("000001", [{"nav_date": "2026-01-05", "unit_nav": 1.0},
                                 {"nav_date": "2026-01-06", "unit_nav": 1.01}])
    assert mk.conn.execute("SELECT COUNT(*) FROM fund_nav").fetchone()[0] == 2
    print("[PASS] upsert 幂等（主档不重复、净值按日期覆盖）")


def test_pit_queries():
    mk = _mk()
    mk.upsert_funds([{"fund_code": "000002", "fund_name": "测试债基",
                      "fund_type": "债券型-长债", "setup_date": "2015-01-01"}])
    mk.upsert_nav("000002", [{"nav_date": f"2026-01-{d:02d}", "unit_nav": 1.0 + d / 1000}
                             for d in range(1, 29)])
    # 规模 PIT：<= asof 的最近一期
    with mk._lock:
        mk.conn.executemany(
            "INSERT INTO fund_scale (fund_code, report_date, scale_yi, updated_at) "
            "VALUES (?,?,?,?)",
            [("000002", "2025-06-30", 5.0, "x"), ("000002", "2025-12-31", 8.0, "x")])
        mk.conn.commit()
    assert mk.scale_asof("000002.OF", "2026-01-10") == 8.0
    assert mk.scale_asof("000002", "2025-09-01") == 5.0
    assert mk.scale_asof("000002", "2024-01-01") is None

    # H2 任期：现任经理最早起始日
    with mk._lock:
        mk.conn.executemany(
            "INSERT INTO fund_manager (fund_code, manager_name, start_date, end_date, "
            "updated_at) VALUES (?,?,?,?,?)",
            [("000002", "张三", "2015-01-01", None, "x"),
             ("000002", "李四", "2020-06-01", "2024-01-01", "x")])
        # 公告在张三起始之后 → 该起始日可知
        mk.conn.execute(
            "INSERT INTO fund_manager_announce (fund_code, ann_date, title, updated_at) "
            "VALUES ('000002','2015-02-01','公告','x')")
        mk.conn.commit()
    t = mk.manager_tenure_days("000002", "2026-01-10")
    assert t is not None and t > 3000, t
    # asof 早于公告 → 该时点不可知
    assert mk.manager_tenure_days("000002", "2015-01-15") is None

    # H4 快照新鲜度门槛
    mk.upsert_subscribe_snapshot(pd.DataFrame([{
        "fund_code": "000002", "stat_date": "2026-01-10",
        "subscribe_stat": "开放申购", "redeem_stat": "开放赎回"}]))
    assert mk.subscribe_status_asof("000002", "2026-01-12") is not None
    assert mk.subscribe_status_asof("000002", "2026-03-01") is None   # 超 10 天
    print("[PASS] PIT 查询（规模 / 经理任期含公告锚点 / 申赎快照新鲜度）")


def test_universe_filters():
    mk = _mk()
    mk.upsert_funds([
        {"fund_code": "000011", "fund_name": "存续股基", "fund_type": "混合型-偏股",
         "setup_date": "2015-01-01"},
        {"fund_code": "000012", "fund_name": "已清盘债基", "fund_type": "债券型-长债",
         "setup_date": "2015-01-01", "liquidation_date": "2024-06-30"},
        {"fund_code": "000013", "fund_name": "次新基金", "fund_type": "混合型-偏股",
         "setup_date": "2026-12-01"},   # 晚于 asof：尚不成立 → 必须排除
        {"fund_code": "000014", "fund_name": "货币宝", "fund_type": "货币型-普通货币",
         "setup_date": "2015-01-01"},
    ])
    # 每只给 800 个不同交易日，末日贴近今天（否则会被 status='stale' 判停更）
    end = (pd.Timestamp(datetime.now().date()) - pd.Timedelta(days=10))
    dates = [d.strftime("%Y-%m-%d")
             for d in pd.date_range(end=end, periods=800, freq="B")]
    for c in ("000011", "000012", "000013", "000014"):
        mk.upsert_nav(c, [{"nav_date": d, "unit_nav": 1.0} for d in dates])
    mk.refresh_stats()
    u = mk.backtest_universe(asof="2026-09-18", min_rows=760)
    assert "000011.OF" in u, "存续且净值充足的应入选"
    assert "000012.OF" not in u, "2024 已清盘，不应出现在 2026 的池"
    assert "000013.OF" not in u, "2026-12 才成立，asof(2026-09) 尚不存在 → 必须排除"
    assert "000014.OF" not in u, "货币型应被排除"
    # 清盘基金在清盘日之前可用（幸存者偏差治理：历史回测能选到它）
    u_hist = mk.backtest_universe(asof="2024-01-01", min_rows=100)
    assert "000012.OF" in u_hist, "清盘前应可用，否则历史样本有幸存者偏差"
    # 停更基金默认排除，include_stale=True 时可回捞（供人工复核/强赎口径）
    stale_code = "000011.OF"
    mk.conn.execute("UPDATE fund SET status='stale' WHERE fund_code='000011'")
    mk.conn.commit()
    assert stale_code not in mk.backtest_universe(asof="2026-09-18", min_rows=100)
    assert stale_code in mk.backtest_universe(asof="2026-09-18", min_rows=100,
                                              include_stale=True)
    print(f"[PASS] 回测标的池三重过滤（本次 {len(u)} 只，历史含清盘基金）")


def test_task_log():
    mk = _mk()
    ts = mk.log_task_start("market_db_maintain")
    mk.log_task_finish("market_db_maintain", ts, status="ok", n_rows=123,
                       message="done")
    r = mk.conn.execute(
        "SELECT status, n_rows FROM sync_task_log WHERE task_name=? AND started_at=?",
        ("market_db_maintain", ts)).fetchone()
    assert r and r["status"] == "ok" and r["n_rows"] == 123
    print("[PASS] sync_task_log 运行台账")


def test_real_db_smoke():
    """真实库冒烟（若存在）。"""
    from cjquant.data.market_db import default_market_db
    mk = default_market_db()
    if mk is None:
        print("[SKIP] 尚未构建 market.db")
        return
    st = mk.stats()
    assert st["funds"] > 20000, st
    assert st["nav_rows"] > 500000, st
    assert st["funds_with_nav"] >= 200, st
    # 主档统计列与现实一致
    row = mk.fund_of("000001.OF")
    assert row and row["nav_rows"] > 1000
    assert len(mk.nav_series("000001.OF")) > 1000
    print(f"[PASS] 真实库冒烟：{st['funds']} 基金 / {st['nav_rows']} 净值行")


def test_best_cash_vehicle():
    """现金载体择优：收益高且稳的那一只；有亏损日的直接淘汰。"""
    mk = _mk()
    try:
        dates = [d.strftime("%Y-%m-%d")
                 for d in pd.date_range("2024-01-01", periods=400, freq="D")]
        # A：稳定高收益（日收益恒 0.00004 → 年化约 1.0%）
        # B：收益更高但波动大（交替 0.0002 / 0.0000）
        # C：收益低且稳
        def build(daily):
            v, out = 1.0, []
            for i, d in enumerate(dates):
                v *= (1.0 + daily[i % len(daily)])
                out.append({"nav_date": d, "unit_nav": v, "adj_nav": v})
            return out
        for code, daily, name in (
            ("900001", [0.00004], "稳高货币A"),
            ("900002", [0.00006, 0.00002], "波动货币B(均值同A)"),
            ("900003", [0.00001], "低收益货币C"),
        ):
            mk.upsert_funds([{"fund_code": code, "fund_name": name,
                              "fund_type": "货币型-普通货币"}])
            mk.upsert_nav(code, build(daily))
        mk.refresh_stats()

        best = mk.best_cash_vehicle(lookback_days=1000)
        assert best is not None, "应有合格候选"
        # 同收益下比稳定性：A 恒定日收益，B 均值相同但来回摆动
        assert best["fund_code"] == "900001", (
            f"应选收益/稳定性综合最优的 900001，实际 {best}")
        assert best["ann_return"] > 0
        print(f"[PASS] 现金载体择优 {best['fund_code']} "
              f"年化 {best['ann_return']:.2%} 波动 {best['ann_vol']:.4%}")

        # 再来一只"收益更高且同样稳"的 → 应该换它（收益优先于稳定性）
        mk.upsert_funds([{"fund_code": "900004", "fund_name": "稳货币D(≈1.5%)",
                          "fund_type": "货币型-普通货币"}])
        mk.upsert_nav("900004", build([0.00006]))
        mk.refresh_stats()
        best2 = mk.best_cash_vehicle(lookback_days=1000)
        assert best2["fund_code"] == "900004", (
            f"收益更高且同样稳的应胜出，实际 {best2}")
        print(f"[PASS] 收益更高者胜出 {best2['fund_code']} "
              f"年化 {best2['ann_return']:.2%}")

        # 有亏损日必须淘汰：给胜出者制造一天亏损，它就该让位
        mk.upsert_nav("900004", [{"nav_date": dates[200], "unit_nav": 0.99,
                                  "adj_nav": 0.99}])
        mk.refresh_stats()
        best3 = mk.best_cash_vehicle(lookback_days=1000)
        assert best3 is None or best3["fund_code"] != "900004", (
            "出现亏损日的货基必须淘汰")
        print(f"[PASS] 出现亏损日的货基被淘汰"
              f"（改选 {best3['fund_code'] if best3 else '无'}）")
    finally:
        mk.close()


def main() -> int:
    test_schema_and_fk()
    test_code_norm()
    test_upsert_idempotent()
    test_pit_queries()
    test_universe_filters()
    test_task_log()
    test_best_cash_vehicle()
    test_real_db_smoke()
    print("\n全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
