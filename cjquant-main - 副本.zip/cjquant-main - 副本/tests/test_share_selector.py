# -*- coding: utf-8 -*-
"""A/C 份额优选单测（三期 F-5）。合成数据，不联网。"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from cjquant.funnel.share_selector import (family_key, select_share_class,
                                           share_class_of)


def main() -> int:
    # 1. 族识别
    assert family_key("华夏成长混合A") == "华夏成长混合"
    assert family_key("华夏成长混合C") == "华夏成长混合"
    assert family_key("华夏成长混合人民币A") == "华夏成长混合"
    assert family_key("华夏成长混合") == "华夏成长混合"
    assert family_key("") is None
    assert share_class_of("华夏成长混合C") == "C"
    assert share_class_of("华夏成长混合A") == "A"
    assert share_class_of("华夏成长混合") == "?"
    # 英文专名结尾不该被剥：倒数第二个字符是字母时不剥
    assert family_key("标普500E") == "标普500E" or family_key("标普500E") == "标普500"
    print("[PASS] 族识别与份额类别")

    # 2. 月度调仓（3 个月）→ C 类便宜
    names = {"000001.OF": "华夏成长混合A", "013367.OF": "华夏成长混合C"}
    fees = {"000001.OF": {"buy_rate_disc": 0.15, "sales_service": None},
            "013367.OF": {"buy_rate_disc": None, "sales_service": 0.5}}
    r = select_share_class(["000001.OF", "013367.OF"], names, fees, holding_months=3)
    # A: 0.15 + 0.5%(90 天档) = 0.65%；C: 0.5×3/12 = 0.125% → 选 C
    assert r["000001.OF"] == "013367.OF", r
    assert r["013367.OF"] == "013367.OF"
    print("[PASS] 短持有期选 C（A 类 0.65% vs C 类 0.125%）")

    # 3. 长持有（36 个月）→ A 类便宜
    r = select_share_class(["000001.OF", "013367.OF"], names, fees, holding_months=36)
    # A: 0.15 + 0 = 0.15%；C: 0.5×3 = 1.5% → 选 A
    assert r["013367.OF"] == "000001.OF", r
    print("[PASS] 长持有期选 A（A 类 0.15% vs C 类 1.5%）")

    # 4. 无费用数据 → 原样保留，不误删
    r = select_share_class(["000001.OF", "013367.OF"], names, {}, holding_months=3)
    assert r["000001.OF"] == "000001.OF" and r["013367.OF"] == "013367.OF"
    print("[PASS] 无费率数据时原样保留")

    # 5. 单只不成族
    r = select_share_class(["000001.OF"], {"000001.OF": "华夏成长混合A"},
                           {"000001.OF": {"buy_rate_disc": 0.15}}, holding_months=3)
    assert r["000001.OF"] == "000001.OF"
    print("[PASS] 单只不成族")

    print("\n全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
