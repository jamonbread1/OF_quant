"""多因子计算（生产级）：动量 / 风险调整 / 回撤。

输入必须是 PIT 后的 adj_nav 宽表（策略 T 日只能见 T-1）。
所有函数对缺数返回 NaN，由评分层置中性 0，不静默填 0 掩盖。
"""
import logging
import numpy as np
import pandas as pd
from typing import Dict

logger = logging.getLogger(__name__)

TRADING_DAYS = 252


def _last_ret(s: pd.Series, window: int) -> float:
    s = s.dropna()
    if len(s) <= window:
        return float("nan")
    try:
        return float(s.iloc[-1] / s.iloc[-1 - window] - 1.0)
    except Exception:
        return float("nan")


def momentum_20(s: pd.Series) -> float:
    return _last_ret(s, 20)


def momentum_60(s: pd.Series) -> float:
    return _last_ret(s, 60)


def momentum_250_skip20(s: pd.Series) -> float:
    """近250日跳过近20日：price[t-20]/price[t-270]-1，需>=271点。"""
    s = s.dropna()
    if len(s) < 272:
        return float("nan")
    try:
        return float(s.iloc[-21] / s.iloc[-271] - 1.0)
    except Exception:
        return float("nan")


def momentum_quality_60(s: pd.Series) -> float:
    """近60日上涨天数占比（稳步上涨 vs 一日暴涨）。"""
    s = s.dropna()
    if len(s) < 61:
        return float("nan")
    rets = s.pct_change().iloc[-60:]
    rets = rets.dropna()
    if rets.empty:
        return float("nan")
    return float((rets > 0).mean())


def _weighted_log_trend(s: pd.Series, window: int = 60):
    """加权对数线性回归：返回 (slope, r2)。近期权重更高（linspace 1→2）。

    思路来自用户提供的聚宽场内 ETF 动量策略（其对 log(净值) 做加权回归取斜率×R²）。
    这里做成通用算子：场外没有分钟数据、也没有涨跌停，风控只能落在**打分**里，
    所以"趋势是否稳"这一维比场内更重要。
    """
    s = s.dropna()
    if len(s) < max(10, window // 2):
        return float("nan"), float("nan")
    y = np.log(s.iloc[-(window + 1):].values.astype(float))
    if not np.all(np.isfinite(y)):
        return float("nan"), float("nan")
    x = np.arange(len(y))
    w = np.linspace(1.0, 2.0, len(y))
    try:
        slope, intercept = np.polyfit(x, y, 1, w=w)
    except Exception:
        return float("nan"), float("nan")
    ss_res = float(np.sum(w * (y - (slope * x + intercept)) ** 2))
    ybar = float(np.average(y, weights=w))
    ss_tot = float(np.sum(w * (y - ybar) ** 2))
    r2 = (1.0 - ss_res / ss_tot) if ss_tot > 0 else 0.0
    return float(slope), float(r2)


def trend_score_60(s: pd.Series) -> float:
    """趋势质量得分 = 年化趋势收益 × R²（聚宽同构：趋势强度 × 稳定性）。

    比裸动量更抗"一日暴涨"：斜率为正但拟合很差（r2 低）的标的会被显著压低。
    """
    slope, r2 = _weighted_log_trend(s, 60)
    if np.isnan(slope) or np.isnan(r2):
        return float("nan")
    ann = float(np.exp(slope * TRADING_DAYS) - 1.0)
    return float(ann * r2)


def trend_r2_60(s: pd.Series) -> float:
    """近 60 日趋势拟合优度 R²（0~1，越高越"稳"）。"""
    _slope, r2 = _weighted_log_trend(s, 60)
    return r2


def downside_vol_60(s: pd.Series) -> float:
    """近 60 日下行波动率（年化，越大越差）。专治"涨时猛跌时也猛"。"""
    s = s.dropna()
    if len(s) < 21:
        return float("nan")
    rets = s.pct_change().dropna().iloc[-60:]
    down = rets[rets < 0]
    if len(down) < 5:
        return float("nan")
    return float(down.std() * np.sqrt(TRADING_DAYS))


def worst_day_20(s: pd.Series) -> float:
    """近 20 日最差单日收益（负值）。场外用来替代聚宽的"近3日跌幅剔除"，
    因为场外没有日内止损，只能在打分阶段先把"刚崩过"的标的压下去。"""
    s = s.dropna()
    if len(s) < 6:
        return float("nan")
    rets = s.pct_change().dropna().iloc[-20:]
    if rets.empty:
        return float("nan")
    return float(rets.min())


def _ann_ret_vol(s: pd.Series, window: int = 252, rf: float = 0.02):
    s = s.dropna().iloc[-window:] if len(s.dropna()) >= 2 else s.dropna()
    rets = s.pct_change().dropna()
    # 取最近 window 个收益
    rets = rets.iloc[-window:]
    n = len(rets)
    if n < 20:
        return float("nan"), float("nan"), rets
    total = float((1.0 + rets).prod() - 1.0)
    ann_ret = float((1.0 + total) ** (TRADING_DAYS / n) - 1.0) if n > 0 else float("nan")
    ann_vol = float(rets.std() * np.sqrt(TRADING_DAYS)) if n > 1 else float("nan")
    return ann_ret, ann_vol, rets


def sharpe_252(s: pd.Series, rf: float = 0.02) -> float:
    ann_ret, ann_vol, _ = _ann_ret_vol(s, 252, rf)
    if np.isnan(ann_ret) or np.isnan(ann_vol) or ann_vol == 0:
        return float("nan")
    return float((ann_ret - rf) / ann_vol)


def sortino_252(s: pd.Series, rf: float = 0.02) -> float:
    ann_ret, _, rets = _ann_ret_vol(s, 252, rf)
    if np.isnan(ann_ret) or rets.empty:
        return float("nan")
    # ⚠️ 不能用 rets[rets<0].std()：那是"负收益子集的离散度"，不是下行偏差。
    #    反例：每天恒定亏 -1% 时 std(常量)=0 → Sortino=0，而真实 DS≈15.9%。
    #    正确定义（说明书 §3.1）：DS = sqrt(252/n · Σ min(r-MAR,0)²)，
    #    分母是全样本 n，阈值 MAR=rf/252 而非 0。
    shortfall = np.minimum(rets.values - (rf / TRADING_DAYS), 0.0)
    ds_ann = float(np.sqrt(np.mean(shortfall ** 2)) * np.sqrt(TRADING_DAYS))
    if ds_ann == 0 or np.isnan(ds_ann):
        return float("nan")
    return float((ann_ret - rf) / ds_ann)


def max_drawdown_252(s: pd.Series) -> float:
    """近252日最大回撤（负数，越接近0越好）。"""
    s = s.dropna().iloc[-252:]
    if len(s) < 20:
        return float("nan")
    roll_max = s.cummax()
    dd = (s - roll_max) / roll_max
    return float(dd.min())


def calmar_252(s: pd.Series, rf: float = 0.02) -> float:
    ann_ret, _, _ = _ann_ret_vol(s, 252, rf)
    mdd = max_drawdown_252(s)
    if np.isnan(ann_ret) or np.isnan(mdd) or mdd == 0:
        return float("nan")
    return float(ann_ret / abs(mdd))


def recovery_days_252(s: pd.Series) -> float:
    """近252日回撤恢复天数（越短越好；未恢复返回窗口长度）。"""
    s = s.dropna().iloc[-252:]
    if len(s) < 20:
        return float("nan")
    roll_max = s.cummax()
    dd = (s - roll_max) / roll_max
    trough_idx = dd.idxmin()
    # 峰值：trough 之前最近的高点
    pre = s.loc[:trough_idx]
    peak_val = pre.max()
    # 恢复：trough 之后首个 >= peak 的位置
    post = s.loc[trough_idx:]
    rec = post[post >= peak_val]
    if rec.empty:
        return float(len(s))
    try:
        days = (rec.index[0] - trough_idx).days
        return float(days if days >= 0 else len(post))
    except Exception:
        return float(len(s))


FACTOR_FUNCS = {
    "mom_20": momentum_20,
    "mom_60": momentum_60,
    "mom_250_skip20": momentum_250_skip20,
    "mom_quality": momentum_quality_60,
    "sharpe": sharpe_252,
    "sortino": sortino_252,
    "calmar": calmar_252,
    "max_dd": max_drawdown_252,
    "recovery": recovery_days_252,
}

# True=越大越好，False=越小越好（评分层自动取负）
HIGHER_IS_BETTER = {
    "mom_20": True,
    "mom_60": True,
    "mom_250_skip20": True,
    "mom_quality": True,
    "sharpe": True,
    "sortino": True,
    "calmar": True,
    "max_dd": True,  # 负数，-0.05 > -0.20
    "recovery": False,
}

DEFAULT_WEIGHTS = {
    "mom_20": 0.15,
    "mom_60": 0.20,
    "mom_250_skip20": 0.10,
    "mom_quality": 0.05,
    "sharpe": 0.20,
    "sortino": 0.10,
    "calmar": 0.10,
    "max_dd": 0.05,
    "recovery": 0.05,
}

# ---------- 可选风控算子（默认**不**参与打分，需策略显式接线） ----------
# 为什么单独放一份而不塞进 FACTOR_FUNCS：
# 往 FACTOR_FUNCS/DEFAULT_WEIGHTS 里加键会改变所有既有策略的打分口径、静默改变回测结果。
# 这里只提供算子，是否启用、权重多少，由策略自己决定。
RISK_FACTOR_FUNCS = {
    "trend_score": trend_score_60,     # 年化趋势 × R²（趋势强度×稳定性）
    "trend_r2": trend_r2_60,           # 趋势拟合优度
    "downside_vol": downside_vol_60,   # 下行波动率（越小越好）
    "worst_day": worst_day_20,         # 近20日最差单日（越小越好）
}

RISK_HIGHER_IS_BETTER = {
    "trend_score": True,
    "trend_r2": True,
    "downside_vol": False,
    "worst_day": True,   # 负数，-0.01 > -0.05
}

# 一份"保守型"建议权重（仅作参考，需策略显式采用）：
# 相比 DEFAULT_WEIGHTS，把趋势稳定性与下行风险纳入，弱化纯短期动量。
RISK_SUGGESTED_WEIGHTS = {
    "mom_60": 0.15,
    "mom_250_skip20": 0.15,
    "trend_score": 0.20,
    "trend_r2": 0.10,
    "sharpe": 0.10,
    "sortino": 0.10,
    "downside_vol": 0.10,
    "max_dd": 0.10,
}


def compute_factors_at(
    nav_panel_pit: pd.DataFrame,
    asof: pd.Timestamp,
    rf: float = 0.02,
) -> pd.DataFrame:
    """asof 截面因子表（已 PIT）。行=基金，列=9因子。"""
    asof = pd.to_datetime(asof)
    hist = nav_panel_pit[nav_panel_pit.index <= asof]
    rows: Dict[str, Dict] = {}
    for code in hist.columns:
        s = hist[code].dropna()
        if s.empty:
            continue
        rows[code] = {
            "mom_20": momentum_20(s),
            "mom_60": momentum_60(s),
            "mom_250_skip20": momentum_250_skip20(s),
            "mom_quality": momentum_quality_60(s),
            "sharpe": sharpe_252(s, rf),
            "sortino": sortino_252(s, rf),
            "calmar": calmar_252(s, rf),
            "max_dd": max_drawdown_252(s),
            "recovery": recovery_days_252(s),
        }
    if not rows:
        return pd.DataFrame()
    return pd.DataFrame(rows).T
