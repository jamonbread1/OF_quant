"""因子评分：横截面 Z-Score + Winsorize + 加权（生产级）。"""
import logging
import pandas as pd
from typing import Dict, List
from .compute import HIGHER_IS_BETTER, DEFAULT_WEIGHTS

logger = logging.getLogger(__name__)


class FactorScorer:
    def __init__(
        self,
        weights: Dict[str, float] = None,
        winsor: float = 3.0,
    ):
        self.weights = dict(DEFAULT_WEIGHTS) if weights is None else dict(weights)
        s = sum(self.weights.values())
        if s <= 0:
            raise ValueError("权重和必须>0")
        # 归一化，保证和=1
        self.weights = {k: v / s for k, v in self.weights.items()}
        self.winsor = winsor

    def score(self, factor_df: pd.DataFrame) -> pd.DataFrame:
        """输入 compute_factors_at 的宽表，输出含 total_score + rank 的表。"""
        if factor_df.empty:
            return factor_df
        z = pd.DataFrame(index=factor_df.index, dtype=float)
        for col in factor_df.columns:
            s = pd.to_numeric(factor_df[col], errors="coerce")
            mu = s.mean(skipna=True)
            sd = s.std(skipna=True)
            if pd.isna(sd) or sd == 0:
                z[col] = 0.0
                continue
            zi = (s - mu) / sd
            if not HIGHER_IS_BETTER.get(col, True):
                zi = -zi
            z[col] = zi.clip(-self.winsor, self.winsor).fillna(0.0)
        total = pd.Series(0.0, index=factor_df.index)
        for col, w in self.weights.items():
            if col in z.columns:
                total += z[col] * w
            else:
                logger.warning(f"权重因子 {col} 不在因子表，跳过")
        out = factor_df.copy()
        out["total_score"] = total
        out["rank"] = out["total_score"].rank(ascending=False, method="first").astype(int)
        return out.sort_values("total_score", ascending=False)

    def top_n(self, scored: pd.DataFrame, n: int = 5) -> List[str]:
        if scored.empty:
            return []
        return scored.head(n).index.tolist()
