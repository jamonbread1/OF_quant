from typing import Iterable, List, Optional, Tuple


class OTCFeeModel:
    """场外基金费用模型（申购费 + 按 FIFO 持有自然日阶梯的赎回费）。

    ⚠️ 阶梯 `(7,1.5%) / (30,0.75%) / (180,0.5%)` 出自《流动性风险管理规定》第 9 条，
       **只约束非货币基金**。货币基金 0 申赎费，必须走 fee_free_codes，
       否则"闲置现金放货基生息"会被套上 1.5% 惩罚费率，回测结论直接被带反。
    """

    def __init__(self, buy_fee_rate: float = 0.0015,
                 fee_free_codes: Optional[Iterable[str]] = None):
        self.buy_fee_rate = buy_fee_rate
        self.sell_fee_tiers: List[Tuple[int, float]] = [
            (7, 0.015),
            (30, 0.0075),
            (180, 0.005),
            (float('inf'), 0.0),
        ]
        self.fee_free_codes = {str(c) for c in (fee_free_codes or []) if c}

    def add_fee_free(self, codes: Iterable[str]) -> int:
        """登记免申赎费标的（货币基金）。返回登记后的总数。"""
        self.fee_free_codes.update(str(c) for c in (codes or []) if c)
        return len(self.fee_free_codes)

    def is_fee_free(self, fund_code: Optional[str] = None) -> bool:
        return bool(fund_code) and str(fund_code) in self.fee_free_codes

    def set_sell_tiers(self, tiers: List[Tuple[int, float]]):
        self.sell_fee_tiers = sorted(tiers, key=lambda x: x[0])

    def get_buy_fee(self, gross_amount: float,
                    fund_code: Optional[str] = None) -> float:
        if self.is_fee_free(fund_code):
            return 0.0
        return gross_amount * self.buy_fee_rate

    def get_sell_fee_rate(self, holding_natural_days: int,
                          fund_code: Optional[str] = None) -> float:
        """按持有自然日匹配费率阶梯。fund_code 缺省时按普通基金处理。"""
        if self.is_fee_free(fund_code):
            return 0.0
        for days_threshold, rate in self.sell_fee_tiers:
            if holding_natural_days < days_threshold:
                return rate
        return 0.0
