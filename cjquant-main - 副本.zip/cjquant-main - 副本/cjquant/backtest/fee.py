from typing import Dict, Iterable, List, Optional, Tuple

from ..data.codeutil import norm_code as _norm_code


class OTCFeeModel:
    """场外基金费用模型（申购费 + 按 FIFO 持有自然日阶梯的赎回费）。

    ⚠️ 阶梯 `(7,1.5%) / (30,0.75%) / (180,0.5%)` 出自《流动性风险管理规定》第 9 条，
       **只约束非货币基金**。货币基金 0 申赎费，必须走 fee_free_codes，
       否则"闲置现金放货基生息"会被套上 1.5% 惩罚费率，回测结论直接被带反。

    🟠 P1-2 修复（2026-09-26）：上面这套是**监管上限**，不是各基金的实际费率。
       用统一上限回测会系统性高估赎回成本（多数基金实际低于此、且持有满
       1~2 年即为 0）。现在支持 per-fund 阶梯（来自 `fund_redeem_tier`，
       由 `ak.fund_fee_em` 抓取落库）；没落库的标的仍退回这套上限。
    """

    def __init__(self, buy_fee_rate: float = 0.0015,
                 fee_free_codes: Optional[Iterable[str]] = None):
        self.buy_fee_rate = buy_fee_rate
        self.sell_fee_tiers: List[Tuple[int, float]] = [
            (7, 0.015),
            (30, 0.0075),
            (180, 0.005),
            (float('inf'), 0.0),
        ]
        self.fee_free_codes = {_norm_code(c) for c in (fee_free_codes or []) if c}
        # per-fund 赎回费阶梯：{6位代码: [(天数上限, 费率), ...]}
        self.sell_tiers_by_code: Dict[str, List[Tuple[int, float]]] = {}

    def add_fee_free(self, codes: Iterable[str]) -> int:
        """登记免申赎费标的（货币基金）。返回登记后的总数。"""
        self.fee_free_codes.update(_norm_code(c) for c in (codes or []) if _norm_code(c))
        return len(self.fee_free_codes)

    def is_fee_free(self, fund_code: Optional[str] = None) -> bool:
        c = _norm_code(fund_code)
        return bool(c) and (c in self.fee_free_codes or str(fund_code) in self.fee_free_codes)

    def set_sell_tiers(self, tiers: List[Tuple[int, float]],
                       fund_code: Optional[str] = None):
        """设置赎回费阶梯。给了 fund_code 就是**该基金专用**，否则是全局默认。"""
        t = sorted(((float(d), float(r)) for d, r in tiers), key=lambda x: x[0])
        if fund_code:
            self.sell_tiers_by_code[_norm_code(fund_code)] = t
        else:
            self.sell_fee_tiers = t

    def set_sell_tiers_map(self, mapping: Dict[str, List[Tuple[int, float]]]) -> int:
        """批量写入 per-fund 阶梯。返回写入条数。"""
        n = 0
        for code, tiers in (mapping or {}).items():
            if not tiers:
                continue
            try:
                self.sell_tiers_by_code[_norm_code(code)] = sorted(
                    ((float(d), float(r)) for d, r in tiers), key=lambda x: x[0])
                n += 1
            except Exception:
                continue
        return n

    def get_buy_fee(self, gross_amount: float,
                    fund_code: Optional[str] = None) -> float:
        if self.is_fee_free(fund_code):
            return 0.0
        return gross_amount * self.buy_fee_rate

    def tiers_of(self, fund_code: Optional[str] = None) -> List[Tuple[int, float]]:
        c = _norm_code(fund_code)
        return self.sell_tiers_by_code.get(c) or self.sell_fee_tiers

    def get_sell_fee_rate(self, holding_natural_days: int,
                          fund_code: Optional[str] = None) -> float:
        """按持有自然日匹配费率阶梯。fund_code 缺省时按普通基金处理。"""
        if self.is_fee_free(fund_code):
            return 0.0
        for days_threshold, rate in self.tiers_of(fund_code):
            if holding_natural_days < days_threshold:
                return rate
        return 0.0
