# -*- coding: utf-8 -*-
"""场外持仓的「继续持有 / 立即卖出」决策模块。

赎回费随持有自然日阶梯下降（见 OTCFeeModel），故"要不要为省手续费多拿几天"
是个可判定问题。完整设计说明见 docs/设计说明-持仓与准入.md。

⚠️ 三条硬约束（改动前务必理解）：
   1. `decide_hold_or_sell()` 是纯函数，无循环/递归/重试，输入同则输出同。
   2. `HoldPolicyState.open_date` 只在**实际成交时**写入，决策绝不重置它，
      否则 held_days 不再单调，"逐日判断满 7 天"会退化成永远差一天的死循环。
   3. 同一交易日只决策一次；卖出但下单失败则进冷却期，避免当日反复触发。
⚠️ 沉没成本（当前浮亏）默认不进判据，λ(loss_aversion)=0。
   真正的判据是边际比较：继续持有的增量收益 + 省下的赎回费 vs 现在卖出的机会成本。
"""
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Callable, Dict, List, Optional, Tuple


def _as_date(x) -> Optional[date]:
    """把 date / datetime / pd.Timestamp / ISO 字符串统一成 date。

    【踩过的坑】pandas.Timestamp 是 datetime 的子类，`isinstance(ts, date)` 为真，
    于是它会被当成 date 直接参与 `date - Timestamp` 运算 → TypeError。
    回测里 PositionLot.confirm_date 正是 Timestamp，所以必须在这里显式归一化，
    且必须先判 datetime 再判 date。
    """
    if x is None:
        return None
    if isinstance(x, datetime):        # 含 pd.Timestamp（先于 date 判断）
        return x.date()
    if isinstance(x, date):
        return x
    try:
        return datetime.fromisoformat(str(x)[:19]).date()
    except Exception:
        return None


@dataclass
class HoldDecision:
    """一次持有/卖出决策的结果（含可解释的分量，便于前端与复盘展示）。"""

    action: str                 # "HOLD" | "SELL"
    reason: str
    asof: Optional[date] = None
    held_days: int = 0
    detail: Dict[str, float] = field(default_factory=dict)

    def as_dict(self) -> Dict:
        d = {
            "action": self.action, "reason": self.reason, "held_days": self.held_days,
            "asof": self.asof.isoformat() if self.asof else None,
        }
        d.update({k: (round(v, 6) if isinstance(v, float) else v) for k, v in self.detail.items()})
        return d


def next_tier_days(held_days: int, tiers: List[Tuple[int, float]]) -> Optional[int]:
    """距离下一个更优惠费率档还差多少天（已经是最优档返回 None）。

    tiers 形如 [(7, 0.015), (30, 0.0075), (180, 0.005), (inf, 0.0)]。
    这是"省手续费"视角下最自然的持有期，比写死 7 天更合理。

    注意末档常用 float('inf') 表示"无上限"，必须跳过（int(inf) 会 OverflowError）。
    """
    for threshold, _rate in sorted(tiers, key=lambda x: x[0]):
        if threshold == float("inf") or threshold is None:
            continue
        if held_days < threshold:
            return int(threshold) - held_days
    return None


def decide_hold_or_sell(
    *,
    held_days: int,
    expected_forward_return: float,
    fee_model,
    horizon_days: Optional[int] = None,
    loss_pct: float = 0.0,
    loss_aversion: float = 0.0,
    safety_margin: float = 0.0,
    asof: Optional[date] = None,
    fee_now: Optional[float] = None,
    fee_later: Optional[float] = None,
) -> HoldDecision:
    """纯函数：给定持有天数与预期收益，判断继续持有还是立刻卖出。

    参数
    ----
    held_days: 已持有自然日（必须来自真实成交日，见模块 docstring 约束 2）
    expected_forward_return: 未来 horizon_days 的预期收益（小数，0.01 = 1%）
    fee_model: 需实现 get_sell_fee_rate(自然日) -> 费率；以及 sell_fee_tiers 属性
    horizon_days: 持有期长度；缺省 = 距下一个更优惠费率档所需天数（已最优档则用 30 天）
    loss_pct: 当前浮亏（负数表示亏损），仅当 loss_aversion > 0 时才影响结果
    loss_aversion: 浮亏计入持有成本的系数 λ，默认 0（沉没成本不进决策）
    safety_margin: 额外的保守边际（如 0.002 表示要求多 0.2% 的安全垫）
    fee_now / fee_later: 直接给定费率（用于 FIFO 批次加权，见 blended_redeem_fee_rate）；
                        缺省则按 held_days 与阶梯自行推算
    """
    tiers = getattr(fee_model, "sell_fee_tiers", None) or []
    if horizon_days is None:
        nt = next_tier_days(held_days, tiers)
        horizon_days = nt if nt else 30

    if fee_now is None:
        fee_now = float(fee_model.get_sell_fee_rate(held_days))
    if fee_later is None:
        fee_later = float(fee_model.get_sell_fee_rate(held_days + horizon_days))
    fee_now = float(fee_now)
    fee_later = float(fee_later)
    fee_saved = fee_now - fee_later                      # 继续持有能省下的赎回费（≥0）

    # 边际收益：预期收益 + 省下的费用 - (可选)浮亏惩罚 - 安全垫
    loss_term = abs(min(0.0, float(loss_pct))) * float(loss_aversion)
    marginal = float(expected_forward_return) + fee_saved - loss_term - float(safety_margin)

    detail = {
        "fee_now": round(fee_now, 6),
        "fee_later": round(fee_later, 6),
        "fee_saved": round(fee_saved, 6),
        "horizon_days": int(horizon_days),
        "expected_forward_return": round(float(expected_forward_return), 6),
        "loss_term": round(loss_term, 6),
        "safety_margin": round(float(safety_margin), 6),
        "marginal": round(marginal, 6),
    }
    if marginal > 0:
        why = ("继续持有更优：预期收益 %.4f%% + 省下赎回费 %.4f%% > 边际成本 %.4f%%"
               % (float(expected_forward_return) * 100, fee_saved * 100,
                  (loss_term + float(safety_margin)) * 100))
        return HoldDecision("HOLD", why, asof, held_days, detail)
    why = ("立即卖出更优：继续持有的边际收益 %.4f%% ≤ 0（省下的费 %.4f%% 不足以覆盖）"
           % (marginal * 100, fee_saved * 100))
    return HoldDecision("SELL", why, asof, held_days, detail)


def blended_redeem_fee_rate(
    lots: List[Tuple[float, date]],
    asof: date,
    fee_model,
    extra_days: int = 0,
    fund_code: Optional[str] = None,
) -> float:
    """按 FIFO 批次算「赎回全部份额」的加权平均费率。

    场外赎回费是**逐笔（按先进先出）**按各笔自己的持有自然日计费的，
    所以一笔"持有 200 天 + 3 天"的持仓，卖出时并不是全按 200 天免赎回费 ——
    新买那部分仍要吃 1.5%。用单一 held_days 会低估费用，这里如实按批次加权。

    fund_code: 传给费用模型用于识别免申赎费标的（货币基金）。
               缺省 None → 按普通基金阶梯，与旧行为一致。

    lots: [(shares, confirm_date), ...]（shares 为份额，confirm_date 为确认日）
    extra_days: 假设再过这么多天再卖（用于估算"继续持有后的费用"）
    """
    asof_d = _as_date(asof)
    total = 0.0
    weighted = 0.0
    for shares, confirm in lots:
        try:
            sh = float(shares)
        except (TypeError, ValueError):
            continue
        if sh <= 0:
            continue
        d = _as_date(confirm)
        age = max(0, (asof_d - d).days) if (d and asof_d) else 0
        rate = float(fee_model.get_sell_fee_rate(age + int(extra_days), fund_code))
        total += sh
        weighted += sh * rate
    return (weighted / total) if total > 0 else 0.0


def decide_hold_or_sell_for_lots(
    *,
    lots: List[Tuple[float, date]],
    asof: date,
    expected_forward_return_fn: Callable[[int, int], float],
    fee_model,
    loss_pct: float = 0.0,
    loss_aversion: float = 0.0,
    safety_margin: float = 0.0,
    horizon_days: Optional[int] = None,
) -> HoldDecision:
    """FIFO 批次版决策：费用按各批次真实持有天数加权，其余判据同 decide_hold_or_sell。"""
    oldest = min((d for d in (_as_date(c) for _s, c in lots) if d), default=_as_date(asof))
    held = max(0, (_as_date(asof) - oldest).days) if oldest else 0
    tiers = getattr(fee_model, "sell_fee_tiers", None) or []
    if horizon_days is None:
        nt = next_tier_days(held, tiers)
        horizon_days = nt if nt else 30
    fee_now = blended_redeem_fee_rate(lots, asof, fee_model, extra_days=0)
    fee_later = blended_redeem_fee_rate(lots, asof, fee_model, extra_days=horizon_days)
    exp_ret = float(expected_forward_return_fn(held, horizon_days))
    return decide_hold_or_sell(held_days=held, expected_forward_return=exp_ret,
                               fee_model=fee_model, horizon_days=horizon_days,
                               loss_pct=loss_pct, loss_aversion=loss_aversion,
                               safety_margin=safety_margin, asof=asof,
                               fee_now=fee_now, fee_later=fee_later)


# ---------------------------------------------------------------------------
# 灵活的「继续持有 / 卖出」判据（用户口径 2026-09-26）
#
# 原设计里 `min_hold_days = 90` 是个**死的日历阈值**：不到 90 天不卖、到了就卖。
# 两个方向的错都会犯：
#   * 死扛手续费 —— 明明还在跌，为了省 0.5% 赎回费继续持有，亏得更多；
#   * 一有风险就赎回 —— 每次波动都交一次钱，费用把收益吃光。
#
# 正确判据是**边际比较**：
#     继续持有的预期亏损  >  已有浮亏 × λ + 赎回费率 + 安全垫   →  卖出
# 三项都是"卖出要付的代价"，只有预期亏损足够大才值得付；λ 与安全垫可调，
# λ 越大越"不愿割肉"，安全垫越大越"不轻易动手"。
# ---------------------------------------------------------------------------


def expected_forward_loss(returns, horizon_days: int, lookback: int = 60):
    """预期继续持有的亏损（正数 = 预期亏损；无法估计返回 None）。

    用近 `lookback` 个交易日的日均收益线性外推 `horizon_days` 天，只取亏损侧
    —— 上涨的情形不构成"卖出的理由"。这是刻意保守的估计：不预测拐点，
    只问"照最近这个势头拿下去，大概还要亏多少"。
    """
    try:
        seq = [float(x) for x in list(returns)[-int(lookback):] if x is not None]
    except Exception:
        return None
    seq = [x for x in seq if x == x]          # 去掉 NaN
    if len(seq) < 10 or int(horizon_days) <= 0:
        return None
    mu = sum(seq) / float(len(seq))
    return max(0.0, -mu * float(horizon_days))


def should_sell_for_loss(*, now_loss_pct: float, fee_rate: float,
                         expected_fwd_loss, loss_aversion: float = 1.0,
                         safety_margin: float = 0.002) -> bool:
    """是否应当卖出。

    now_loss_pct    : 当前浮亏（小数，负数 = 亏损）
    fee_rate        : 现在卖出要付的赎回费率（FIFO 批次加权后的小数）
    expected_fwd_loss: 继续持有到下一个更优费率档的预期亏损（None = 无法估计）
    loss_aversion   : 已有亏损计入"卖出代价"的系数 λ（0 = 纯沉没成本，不管）
    safety_margin   : 额外安全垫，避免"一有风吹草动就赎回"

    ⚠️ 无法估计预期亏损时返回 True（遵从模型的调仓指令），不做无根据的拖延。
    """
    if expected_fwd_loss is None:
        return True
    held_loss = abs(min(0.0, float(now_loss_pct or 0.0)))
    cost_sell = (float(fee_rate or 0.0)
                 + held_loss * float(loss_aversion)
                 + float(safety_margin))
    return float(expected_fwd_loss) > cost_sell


class HoldPolicyState:
    """单只持仓的决策状态机：保证幂等、冷却、以及持有期单调递增。

    生命周期（只有真实成交才会改状态）：
        on_open(成交日)  ->  open_date = 成交日，计数清零
        decide(asof)     ->  纯查/纯算，不改 open_date
        on_sell_failed() ->  进入冷却，冷却期内不再评估
        on_close()       ->  清空状态
    """

    def __init__(self, code: str, cooldown_days: int = 7, max_evaluations: int = 400):
        self.code = code
        self.cooldown_days = int(cooldown_days)
        self.max_evaluations = int(max_evaluations)
        self.open_date: Optional[date] = None
        self.last_decision_date: Optional[date] = None
        self.cooldown_until: Optional[date] = None
        self.evaluate_count = 0
        self._cached: Optional[HoldDecision] = None

    # ---------- 真实成交才会调用的钩子 ----------
    def on_open(self, asof: date) -> None:
        self.open_date = asof
        self.last_decision_date = None
        self.cooldown_until = None
        self.evaluate_count = 0
        self._cached = None

    def on_close(self) -> None:
        self.open_date = None
        self.last_decision_date = None
        self.cooldown_until = None
        self._cached = None
        self.evaluate_count = 0

    def on_sell_failed(self, asof: date) -> None:
        """卖出未成交（如暂停赎回）-> 冷却，避免同一天/连续几天反复触发。"""
        self.cooldown_until = asof + timedelta(days=self.cooldown_days)

    # ---------- 查询 ----------
    def held_days(self, asof: date) -> int:
        if self.open_date is None:
            return 0
        return max(0, (asof - self.open_date).days)

    def decide(
        self,
        asof: date,
        expected_forward_return_fn: Callable[[int, int], float],
        fee_model,
        **kwargs,
    ) -> Optional[HoldDecision]:
        """决策入口。

        expected_forward_return_fn(held_days, horizon_days) -> 预期收益（小数）。
        幂等：同一 asof 重复调用直接返回缓存；冷却期内返回 None（表示"本次不评估"）。
        """
        if self.open_date is None:
            return None
        if self.cooldown_until is not None and asof < self.cooldown_until:
            return None                                   # 冷却中，不评估（防抖）
        if self.last_decision_date == asof and self._cached is not None:
            return self._cached                           # 幂等：同日只算一次

        # 结构上防死循环：一旦被异常地反复评估，直接报错而不是静默循环
        self.evaluate_count += 1
        if self.evaluate_count > self.max_evaluations:
            raise RuntimeError(
                f"{self.code} 决策次数异常({self.evaluate_count})，疑似滚动循环，请检查调用方")

        held = self.held_days(asof)                       # 只由 open_date 推算，单调递增
        tiers = getattr(fee_model, "sell_fee_tiers", None) or []
        horizon = kwargs.pop("horizon_days", None)
        if horizon is None:
            nt = next_tier_days(held, tiers)
            horizon = nt if nt else 30
        exp_ret = float(expected_forward_return_fn(held, horizon))
        dec = decide_hold_or_sell(held_days=held, expected_forward_return=exp_ret,
                                  fee_model=fee_model, horizon_days=horizon,
                                  asof=asof, **kwargs)
        self.last_decision_date = asof
        self._cached = dec
        if dec.action == "SELL":
            # 注意：这里**不**改 open_date —— 决策不重置持有期，否则就是死循环的源头
            pass
        return dec
