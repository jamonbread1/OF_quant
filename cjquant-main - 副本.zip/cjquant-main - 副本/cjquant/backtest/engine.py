import pandas as pd
import uuid
import logging
from datetime import datetime
from typing import Dict, List
from .model import Order, TradeRecord
from .portfolio import TransitCashAccount, FundPosition
from .fee import OTCFeeModel
from .slippage import BaseSlippage, ZeroSlippage
from .exceptions import InsufficientPositionError

class OTCBacktestEngine:
    def __init__(self, 
                 market_data: pd.DataFrame, 
                 initial_cash: float = 1e7,
                 t_plus_confirm: int = 1, # T+1确认净值
                 t_plus_settle: int = 3,  # 赎回T+3到账
                 slippage_model: BaseSlippage = None,
                 trade_start=None):
        
        self.market_data = market_data.copy()
        all_dates = list(self.market_data.index.unique().sort_values())
        if trade_start is not None:
            # 预热期支持：market_data 里保留更早的数据供策略取历史算因子，
            # 但下单/计净值/业绩统计只从 trade_start 开始（回测窗口与策略预热解耦）。
            ts = pd.to_datetime(trade_start)
            all_dates = [d for d in all_dates if d >= ts]
            if not all_dates:
                raise ValueError(f"trade_start({trade_start}) 晚于全部市场数据日期，无可用交易日")
        self.trading_dates = all_dates
        
        # 预建 NAV 快查表（含前向填充，解决节假日/数据缺口时市值归零问题）
        self._nav_cache: dict = {}  # {(date, fund_code): adj_nav}
        # F-3：记录每只基金最后有效净值日。清盘/停更基金若被 ffill 到回测结束，
        # 持仓市值会被永久冻结（清盘损失永不兑现）。ffill 只对**序列中间**的
        # 缺口有效；末值之后必须置 None，由 _record_daily_stats 触发强制赎回。
        self._nav_last_valid: dict = {}  # {fund_code: last_valid_date}
        for code in self.market_data['fund_code'].unique():
            fund_df = self.market_data[self.market_data['fund_code'] == code]['adj_nav']
            valid = fund_df[fund_df.notna()]
            if len(valid):
                self._nav_last_valid[code] = valid.index.max()
            # 对交易日历进行前向填充：缺失的交易日用上一个有效净值代替
            fund_series = fund_df.reindex(self.trading_dates, method='ffill')
            last_ok = self._nav_last_valid.get(code)
            for date, nav_val in fund_series.items():
                if pd.notna(nav_val) and (last_ok is None or date <= last_ok):
                    self._nav_cache[(date, code)] = float(nav_val)

        # F-5：交易日历的 O(1) 索引表。self.trading_dates.index() 是 O(n) 列表
        # 查找，且在 step() 的订单循环里逐单调用 → O(n²)；长回测的主要瓶颈。
        self._date_idx: dict = {d: i for i, d in enumerate(self.trading_dates)}
        
        self.cash_account = TransitCashAccount(initial_cash)
        self.positions: Dict[str, FundPosition] = {}
        self.fee_model = OTCFeeModel()
        self.slippage = slippage_model or ZeroSlippage()
        
        self.t_plus_confirm = t_plus_confirm
        self.t_plus_settle = t_plus_settle
        
        self.pending_orders: List[Order] = []
        self.trade_history: List[TradeRecord] = []
        self.daily_stats: List[dict] = []
        # F-4：本 bar 累计的外部净现金流（定投/投资者出入金），由 record_cash_flow 登记
        self._ext_cash_flow = 0.0
        # 全量归因用：每日持仓市值分布 {date: {code: mv}}。复盘"跌是谁带来的、
        # 赚是谁贡献的"必须有逐日逐标的的市值序列，只靠 total_assets 做不到。
        self.holdings_daily: List[dict] = []
        
        self.current_date_idx = 0
        self.logger = logging.getLogger("OTC_Engine")

    @property
    def current_date(self) -> datetime:
        return self.trading_dates[self.current_date_idx]

    def _get_nav(self, fund_code: str, date) -> float:
        """从预建缓存中查询复权净值（含前向填充，不会因节假日返回 None）"""
        return self._nav_cache.get((date, fund_code), None)

    def _get_future_trading_date(self, start_date_idx: int, t_plus_days: int) -> datetime:
        """按照交易日历向后推算 (自动跳过节假日)"""
        target_idx = start_date_idx + t_plus_days
        if target_idx >= len(self.trading_dates):
            # 越界处理，返回最后一个可用日期
            return self.trading_dates[-1]
        return self.trading_dates[target_idx]

    def submit_order(self, fund_code: str, direction: str, value: float = 0, shares: float = 0):
        # F-6：末根 bar 下单时，确认日会越界（旧实现返回最后日期 → T+1 退化成
        # T+0、当天立即确认，成交价用的还是当天的净值）。显式拒绝而不是静默退化。
        if self.current_date_idx + self.t_plus_confirm >= len(self.trading_dates):
            self.logger.warning(
                f"[{self.current_date}] 拒绝 {direction} {fund_code}：距回测结束不足 "
                f"T+{self.t_plus_confirm} 个交易日，确认日越界（拒绝优于 T+1 退化成 T+0）")
            return None

        if direction == 'BUY':
            self.cash_account.lock_cash(value) # 提交时立即冻结资金
        elif direction == 'SELL':
            if fund_code not in self.positions:
                raise InsufficientPositionError(f"无持仓: {fund_code}")
            pos = self.positions[fund_code]
            if pos.total_available_shares < shares:
                raise InsufficientPositionError(f"可用份额不足. 可用:{pos.total_available_shares}, 需求:{shares}")
            pos.frozen_shares += shares

        order = Order(
            order_id=uuid.uuid4().hex[:8],
            submit_date=self.current_date,
            fund_code=fund_code,
            direction=direction,
            order_value=value,
            order_shares=shares
        )
        self.pending_orders.append(order)
        return order

    def step(self):
        today = self.current_date
        
        # 1. 资金到账处理
        self.cash_account.process_daily_arrival(today)
        
        # 2. 撮合确认队列中的订单
        unprocessed_orders = []
        for order in self.pending_orders:
            # F-5：字典 O(1) 查找，替代 O(n) 的 list.index（step 循环内 → 曾是 O(n²)）
            submit_idx = self._date_idx.get(order.submit_date)
            if submit_idx is None:
                self.logger.warning(f"订单提交日 {order.submit_date} 不在交易日历中，作废")
                continue
            confirm_date = self._get_future_trading_date(submit_idx, self.t_plus_confirm)

            # 如果今天就是确认日
            if today == confirm_date:
                self._execute_order(order, confirm_date)
            else:
                unprocessed_orders.append(order)

        self.pending_orders = unprocessed_orders

        # 2.5 F-3：清盘/停更基金的强制赎回兜底。持仓基金的最后有效净值日已过
        # （说明净值序列结束，ffill 不再覆盖），若继续持有，市值会被记为 0 或
        # 被旧缓存冻结 —— 前者损失"凭空蒸发"（不真实），后者清盘损失永不兑现。
        # 处理：按最后有效净值全额清算，资金走正常 T+n 到账与阶梯赎回费。
        for code in list(self.positions.keys()):
            if not self.positions[code].total_shares:
                continue
            last_ok = self._nav_last_valid.get(code)
            if last_ok is not None and today > last_ok and self._date_idx.get(today, 0) > 0:
                self._force_redeem_delisted(code, last_ok)
        
        # 3. 每日结算
        self._record_daily_stats()
        
        # 时间推移
        self.current_date_idx += 1

    def _execute_order(self, order: Order, confirm_date: datetime):
        nav = self._get_nav(order.fund_code, confirm_date)
        if nav is None:
            self.logger.warning(f"基金 {order.fund_code} 在 {confirm_date} 无净值数据，订单作废")
            order.status = 'REJECTED'
            if order.direction == 'BUY':
                self.cash_account.available_cash += order.order_value
                self.cash_account.frozen_cash -= order.order_value
            elif order.direction == 'SELL':
                if order.fund_code in self.positions:
                    self.positions[order.fund_code].frozen_shares -= order.order_shares
            return

        if order.fund_code not in self.positions:
            self.positions[order.fund_code] = FundPosition(order.fund_code, self.fee_model)
        
        pos = self.positions[order.fund_code]

        if order.direction == 'BUY':
            # 计入冲击成本
            exec_nav = self.slippage.get_impact_nav(nav, order.order_value, 'BUY')
            fee = self.fee_model.get_buy_fee(order.order_value, order.fund_code)
            net_cash = order.order_value - fee
            shares_bought = net_cash / exec_nav
            
            self.cash_account.frozen_cash -= order.order_value
            pos.add_lot(confirm_date, shares_bought, exec_nav)
            
            settle_date = confirm_date # 买入当即确认份额
            trade = TradeRecord(uuid.uuid4().hex[:8], order.order_id, order.fund_code, 'BUY', 
                                order.submit_date, confirm_date, settle_date, exec_nav, 
                                shares_bought, order.order_value, fee, order.order_value)
                                
        elif order.direction == 'SELL':
            # 基于 FIFO 结算惩罚性手续费
            exec_nav = self.slippage.get_impact_nav(nav, order.order_shares * nav, 'SELL')
            gross_val, fee, net_val = pos.process_sell(confirm_date, order.order_shares, exec_nav)

            # 计算 T+n 的赎回到账日（F-5：字典查找）
            submit_idx = self._date_idx.get(order.submit_date, 0)
            settle_date = self._get_future_trading_date(submit_idx, self.t_plus_settle)
            
            # 资金扔进黑洞队列
            self.cash_account.add_to_transit(net_val, settle_date)
            
            trade = TradeRecord(uuid.uuid4().hex[:8], order.order_id, order.fund_code, 'SELL', 
                                order.submit_date, confirm_date, settle_date, exec_nav, 
                                order.order_shares, gross_val, fee, net_val)

        order.status = 'CONFIRMED'
        self.trade_history.append(trade)

    def _force_redeem_delisted(self, fund_code: str, last_valid_date):
        """F-3：清盘/停更基金的强制赎回。

        说明书 §10.2 与 README 都声称"清盘强制赎回"，但引擎层此前没有兜底——
        净值序列结束后持仓市值被 ffill 冻结（损失永不兑现）或记 0（凭空蒸发）。
        正确语义：按**最后有效净值**全额清算，走正常 FIFO 阶梯赎回费与 T+n 到账，
        让损失真实地进入权益曲线。

        只触发一次：清算后 total_shares=0，不会再进这个分支。
        """
        pos = self.positions[fund_code]
        nav = self._get_nav(fund_code, last_valid_date)
        if nav is None or pos.total_shares <= 0:
            return
        today = self.current_date
        exec_nav = self.slippage.get_impact_nav(nav, pos.total_shares * nav, 'SELL')
        gross_val, fee, net_val = pos.process_sell(today, pos.total_shares, exec_nav)
        submit_idx = self._date_idx.get(today, 0)
        settle_date = self._get_future_trading_date(submit_idx, self.t_plus_settle)
        self.cash_account.add_to_transit(net_val, settle_date)
        self.trade_history.append(TradeRecord(
            uuid.uuid4().hex[:8], "FORCE_REDEEM", fund_code, 'SELL',
            today, today, settle_date, exec_nav, pos.total_shares,
            gross_val, fee, net_val))
        self.logger.warning(
            f"[{today}] {fund_code} 净值序列止于 {last_valid_date}（清盘/停更），"
            f"已按最后净值 {nav:.4f} 强制赎回：变现 {net_val:,.2f}（费 {fee:,.2f}）")

    def record_cash_flow(self, value: float, date=None):
        """F-4：登记每 bar 的**净外部现金流**（定投为正、赎回到投资者手里为负）。

        ⚠️ 这是给 TWR 用的（risk.twr_returns）：内部申赎（策略的买/卖）**不算**
        外部现金流，只有账户与投资者之间的资金进出才算。引擎不解释语义，
        只负责把调用方给的数落进 daily_stats['cash_flow']，供上层算 TWR。
        """
        self._ext_cash_flow += float(value)

    def _record_daily_stats(self):
        """计算每日 FOF 资产总值"""
        total_market_value = 0.0
        today = self.current_date

        for code, pos in self.positions.items():
            nav = self._get_nav(code, today)
            if nav is not None:
                total_market_value += pos.total_shares * nav

        # 包含 transit 中的资金，因为这是属于投资者的钱，只是在途
        transit_value = sum(self.cash_account.transit_queue.values())
        total_assets = self.cash_account.available_cash + self.cash_account.frozen_cash + transit_value + total_market_value

        self.daily_stats.append({
            'date': today,
            'available_cash': self.cash_account.available_cash,
            'frozen_cash': self.cash_account.frozen_cash,
            'transit_cash': transit_value,
            'market_value': total_market_value,
            'total_assets': total_assets,
            # F-4：本 bar 的净外部现金流（见 record_cash_flow）。回测无定投时恒 0，
            # 上线有定投时 nonzero → 上层用 risk.twr_returns 算真实 TWR。
            'cash_flow': self._ext_cash_flow,
        })
        self._ext_cash_flow = 0.0

        # 全量归因：逐日持仓市值分布（含清零的已清盘标的，便于看到"某天突然没了"）
        hold_row = {'date': today}
        for code, pos in self.positions.items():
            if pos.total_shares <= 0:
                continue
            nav = self._get_nav(code, today)
            if nav is not None:
                hold_row[code] = round(pos.total_shares * nav, 4)
        self.holdings_daily.append(hold_row)

    def run_all(self):
        """执行完整回测"""
        while self.current_date_idx < len(self.trading_dates):
            # 这里可以接入你的策略逻辑 (例如月底调仓)
            # strategy.on_bar(self.current_date) 
            self.step()

    def export_trades_csv(self, file_path: str):
        if not self.trade_history:
            self.logger.warning("没有产生任何交易，跳过导出")
            return
        df = pd.DataFrame([vars(t) for t in self.trade_history])
        for col in ['submit_date', 'confirm_date', 'settle_date']:
            df[col] = df[col].dt.strftime('%Y-%m-%d')
        df.to_csv(file_path, index=False, encoding='utf-8-sig')

    def export_results_csv(self, file_path: str):
        if not self.daily_stats:
            return
        df = pd.DataFrame(self.daily_stats)
        df.set_index('date', inplace=True)
        # 顺便计算每日收益率
        df['daily_return'] = df['total_assets'].pct_change().fillna(0)
        df.to_csv(file_path, encoding='utf-8-sig')