import numpy as np
import pandas as pd
from scipy.optimize import minimize
from .base import BaseOptimizer
from .utils import calculate_shrunk_covariance

class RiskParityOptimizer(BaseOptimizer):
    def __init__(self, returns: pd.DataFrame):
        super().__init__(returns)
        self.cov = calculate_shrunk_covariance(returns)
        # 数值尺度修正（2026-09-18）。
        # 风险平价的目标量纲是「风险贡献偏离均值的平方」，日频协方差下大约 1e-5 ~ 1e-8，
        # 而 SLSQP 默认 ftol=1e-6 —— 比目标本身还大，于是求解器在第 1 次迭代就判定
        # "已收敛"，原样返回初始等权值。表现为：不论输入什么数据，风险平价都输出 1/N
        # （实测 2 只 σ=20%/10% 得 50/50，理论应为 20/80）。
        # 这里用一个只依赖数据、不依赖权重的正常数缩放目标函数：
        # 正数常数缩放不改变最优点，只把数值抬到求解器能分辨的量级。
        _diag_sum = float(np.sum(np.diag(np.asarray(self.cov, dtype=float))))
        self._scale = (_diag_sum ** 2) if _diag_sum > 0 else 1.0

    def _risk_contribution(self, w, cov):
        """各资产的风险贡献 RC_i = w_i * (Σw)_i / σ_p（σ_p = 组合波动）。"""
        wv = np.asarray(w, dtype=float).ravel()
        c = np.asarray(cov, dtype=float)
        var = float(wv @ c @ wv)
        if not np.isfinite(var) or var <= 0:
            return np.zeros_like(wv)
        sigma = np.sqrt(var)
        mrc = (c @ wv) / sigma        # 边际风险贡献 (MRC)
        return mrc * wv               # 风险贡献 (RC)

    def _objective(self, w, cov):
        rc = self._risk_contribution(w, cov)
        num_assets = len(rc)
        target_rc = np.sum(rc) / num_assets
        risk_diffs = np.sum(np.square(rc - target_rc))
        # 归一化到与数据量纲无关的尺度，否则会被 SLSQP 的默认 ftol 直接吞掉
        return float(risk_diffs / self._scale)

    def optimize(self, constraints: list = None) -> pd.Series:
        initial_w = np.array([1.0 / self.num_assets] * self.num_assets)
        bounds = [(0, 1) for _ in range(self.num_assets)]
        
        cons = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1.0})
        
        res = minimize(
            self._objective, 
            initial_w, 
            args=(self.cov.values,),
            method='SLSQP',
            constraints=cons,
            bounds=bounds,
            # SLSQP 只认 ftol，写 tol 会被忽略（原来一直报 OptimizeWarning 并被吞掉）
            options={'ftol': 1e-12, 'maxiter': 500}
        )
        
        out = self._validate_weights(res.x)
        # 求解失败时不要静默返回等权值冒充风险平价
        if not getattr(res, "success", True):
            import logging
            logging.getLogger(__name__).warning(
                f"风险平价求解未收敛（{getattr(res, 'message', '')}），返回当前最优近似解")
        return out

class MeanVarianceOptimizer(BaseOptimizer):
    def __init__(self, returns: pd.DataFrame, risk_free_rate: float = 0.02):
        super().__init__(returns)
        self.cov = calculate_shrunk_covariance(returns)
        self.exp_rets = returns.mean() * 252
        self.rf = risk_free_rate

    def _objective(self, w):
        port_ret = np.sum(self.exp_rets * w)
        port_vol = np.sqrt(np.dot(w.T, np.dot(self.cov * 252, w)))
        sharpe = (port_ret - self.rf) / port_vol
        return -sharpe # 最小化负夏普

    def optimize(self) -> pd.Series:
        cons = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1.0})
        bounds = [(0, 1) for _ in range(self.num_assets)]
        res = minimize(self._objective, [1./self.num_assets]*self.num_assets, 
                       method='SLSQP', bounds=bounds, constraints=cons)
        return self._validate_weights(res.x)