# -*- coding: utf-8 -*-
"""五层漏斗 FOF 选基算子库（对应《场外基金量化选基策略算法说明书》v1.0）。

模块与手册的对应关系：
    filters.py    L2 准入 H1~H8（含"未校验"标记）
    style.py      L3-D4 风格因子指数 + RBSA（§3.3）
    factors.py    L3 因子六大维度（§3）+ 持仓穿透（§3.4）+ L4 预处理（§4）
    pool.py       L4 打分 / 分档 / 缓冲带 / 去冗余（§6）
    portfolio.py  L5-A 分数加权 / 约束截断 / 风险平价 / 波动率控仓 / 换手约束（§7、§9）
    risk.py       L5-B 均线定投 / 趋势开关 / 止盈止损 / 崩溃空仓（§8）
    preprocess.py §5 的 IC 检验、ICIR 权重与门槛判定（默认走等权 Baseline）
    pipeline.py   端到端编排 `run_funnel` —— 回测插件与定时任务**共用这一份**

**数据诚实原则**（本项目最在意的一条）
---------------------------------
任何算子所需的数据若本机取不到（例如基金经理任期、机构持有比例、基准行业权重），
一律置 NaN 或记入 `unverified`，**不填 0、不猜值、不假装通过**。
`run_funnel` 的返回里永远带一份"本次哪些规则没生效"的清单。
"""
from .filters import (FilterConfig, FilterResult, FundFacts, hard_filters,    # noqa: F401
                      LAG_QUARTER_DAYS, LAG_HALF_YEAR_DAYS, LAG_YEAR_DAYS)
from .style import (STYLE_INDEXES, STYLE_ORDER, STYLE_VECTOR_BY_TYPE,         # noqa: F401
                    BENCHMARK_SYMBOLS, load_index_prices, load_style_prices,
                    load_benchmark_prices, load_style_returns,
                    load_benchmark_returns, solve_style_exposure, style_r2,
                    style_drift, style_consistency, style_match)
from .factors import (FACTOR_DIM, HIGHER_IS_BETTER, INTERVAL_FACTORS,         # noqa: F401
                      DIM_WEIGHTS, MOM_BLEND_WEIGHTS, FundData,
                      compute_factor_table, add_cross_sectional,
                      blend_momentum_cross_section, fill_missing,
                      map_interval_factors, build_style_exog,
                      preprocess_factors, winsorize_mad, standardize,
                      neutralize, symmetric_orthogonalize, interval_score,
                      direction_unify, implied_turnover, top10_weights,
                      consensus_exposure, build_consensus, momentum_12_3,
                      momentum_windows, momentum_blend, reversal_1m,
                      residual_momentum, size_shock, industry_hhi,
                      capture_ratio, capture_updown)
from .pool import (PoolParams, PENALTY_TABLE, LAMBDA_HARD, LAMBDA_CAP,       # noqa: F401
                   HARD_BLACK_FLAGS, CORE_EXCLUDE_FLAGS, NON_SCORING,
                   penalty_to_lambda, flag_lambdas,
                   two_level_score, apply_penalty, rank_pct, assign_tiers,
                   build_pool, greedy_decorrelate, decorrelate_with_refill,
                   pool_avg_corr)
from .portfolio import (softmax_weights, apply_caps, apply_bounds,            # noqa: F401
                        marginal_risk_contribution, risk_contributions,
                        risk_shares, erc_weights,
                        realized_vol, vol_target_leverage, turnover_of,
                        limit_turnover)
from .risk import (CrashState, ma_deviation, dca_multiplier, trend_switch,    # noqa: F401
                   trend_multiplier, drawdown_multiplier,
                   take_profit_multiplier, trailing_stop_hit, max_drawdown_of,
                   twr_returns, twr_index, twr_drawdown, twr_holding_return,
                   max_drawdown_of_twr, arbitrate_multipliers)
from .preprocess import (compute_ic, ic_stats, ic_weights,                    # noqa: F401
                         forward_returns, ic_available)
from .pipeline import (FunnelResult, SubpoolResult, SubpoolConfig, run_funnel,  # noqa: F401
                       classify_subpool, SUBPOOLS, SUBPOOL_NAMES, CLASS_ORDER)

__all__ = [
    "FilterConfig", "FilterResult", "FundFacts", "hard_filters",
    "LAG_QUARTER_DAYS", "LAG_HALF_YEAR_DAYS", "LAG_YEAR_DAYS",
    "STYLE_INDEXES", "STYLE_ORDER", "STYLE_VECTOR_BY_TYPE", "BENCHMARK_SYMBOLS",
    "load_index_prices", "load_style_prices", "load_benchmark_prices",
    "load_style_returns", "load_benchmark_returns",
    "solve_style_exposure", "style_r2", "style_drift", "style_consistency", "style_match",
    "FACTOR_DIM", "HIGHER_IS_BETTER", "INTERVAL_FACTORS", "DIM_WEIGHTS",
    "MOM_BLEND_WEIGHTS", "FundData", "compute_factor_table", "add_cross_sectional",
    "blend_momentum_cross_section", "fill_missing", "map_interval_factors",
    "build_style_exog", "preprocess_factors",
    "winsorize_mad", "standardize", "neutralize", "symmetric_orthogonalize",
    "interval_score", "direction_unify",
    "implied_turnover", "top10_weights", "consensus_exposure", "build_consensus",
    "momentum_12_3", "momentum_windows", "momentum_blend", "reversal_1m",
    "residual_momentum", "size_shock", "industry_hhi",
    "capture_ratio", "capture_updown",
    "PoolParams", "PENALTY_TABLE", "LAMBDA_HARD", "LAMBDA_CAP",
    "HARD_BLACK_FLAGS", "CORE_EXCLUDE_FLAGS", "NON_SCORING",
    "penalty_to_lambda", "flag_lambdas",
    "two_level_score", "apply_penalty",
    "rank_pct", "assign_tiers", "build_pool", "greedy_decorrelate",
    "decorrelate_with_refill", "pool_avg_corr",
    "softmax_weights", "apply_caps", "apply_bounds",
    "marginal_risk_contribution", "risk_contributions", "risk_shares",
    "erc_weights", "realized_vol", "vol_target_leverage",
    "turnover_of", "limit_turnover",
    "CrashState", "ma_deviation", "dca_multiplier", "trend_switch", "trend_multiplier",
    "drawdown_multiplier", "take_profit_multiplier", "trailing_stop_hit", "max_drawdown_of",
    "twr_returns", "twr_index", "twr_drawdown", "twr_holding_return",
    "max_drawdown_of_twr", "arbitrate_multipliers",
    "compute_ic", "ic_stats", "ic_weights", "forward_returns", "ic_available",
    "FunnelResult", "SubpoolResult", "SubpoolConfig", "run_funnel",
    "classify_subpool", "SUBPOOLS", "SUBPOOL_NAMES", "CLASS_ORDER",
]
