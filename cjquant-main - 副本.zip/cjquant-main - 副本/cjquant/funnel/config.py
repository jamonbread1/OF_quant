# -*- coding: utf-8 -*-
"""漏斗策略参数（对应说明书 §11 参数总表）。

默认值一律取说明书的建议值。标记为"高/极高"敏感度的参数走 walk-forward 优化，
其余**锁定不做优化**（§13.7：这是控制过拟合最有效的手段）。
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

# 报告披露滞后（自然日）——说明书 §1.3
LAG_QUARTER = 25
LAG_HALF_YEAR = 60
LAG_YEAR = 90


@dataclass
class FunnelConfig:
    # ---- L2 准入 ----
    age_min_years: float = 3.0
    tenure_min_days: int = 504          # 504 交易日 ≈ 2 年（H2；数据缺失时不拦截）
    aum_min_yi: float = 2.0
    aum_max_yi: float = 300.0
    liq_warn_yi: float = 0.5            # 连续 2 期低于此值 → 清盘预警
    liq_drop_ratio: float = -0.30       # 单期规模缩水超过 30% 且 <0.8 亿 → 预警
    tc_max_by_type: Dict[str, float] = field(default_factory=lambda: {
        "指数": 0.8, "股票": 1.8, "偏股": 1.8, "混合": 1.8,
        "灵活配置": 1.8, "偏债": 1.2, "债券": 0.7, "QDII": 1.8,
        "黄金": 0.7, "商品": 0.7,
    })
    tc_max_default: float = 1.8
    buy_fee_max: float = 0.015          # 折后申购费率上限 1.5%
    style_match_min: float = 0.60
    miss_rate_max: float = 0.01
    max_gap_days: int = 5
    jump_abs: float = 0.25

    # ---- L3 因子窗口（交易日）----
    L_S: int = 63
    L_M: int = 126
    L_L: int = 252
    L_XL: int = 756
    style_window: int = 756             # RBSA 回归窗口

    # ---- L4 预处理 ----
    mad_n: float = 5.0
    neutralize: bool = True             # 动量/持仓族必须中性化
    orthogonalize: bool = False         # 对称正交（可选，默认关）
    ic_lookback: int = 12               # IC 序列长度（期）

    # ---- L4 打分与池 ----
    dim_weights: Dict[str, float] = field(default_factory=lambda: {
        "D1": 0.28, "D2": 0.24, "D3": 0.16, "D4": 0.14, "D5": 0.12, "D6": 0.06,
    })
    ic_min: float = 0.02
    ic_t_min: float = 2.0
    ic_win_rate_min: float = 0.55
    theta_in: float = 0.90
    theta_keep: float = 0.70
    n_target: int = 25
    n_min: int = 18
    n_max: int = 35
    min_hold_days: int = 90
    rho_max: float = 0.90
    pool_corr_warn: float = 0.85

    # ---- L5-A 组合 ----
    w_max: float = 0.20
    w_min: float = 0.02
    mgr_cap: float = 0.30               # 单管理人上限
    style_cap: float = 0.40             # 单主导风格上限
    min_names: int = 8
    lambda_score: float = 2.0
    erc_iters: int = 200
    class_bounds: Dict[str, Tuple[float, float]] = field(default_factory=lambda: {
        "EQ": (0.30, 0.65), "BOND": (0.20, 0.50),
        "ALT": (0.05, 0.15), "QDII": (0.00, 0.20),
    })

    # ---- L5-B 风控 ----
    sigma_target: float = 0.11          # 多资产口径；纯权益池用 0.20~0.25
    l_min: float = 0.30
    l_max: float = 1.00
    ma_window: int = 120
    beta_dev: float = 2.5
    tp_ladder: List[Tuple[float, float]] = field(default_factory=lambda: [
        (0.25, 0.25), (0.50, 0.25), (0.80, 0.25),
    ])
    dd_ladder: List[Tuple[float, float]] = field(default_factory=lambda: [
        (-0.10, 0.85), (-0.15, 0.65), (-0.20, 0.40),
    ])
    trailing_stop: float = 0.12
    crash_pctl: float = 0.10
    confirm_days: int = 20
    to_max: float = 0.35

    # ---- 运行开关 ----
    use_rbsa: bool = True               # 关闭则 D4 缺席（维度权重归一化到其余）
    use_holdings: bool = True           # 关闭则 D5 缺席
    use_fee: bool = True                # 关闭则 TC 因子缺席
    use_crash_fsm: bool = False         # 崩溃空仓默认关（说明书：需分别报告两套结果）
    rf: float = 0.02

    def tc_max(self, fund_type: Optional[str]) -> float:
        if not fund_type:
            return self.tc_max_default
        for key, cap in self.tc_max_by_type.items():
            if key in fund_type:
                return cap
        return self.tc_max_default
