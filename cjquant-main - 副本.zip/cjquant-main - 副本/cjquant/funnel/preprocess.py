# -*- coding: utf-8 -*-
"""L4 预处理层：说明书 §4 去极值 / 标准化 / 中性化 / 正交化，以及 §5 的 IC 检验。

缺失一律保持 NaN：按 §4.1 的规则，"可得因子权重归一化"由打分层处理，
这里**不填充**。填充会把"没数据"伪装成"中性"，是回测里最危险的自我欺骗之一。
"""
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd

# 方向字典在 factors 里（True=越大越好）
from .factors import HIGHER_IS_BETTER, INTERVAL_FACTORS


def interval_score(x: float, a: float, b: float) -> float:
    """§4.6 区间映射 g(x;a,b)：区间内满分 1，区间外线性衰减到 0。"""
    if x is None or not np.isfinite(x):
        return float("nan")
    if a <= x <= b:
        return 1.0
    dist = (a - x) if x < a else (x - b)
    return float(max(0.0, 1.0 - dist / (b - a)))


def winsorize_mad(df: pd.DataFrame, n: float = 5.0) -> pd.DataFrame:
    """§4.2 MAD 去极值：clip 到 median ± n × 1.4826 × MAD（基金因子厚尾，不用 3σ）。"""
    if df is None or df.empty:
        return df
    out = df.copy()
    for c in out.columns:
        s = pd.to_numeric(out[c], errors="coerce")
        med = s.median()
        mad = (s - med).abs().median()
        if not np.isfinite(med) or not np.isfinite(mad) or mad <= 0:
            continue
        sigma = 1.4826 * float(mad)
        out[c] = s.clip(med - n * sigma, med + n * sigma)
    return out


def standardize(df: pd.DataFrame) -> pd.DataFrame:
    """§4.3 横截面 z-score（NaN 不参与、保持 NaN）。"""
    if df is None or df.empty:
        return df
    out = df.copy()
    for c in out.columns:
        s = pd.to_numeric(out[c], errors="coerce")
        mu, sd = s.mean(), s.std()
        if not np.isfinite(sd) or sd <= 0:
            out[c] = s * 0.0
            continue
        out[c] = (s - mu) / sd
    return out


def direction_unify(df: pd.DataFrame) -> pd.DataFrame:
    """§4.6 方向统一：区间型先映射成正向，其余按方向取号。"""
    if df is None or df.empty:
        return df
    out = df.copy()
    for c in out.columns:
        s = pd.to_numeric(out[c], errors="coerce")
        if c in INTERVAL_FACTORS:
            a, b = INTERVAL_FACTORS[c]
            out[c] = s.map(lambda v: interval_score(v, a, b))
            continue
        if not HIGHER_IS_BETTER.get(c, True):      # False = 越小越好 → 取负号
            out[c] = -s
    return out


def neutralize(z: pd.DataFrame, exposures: Optional[pd.DataFrame]) -> pd.DataFrame:
    """§4.4 中性化：对每个因子横截面回归取残差（去掉规模/年龄/风格的共同影响）。"""
    if z is None or z.empty or exposures is None or exposures.empty:
        return z
    X = exposures.reindex(z.index)
    keep_cols = [c for c in X.columns if X[c].notna().sum() > max(5, 0.5 * len(X))]
    if not keep_cols:
        return z
    Xm = X[keep_cols].astype(float)
    Xm = Xm.fillna(Xm.median())
    Xv = np.column_stack([np.ones(len(Xm)), Xm.values])
    out = z.copy()
    for c in z.columns:
        y = pd.to_numeric(z[c], errors="coerce")
        mask = y.notna()
        if mask.sum() < max(8, 0.5 * len(y)):
            continue
        yv = y[mask].values
        Xs = Xv[mask.values]
        try:
            beta, *_ = np.linalg.lstsq(Xs, yv, rcond=None)
            resid = yv - Xs.dot(beta)
        except Exception:
            continue
        sd = float(np.std(resid))
        vals = pd.Series(np.nan, index=z.index)
        vals.loc[mask] = (resid / sd) if sd > 0 else 0.0
        out[c] = vals
    return out


def symmetric_orthogonalize(z: pd.DataFrame, cond_limit: float = 1e8) -> pd.DataFrame:
    """§4.5 对称正交（Löwdin）：Z⊥ = Z·S^{-1/2}，保序性最好；病态则退回原矩阵。"""
    if z is None or z.empty:
        return z
    X = z.fillna(0.0)
    n = max(len(X), 1)
    S = X.T.dot(X).values / n
    try:
        w, U = np.linalg.eigh(S)
    except Exception:
        return z
    if np.min(np.abs(w)) <= 1e-12 or np.max(np.abs(w)) / max(np.min(np.abs(w)), 1e-12) > cond_limit:
        return z
    Sinv = U @ np.diag(1.0 / np.sqrt(np.abs(w))) @ U.T
    return pd.DataFrame(X.values @ Sinv, index=X.index, columns=X.columns)


# ---------------------------------------------------------------------------
# IC 检验（§5）
# ---------------------------------------------------------------------------
def forward_returns(nav_panel: pd.DataFrame, asof: pd.Timestamp, h: int) -> pd.Series:
    """FwdRet(t,h) = P_{t+h}/P_t - 1（未来收益，仅用于 IC 检验，不进信号）。"""
    if nav_panel.empty:
        return pd.Series(dtype=float)
    sub = nav_panel.loc[nav_panel.index > asof]
    if len(sub) < h:
        return pd.Series(dtype=float)
    end = sub.index[h - 1]
    return (nav_panel.loc[end] / nav_panel.loc[nav_panel.index <= asof].iloc[-1] - 1.0).dropna()


def compute_ic(z: pd.DataFrame, fwd: pd.Series) -> pd.Series:
    """Spearman 秩相关 IC（抗异常值）。"""
    if z is None or z.empty or fwd is None or fwd.empty:
        return pd.Series(dtype=float)
    common = z.index.intersection(fwd.index)
    if len(common) < 8:
        return pd.Series(dtype=float)
    out = {}
    for c in z.columns:
        a = pd.to_numeric(z.loc[common, c], errors="coerce")
        b = pd.to_numeric(fwd.loc[common], errors="coerce")
        m = a.notna() & b.notna()
        if m.sum() < 8:
            continue
        ra, rb = a[m].rank(), b[m].rank()
        # ⚠️ 零方差会让 IC 变成 0/0：Series.corr() 内部走 np.corrcoef 的
        #    `c /= stddev[:, None]`，往日志刷 RuntimeWarning（实测 pandas 3.0.5
        #    下 DataFrame.corr() 已静默，**Series.corr() 没有** —— 所以这里必须自己拦）。
        #    常数列的真实来源：中性化后某维度 z 值全相等、或横截面前瞻收益全相等。
        #    语义上"没有区分度 = 没有信息"，直接跳过（不写 NaN，避免污染 ic_stats）。
        if float(ra.std() or 0.0) <= 0.0 or float(rb.std() or 0.0) <= 0.0:
            continue
        try:
            with np.errstate(invalid="ignore", divide="ignore"):
                v = float(ra.corr(rb))
        except Exception:
            continue
        if np.isfinite(v):
            out[c] = v
    return pd.Series(out)


def ic_stats(ic_history: pd.DataFrame) -> pd.DataFrame:
    """IC 序列统计：均值/标准差/ICIR/t 值/胜率。"""
    if ic_history is None or ic_history.empty:
        return pd.DataFrame()
    rows = {}
    for c in ic_history.columns:
        s = pd.to_numeric(ic_history[c], errors="coerce").dropna()
        if len(s) < 3:
            continue
        mean, sd = float(s.mean()), float(s.std())
        icir = mean / sd if sd > 0 else float("nan")
        tstat = icir * np.sqrt(len(s)) if np.isfinite(icir) else float("nan")
        win = float((s * np.sign(mean) > 0).mean()) if mean != 0 else 0.0
        rows[c] = {"ic_mean": mean, "ic_std": sd, "icir": icir,
                   "t_stat": tstat, "win_rate": win, "n": len(s)}
    return pd.DataFrame(rows).T


def ic_weights(stats: pd.DataFrame, scheme: str = "C",
               clip: Tuple[float, float] = (0.03, 0.25)) -> Dict[str, float]:
    """§5.4 因子权重方案 A/B/C/D（默认 C = ICIR 加权），含权重截断。"""
    if stats is None or stats.empty:
        return {}
    if scheme == "A":
        raw = {c: 1.0 for c in stats.index}
    elif scheme == "B":
        raw = {c: abs(float(stats.loc[c, "ic_mean"])) for c in stats.index}
    elif scheme == "C":
        raw = {c: abs(float(stats.loc[c, "icir"])) if np.isfinite(stats.loc[c, "icir"]) else 0.0
               for c in stats.index}
    elif scheme == "D":
        try:
            mu = stats["ic_mean"].values.astype(float)
            cov = np.cov(stats[["ic_mean"]].values.T) if len(stats) > 1 else np.array([[1.0]])
            raw = dict(zip(stats.index, np.linalg.pinv(cov).dot(mu)))
            raw = {k: abs(float(v)) for k, v in raw.items()}
        except Exception:
            raw = {c: 1.0 for c in stats.index}
    else:
        raw = {c: 1.0 for c in stats.index}
    lo, hi = clip
    vals = np.array([float(v) for v in raw.values()], dtype=float)
    if not np.isfinite(vals).any() or vals.sum() <= 0:
        return {c: 1.0 / len(raw) for c in raw}
    # 归一化后截断，再归一化
    w = {k: float(v) / float(vals.sum()) for k, v in raw.items()}
    w = {k: float(min(max(v, lo), hi)) for k, v in w.items()}
    s = sum(w.values())
    return {k: v / s for k, v in w.items()} if s > 0 else w


def ic_available(stats: Optional[pd.DataFrame], cfg_ic_min: float = 0.02,
                 cfg_t_min: float = 2.0, cfg_win: float = 0.55) -> Dict[str, bool]:
    """§5 门槛判定：|ICMean| ≥ 0.02 且 |t| ≥ 2.0 且 IC 胜率 ≥ 0.55。

    没通过检验的因子**不进打分**（等权合成时也排除），而不是"看起来合理就用"。
    """
    if stats is None or stats.empty:
        return {}
    out: Dict[str, bool] = {}
    for c in stats.index:
        try:
            m = abs(float(stats.loc[c, "ic_mean"]))
            t = abs(float(stats.loc[c, "t_stat"]))
            w = float(stats.loc[c, "win_rate"])
            out[c] = bool(m >= cfg_ic_min and t >= cfg_t_min and w >= cfg_win)
        except Exception:
            out[c] = False
    return out
