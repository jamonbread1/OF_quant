# -*- coding: utf-8 -*-
"""L1~L5 端到端编排（说明书 §12 伪代码的项目内实现）。

回测插件与定时任务**必须都走这里**，否则一定会出现"回测一套、上线另一套"。
`FunnelResult` 里带了全部诊断信息（含"哪些规则本次没生效"），
方便在日志与决策记录里如实披露。

🔧 v1.1 结构修正（P0-1 / §6.6）
--------------------------------
旧实现在**全候选集 U(t)** 上做标准化、中性化、正交化与分位排名。
这与 §6.6「各类别不能混在一起打分排名」直接冲突：
债基 Sharpe 常年 2~4、股基 0.5~1.5，按全 U 排名取前 10% 进 Core，
Core 档几乎全是债基与货币，Pool_EQ 长期不足额甚至为空。

现改为**子池内**闭环：

    for c in (EQ, IDX, BOND, ALT, QDII):
        U_c(t) 准入 → 子池内预处理(§4) → 子池内打分(§6.1~6.3)
                    → 子池内缓冲带(§6.4) → 子池内去冗余(§6.5)
    → 类别间 ERC(§7.1) → 类别内 softmax(§7.2) → 约束(§7.3)
    → 波动率目标(§7.4) → 风控仲裁 min(§7.5)
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Set, Tuple

import numpy as np
import pandas as pd

from .filters import FilterConfig, FundFacts, hard_filters
from .factors import (FACTOR_DIM, FundData, add_cross_sectional,
                      blend_momentum_cross_section, build_style_exog,
                      compute_factor_table, preprocess_factors)
from .pool import (PoolParams, apply_penalty, assign_tiers, build_pool,
                   decorrelate_with_refill, pool_avg_corr, rank_pct,
                   two_level_score)
from .portfolio import (apply_bounds, apply_caps, apply_group_caps, erc_weights,
                        limit_turnover, softmax_weights, vol_target_leverage)
from .risk import arbitrate_multipliers
from . import style as fstyle


# ---------------------------------------------------------------------------
# 相关性矩阵（§6.5 去冗余的输入）
# ---------------------------------------------------------------------------

# 已提示过的零方差标的：回测里每个 bar 都会调一次 _corr_matrix，
# 每次都打印等于换了个方式刷屏（实测 BOND 子池每个 bar 都命中同一个货币基金）。
_DEGENERATE_REPORTED: set = set()


def _corr_matrix(price_panel: pd.DataFrame) -> pd.DataFrame:
    """收益率相关矩阵，**对零方差列免疫**。

    为什么不能直接 `.pct_change().corr()`：
        `DataFrame.corr()` 走 `np.corrcoef`，内部要 `c /= stddev[:, None]`。
        只要有一列收益率**恒为 0**（stddev == 0），就是 0/0 → 该行列全变 NaN，
        同时 numpy 往日志刷：
            RuntimeWarning: invalid value encountered in divide
            c /= stddev[:, None]
        实测：每个调仓 bar 都刷一遍，把回测日志淹掉。

    零方差列的真实来源：
        * **货币基金**（净值常年钉在 1.0000）—— Pool_CASH 本来就装这些，必然命中；
        * 净值停更/被清洗成常数的基金（数据质量问题）。

    处置：
        1) 只用**非退化列**算相关，从根上不产生 0/0，也就没有警告；
        2) 退化列与其他列的相关系数定义为 **0.0**（无信息 = 不相关），
           与 `pool._max_corr` 的既有约定一致（它把非有限值也当 0）；
        3) 对角线恒为 1.0 —— 否则退化列会被 `pool_avg_corr` 的 NaN 过滤掉，
           或被误读成"与谁都无关"的完美分散标的。
    """
    if price_panel is None or price_panel.shape[1] < 2:
        return pd.DataFrame()
    rets = price_panel.pct_change().replace([np.inf, -np.inf], np.nan).dropna(how="all")
    cols = list(rets.columns)
    if len(cols) < 2 or rets.empty:
        return pd.DataFrame()

    # 退化判定：有效样本不足、或标准差为 0/非有限
    std = rets.std()
    n_ok = rets.notna().sum()
    degenerate = [c for c in cols
                  if not np.isfinite(float(std.get(c, np.nan)))
                  or float(std.get(c, 0.0)) <= 0.0
                  or int(n_ok.get(c, 0)) < 3]
    valid = [c for c in cols if c not in set(degenerate)]

    corr = pd.DataFrame(0.0, index=cols, columns=cols)
    if len(valid) >= 2:
        # errstate 兜底：即便还有别的退化情形，也别把警告刷到用户日志里
        with np.errstate(invalid="ignore", divide="ignore"):
            sub = rets[valid].corr()
        corr.loc[valid, valid] = sub.values
    for c in cols:
        corr.loc[c, c] = 1.0
    # 数值噪声清理：相关矩阵必须落在 [-1, 1] 且有限
    corr = corr.replace([np.inf, -np.inf], 0.0).fillna(0.0).clip(-1.0, 1.0)
    fresh = [c for c in degenerate if c not in _DEGENERATE_REPORTED]
    if fresh:
        _DEGENERATE_REPORTED.update(fresh)
        print(f"[corr] {len(fresh)} 只标的收益率零方差（货币基金/净值恒定），"
              f"其相关性按 0 处理：{fresh[:5]}{'…' if len(fresh) > 5 else ''}"
              f"（同一标的仅提示一次）")
    return corr


# ---------------------------------------------------------------------------
# §6.6 跨类别分池
# ---------------------------------------------------------------------------

@dataclass
class SubpoolConfig:
    """一个子池的静态配置。"""
    name: str
    n_target: int
    keywords: Tuple[str, ...]
    benchmark: str
    scored: bool = True            # False = 不参与打分（货币池只做流动性管理）
    r2_threshold: float = 0.70     # §3.3 v1.1 分池 R² 阈值
    w_max: float = 0.20            # §7.3 C1：ALT/CASH 可放宽到 0.30


# 顺序即优先级：先匹配到的先生效。
#   CASH 最先（货币池不打分）；QDII / ALT 要排在 IDX 之前 —— 否则
#   "QDII-指数" 会被"指数"抢走归到 IDX、"黄金ETF联接"会被"ETF联接"抢走归到 IDX，
#   而 §6.6 里它们分别属于 Pool_QDII 与 Pool_ALT。
SUBPOOLS: Tuple[SubpoolConfig, ...] = (
    SubpoolConfig("CASH", 3, ("货币", "现金"), "—",
                  scored=False, w_max=0.30),
    SubpoolConfig("QDII", 6, ("QDII", "国际", "海外", "全球", "美国", "香港",
                              "标普", "纳斯达克", "德国", "日本", "印度", "越南"),
                  "对应海外指数（人民币计价）", r2_threshold=0.65),
    SubpoolConfig("ALT", 4, ("黄金", "商品", "原油", "有色", "豆粕", "能源"),
                  "上海金 / 商品指数", r2_threshold=0.65, w_max=0.30),
    SubpoolConfig("BOND", 10, ("纯债", "债券", "偏债", "中短债", "利率债", "信用债"),
                  "中债总财富指数", r2_threshold=0.60),
    SubpoolConfig("IDX", 8, ("指数", "增强", "ETF联接"), "对应标的指数"),
    SubpoolConfig("EQ", 15, ("股票", "偏股", "混合", "灵活配置", "成长", "价值"),
                  "中证800"),
)

SUBPOOL_NAMES: Tuple[str, ...] = tuple(s.name for s in SUBPOOLS if s.scored)
# §7.1 资产类别集合 A = {EQ, BOND, ALT, QDII}
CLASS_ORDER: Tuple[str, ...] = ("EQ", "BOND", "ALT", "QDII")
DEFAULT_CLASS_BOUNDS: Dict[str, Tuple[float, float]] = {
    "EQ": (0.30, 0.65), "BOND": (0.20, 0.50),
    "ALT": (0.05, 0.15), "QDII": (0.00, 0.20),
}

# 子池 → §7.1 资产类别。
#   打分/建池按 **6 个子池** 独立闭环（§6.6「类别内打分」），
#   配置按 **4 个大类**（§7.1「类别间配置」）—— 两者粒度不同：
#     Pool_IDX 是独立子池（指数基金 N_target=8、R² 阈值与 EQ 不同），
#     但它本质是权益，在 ERC 大类上并入 EQ，否则 IDX 成员会拿不到任何权重。
#     Pool_CASH 不参与打分，也不属于 A，仅作为风控释放仓位的去向（§6.6）。
CLASS_OF_POOL: Dict[str, Optional[str]] = {
    "EQ": "EQ", "IDX": "EQ", "BOND": "BOND", "ALT": "ALT",
    "QDII": "QDII", "CASH": None,
}


# 🟡 P2-3（报告 §2.4）：结构化的"类型 → 子池"白名单。
# 原来的 `classify_subpool` 只做**关键词子串匹配**，有两个真实缺陷：
#   ① 依赖 SUBPOOLS 的字面顺序打补丁（"QDII-指数"要靠 QDII 排在 IDX 前才不被抢走）；
#   ② 匹配不到就 `return "EQ"` —— 把"不知道它是什么"伪造成"它是权益"，
#      于是债券/商品类标的会被套上股票风格向量、还会分走 EQ 的额度。
# 这里先按**完整类型名**精确查表（两种常见写法都收录），查不到才退回关键词，
# 再查不到就归 EQ 但**明确告警**（不再静默）。
FUND_TYPE_POOL: Dict[str, str] = {
    # ---- 权益 ----
    "股票型": "EQ", "普通股票型": "EQ", "标准股票型": "EQ",
    "混合型-偏股": "EQ", "偏股混合型": "EQ", "偏股型": "EQ",
    "混合型-灵活": "EQ", "灵活配置型": "EQ", "灵活配置混合型": "EQ",
    "混合型-平衡": "EQ", "平衡混合型": "EQ",
    "混合型-绝对收益": "EQ", "绝对收益型": "EQ",
    # ---- 指数（独立子池，但 ERC 大类并入 EQ）----
    "指数型-股票": "IDX", "股票指数型": "IDX", "指数型": "IDX",
    "增强指数型": "IDX", "指数型-增强": "IDX", "指数型-其他": "IDX",
    "ETF联接": "IDX", "被动指数型": "IDX",
    # ---- 固收 ----
    "债券型-纯债": "BOND", "纯债债券型": "BOND", "纯债型": "BOND",
    "债券型-长债": "BOND", "长期纯债型": "BOND",
    "债券型-中短债": "BOND", "中短债型": "BOND",
    "债券型-信用债": "BOND", "信用债型": "BOND",
    "债券型-利率债": "BOND", "利率债型": "BOND",
    "债券型-混合一级": "BOND", "混合债券型-一级": "BOND", "一级债基": "BOND",
    "债券型-混合二级": "BOND", "混合债券型-二级": "BOND", "二级债基": "BOND",
    "混合型-偏债": "BOND", "偏债混合型": "BOND", "偏债型": "BOND",
    "QDII-纯债": "BOND", "债券型-QDII": "BOND",
    "保本型": "BOND",
    # ---- 另类（商品/黄金）----
    "商品型": "ALT", "黄金型": "ALT", "商品型-其他": "ALT",
    # ---- QDII 权益 ----
    "QDII-普通股票": "QDII", "QDII-股票": "QDII", "QDII-指数": "QDII",
    "QDII-海外股票": "QDII", "QDII-混合": "QDII", "QDII-其他": "QDII",
    "国际(QDII)": "QDII",
    # ---- 现金 ----
    "货币型": "CASH", "货币型-普通货币": "CASH", "货币型-浮动净值": "CASH",
    "理财型": "CASH", "短期理财型": "CASH",
}
# 不适合套用股票风格框架的品类（报告 §2.4 黑名单）——供 H7 / RBSA 判断
STYLE_NOT_APPLICABLE_PREFIXES = (
    "货币型", "债券型", "QDII-纯债", "商品型", "黄金", "理财型", "保本型",
    "混合型-偏债", "偏债", "FOF",   # 偏债/FOF 的收益来源同样不是股票五因子
)


def style_applicable(fund_type: Optional[str]) -> bool:
    """该类型是否适用股票五因子风格框架（H7 的类型白名单）。

    债券/货币/商品/理财的收益来源无法用价值·成长·规模·动量·质量表达，
    硬套只会得到低 R² 与"风格不纯"的误杀。
    """
    t = str(fund_type or "").strip()
    if not t:
        return False
    return not any(t.startswith(p) for p in STYLE_NOT_APPLICABLE_PREFIXES)


def classify_subpool(fund_type: Optional[str], fund_name: Optional[str] = None) -> str:
    """按基金类型/名称把标的归入 §6.6 的子池。

    顺序：结构化白名单（精确）→ 关键词子串 → EQ + 明确告警。
    """
    text = f"{fund_type or ''} {fund_name or ''}"
    ft = str(fund_type or "").strip()
    if ft:
        hit = FUND_TYPE_POOL.get(ft)
        if hit:
            return hit
        # 兼容"混合型-偏股"与"偏股混合型"两种写法（分隔符两侧的**整段**互换）
        # ⚠️ 不能退化成 `k in ft` 的子串匹配：那样 "黄金ETF联接" 会被
        #    "ETF联接" 抢走归到 IDX（实测踩过，ALT 危机对冲整类消失）。
        if "-" in ft:
            a, b = ft.split("-", 1)
            for cand in (f"{b}{a}", f"{b}-{a}"):
                if cand in FUND_TYPE_POOL:
                    return FUND_TYPE_POOL[cand]
    if not text.strip():
        return "EQ"
    for sp in SUBPOOLS:
        for kw in sp.keywords:
            if kw in text:
                return sp.name
    print(f"[classify_subpool] 警告：类型 {ft!r} 未命中白名单与关键词，"
          f"暂归 EQ（请补进 FUND_TYPE_POOL，避免债券/商品被当权益打分）")
    return "EQ"


@dataclass
class SubpoolResult:
    """单个子池的产出。"""
    name: str
    candidates: List[str] = field(default_factory=list)
    eligible: List[str] = field(default_factory=list)
    members: List[str] = field(default_factory=list)
    score: pd.Series = field(default_factory=lambda: pd.Series(dtype=float))
    pct: pd.Series = field(default_factory=lambda: pd.Series(dtype=float))
    tiers: Dict[str, str] = field(default_factory=dict)
    entry: Dict[str, str] = field(default_factory=dict)
    avg_corr: float = float("nan")
    diagnostics: List[str] = field(default_factory=list)
    dropped: Dict[str, int] = field(default_factory=dict)
    unverified: Dict[str, int] = field(default_factory=dict)


@dataclass
class FunnelResult:
    asof: Optional[str] = None
    candidates: List[str] = field(default_factory=list)
    eligible: List[str] = field(default_factory=list)
    dropped: Dict[str, int] = field(default_factory=dict)       # 剔除原因 -> 只数
    unverified: Dict[str, int] = field(default_factory=dict)    # 未校验规则 -> 涉及只数
    flags: Dict[str, List[str]] = field(default_factory=dict)
    raw: pd.DataFrame = field(default_factory=pd.DataFrame)
    z: pd.DataFrame = field(default_factory=pd.DataFrame)
    score: pd.Series = field(default_factory=lambda: pd.Series(dtype=float))
    pct: pd.Series = field(default_factory=lambda: pd.Series(dtype=float))
    tiers: Dict[str, str] = field(default_factory=dict)
    members: List[str] = field(default_factory=list)            # 全部子池成员合计
    entry: Dict[str, str] = field(default_factory=dict)
    weights: pd.Series = field(default_factory=lambda: pd.Series(dtype=float))       # 控仓前
    final_weights: pd.Series = field(default_factory=lambda: pd.Series(dtype=float))  # 控仓后
    leverage: float = 1.0
    avg_corr: float = float("nan")
    dims: Dict[str, int] = field(default_factory=dict)
    # 🔧 v1.1 新增
    pools: Dict[str, List[str]] = field(default_factory=dict)   # 子池 -> 成员
    pool_of: Dict[str, str] = field(default_factory=dict)       # 代码 -> 子池
    subpool_results: Dict[str, SubpoolResult] = field(default_factory=dict)
    class_weights: Dict[str, float] = field(default_factory=dict)   # §7.1 ERC 类别权重
    diagnostics: Dict[str, object] = field(default_factory=dict)
    risk_multiplier: float = 1.0
    risk_driver: Optional[str] = None                            # §7.5 主导风控层
    cash_weight: float = 0.0                                     # 控仓后留存现金（无货币池载体时）
    # F-3：本期各基金的 RBSA 风格暴露（code -> 向量）。调用方持久化后作为
    # 下期 run_funnel(prev_style_w=...) 传入，style_consist（D4）才有输入。
    style_w_map: Dict[str, object] = field(default_factory=dict)

    @property
    def unverified_rules(self) -> List[str]:
        return sorted(self.unverified.keys())

    # ---- 便于调用方（回测插件 / 定时任务）取用的兼容视图 ----
    @property
    def pool(self) -> List[str]:
        """全部子池成员合计（等价 `members`）。"""
        return list(self.members)

    @property
    def passed(self) -> List[str]:
        """通过准入的标的（等价 `eligible`）。"""
        return list(self.eligible)

    @property
    def filter_summary(self) -> Dict[str, object]:
        """L2 准入的结构化摘要。"""
        return {
            "total": len(self.candidates),
            "passed": len(self.eligible),
            "dropped": dict(self.dropped),
            "unverified_rules": self.unverified_rules,
        }


def _build_fund_data(code: str, nav: pd.Series, master, reports, asof,
                     style_rets: Optional[pd.DataFrame], use_style: bool,
                     use_holdings: bool,
                     calendar: Optional[pd.DatetimeIndex] = None,
                     style_w_prev=None):
    """组装一只基金的事实 + 数据，并跑 H1~H8 准入。返回 (facts_result, FundData|None)。

    calendar: 市场交易日历，供 H8 缺失率使用。用周一~周五代替会把完整序列
    误判为高缺失并清空整个候选池（见 filters._data_quality 的说明）。
    style_w_prev: 该基金**上一期**的 RBSA 风格暴露向量 —— style_consist 因子
    （D4）依赖它与本期 style_w 的余弦相似度。三期 F-3 修复：此前 run_funnel
    从未传过这个值，style_consist 恒 NaN，D4 永远只有 r2 一根柱子。
    """
    row, scale_hist = {}, []
    if master is not None:
        try:
            row = master.get_fund(code) or {}
            scale_hist = [(h.get("report_date"), h.get("scale_yi"))
                          for h in (master.scale_history(code) or [])]
        except Exception:
            pass
    fee = holdings = holdings_prev = industry = None
    # H2 / H6 只查本地 SQLite（零网络成本），所以不受 use_holdings 影响 ——
    # use_holdings 关掉的是"联网抓持仓明细"，不该连带把经理任期与持有人结构也停掉。
    tenure_days = inst_ratio = None
    if reports is not None:
        try:
            tenure_days = reports.manager_tenure_days(code, asof)
            inst_ratio = reports.inst_ratio_asof(code, asof)
        except Exception:
            pass
    if reports is not None and use_holdings:
        try:
            fee = reports.fee_of(code) or None
            holdings = reports.holdings_asof(code, asof)
            industry = reports.industry_asof(code, asof)
            ds = reports.report_dates(code, asof, table="fund_holdings")
            if len(ds) >= 2:
                holdings_prev = reports.holdings_at(code, ds[-2])
        except Exception:
            pass

    # H4 申赎状态（修复方案 v1.0 §3.1d）：改查 `subscribe_status_daily` 快照表。
    # 东财只给"当日"状态、没有历史，唯一拿到 PIT 的办法是我们自己每天落一份快照
    # （data_ops/purchase_snapshot.py），决策日读 <= asof 的最近一条，
    # 且新鲜度门槛 10 天 —— 没采集过的历史如实记"未校验"，**绝不回填**。
    tradable = limited = close_ended = None
    snap = None
    if reports is not None:
        try:
            snap = reports.subscribe_status_asof(code, asof)
        except Exception:
            snap = None
    if snap:
        ss = str(snap.get("subscribe_stat") or "")
        rs = str(snap.get("redeem_stat") or "")
        tradable = not ("暂停" in ss or "暂停" in rs)
        limited = ("限大额" in ss) or ("限大额" in rs)
        # §3.2：下一开放日非 NULL ⇒ 定开/持有期产品（实测：开放基金=NaT）
        close_ended = snap.get("next_open_date")
    else:
        # 快照表还没有历史（新表冷启动）：退回旧的 fee 快照 ±7 天判据
        if fee:
            ss = str(fee.get("subscribe_stat") or "")
            rs = str(fee.get("redeem_stat") or "")
            if ss or rs:
                try:
                    upd = pd.Timestamp(str(fee.get("updated_at") or "")[:10])
                    if abs((pd.Timestamp(asof).normalize() - upd).days) <= 7:
                        tradable = not ("暂停" in ss or "暂停" in rs)
                        limited = ("限大额" in ss) or ("限大额" in rs)
                except Exception:
                    pass

    style_w = style_r2 = style_match = None
    style_na_reason = None
    if use_style and style_rets is not None and not style_rets.empty:
        try:
            r = nav.pct_change().dropna()
            # H7 分级（修复方案 v1.0 §3.6）：先判"类型是否适用风格约束"。
            # 货币/FOF/QDII/商品的 H7 未校验是**设计意图**，与"RBSA 真失败"
            # 不是一回事，混在一张清单里会掩盖真正要修的问题。
            vec0 = fstyle.style_vector_for(row.get("fund_type"), row.get("fund_name"))
            if vec0 is None:
                style_na_reason = "not_applicable"
            style_w = fstyle.solve_style_exposure(r, style_rets)
            if style_w is not None:
                style_r2 = fstyle.style_r2(r, style_rets, style_w)
                # 必须同时传基金名：黄金 ETF 联接的 fund_type 是「指数型-其他」，
                # 只看类型会被套上股票风格向量而遭 H7 误杀（见 style_vector_for）。
                if vec0:
                    style_match = fstyle.style_match(vec0, style_w)
            elif style_na_reason is None:
                style_na_reason = "rbsa_failed"
        except Exception:
            style_na_reason = style_na_reason or "rbsa_failed"

    scale_yi = None
    if master is not None:
        try:
            asof_d = pd.Timestamp(asof).date()
            scale_yi = master.scale_asof(code, asof_d)
        except Exception:
            scale_yi = None

    facts = FundFacts(code=code, nav=nav, setup_date=row.get("setup_date"),
                      liquidation_date=row.get("liquidation_date"),
                      fund_type=row.get("fund_type"), fund_name=row.get("fund_name"),
                      scale_yi=scale_yi, scale_hist=scale_hist, fee=fee,
                      tradable=tradable, limited_purchase=limited,
                      close_ended=close_ended,
                      manager_tenure_days=tenure_days, inst_ratio=inst_ratio,
                      style_match=style_match, style_r2=style_r2,
                      style_na_reason=style_na_reason)
    fr = hard_filters(facts, pd.Timestamp(asof), FilterConfig(), calendar=calendar)
    if not fr.passed:
        return fr, None
    data = FundData(code, nav, setup_date=row.get("setup_date"),
                    fund_type=row.get("fund_type"), fund_name=row.get("fund_name"),
                    scale_yi=scale_yi, fee=fee, holdings=holdings,
                    holdings_prev=holdings_prev, industry=industry,
                    style_w=style_w, style_r2=style_r2,
                    style_w_prev=style_w_prev)
    return fr, data


def _subpool_returns(nav_panel: pd.DataFrame, members: Sequence[str],
                     window: int = 252) -> Optional[pd.Series]:
    """子池等权组合的日收益（§7.1：类别收益用子池等权组合净值代表）。"""
    cols = [c for c in members if c in nav_panel.columns]
    if len(cols) < 1:
        return None
    px = nav_panel[cols].dropna(how="all")
    if px.empty:
        return None
    r = px.pct_change().dropna(how="all")
    if r.empty:
        return None
    if len(r) > window:
        r = r.iloc[-window:]
    return r.mean(axis=1)


def _cap_within(w: pd.Series, w_max: float, w_min: float, w_sub: float,
                max_iter: int = 50) -> pd.Series:
    """子池额度内的 C1 上限 + C2 下界清理，**全程保持 Σ = w_sub**。"""
    out = pd.to_numeric(w, errors="coerce").fillna(0.0).astype(float)
    if out.sum() <= 0:
        return out
    out = out * (float(w_sub) / out.sum())
    for _ in range(6):
        # ---- C1 单只上限 ----
        for _ in range(int(max_iter)):
            viol = out[out > float(w_max) + 1e-12]
            if len(viol) == 0:
                break
            out.loc[viol.index] = float(w_max)
            elig = out[(out < float(w_max) - 1e-12) & (out > 0)]
            gap = float(w_sub) - float(out.sum())
            if len(elig) == 0 or abs(gap) < 1e-12:
                break
            base = float(elig.sum())
            out.loc[elig.index] = elig + (gap * elig / base if base > 0 else gap / len(elig))
        # ---- C2 下界清理 ----
        low = out[(out > 0) & (out < float(w_min) - 1e-12)]
        if len(low) == 0:
            break
        out.loc[low.index] = 0.0
        alive = out[out > 0]
        if len(alive) == 0:
            break
        gap = float(w_sub) - float(out.sum())
        base = float(alive.sum())
        out.loc[alive.index] = alive + (gap * alive / base if base > 0 else 0.0)
    s = float(out.sum())
    return out / s * float(w_sub) if s > 0 else out


def _topup_capped(base: pd.Series, add: float, w_max: float,
                  max_iter: int = 12) -> Tuple[pd.Series, float]:
    """在**不突破单只上限 w_max** 的前提下给一组标的加仓 add。

    返回 (加仓后的序列, 装不下而退回现金的余额)。

    ⚠️ 为什么不能直接 `base + add * base/base.sum()`：
        那是最常见的"绕过风控"写法 —— 债券池只有 3 只时，0.30 的释放额度
        会让单只直接顶到 0.40+，C1 单只上限形同虚设（P0-1 的同源问题）。
        这里按"各标的剩余额度"反复摊，装不满就老实退回现金
        （"不是必须用尽可用资金"）。
    """
    out = pd.to_numeric(base, errors="coerce").fillna(0.0).astype(float)
    left = float(add)
    if left <= 0 or out.empty:
        return out, max(0.0, left)
    for _ in range(int(max_iter)):
        room = (float(w_max) - out).clip(lower=0.0)
        if float(room.sum()) <= 1e-12 or left <= 1e-12:
            break
        give = min(left, float(room.sum()))
        out = out + give * (room / float(room.sum()))
        left -= give
    return out, max(0.0, left)


def _trim_to_holdable(subs, hold_cap: int, score: pd.Series):
    """把类别成员裁到「w_min 可容纳」的上限，各子池按成员数比例分摊、档内留高分。

    为什么必须先裁：若不裁，子池额度 ∝ 成员数会给出人均 w_a / n_total，
    当它 < w_min 时**每一只都低于下限**，C2 会把整个子池清空。
    """
    total_n = sum(len(m) for _, m, _ in subs)
    if total_n <= hold_cap:
        return subs
    out = []
    for name, members, mx in subs:
        if not members:
            continue
        k = max(1, int(math.floor(hold_cap * len(members) / total_n)))
        if len(members) > k:
            sc = score.loc[members].dropna().sort_values(ascending=False)
            members = [c for c in members if c in sc.index][:k] or list(members)[:k]
        out.append((name, members, mx))
    return out


def _alloc_once(w_a: float, subs, score: pd.Series, w_min: float, lam: float) -> Dict[str, float]:
    """按给定 λ 做一次「裁剪 → 子池切分 → softmax → C1 → C2」。"""
    out: Dict[str, float] = {}
    total_n = sum(len(m) for _, m, _ in subs)
    if total_n == 0:
        return out
    # 子池额度 ∝ **实际成员数**（用 N_target 会导致小池额度不够，全员被 C2 清零）
    for _name, members, mx in subs:
        w_sub = float(w_a) * len(members) / total_n
        sc = score.loc[members].dropna()
        if sc.empty:
            sub = pd.Series(1.0 / len(members), index=members)
        else:
            sub = softmax_weights(sc, lam=float(lam))
            if len(sub) < len(members):
                sub = sub.reindex(members).fillna(0.0)
            sub = sub / sub.sum() if sub.sum() > 0 else pd.Series(1.0 / len(members),
                                                                  index=members)
        sub = _cap_within(sub, w_max=float(mx), w_min=float(w_min), w_sub=w_sub)
        for c, v in sub.items():
            out[str(c)] = float(v)
    return out


def _class_allocation(w_a: float, subs: Sequence[Tuple[str, List[str], float]],
                      score: pd.Series, w_min: float, lam: float,
                      min_keep_ratio: float = 1.0, max_tries: int = 6
                      ) -> Tuple[Dict[str, float], float]:
    """在类别额度 w_a 内完成：子池切分 → 子池内 softmax → C1 → C2。

    返回 ({code: weight}, 实际生效的 λ)，Σ = w_a。

    ⚠️ 为什么必须在类别内闭环（不能先拼全组合再统一 apply_caps）：
        统一做 C2（清零 w < w_min）后全局重新归一化，会把被清掉的额度
        摊到其他类别上 —— EQ 低分被清零 → EQ 实际敞口低于 ERC 给的 w_EQ，
        §7.1 的 ERC 结果被 §7.3 悄悄改写。这里全程只在本类别内再分配。

    ⚠️ 为什么 λ 要自适应（说明书 §7.2 的诊断方法）：
        λ 过大 → softmax 极度集中 → 大量标的权重跌破 w_min 被 C2 清零，
        最终权重由"截断规则"而非"分数"决定，这正是 §7.2 明令要避免的。
        实测（278 只真实基金）：λ=1.0 时 38 只池只落出 14 只持仓。
        这里按"存活率 ≥ min_keep_ratio"逐次折半 λ，让分数而不是截断说了算。
    """
    alive = [(n, [c for c in m if c in score.index], mx) for n, m, mx in subs]
    alive = [(n, m, mx) for n, m, mx in alive if m]
    total_n = sum(len(m) for _, m, _ in alive)
    if total_n == 0:
        return {}, float(lam)
    # C2 可行性硬上限：整类最多只能放下 w_a / w_min 只
    hold_cap = max(1, int(math.floor(float(w_a) / max(float(w_min), 1e-9))))
    alive = _trim_to_holdable(alive, hold_cap, score)
    total_n = sum(len(m) for _, m, _ in alive)
    if total_n == 0:
        return {}, float(lam)
    target = max(1, int(math.ceil(min(total_n, hold_cap) * float(min_keep_ratio))))

    lam_i = float(lam)
    best: Dict[str, float] = {}
    best_lam = lam_i
    for _ in range(int(max_tries)):
        out = _alloc_once(w_a, alive, score, w_min, lam_i)
        n_held = sum(1 for v in out.values() if v > 0)
        if n_held > sum(1 for v in best.values() if v > 0):
            best, best_lam = out, lam_i
        if n_held >= target:
            return out, lam_i
        lam_i *= 0.5
    return best, best_lam


def run_funnel(nav_panel: pd.DataFrame, asof,
               master=None, reports=None,
               style_rets: Optional[pd.DataFrame] = None,
               bm_rets: Optional[pd.Series] = None,
               pool_params: Optional[PoolParams] = None,
               prev_members: Optional[Sequence[str]] = None,
               prev_entry: Optional[Dict[str, str]] = None,
               port_rets: Optional[pd.Series] = None,
               sigma_target: float = 0.11,
               use_style: bool = True, use_holdings: bool = True,
               w_max: float = 0.20, w_min: float = 0.02,
               lam: float = 1.0, to_max: float = 0.20,
               current_weights: Optional[pd.Series] = None,
               rf: float = 0.02,
               class_bounds: Optional[Dict[str, Tuple[float, float]]] = None,
               min_names: int = 8,
               risk_multipliers: Optional[Dict[str, float]] = None,
               type_of: Optional[Dict[str, str]] = None,
               orthogonalize: bool = True,
               prev_style_w: Optional[Dict[str, object]] = None,
               dim_weights: Optional[Dict[str, float]] = None,
               neutralize_factors: bool = True,
               group_of: Optional[Dict[str, str]] = None,
               group_cap: Optional[float] = None) -> FunnelResult:
    """跑一次完整的 L1~L5（🔧 v1.1：L2~L4 在**子池内**闭环，§12 伪代码已改）。

    nav_panel: 行=日期、列=基金代码的复权净值（已 PIT 截断，右端点 t-1）。

    ⚠️ 默认值即**说明书推荐值**（2026-09-19 对齐，P1-4）：lam=1.0（z 口径，
    2.0 会让前几名必然触顶 w_max）、to_max=0.20（实测甜点；0.35 年化差 1pp、
    0.08 回撤反而扩大到 −21.78%）、orthogonalize=True（D3 四因子高度共线，
    不正交化会让动量暴露高于设计意图）。显式传了旧值的调用方不受影响；
    **新调用方直接用默认，不要再抄旧文档里的 2.0/0.35/False**。
    """
    res = FunnelResult(asof=str(asof)[:10])
    if nav_panel is None or nav_panel.empty:
        return res
    base_params = pool_params or PoolParams()
    # 让调用方的 `pool_params.n_target` **真正生效**：按比例缩放各子池容量。
    # ⚠️ 原实现直接对每个子池用 `sp.n_target`（SUBPOOLS 的静态配置，打分子池合计 43），
    #    传入的 n_target 只出现在日志里 —— 实测 TOP_N=25 与 TOP_N=12 跑出**完全相同**
    #    的成交笔数(208)与净值曲线，才暴露这个参数从未生效。
    #    现在按 `n_target / Σ(打分子池 n_target)` 等比缩放；传 43 时与旧版行为一致。
    #    CASH 池（scored=False）不参与缩放，它走的是下面的 members 截断，容量由策略侧控制。
    _cfg_total = sum(s.n_target for s in SUBPOOLS if s.scored) or 1
    _pool_scale = float(base_params.n_target) / float(_cfg_total)
    res.diagnostics["pool_scale"] = round(float(_pool_scale), 4)
    res.candidates = [str(c) for c in nav_panel.columns]

    # ---------------- L2 准入 + L2.5 RBSA 预计算（全市场一次） ----------------
    data: Dict[str, FundData] = {}
    facts_map: Dict[str, object] = {}
    meta: Dict[str, Dict[str, Optional[str]]] = {}
    prev_w_map = dict(prev_style_w or {})     # F-3：上期风格暴露（style_consist 依赖）
    for code in nav_panel.columns:
        nav = nav_panel[code].dropna()
        if len(nav) < 60:
            continue
        fr, fd = _build_fund_data(str(code), nav, master, reports, asof,
                                  style_rets, use_style, use_holdings,
                                  calendar=nav_panel.index,
                                  style_w_prev=prev_w_map.get(str(code)))
        for u in fr.unverified:
            res.unverified[u] = res.unverified.get(u, 0) + 1
        if fd is None:
            key = fr.reasons[0].split(" ")[0] if fr.reasons else "其他"
            res.dropped[key] = res.dropped.get(key, 0) + 1
            continue
        data[str(code)] = fd
        facts_map[str(code)] = fr
        meta[str(code)] = {"fund_type": fd.fund_type, "fund_name": fd.fund_name}
    res.eligible = list(data.keys())
    # F-3：本期风格暴露快照 —— 调用方持久化，下期回传 prev_style_w
    res.style_w_map = {c: d.style_w for c, d in data.items()
                       if getattr(d, "style_w", None) is not None}
    if len(data) < 3:
        return res

    # ---------------- 子池划分（§6.6） ----------------
    pool_of: Dict[str, str] = {}
    for code in data:
        t = (type_of or {}).get(code)
        if t is None:
            m = meta.get(code) or {}
            t = m.get("fund_type")
            name = m.get("fund_name")
        else:
            name = None
        pool_of[code] = classify_subpool(t, name)
    res.pool_of = dict(pool_of)

    prev_set = set(str(c) for c in (prev_members or []))
    prev_entry_map = dict(prev_entry or {})

    # ---------------- 原始因子（一次算全，贵；子池内只做相对运算） ----------------
    # 持仓字典：供子池内的 add_cross_sectional 使用（cons/换手类因子读持仓）。
    # 注意 compute_factor_table 不再收 holdings_map 形参（F-2：它从不消费），
    # 但这个字典本身是活的，别再删。
    holdings_map = {c: d.holdings for c, d in data.items()
                    if getattr(d, "holdings", None) is not None and len(d.holdings)}
    raw_all = compute_factor_table(data, bm_rets=bm_rets, rf=rf,
                                   style_rets=style_rets)
    if raw_all.empty:
        return res
    res.raw = raw_all

    all_scores: Dict[str, float] = {}
    all_pct: Dict[str, float] = {}
    all_tiers: Dict[str, str] = {}
    all_flags: Dict[str, List[str]] = {}
    z_frames: List[pd.DataFrame] = []
    sub_results: Dict[str, SubpoolResult] = {}
    pool_members: Dict[str, List[str]] = {}
    entry_out: Dict[str, str] = {}

    # ---------------- 子池内闭环（P0-1） ----------------
    for sp in SUBPOOLS:
        codes = [c for c in data if pool_of.get(c) == sp.name]
        spr = SubpoolResult(name=sp.name, candidates=list(codes))
        if not codes:
            sub_results[sp.name] = spr
            continue

        if not sp.scored:
            # §6.6：货币池不参与任何打分，只做流动性管理
            spr.members = list(codes)[: max(1, sp.n_target)]
            pool_members[sp.name] = list(spr.members)
            sub_results[sp.name] = spr
            continue

        spr.eligible = list(codes)
        sub_raw = raw_all.loc[[c for c in codes if c in raw_all.index]].copy()
        # §3.2 合成动量（横截面 z）必须在子池内做
        sub_raw = blend_momentum_cross_section(sub_raw)
        # 横截面因子（rmom / cons / size_pct 分位）必须在子池内做
        sub_holdings = {c: h for c, h in holdings_map.items() if c in codes}
        sub_raw = add_cross_sectional(sub_raw, holdings_map=sub_holdings)
        if sub_raw.empty:
            sub_results[sp.name] = spr
            continue

        # §4 预处理：缺失值 → 区间映射 → 去极值 → 标准化 → 方向统一 → 中性化
        exog = pd.DataFrame(index=sub_raw.index)
        if "ln_size" in sub_raw.columns:
            exog["ln_size"] = pd.to_numeric(sub_raw["ln_size"], errors="coerce")
        # P1-4：风格权重做中性化变量时**去掉第一个维度**（Σw=1 与截距完全共线）
        style_w_map = {c: data[c].style_w for c in codes
                       if getattr(data.get(c), "style_w", None) is not None}
        if style_w_map:
            sexog = build_style_exog(style_w_map, drop_first=True)
            if not sexog.empty:
                exog = exog.join(sexog, how="left")
        neu_cols = [c for c in ("mom_blend", "rmom", "rev", "rmom_resid",
                                "hhi", "imp_turnover", "cons", "bet_dep")
                    if c in sub_raw.columns]
        # A-3 进攻档（三期工程 §6.2）：进攻线关闭中性化——剥离风格 Beta
        # 等于把小盘/成长暴露（A股超额的真实来源）也剥掉。
        if not neutralize_factors:
            neu_cols = []
        z = preprocess_factors(sub_raw, exog=exog if not exog.empty else None,
                               neutralize_cols=neu_cols, orthogonalize=orthogonalize)
        z_frames.append(z)

        # §6.1 两级加权打分（dim_weights：三期 A-1 进攻档可换维度权重；
        #      缺省用说明书 §6.1 的稳健权重）
        score = two_level_score(z, dim_weights=dim_weights)
        if score.empty:
            sub_results[sp.name] = spr
            continue

        # §6.2 旗标（加法惩罚）+ 子池 R² 阈值（§3.3 v1.1 分池阈值）
        flags: Dict[str, List[str]] = {}
        for code in codes:
            fl = list(getattr(facts_map.get(code), "flags", []))
            if code in z.index and "r2" in z.columns:
                r2 = z.loc[code, "r2"]
                if r2 is not None and r2 == r2 and float(r2) < float(sp.r2_threshold):
                    fl.append("Flag_Opaque")
            if fl:
                flags[code] = fl
                all_flags[code] = fl
        score = apply_penalty(score, flags)

        # §6.3 子池内分位 + 分档
        pct = rank_pct(score)
        tiers = assign_tiers(pct, flags)
        spr.score, spr.pct, spr.tiers = score, pct, tiers

        # §6.4 缓冲带（子池容量口径）+ §6.5 去冗余补齐回路
        sp_n = max(1, int(round(sp.n_target * _pool_scale)))
        pparams = PoolParams.for_subpool(sp_n, base=base_params)
        prev_sub = [c for c in codes if c in prev_set]
        entry_sub = {c: v for c, v in prev_entry_map.items() if c in codes}
        members, entry_sub, diags = build_pool(
            pct, prev_sub, entry_sub, str(asof)[:10],
            params=pparams, blacklist=None, tiers=tiers)
        spr.diagnostics = list(diags)

        corr_src = nav_panel[[c for c in members if c in nav_panel.columns]]
        corr = _corr_matrix(corr_src) if len(members) > 1 else pd.DataFrame()
        if not corr.empty:
            members, dcorr = decorrelate_with_refill(members, corr, pct,
                                                     pool_params=pparams, tiers=tiers)
            spr.diagnostics += list(dcorr)
            spr.avg_corr = pool_avg_corr(members, corr)
        spr.members = list(members)
        spr.entry = dict(entry_sub)
        pool_members[sp.name] = list(members)
        entry_out.update(entry_sub)

        for c in score.index:
            all_scores[c] = float(score[c]) if not pd.isna(score[c]) else np.nan
        for c in pct.index:
            all_pct[c] = float(pct[c]) if not pd.isna(pct[c]) else np.nan
        all_tiers.update(tiers)
        sub_results[sp.name] = spr

    res.subpool_results = sub_results
    res.z = pd.concat(z_frames, axis=0) if z_frames else pd.DataFrame()
    res.z = res.z[~res.z.index.duplicated(keep="first")]
    res.pools = {k: list(v) for k, v in pool_members.items()}
    res.members = [c for sp in SUBPOOLS for c in pool_members.get(sp.name, [])]
    res.entry = entry_out
    res.flags = all_flags
    res.score = pd.Series(all_scores, dtype=float)
    res.pct = pd.Series(all_pct, dtype=float)
    res.tiers = all_tiers
    if res.score.notna().any():
        res.dims = {dim: int(sum(1 for c in res.raw.columns
                                 if FACTOR_DIM.get(c) == dim
                                 and res.raw[c].notna().any()))
                    for dim in ("D1", "D2", "D3", "D4", "D5", "D6")}
    corrs = [float(s.avg_corr) for s in sub_results.values() if np.isfinite(s.avg_corr)]
    res.avg_corr = float(np.mean(corrs)) if corrs else float("nan")
    res.diagnostics = {
        "pools": {k: len(v) for k, v in pool_members.items()},
        "unverified_rules": res.unverified_rules,
        "dropped": dict(res.dropped),
        "per_pool": {k: {"members": len(v),
                         # NaN 必须转成 None：json.dumps(allow_nan=False) 会直接抛错，
                         # 而浏览器的 JSON.parse 也读不了裸 NaN —— 一个 nan
                         # 就能让整个 /api/decisions 返回 500（实测踩过）。
                         "avg_corr": (float(sub_results[k].avg_corr)
                                      if k in sub_results
                                      and np.isfinite(sub_results[k].avg_corr)
                                      else None),
                         "diagnostics": (sub_results[k].diagnostics if k in sub_results else [])}
                     for k, v in pool_members.items()},
    }
    if not res.members:
        return res

    # ---------------- L5-A：类别间 ERC（§7.1） ----------------
    # 大类收益 = 该类下所有子池成员的等权组合（EQ 大类 = Pool_EQ ∪ Pool_IDX）
    cls_rets: Dict[str, pd.Series] = {}
    for a in CLASS_ORDER:
        subs = [s.name for s in SUBPOOLS if CLASS_OF_POOL.get(s.name) == a]
        codes_a = [c for sp in subs for c in pool_members.get(sp, [])]
        r = _subpool_returns(nav_panel, codes_a)
        if r is not None and len(r) > 60:
            cls_rets[a] = r
    class_w: Dict[str, float] = {}
    if len(cls_rets) >= 2:
        rets = pd.DataFrame(cls_rets).dropna(how="all")
        if len(rets) > 60:
            cov = rets.cov() * 252.0
            cov = cov.loc[list(cls_rets), list(cls_rets)]
            bounds = dict(class_bounds or DEFAULT_CLASS_BOUNDS)
            bounds = {k: v for k, v in bounds.items() if k in cls_rets}
            # §7.1 边界可行性前置检查
            lo_sum = sum(v[0] for v in bounds.values())
            hi_sum = sum(v[1] for v in bounds.values())
            if not (lo_sum <= 1.0 + 1e-9 <= hi_sum):
                bounds = {k: (0.0, 1.0) for k in cls_rets}
            w = erc_weights(cov, bounds=bounds if bounds else None)
            class_w = {k: float(v) for k, v in w.items()}
    if not class_w:
        # ERC 不可用（样本不足等）→ 退化到固定基准权重（§0.5 的建议比例）
        present = [a for a in CLASS_ORDER if any(
            pool_members.get(s.name) for s in SUBPOOLS if CLASS_OF_POOL.get(s.name) == a)]
        fixed = {"EQ": 0.45, "BOND": 0.35, "ALT": 0.10, "QDII": 0.10}
        tot = sum(fixed.get(a, 0.0) for a in present) or 1.0
        class_w = {a: fixed.get(a, 0.0) / tot for a in present}
    res.class_weights = {k: round(v, 6) for k, v in class_w.items()}

    # ---------------- L5-A：类别内 softmax（§7.2）+ 组合 ----------------
    # 分值只在**子池内**可比（P0-1），且 §7.3 的截断必须在**类别内**闭环（见
    # `_class_allocation` 的说明），所以这里按「大类 → 子池 → 单只」三级分配。
    #
    # 🔴 P0-1 修复（2026-09-26 评审）：原实现末尾 `w = w / w.sum()` 把组合强行
    #    归一化到 100%。只要有一个类别没有合格成员（QDII 全被 H 规则剔除、
    #    ALT 只剩 1 只等），Σw_parts < 1，这一步会把**每一只**按 1/Σ 放大 ——
    #    实测单只权重从 0.20 被放大到 0.303、最高 0.4911（473/510 个交易日
    #    违反 w_max=0.20），§7.3 的单只上限与 §7.1 的类别边界同时被击穿。
    #    正确语义：**配不满就是配不满**。缺额先在有额度的类别间再分配，
    #    仍配不满的部分留作现金（或落到 Pool_CASH 货币载体）——
    #    「不是必须用尽可用资金」，现金本身就是一种合法的仓位。
    sp_cfg = {s.name: s for s in SUBPOOLS}

    def _subs_of(a: str):
        return [(s.name,
                 [c for c in pool_members.get(s.name, []) if c in res.score.index],
                 float(sp_cfg[s.name].w_max) if s.name in sp_cfg else float(w_max))
                for s in SUBPOOLS
                if CLASS_OF_POOL.get(s.name) == a and pool_members.get(s.name)]

    bounds_all = dict(class_bounds or DEFAULT_CLASS_BOUNDS)
    alloc: Dict[str, Dict[str, float]] = {}      # 类别 -> {code: w}
    lam_used: Dict[str, float] = {}
    for a, w_a in class_w.items():
        got, lam_a = _class_allocation(float(w_a), _subs_of(a), res.score,
                                       w_min=float(w_min), lam=float(lam))
        alloc[a] = got or {}
        lam_used[a] = round(float(lam_a), 4)
    if lam_used:
        res.diagnostics["lambda_effective"] = lam_used

    def _filled(a: str) -> float:
        return float(sum(v for v in alloc.get(a, {}).values() if v > 0))

    # ---- 缺额再分配：只补给"类别额度还有空间"的类别，重建时仍走 C1/C2 ----
    for _ in range(8):
        filled = {a: _filled(a) for a in alloc}
        short = 1.0 - float(sum(filled.values()))
        if short <= 1e-9:
            break
        head: Dict[str, float] = {}
        for a in alloc:
            hi = float(bounds_all.get(a, (0.0, 1.0))[1])
            room = hi - filled[a]
            if room > 1e-9:
                head[a] = room
        if not head:
            break
        cap_sum = float(sum(head.values()))
        add_total = min(short, cap_sum)
        before = float(sum(filled.values()))
        for a, room in head.items():
            extra = add_total * room / cap_sum
            if extra <= 1e-12:
                continue
            got, lam_a = _class_allocation(filled[a] + extra, _subs_of(a), res.score,
                                           w_min=float(w_min),
                                           lam=float(lam_used.get(a, lam)))
            if got and _filled(a) < float(sum(v for v in got.values() if v > 0)):
                alloc[a] = got
                lam_used[a] = round(float(lam_a), 4)
        # 一轮下来没有任何类别能吃下额度 → 退出，避免死循环
        if float(sum(_filled(a) for a in alloc)) - before < 1e-9:
            break

    w_parts: Dict[str, float] = {}
    for a in alloc:
        w_parts.update(alloc[a])

    if not w_parts:
        return res
    w = pd.Series(w_parts, dtype=float)
    w = w[w > 0]
    if w.sum() <= 0:
        return res
    # 🔒 P0-1：这里**不**做 `w / w.sum()`。目标敞口就是 w.sum()（≤ 1），
    #    差额 underfill 是刻意保留的现金，由 §7.4 的释放仓位逻辑与 Pool_CASH 承接。
    alloc_total = float(w.sum())
    if alloc_total > 1.0 + 1e-9:
        # 理论上不会发生（各类别都在自己的额度内）；真超了才等比缩回
        w = w * (1.0 / alloc_total)
        alloc_total = 1.0
    underfill = max(0.0, 1.0 - alloc_total)
    if underfill > 1e-9:
        res.diagnostics["class_underfill"] = round(underfill, 6)
    # ---- P2-2：单管理人/单风格/单公司上限（C3/C4）----
    # 这两个上限以前只是 `FunnelConfig` 里的**声明**，`group_of` 从未被传进来，
    # apply_caps 被 import 却无人调用 —— 实测出现过单只 49% 的集中度而无人拦截。
    # 超限的部分**退回现金**（不是摊给别人），因此敞口只会变小、不会变大。
    if group_of:
        w = apply_group_caps(w, group_of=group_of,
                             group_cap=float(group_cap if group_cap is not None else 0.30),
                             w_max=float(w_max), target_sum=float(alloc_total))
        alloc_total = float(w.sum())
        underfill = max(0.0, 1.0 - alloc_total)
        res.diagnostics["class_underfill"] = round(underfill, 6)
    # C5 最少标的数复检（不做强行凑数，只提示扩池）
    n_eff = int((w > 0).sum())
    if n_eff < int(min_names):
        res.diagnostics["C5_warning"] = (
            f"有效标的 {n_eff} 只 < C5 下限 {int(min_names)}，建议扩池")
    # 货币池成员作为现金载体挂 0 权重进入组合，供 §7.4 释放仓位时承接
    for c in pool_members.get("CASH", []):
        if c not in w.index:
            w.loc[c] = 0.0

    # ---------------- §7.4 波动率目标 + §7.5 风控仲裁（取 min） ----------------
    lev = vol_target_leverage(port_rets, sigma_target=float(sigma_target))
    res.leverage = float(lev)
    mults: Dict[str, float] = {}
    if risk_multipliers:
        mults.update({k: float(v) for k, v in risk_multipliers.items()})
    mults["VolTarget"] = float(lev)
    eff_mult, driver = arbitrate_multipliers(mults)
    res.risk_multiplier = float(eff_mult)
    res.risk_driver = driver

    # 释放的仓位按 §12 修正：先算 released 再乘（原式用已乘的 w_EQ 会丢仓位）
    #
    # 🔴 P0-1 修复续：这里要区分**两种**缺口，不能混为一谈 ——
    #   ① underfill（类别配不满）：是**结构性**的，说明池子里没有合格的标的，
    #      按"不是必须用尽可用资金"的原则，它只能去现金/货币载体，
    #      **绝不能因为"还有 60% 要配债券"就被硬塞进债券池**；
    #   ② risk_released（波动率目标/回撤减仓主动降下来的敞口）：
    #      这部分才走 §7.4 的"债券池 60% / 现金 40%"。
    w_lev = w * float(eff_mult)
    risk_released = alloc_total * (1.0 - float(eff_mult))
    cash_left = float(underfill)
    if risk_released > 1e-9:
        # 🔧 用户口径（2026-09-26）：**允许出现空闲资金，空闲一律存入
        #    申赎都免手续费的货币基金**，不再按 §7.4 的"债券池 60% / 现金 40%"
        #    把降下来的敞口硬塞回债券。
        #    理由：① 降仓本身就是风控判断，转手买成债券等于没降风险敞口；
        #          ② 债券仍有久期/信用风险，不是"无风险现金"；
        #          ③ 货币基金 T+0/T+1 可赎、0 申赎费，才是真正的闲置资金去处。
        #    没有货基载体时才记为留存现金（执行层会把现金留在账上）。
        cash_members = [c for c in pool_members.get("CASH", []) if c in w_lev.index]
        add = risk_released
        if cash_members and add > 1e-12:
            base = w_lev.loc[cash_members]
            if base.sum() > 0:
                w_lev.loc[cash_members] = base + add * (base / base.sum())
            else:
                w_lev.loc[cash_members] = add / len(cash_members)
            res.diagnostics["released_to_cash_vehicle"] = round(float(add), 6)
        else:
            cash_left += add
    res.cash_weight = round(float(cash_left), 6)
    res.weights = w
    # 🔒 limit_turnover 必须保留目标敞口（≤1），不能把部分调仓后的权重再拉回 100%
    res.final_weights = limit_turnover(w_lev, current_weights, to_max=float(to_max),
                                       target_sum=float(w_lev.sum())) \
        if current_weights is not None else w_lev
    return res
