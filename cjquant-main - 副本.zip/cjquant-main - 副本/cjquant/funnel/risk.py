# -*- coding: utf-8 -*-
"""L5-B 择时与风控算子：说明书 §8。

诚实提醒（§13.8）：均线偏离定投的真实作用是**降低波动、改善持有体验**，
不必然提高收益；崩溃空仓机制规避暴跌的代价是 V 型反转里长期踏空。
因此这些算子默认只做**减仓系数**，且崩溃空仓默认关闭（use_crash_fsm=False），
回测时对"含/不含空仓"分别报告。
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .config import FunnelConfig


def ma_deviation(index_close: pd.Series, window: int = 120) -> float:
    """Dev_t = I_t / MA_m(t) - 1。"""
    if index_close is None or len(index_close) < window + 5:
        return float("nan")
    ma = float(index_close.rolling(window).mean().iloc[-1])
    return float(index_close.iloc[-1] / ma - 1.0) if ma > 0 else float("nan")


def dca_multiplier(dev: float, cfg: FunnelConfig) -> float:
    """§8.1 方案 B：分段阶梯（透明、易执行）。"""
    if dev is None or not np.isfinite(dev):
        return 1.0
    if dev <= -0.20:
        return 2.5
    if dev <= -0.10:
        return 1.8
    if dev <= -0.05:
        return 1.4
    if dev <= 0.0:
        return 1.15
    if dev <= 0.10:
        return 1.0
    if dev <= 0.20:
        return 0.6
    if dev <= 0.30:
        return 0.3
    return 0.0


def trend_switch(index_close: pd.Series, window: int = 120,
                 confirm_days: int = 5) -> Optional[bool]:
    """§8.2 趋势开关：价在均线上且均线向上，需连续 confirm_days 日确认（防抖）。"""
    if index_close is None or len(index_close) < window + confirm_days + 5:
        return None
    ma = index_close.rolling(window).mean()
    cond = (index_close > ma) & (ma > ma.shift(21))
    recent = cond.iloc[-confirm_days:]
    if len(recent) < confirm_days:
        return None
    return bool(recent.all())


def trend_multiplier(on: Optional[bool], floor: float = 0.5) -> float:
    if on is None:
        return 1.0
    return 1.0 if on else floor


def drawdown_multiplier(dd: float, cfg: FunnelConfig) -> float:
    """§8.3 阈值3：最大回撤预警减仓（-10%→0.85 / -15%→0.65 / -20%→0.40）。"""
    if dd is None or not np.isfinite(dd):
        return 1.0
    mult = 1.0
    for thr, m in cfg.dd_ladder:
        if dd <= thr:
            mult = min(mult, m)
    return float(mult)


def twr_returns(values: pd.Series, cashflows: Optional[pd.Series] = None) -> pd.Series:
    """🔧 v1.1 P0-3：时间加权收益率（TWR）日收益，与现金流完全解耦。

        CF_t = t 日净现金流（定投注入为正、赎回为负；以 t 日收盘计）
        r_p,t = V_t / (V_{t-1} + CF_t) − 1

    为什么不能用 V_t/V_{t−1}−1（说明书 §8.3 的缺陷复现）：
        组合 100 万跌到 90 万（真实回撤 −10%），此时定投 10 万
        → V 变回 100 万 → DD_p = 0，**回撤信号被抹平**；
        反过来持续定投让 V_t 单调上升，RunningMax(V) 不断刷新，
        止盈信号会被反复提前触发。
    §7.4 的已实现波动率 σ̂ 也必须用这条序列（口径统一）。
    """
    v = pd.Series(values).dropna().astype(float) if values is not None else pd.Series(dtype=float)
    if len(v) < 2:
        return pd.Series(dtype=float)
    if cashflows is not None:
        cf = pd.Series(cashflows).reindex(v.index).fillna(0.0).astype(float)
    else:
        cf = pd.Series(0.0, index=v.index)
    base = v.shift(1) + cf
    r = (v / base - 1.0).where(base > 0)
    return r.dropna()


def twr_index(values: pd.Series, cashflows: Optional[pd.Series] = None) -> pd.Series:
    """累计 TWR 净值指数 I_p,t = Π(1+r_p,s)，I_p,0 = 1。

    性质：I_p 序列**永不重置**（止盈只改变仓位不改变基准），
    否则 R_hold 的历史连续性被破坏（§8.3 实现约束 c）。
    """
    r = twr_returns(values, cashflows)
    if r.empty:
        return pd.Series(dtype=float)
    return (1.0 + r).cumprod()


def twr_drawdown(values: pd.Series, cashflows: Optional[pd.Series] = None) -> float:
    """DD_p(t) = I_p,t / max_{s≤t} I_p,s − 1（§8.3 / §8.4 统一口径）。"""
    idx = twr_index(values, cashflows)
    if len(idx) < 2:
        return 0.0
    return float((idx / idx.cummax() - 1.0).min())


def twr_holding_return(values: pd.Series, cashflows: Optional[pd.Series] = None,
                       entry: Optional[float] = None) -> float:
    """R_hold(t) = I_p,t / I_p,entry − 1（§8.3 止盈判据）。"""
    idx = twr_index(values, cashflows)
    if idx.empty:
        return float("nan")
    base = float(entry) if entry else 1.0
    if base <= 0:
        return float("nan")
    return float(idx.iloc[-1] / base - 1.0)


def max_drawdown_of(equity: pd.Series) -> float:
    """基于净值（金额或指数）序列的最大回撤。

    ⚠️ 若传入的是组合**金额** V_t 且期间有外部现金流，结果不可用于风控
    （见 P0-3）。有定投/申赎时请用 `twr_drawdown` / `max_drawdown_of_twr`。
    （2026-09-19 清理：本文件曾有两份同名定义互相覆盖，现只保留这一份。）
    """
    if equity is None or len(equity) < 2:
        return 0.0
    s = equity.dropna()
    return float((s / s.cummax() - 1.0).min())


def take_profit_multiplier(cum_ret: float, done: List[float], cfg: FunnelConfig
                           ) -> Tuple[float, List[float]]:
    """§8.3 阈值1：目标收益止盈（分批）。返回 (剩余仓位系数, 已触发档位)。

    🔧 v1.1：原式 `remain *= (1 - cut)` 是**乘法**累积
    （0.75³ = 0.42），但说明书要求"收益达 25%/50%/80% 各卖出 25% 仓位，
    **保留 25% 底仓**"——即按原始仓位**减去**：1 − 0.25×3 = 0.25。
    """
    if cum_ret is None or not np.isfinite(cum_ret):
        return 1.0, done
    remain = 1.0
    triggered = list(done)
    for i, (thr, cut) in enumerate(cfg.tp_ladder):
        if cum_ret >= thr and i not in triggered:
            triggered.append(i)
            remain -= float(cut)
    return float(max(0.0, remain)), triggered


def arbitrate_multipliers(multipliers: Dict[str, float]
                          ) -> Tuple[float, Optional[str]]:
    """🔧 v1.1 P1-10 / §7.5：多层风控乘数**取最小值，不连乘**。

    各层（§7.4 波动率目标 L_t、§8.2 趋势、§8.3 回撤、§8.3 移动止盈、
    §8.4 崩溃空仓）都作用于 w_EQ^{base}，但旧设计从未定义它们如何组合。

    连乘的合成谬误：L_t=0.60 + Trend=0.50 + 回撤−15%(×0.65)
        → 0.60 × 0.50 × 0.65 = 0.195，权益被砍到 19.5%，
        而每一层单独看都"合理"。

    取 min 的物理意义：由**最严格的那一层**说了算。
    返回 (最终乘数, 主导层名称) —— 主导层必须记入 risk_log 供 §10.6 归因。
    """
    valid = {k: float(v) for k, v in (multipliers or {}).items()
             if v is not None and np.isfinite(float(v))}
    if not valid:
        return 1.0, None
    key = min(valid, key=lambda k: valid[k])
    return valid[key], key


def trailing_stop_hit(cum_ret: float, dd: float, cfg: FunnelConfig) -> bool:
    """§8.3 阈值2：收益≥20% 后回撤超过 θ_tr=12% → 减半仓。"""
    if cum_ret is None or dd is None or not np.isfinite(cum_ret) or not np.isfinite(dd):
        return False
    return bool(cum_ret >= 0.20 and dd <= -cfg.trailing_stop)


@dataclass
class CrashState:
    """§8.4 崩溃空仓状态机。"""
    state: str = "NORMAL"
    loss_streak: int = 0
    recover_steps: int = 0
    confirm_count: int = 0

    def update(self, vol_now: float, dd_now: float,
               vol_hist: Optional[pd.Series] = None,
               dd_hist: Optional[pd.Series] = None,
               trend_on: Optional[bool] = None,
               cfg: Optional[FunnelConfig] = None) -> float:
        """返回权益仓位系数（1.0=不减仓，0.10=FLAT 保留观察仓）。"""
        cfg = cfg or FunnelConfig()
        if not cfg.use_crash_fsm:
            return 1.0
        vq = float(np.quantile(vol_hist.dropna(), 0.80)) if vol_hist is not None and len(vol_hist.dropna()) > 20 else np.nan
        dq = float(np.quantile(dd_hist.dropna(), cfg.crash_pctl)) if dd_hist is not None and len(dd_hist.dropna()) > 20 else np.nan
        if self.state == "NORMAL":
            if np.isfinite(vq) and vol_now > vq and self.loss_streak >= 2:
                self.state = "RISK_OFF"
                return 0.85
            return 1.0
        if self.state == "RISK_OFF":
            if np.isfinite(dq) and dd_now <= dq and self.loss_streak >= 3:
                self.state = "FLAT"
                return 0.10
            if np.isfinite(vq) and vol_now <= vq:
                self.state = "NORMAL"
                return 1.0
            return 0.85
        if self.state == "FLAT":
            ok_vol = (not np.isfinite(vol_now)) or vol_now <= cfg.sigma_target
            self.confirm_count = self.confirm_count + 1 if (ok_vol and trend_on) else 0
            if self.confirm_count >= cfg.confirm_days:
                self.state = "RECOVERING"
                self.recover_steps = 0
                return 0.325
            return 0.10
        if self.state == "RECOVERING":
            self.recover_steps += 1
            if self.recover_steps >= 4:
                self.state = "NORMAL"
                return 1.0
            return min(0.325 + 0.225 * self.recover_steps, 1.0)
        return 1.0


def max_drawdown_of_twr(values: pd.Series, cashflows: Optional[pd.Series] = None) -> float:
    """有现金流时的正确回撤口径（P0-3）。"""
    return twr_drawdown(values, cashflows)
