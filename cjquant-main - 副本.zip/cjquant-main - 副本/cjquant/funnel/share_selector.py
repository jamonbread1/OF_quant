﻿# -*- coding: utf-8 -*-
"""A/C 份额优选（三期工程 F-5 / 评审 P1-2）。

为什么重要
----------
同一只基金的 A 类与 C 类是**两个不同代码**：A 类一次性收申购费（折后约 0.15%），
持有 <1~2 年还有赎回费；C 类免申购费、但按日计提销售服务费（约 0.4~0.8%/年）。
说明书 v1.1 修正了平衡点（3 个月 → **约 12 个月**）：月度调仓下持有期短，
**默认应该选 C 类** —— 单独这一项每年省 0.2~0.4%，零风险。

成本模型（holding_months = 预期持有期）
--------------------------------------
    cost_A(T) = buy_rate_disc + redeem_A(T)         # 申购费一次性 + 赎回费阶梯
    cost_C(T) = sales_service × T / 12              # 按日计提，通常无赎回费

其中 A 类赎回费近似用回测费率模型的公共口径（<7 天 1.5% / <30 天 0.75% /
<180 天 0.5% / <365 天 0.25% / ≥365 天 0）——月度调仓最短持有 90 天，
所以 A 类在 T<12 个月时至少背 0.25~0.5% 赎回费，这正是 v1.1 把平衡点
从 3 个月推到约 12 个月的原因。

族识别的诚实原则
----------------
A/C 族靠**名称尾部份额字母 + 同类型**归组，这是启发式：识别不了的单只
**原样保留**（宁可不优化，不误删）。名称清洗规则故意保守 ——
只剥末尾的 A/C/E 份额字母与"人民币/类"等后缀，剥完为空则不成族。
"""
from typing import Dict, List, Optional, Tuple

# A 类赎回费阶梯（自然日 → 费率 %）。与 cjquant.backtest.fee 的公共口径一致，
# 额外补一档 <365 天 0.25%（多数 A 类权益基金的真实阶梯）。
_A_REDEEM_TIERS: List[Tuple[int, float]] = [
    (7, 1.5), (30, 0.75), (180, 0.5), (365, 0.25), (10**9, 0.0),
]

_SHARE_TAIL = ("A", "B", "C", "E", "D")
_NAME_TAILS = ("人民币", "RMB", "类", "份额")


def _num(x) -> Optional[float]:
    try:
        v = float(x)
        return v if v == v else None
    except (TypeError, ValueError):
        return None


def family_key(name: str) -> Optional[str]:
    """名称 → 族键：剥尾部份额标识后归一化。剥完为空返回 None（不成族）。"""
    s = str(name or "").strip()
    if not s:
        return None
    changed = True
    while changed and s:
        changed = False
        for tail in _NAME_TAILS:
            if s.endswith(tail) and len(s) > len(tail):
                s = s[: -len(tail)].strip()
                changed = True
        if s and s[-1].upper() in _SHARE_TAIL and len(s) > 1:
            # ⚠️ 只剥"明确的份额字母"：前面是汉字/数字/右括号的才算。
            #     英文专名结尾（如 QDII 的 "S&P500"）会被前一条 len>1 挡住一部分，
            #     但保守起见要求倒数第二个字符不是字母。
            if not (s[-2].isascii() and s[-2].isalpha()):
                s = s[:-1].strip()
                changed = True
    return s or None


def share_class_of(name: str) -> str:
    """从名称末尾读份额类别（A/C/未知）。"""
    s = str(name or "").strip()
    while s and s.endswith(_NAME_TAILS):
        s = s[: -len([t for t in _NAME_TAILS if s.endswith(t)][0])].strip()
    if s and s[-1].upper() in ("A", "C") and not (len(s) > 1 and s[-2].isascii() and s[-2].isalpha()):
        return s[-1].upper()
    return "?"


def _a_redeem_rate(holding_days: int) -> float:
    for days, rate in _A_REDEEM_TIERS:
        if holding_days < days:
            return rate
    return 0.0


def compare_family(codes: List[str], names: Dict[str, str],
                   fees: Dict[str, dict], holding_months: float
                   ) -> Tuple[Optional[str], str]:
    """族内择优。返回 (保留的代码或 None=不比较, 理由)。

    ⚠️ 费率数据不完整时**放弃比较**（返回 codes[0] + "no_data"）：
    缺失当成 0 成本会让比较变成"瞎选" —— 把没有数据的 C 类当 0 成本，
    等于无条件选 C，这正是"数据诚实原则"要防的假优化。
    """
    days = max(1, int(round(holding_months * 30)))
    scored = []
    for c in codes:
        f = fees.get(c) or {}
        cls = share_class_of(names.get(c, ""))
        buy = _num(f.get("buy_rate_disc"))
        ss = _num(f.get("sales_service"))
        if cls == "A":
            if buy is None:
                return None, "no_data"          # A 类缺申购费 → 放弃
            cost = buy + _a_redeem_rate(days)
        elif cls == "C":
            if ss is None:
                return None, "no_data"          # C 类缺销售服务费 → 放弃
            cost = ss * holding_months / 12.0
        else:
            # 份额类别识别不了：两类关键字段都没有 → 放弃；有任一则按粗判
            if (ss or 0.0) > 0:
                cost = ss * holding_months / 12.0
            elif buy is not None:
                cost = buy + _a_redeem_rate(days)
            else:
                return None, "no_data"
        scored.append((cost, c, cls))
    if len(scored) < 2:
        return None, "no_data"
    scored.sort(key=lambda x: x[0])
    best = scored[0]
    worst = scored[-1]
    return best[1], (f"share_class={best[2]} cost≈{best[0]:.3f}% vs "
                     f"{worst[2]} {worst[0]:.3f}% @ {holding_months:.1f}月")


def select_share_class(candidates: List[str], names: Dict[str, str],
                       fees: Dict[str, dict], holding_months: float = 6.0,
                       ) -> Dict[str, str]:
    """对候选池做 A/C 优选。返回 {原候选: 替换后的代码}（未替换的映射为自身）。

    ⚠️ 替换后的代码必须**也在净值库里**才能落地 —— 本函数不管数据可得性，
    调用方（策略接入时）要用本地净值索引过滤一次，替换不了的保持原代码。
    这是"已实现未接线"的原因：族替换会改变回测标的集，必须先跑净值覆盖率验证。
    """
    fams: Dict[str, List[str]] = {}
    for c in candidates:
        k = family_key(names.get(c, ""))
        if k:
            fams.setdefault(k, []).append(c)
    out: Dict[str, str] = {}
    for c in candidates:
        out[c] = c
    for k, codes in fams.items():
        if len(codes) < 2:
            continue
        keep, why = compare_family(codes, names, fees, holding_months)
        if keep is None:
            # 数据不完整：整族原样保留，绝不瞎选（数据诚实原则）
            continue
        for c in codes:
            out[c] = keep
            if c != keep:
                out[f"__why__{c}"] = why   # 调试信息单独放，不污染映射
    return out
