# -*- coding: utf-8 -*-
"""L3~L5 因子计算与预处理（说明书 §3 / §4）。

这是**回测插件与定时任务共用的唯一实现** —— 两边都调 `compute_factor_table`
+ `preprocess_factors` + `score_factors`，保证"回测一套口径、上线另一套"不会发生。

因子清单与方向（HI=True 表示越大越好）
-----------------------------------
D1 收益质量：sharpe, calmar, ir
D2 风险控制：mdd(负→反向), underwater(越小越好), sortino, capture(CaptureSpread), worst_dd
D3 动量反转：mom_blend(§3.2 合成), rmom(横截面分位), rev, rmom_resid(残差动量)
D4 风格稳定：r2, style_consist, ac1(越小越好)
D5 持仓健康：hhi(区间映射), imp_turnover(越小越好), bet_dep(越小越好), cons(区间映射)
D6 容量费用：tc(越小越好), size_shock(越小越好), inst_ratio(区间映射)

🔧 v1.1 相对旧版的口径修正（全部对齐《算法说明书》v1.1）
----------------------------------------------------
1. **P1-5 CaptureSpread**：`capture` 由 UC/DC 改为 UC − DC。
   原式在 DC<0（熊市逆势上涨）时符号翻转，会**惩罚策略最想要的品种**。
2. **P0-4 右端点 t−1**：`momentum_12_3` 原用 `iloc[-64]/iloc[-253]`，
   在已 PIT 截断（末值=t−1）的序列上等于又退了一天，现改为 `iloc[-63]/iloc[-252]`。
3. **§6.1 注 2**：`omega` 移出 D1 —— 未通过 IC 检验前只作监控指标，不参与 Score。
4. **§3.2 共线性**：`mom_blend` 去掉第 4 项短期反转，权重归一为
   0.294/0.412/0.294，反转信号只由 `rev` 单独承担（否则 D3 内重复计价）。
5. **§4.6 顺序**：区间映射必须在**原始值**上做。旧代码对 z-score 做
   `interval_score(v, 0.02, 0.15)`，而区间是定义在 HHI 原值上的 —— 语义错误。

区间映射（说明书 §4.6）：HHI ∈ [0.02,0.15] 满分；Cons ∈ [0.20,0.60] 满分；
inst_ratio ∈ [0.10,0.80] 满分；区间外按 g(x;a,b)=max(0, 1-dist/(b-a)) 线性衰减。
"""
from __future__ import annotations

import math
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

TRADING_DAYS = 252
L_S, L_M, L_L, L_XL = 63, 126, 252, 756

# 因子 -> 维度（说明书 §6.1 v1.1 维度表）
#   不在本表中的因子（omega / mom_12_3 / size_pct）为**监控或中性化变量**，不参与 Score。
FACTOR_DIM: Dict[str, str] = {
    "sharpe": "D1", "calmar": "D1", "ir": "D1",
    "mdd": "D2", "underwater": "D2", "sortino": "D2", "capture": "D2", "worst_dd": "D2",
    "mom_blend": "D3", "rmom": "D3", "rev": "D3", "rmom_resid": "D3",
    "r2": "D4", "style_consist": "D4", "ac1": "D4",
    "hhi": "D5", "imp_turnover": "D5", "bet_dep": "D5", "cons": "D5",
    "tc": "D6", "size_shock": "D6", "inst_ratio": "D6",
}

# 因子方向：True=越大越好
HIGHER_IS_BETTER: Dict[str, bool] = {
    "sharpe": True, "calmar": True, "ir": True, "omega": True,
    "mdd": True,            # 原值为负(-0.05 > -0.20)，越大越好
    "underwater": False,
    "sortino": True, "capture": True, "worst_dd": True,
    "mom_12_3": True, "mom_blend": True, "rev": True, "rmom": True, "rmom_resid": True,
    "r2": True, "style_consist": True, "ac1": False,
    "hhi": True,            # 已区间映射为正向
    "ind_hhi": False,       # 行业集中度：越高越集中
    "imp_turnover": False,
    "bet_dep": False,       # 赛道押注依赖度：越大越依赖押注
    "cons": True,           # 已区间映射为正向
    "tc": False,
    "size_pct": True,       # 仅作中性化变量，weight=0
    "size_shock": False,    # 1=单季规模翻倍
    "inst_ratio": True,     # 已区间映射为正向
}

# 区间型因子：(a, b) 区间内满分（说明书 §4.6 + §3.6 的中等区间打分）
INTERVAL_FACTORS: Dict[str, Tuple[float, float]] = {
    "hhi": (0.02, 0.15),
    "cons": (0.20, 0.60),
    "inst_ratio": (0.10, 0.80),
}

# 维度权重（说明书 §6.1）
DIM_WEIGHTS: Dict[str, float] = {
    "D1": 0.28, "D2": 0.24, "D3": 0.16, "D4": 0.14, "D5": 0.12, "D6": 0.06,
}

# §3.2 v1.1 推荐的合成动量权重：去掉第 4 项（短期反转）后归一化
#   原 0.25/0.35/0.25（三项之和 0.85）→ 0.294/0.412/0.294
MOM_BLEND_WEIGHTS: Tuple[float, float, float] = (0.294, 0.412, 0.294)

# 维度内权重：MVP 用**等权**（说明书 §5.4 方案 A，最难过拟合）
NA = float("nan")


def _rets(nav: pd.Series, window: Optional[int] = None) -> pd.Series:
    s = pd.Series(nav).dropna()
    r = s.pct_change().dropna()
    return r.iloc[-window:] if window and len(r) > window else r


def _nav_win(nav: pd.Series, window: int) -> pd.Series:
    s = pd.Series(nav).dropna()
    return s.iloc[-window:] if len(s) > window else s


def ann_return(r: pd.Series) -> float:
    r = r.dropna()
    if len(r) < 20:
        return NA
    total = float((1.0 + r).prod() - 1.0)
    try:
        return float((1.0 + total) ** (TRADING_DAYS / len(r)) - 1.0)
    except Exception:
        return NA


def ann_vol(r: pd.Series) -> float:
    r = r.dropna()
    return float(r.std() * math.sqrt(TRADING_DAYS)) if len(r) >= 20 else NA


def max_drawdown(s: pd.Series) -> float:
    s = pd.Series(s).dropna()
    if len(s) < 20:
        return NA
    return float((s / s.cummax() - 1.0).min())


def underwater_days(s: pd.Series) -> float:
    """最长水下持续期（交易日）。"""
    s = pd.Series(s).dropna()
    if len(s) < 20:
        return NA
    dd = (s / s.cummax() - 1.0) < 0
    best = cur = 0
    for v in dd.values:
        cur = cur + 1 if v else 0
        best = max(best, cur)
    return float(best)


def downside_dev(r: pd.Series, rf: float) -> float:
    r = r.dropna()
    if len(r) < 20:
        return NA
    mar = rf / TRADING_DAYS
    d = r[r < mar] - mar
    if len(d) < 5:
        return NA
    return float(math.sqrt((TRADING_DAYS / len(r)) * float((d ** 2).sum())))


def omega_ratio(r: pd.Series, rf: float) -> float:
    r = r.dropna()
    if len(r) < 20:
        return NA
    tau = rf / TRADING_DAYS
    up = float((r - tau).clip(lower=0).sum())
    dn = float((tau - r).clip(lower=0).sum())
    return up / dn if dn > 0 else NA


def information_ratio(r: pd.Series, bm: pd.Series) -> float:
    common = r.dropna().index.intersection(pd.Series(bm).dropna().index)
    if len(common) < 60:
        return NA
    ri, rb = r.loc[common], pd.Series(bm).loc[common]
    te = float((ri - rb).std() * math.sqrt(TRADING_DAYS))
    if te <= 0 or math.isnan(te):
        return NA
    return float((ann_return(ri) - ann_return(rb)) / te)


def capture_ratio(r: pd.Series, bm: pd.Series) -> float:
    """🔧 v1.1 修正：CaptureSpread = UC − DC（原式 UC/DC 有符号缺陷）。

    缺陷复现（说明书 §3.1）：Down 集合内 R^bm < 0，若基金在下跌市中逆势上涨
    （mean(r) > 0），则 DC = 正/负 < 0 → UC/DC < 0，在"越大越好"的统一方向下
    **抗跌能力最强的基金反而被排到最后**。
        例：UC=1.05, DC=−0.30（熊市逆势涨）→ 比值 −3.5（末位）；差值 1.35（首位）✓
    仅保留比值口径作诊断，不得用于打分。
    """
    uc, dc = _capture_parts(r, bm)
    if uc is None or dc is None:
        return NA
    return float(uc - dc)


def capture_updown(r: pd.Series, bm: pd.Series) -> float:
    """诊断用：UC / DC 比值。DC ≤ 0.05 时该口径无意义，返回 NaN。"""
    uc, dc = _capture_parts(r, bm)
    if uc is None or dc is None or dc <= 0.05:
        return NA
    return float(uc / dc)


def _capture_parts(r: pd.Series, bm: pd.Series) -> Tuple[Optional[float], Optional[float]]:
    common = r.dropna().index.intersection(pd.Series(bm).dropna().index)
    if len(common) < 60:
        return None, None
    ri, rb = r.loc[common], pd.Series(bm).loc[common]
    up, dn = rb > 0, rb < 0
    if int(up.sum()) < 10 or int(dn.sum()) < 10:
        return None, None
    mu, md = float(rb[up].mean()), float(rb[dn].mean())
    if not mu or not md:
        return None, None
    return float(ri[up].mean() / mu), float(ri[dn].mean() / md)


def worst_rolling_return(s: pd.Series, window: int = L_M) -> float:
    s = pd.Series(s).dropna()
    if len(s) < window + 5:
        return NA
    rr = (s / s.shift(window) - 1.0).dropna()
    return float(rr.min()) if len(rr) else NA


def autocorr1(r: pd.Series) -> float:
    r = r.dropna()
    return float(r.autocorr(lag=1)) if len(r) >= 60 else NA


def momentum_12_3(s: pd.Series) -> float:
    """经典 12-3 动量 MOM^{[3,12]} = P[t-63] / P[t-252] - 1。

    🔧 v1.1：序列已 PIT 截断（末值 = P[t-1]），故 P[t-63] 即 iloc[-63]。
    旧实现用 iloc[-64]/iloc[-253]，在截断序列上等于又退了一天（右端点变 t-2）。
    """
    s = pd.Series(s).dropna()
    if len(s) < L_L + 2:
        return NA
    try:
        return float(s.iloc[-63] / s.iloc[-252] - 1.0)
    except Exception:
        return NA


def momentum_windows(s: pd.Series) -> Dict[str, float]:
    """§3.2 MOM^{[a,b]} 三档原始区间收益（右端点一律 t−1）。

        MOM^{[3,6]}  = P[t-63]  / P[t-126] - 1
        MOM^{[6,12]} = P[t-126] / P[t-252] - 1
        MOM^{[12,24]}= P[t-252] / P[t-504] - 1
    """
    s = pd.Series(s).dropna()
    out = {k: NA for k in ("mom_3_6", "mom_6_12", "mom_12_24")}
    try:
        if len(s) >= 130:
            out["mom_3_6"] = float(s.iloc[-63] / s.iloc[-126] - 1.0)
        if len(s) >= L_L + 2:
            out["mom_6_12"] = float(s.iloc[-126] / s.iloc[-252] - 1.0)
        if len(s) >= 506:
            out["mom_12_24"] = float(s.iloc[-252] / s.iloc[-504] - 1.0)
    except Exception:
        pass
    return out


def momentum_blend(s: pd.Series, weights: Optional[Sequence[float]] = None,
                   include_reversal: bool = False) -> float:
    """§3.2 多窗口动量合成 MOM^{blend}（解除 `__init__` 再导出的缺失符号）。

    🔧 v1.1 **推荐口径（默认）**：只取前三项，权重 0.294/0.412/0.294。
    原设计的第 4 项 `0.15·z(MOM^{[0,3]} reversed)` 就是短期反转，
    与独立的 `REV` 算子**重复计价** —— §6.1 的 D3 同时纳入 MOM^blend 与 REV，
    等于把反转信号算了两遍。反转只由 `rev` 承担。

    注意：说明书的 z(·) 是**横截面**标准化，单只基金内无法完成；
    真正的截面 z 合成在 `compute_factor_table` 里做并覆盖本列。
    本函数是"缺截面时的退化口径"（原始区间收益加权），单调可比但未经截面标准化。
    """
    w = momentum_windows(s)
    vals = [w["mom_3_6"], w["mom_6_12"], w["mom_12_24"]]
    ws = list(weights) if weights else list(MOM_BLEND_WEIGHTS)
    if include_reversal:
        vals.append(reversal_1m(s))
        ws = [0.25, 0.35, 0.25, 0.15]
    num = den = 0.0
    for v, wi in zip(vals, ws):
        if v is None or (isinstance(v, float) and math.isnan(v)):
            continue
        num += float(v) * float(wi)
        den += float(wi)
    return float(num / den) if den > 0 else NA


def residual_momentum(nav: pd.Series, style_rets: Optional[pd.DataFrame] = None,
                      mkt_rets: Optional[pd.Series] = None) -> float:
    """§3.2 残差动量 RMOM^{resid}：剥离市场与风格 Beta 后的纯 Alpha 动量。

    第一步：滚动 252 日回归 r_i = α + β^{mkt}·R^{mkt} + Σ_k β^k·f_k + ε
    第二步：累积残差收益（跳过近 3 个月，与经典动量对齐）
            RMOM^{resid} = Π_{s∈[t-252, t-63]} (1+ε_s) - 1

    数据不足或因子缺失 → NaN（绝不填 0）。
    """
    s = pd.Series(nav).dropna()
    if len(s) < L_L + 5:
        return NA
    r = s.pct_change().dropna().iloc[-L_L:]
    if len(r) < 60:
        return NA
    cols: Dict[str, pd.Series] = {}
    if mkt_rets is not None and len(mkt_rets):
        cols["mkt"] = pd.Series(mkt_rets).dropna()
    if style_rets is not None and not style_rets.empty:
        for c in style_rets.columns:
            cols[str(c)] = pd.to_numeric(style_rets[c], errors="coerce").dropna()
    if not cols:
        return NA
    X = pd.DataFrame(cols)
    idx = r.index
    for c in list(X.columns):
        idx = idx.intersection(X[c].index)
    if len(idx) < 60:
        return NA
    try:
        yv = r.loc[idx].astype(float).values
        Xv = np.column_stack([np.ones(len(idx))] + [X[c].loc[idx].astype(float).values
                                                    for c in X.columns])
        # lstsq 收到 NaN/Inf 会让 LAPACK 报 DLASCL 并返回垃圾系数；这里显式挡掉
        if not (np.all(np.isfinite(Xv)) and np.all(np.isfinite(yv))):
            return NA
        beta, *_ = np.linalg.lstsq(Xv, yv, rcond=None)
        eps = yv - Xv.dot(beta)
        if not np.all(np.isfinite(eps)):
            return NA
    except Exception:
        return NA
    # 跳过近 3 个月（63 交易日）：只累积 [t-252, t-63] 段
    eps = eps[: max(1, len(eps) - 63)]
    if len(eps) < 20:
        return NA
    return float(np.prod(1.0 + eps) - 1.0)


def reversal_1m(s: pd.Series) -> float:
    """短期反转 REV = -(P[t-1] / P[t-1-21] - 1)（🔧 v1.1 P0-4 已修正右端点）。"""
    s = pd.Series(s).dropna()
    if len(s) < 25:
        return NA
    try:
        return float(-(s.iloc[-1] / s.iloc[-22] - 1.0))
    except Exception:
        return NA


# ---------------------------------------------------------------------------
# 持仓穿透族（说明书 §3.4）
# ---------------------------------------------------------------------------

def _implied_prices(h: pd.DataFrame) -> Dict[str, float]:
    """用 持仓市值/持股数 反推个股价格（元/股）—— 免去额外行情源。

    数据可得性：fund_portfolio_hold_em 同时给出"持股数(万股)"与"持仓市值(万元)"，
    二者相除即为价格，因此隐含换手率的价格调整 g_k 不需要再取股票行情。
    """
    out: Dict[str, float] = {}
    if h is None or not len(h):
        return out
    for _, row in h.iterrows():
        try:
            mv = float(row.get("market_val"))
            sh = float(row.get("shares"))
            code = str(row.get("stock_code") or "")
        except (TypeError, ValueError):
            continue
        if code and sh > 0 and mv > 0:
            out[code] = mv / sh
    return out


def top10_weights(h: Optional[pd.DataFrame]) -> List[float]:
    if h is None or not len(h) or "weight" not in h.columns:
        return []
    w = pd.to_numeric(h["weight"], errors="coerce").dropna()
    return [float(x) for x in w.sort_values(ascending=False).head(10) if x > 0]


def implied_turnover(cur: Optional[pd.DataFrame], prev: Optional[pd.DataFrame]) -> float:
    """隐含换手率 = 1 - Σ_k min(w̃_q,k , w̃_{q-1,k}(1+g_k)/Σ[...])（说明书 §3.4）。"""
    if cur is None or prev is None or not len(cur) or not len(prev):
        return NA
    cw = pd.to_numeric(cur.get("weight"), errors="coerce")
    pw = pd.to_numeric(prev.get("weight"), errors="coerce")
    if cw is None or pw is None:
        return NA
    cur_map = {str(c): float(v) for c, v in zip(cur["stock_code"].astype(str), cw.fillna(0.0)) if float(v) > 0}
    prev_map = {str(c): float(v) for c, v in zip(prev["stock_code"].astype(str), pw.fillna(0.0)) if float(v) > 0}
    if not cur_map or not prev_map:
        return NA
    top = sorted(cur_map.items(), key=lambda kv: -kv[1])[:10]
    keys = [k for k, _ in top]
    sc = sum(v for _, v in top)
    if sc <= 0:
        return NA
    cur_n = {k: v / sc for k, v in top}
    pc, pp = _implied_prices(cur), _implied_prices(prev)
    adj: Dict[str, float] = {}
    for k in keys:
        base = prev_map.get(k)
        if not base or base <= 0:
            continue
        g = (pc[k] / pp[k] - 1.0) if (k in pc and k in pp and pp[k] > 0) else 0.0
        adj[k] = base * (1.0 + g)
    if not adj:
        return NA
    tot = sum(adj.values())
    if tot <= 0:
        return NA
    overlap = sum(min(cur_n.get(k, 0.0), v / tot) for k, v in adj.items())
    return float(1.0 - overlap)


def consensus_exposure(h: Optional[pd.DataFrame], consensus: set) -> float:
    """Cons_i = Σ_{k∈C} w_{i,k}（说明书 §3.4）。"""
    if h is None or not len(h) or not consensus:
        return NA
    w = pd.to_numeric(h.get("weight"), errors="coerce").fillna(0.0)
    codes = h["stock_code"].astype(str)
    return float(sum(float(v) for c, v in zip(codes, w) if c in consensus))


def build_consensus(holdings_map: Dict[str, pd.DataFrame], q: float = 0.90) -> set:
    """共识池 C(t)：N_k ≥ 90% 分位（说明书 §3.4）。"""
    counts: Dict[str, int] = {}
    for h in holdings_map.values():
        if h is None or not len(h):
            continue
        for c in set(h["stock_code"].astype(str)):
            counts[c] = counts.get(c, 0) + 1
    if not counts:
        return set()
    vals = sorted(counts.values())
    idx = min(len(vals) - 1, max(0, int(round(q * (len(vals) - 1)))))
    theta = vals[idx]
    return {c for c, n in counts.items() if n >= max(theta, 2)}


# ---------------------------------------------------------------------------
# 因子表
# ---------------------------------------------------------------------------

class FundData:
    """单只基金在决策日 t 的全部输入（全部已 PIT 截断）。"""

    __slots__ = ("code", "nav", "setup_date", "liquidation_date", "fund_type",
                 "fund_name", "scale_yi", "scale_hist", "fee", "tradable",
                 "holdings", "holdings_prev", "industry", "style_w", "style_w_prev",
                 "style_r2", "style_match", "inst_ratio")

    def __init__(self, code: str, nav: pd.Series, **kw):
        self.code = code
        self.nav = nav
        self.setup_date = kw.get("setup_date")
        self.liquidation_date = kw.get("liquidation_date")
        self.fund_type = kw.get("fund_type")
        self.fund_name = kw.get("fund_name")
        self.scale_yi = kw.get("scale_yi")
        self.scale_hist = kw.get("scale_hist") or []
        self.fee = kw.get("fee")
        self.tradable = kw.get("tradable")
        self.holdings = kw.get("holdings")
        self.holdings_prev = kw.get("holdings_prev")
        self.industry = kw.get("industry")
        self.style_w = kw.get("style_w")
        self.style_w_prev = kw.get("style_w_prev")
        self.style_r2 = kw.get("style_r2")
        self.style_match = kw.get("style_match")
        self.inst_ratio = kw.get("inst_ratio")


def _industry_weights(industry) -> Optional[pd.Series]:
    """把行业配置数据规整成 {行业: 权重}（占基金资产口径）。"""
    if industry is None:
        return None
    try:
        if isinstance(industry, pd.Series):
            s = pd.to_numeric(industry, errors="coerce")
        elif isinstance(industry, pd.DataFrame):
            col = None
            for c in ("占净值比例", "weight", "pct", "占比"):
                if c in industry.columns:
                    col = c
                    break
            if col is None:
                return None
            key = "行业" if "行业" in industry.columns else industry.columns[0]
            s = pd.to_numeric(industry.set_index(key)[col], errors="coerce")
        elif isinstance(industry, dict):
            s = pd.Series(industry, dtype=float)
        else:
            return None
        s = s.dropna()
        return s if len(s) else None
    except Exception:
        return None


def industry_hhi(industry) -> float:
    """§3.4 IndHHI_i = Σ_j (p_{i,q,j})²（行业集中度，越高越集中）。"""
    s = _industry_weights(industry)
    if s is None:
        return NA
    # 兼容"百分比"口径（合计≈100）与"小数"口径（合计≈1）
    v = s.values.astype(float)
    if np.nanmedian(np.abs(v)) > 1.5:
        v = v / 100.0
    return float(np.nansum(v ** 2))


def size_shock(scale_hist: Sequence[Tuple[str, float]],
               shock_thr: float = 1.0) -> float:
    """§3.6 SizeShock：单季规模翻倍 → 1（降权）。不足两期 → NaN（不猜）。"""
    try:
        hist = [(d, float(v)) for d, v in (scale_hist or ())
                if v is not None and not (isinstance(v, float) and math.isnan(float(v)))]
    except Exception:
        return NA
    if len(hist) < 2:
        return NA
    hist = sorted(hist, key=lambda x: str(x[0]))
    prev, cur = float(hist[-2][1]), float(hist[-1][1])
    if prev <= 0:
        return NA
    return 1.0 if (cur / prev - 1.0) > float(shock_thr) else 0.0


def single_fund_factors(d: "FundData", bm_rets: Optional[pd.Series] = None,
                        rf: float = 0.02,
                        style_rets: Optional[pd.DataFrame] = None) -> Dict[str, float]:
    """单只基金的原始因子（缺失=NaN，绝不填 0）。"""
    nav = pd.Series(d.nav).dropna() if d.nav is not None else pd.Series(dtype=float)
    if len(nav) < 30:
        return {}
    r_l = _rets(nav, L_L)
    nav_l = _nav_win(nav, L_L)
    nav_xl = _nav_win(nav, L_XL)
    mw = momentum_windows(nav)

    ar = ann_return(r_l)
    vol = ann_vol(r_l)
    f: Dict[str, float] = {
        # D1（🔧 v1.1：omega 移出打分，仅监控）
        "sharpe": (ar - rf) / vol if vol and vol > 0 and not math.isnan(vol) and not math.isnan(ar) else NA,
        "calmar": (ar / abs(max_drawdown(nav_l))) if (not math.isnan(ar)) and max_drawdown(nav_l) and max_drawdown(nav_l) < 0 else NA,
        "ir": information_ratio(r_l, bm_rets) if bm_rets is not None else NA,
        "omega": omega_ratio(r_l, rf),
        # D2（capture = CaptureSpread = UC − DC）
        "mdd": max_drawdown(nav_xl),
        "underwater": underwater_days(nav_xl),
        "sortino": ((ar - rf) / downside_dev(r_l, rf)) if not math.isnan(ar) else NA,
        "capture": capture_ratio(r_l, bm_rets) if bm_rets is not None else NA,
        "worst_dd": worst_rolling_return(nav, L_M),
        # D3（mom_blend 的截面 z 合成在 compute_factor_table 里覆盖）
        "mom_12_3": momentum_12_3(nav),
        "mom_3_6": mw["mom_3_6"],
        "mom_6_12": mw["mom_6_12"],
        "mom_12_24": mw["mom_12_24"],
        "mom_blend": momentum_blend(nav),
        "rmom_resid": residual_momentum(nav, style_rets=style_rets, mkt_rets=bm_rets),
        "rev": reversal_1m(nav),
        "rmom": NA,                       # 横截面分位：池阶段补
        # D4
        "r2": float(d.style_r2) if d.style_r2 is not None else NA,
        "style_consist": (float(_cos(d.style_w, d.style_w_prev)) if (d.style_w is not None and d.style_w_prev is not None) else NA),
        "ac1": autocorr1(r_l),
        # D5
        "hhi": float(sum(x * x for x in top10_weights(d.holdings))) if d.holdings is not None and len(d.holdings) else NA,
        "ind_hhi": industry_hhi(d.industry),
        # bet_dep 需 Brinson 归因（R_{i,j} 依赖行业指数收益，本机无源）→ 恒 NaN，
        # 按"数据诚实原则"不填 0、不猜；无该因子时 D5 权重在剩余因子间归一化。
        "bet_dep": NA,
        "imp_turnover": implied_turnover(d.holdings, d.holdings_prev),
        "cons": NA,                       # 需全池共识：池阶段补
        # D6
        "tc": float(sum(float((d.fee or {}).get(k) or 0.0)
                        for k in ("mgmt_rate", "custody_rate", "sales_service")))
        if any((d.fee or {}).get(k) is not None for k in ("mgmt_rate", "custody_rate", "sales_service")) else NA,
        "size_pct": float(d.scale_yi) if d.scale_yi is not None else NA,
        "size_shock": size_shock(d.scale_hist),
        "inst_ratio": float(d.inst_ratio) if d.inst_ratio is not None else NA,
    }
    return f


def _cos(a, b) -> float:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if a.size != b.size or not a.any() or not b.any():
        return NA
    na, nb = float(np.linalg.norm(a)), float(np.linalg.norm(b))
    return float(np.dot(a, b) / (na * nb)) if na and nb else NA


def compute_factor_table(data: Dict[str, "FundData"],
                         bm_rets: Optional[pd.Series] = None,
                         rf: float = 0.02,
                         style_rets: Optional[pd.DataFrame] = None,
                         codes: Optional[Sequence[str]] = None) -> pd.DataFrame:
    """行=基金、列=因子的**原始**因子表（不含任何横截面运算）。

    （2026-09-19 清理：移除了从未被使用的 `holdings_map` 形参——
    持仓族因子实际读 `FundData.holdings`，这个参数只会误导维护者
    以为 D5 在这里算。）

    🔧 v1.1 P0-1：横截面运算（rmom / cons / size_pct 的分位）全部下沉到
    `add_cross_sectional`，由调用方在**子池 U_c(t) 内**调用。
    原因见 §6.6：债基与股基的因子分布不可比，混在一起做横截面变换
    会让债基的 z 值系统性占优，池被债基占满。

    `codes` 可用于只算子集（子池循环时省算力）。
    """
    rows = {}
    for code, d in data.items():
        if codes is not None and code not in set(codes):
            continue
        try:
            rows[code] = single_fund_factors(d, bm_rets=bm_rets, rf=rf,
                                             style_rets=style_rets)
        except Exception:
            continue
    df = pd.DataFrame(rows).T if rows else pd.DataFrame()
    if df.empty:
        return df
    # ln(AUM)：§4.4 中性化的规模变量。原实现把 rank_pct 后的 size_pct 当 ln_size 用，
    # 那是分位数不是对数规模，中性化回归的解释变量口径错了 —— 这里补上真值。
    if "size_pct" in df.columns:
        raw_aum = pd.to_numeric(df["size_pct"], errors="coerce")
        df["ln_size"] = np.log(raw_aum.where(raw_aum > 0))
    return df


def add_cross_sectional(raw: pd.DataFrame,
                        holdings_map: Optional[Dict[str, pd.DataFrame]] = None
                        ) -> pd.DataFrame:
    """在**子池内**补横截面因子：rmom（动量分位）、cons（共识池暴露）、size_pct（规模分位）。

    必须在子池切片之后调用 —— 否则分位是拿债基跟股基比（§6.3 / §6.6）。
    """
    if raw.empty:
        return raw
    df = raw.copy()
    mom_col = "mom_12_3" if "mom_12_3" in df.columns else (
        "mom_blend" if "mom_blend" in df.columns else None)
    if mom_col:
        df["rmom"] = pd.to_numeric(df[mom_col], errors="coerce").rank(pct=True)
    if "size_pct" in df.columns:
        df["size_pct"] = pd.to_numeric(df["size_pct"], errors="coerce").rank(pct=True)
    if "ln_size" in df.columns and "size_pct" in df.columns:
        # ln_size 是中性化变量，保持原始对数值，不参与分位化
        pass
    sub = {c: h for c, h in (holdings_map or {}).items() if c in df.index}
    if sub:
        cons_pool = build_consensus(sub)
        df["cons"] = [consensus_exposure(sub.get(c), cons_pool) for c in df.index]
    return df


def blend_momentum_cross_section(raw: pd.DataFrame,
                                 weights: Optional[Sequence[float]] = None) -> pd.DataFrame:
    """§3.2 MOM^{blend} 的**横截面 z 合成**（说明书的 z(·) 是截面标准化）。

    MOM^{blend} = 0.294·z(MOM^{[3,6]}) + 0.412·z(MOM^{[6,12]}) + 0.294·z(MOM^{[12,24]})
    必须在子池内调用；某档缺失则该档不参与，权重在可得档间归一化。
    """
    if raw.empty:
        return raw
    df = raw.copy()
    cols = [c for c in ("mom_3_6", "mom_6_12", "mom_12_24") if c in df.columns]
    if not cols:
        return df
    ws = list(weights) if weights else list(MOM_BLEND_WEIGHTS)
    zs, wsel = [], []
    for c, w in zip(cols, ws[: len(cols)]):
        s = pd.to_numeric(df[c], errors="coerce")
        mu, sd = s.mean(skipna=True), s.std(skipna=True)
        zs.append((s - mu) / sd if (sd and not pd.isna(sd) and sd != 0) else s * 0.0)
        wsel.append(float(w))
    tot = pd.Series(0.0, index=df.index)
    wsum = pd.Series(0.0, index=df.index)
    for z, w in zip(zs, wsel):
        valid = z.notna()
        tot = tot.add((z.fillna(0.0) * w).where(valid, 0.0), fill_value=0.0)
        wsum = wsum + valid.astype(float) * w
    df["mom_blend"] = tot / wsum.where(wsum > 0, np.nan)
    return df


# ---------------------------------------------------------------------------
# 预处理（说明书 §4）
# ---------------------------------------------------------------------------

def winsorize_mad(df: pd.DataFrame, n: float = 5.0) -> pd.DataFrame:
    """MAD 去极值：clip 到 median ± n × 1.4826×MAD（基金因子厚尾，不用 3σ）。"""
    if df.empty:
        return df
    out = df.copy()
    for c in out.columns:
        s = pd.to_numeric(out[c], errors="coerce")
        med = s.median(skipna=True)
        mad = (s - med).abs().median(skipna=True)
        if pd.isna(med) or pd.isna(mad) or mad == 0:
            continue
        sigma = 1.4826 * float(mad)
        out[c] = s.clip(lower=med - n * sigma, upper=med + n * sigma)
    return out


def standardize(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    out = df.copy()
    for c in out.columns:
        s = pd.to_numeric(out[c], errors="coerce")
        mu, sd = s.mean(skipna=True), s.std(skipna=True)
        out[c] = (s - mu) / sd if (sd and not pd.isna(sd) and sd != 0) else s * 0.0
    return out


def interval_score(x: float, a: float, b: float) -> float:
    """g(x;a,b)：区间内 1.0，区间外线性衰减到 0（说明书 §4.6）。"""
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return NA
    if a <= x <= b:
        return 1.0
    dist = (a - x) if x < a else (x - b)
    return float(max(0.0, 1.0 - dist / (b - a)))


def fill_missing(df: pd.DataFrame, max_missing_rate: float = 0.20) -> pd.DataFrame:
    """§4.1 缺失值处理（**子池内**调用）：

    1) 缺失比例 ≤ 20% → 用子池中位数填充
    2) 缺失比例 > 20% → 该因子整列置 NULL（该因子族在本期不参与）
    3) 打分时按"可得因子权重归一化"，不对缺失基金惩罚性扣分

    §4.1 v1.1 说明：NULL 不能直接进 §4.4 的 OLS 与 §4.5 的 S^{-1/2}
    （n 不一致 / S 奇异）。这里采用**方案 1（推荐·迭代填充）**：
    先填中位数构造完整矩阵完成变换，再把原 NULL 位置重新置 NULL。
    """
    if df.empty:
        return df
    out = df.copy()
    n = len(out)
    for c in out.columns:
        s = pd.to_numeric(out[c], errors="coerce")
        miss = int(s.isna().sum())
        if miss == 0:
            continue
        if n > 0 and miss / float(n) > float(max_missing_rate):
            out[c] = np.nan              # 该因子族整体缺席
        else:
            med = s.median(skipna=True)
            out[c] = s.fillna(med) if not pd.isna(med) else s
    return out


def map_interval_factors(raw: pd.DataFrame,
                         intervals: Optional[Dict[str, Tuple[float, float]]] = None
                         ) -> pd.DataFrame:
    """§4.6 区间型因子映射 —— **必须在原始值上做**。

    ⚠️ 旧实现对 z-score 做 `interval_score(v, 0.02, 0.15)`，而区间是定义在
    HHI 原值（占净值比重的平方和）上的 —— 拿 z 值去比 0.02~0.15 毫无意义，
    几乎所有样本都会落到"区间外→衰减到 0"，该因子退化成常数。
    """
    if raw.empty:
        return raw
    table = dict(intervals or INTERVAL_FACTORS)
    out = raw.copy()
    for c, (a, b) in table.items():
        if c in out.columns:
            out[c] = pd.to_numeric(out[c], errors="coerce").map(
                lambda v: interval_score(v, a, b))
    return out


def direction_unify(z: pd.DataFrame) -> pd.DataFrame:
    """方向统一（越大越好）。区间映射已由 `map_interval_factors` 在原始值上完成。"""
    if z.empty:
        return z
    out = z.copy()
    for c in out.columns:
        if c in INTERVAL_FACTORS:
            continue                      # 已是正向的 g(x) ∈ [0,1]
        if not HIGHER_IS_BETTER.get(c, True):
            out[c] = -pd.to_numeric(out[c], errors="coerce")
    return out


def neutralize(z: pd.DataFrame, exog: pd.DataFrame, cols: Optional[Iterable[str]] = None,
               cond_max: float = 1e10) -> pd.DataFrame:
    """横截面 OLS 取残差（说明书 §4.4）：剥离规模/年龄/风格的共同影响。

    🔧 v1.1 P1-4 共线性修正：`w^{style}` 满足 Σ_k w_k = 1，若把全部 K 个风格权重
    放进回归再加截距 → 虚拟变量陷阱（设计矩阵秩亏），系数无解释意义、残差不稳定。
    调用方须**去掉一个风格维度**（见 `build_style_exog`）。
    本函数在回归前计算条件数，cond(X^T X) > cond_max 直接跳过并报警。

    exog 行需与 z 对齐；缺失值按截面中位数填（中性化变量缺失不是因子缺失，
    填中位数不会改变因子本身的缺失语义）。
    """
    if z.empty or exog is None or exog.empty:
        return z
    cols = list(cols) if cols is not None else [c for c in z.columns]
    X_df = exog.reindex(z.index)
    # 先剔掉含 NaN/Inf 的行与列：lstsq 收到 NaN 会让 LAPACK 报
    # "DLASCL parameter number 4 had an illegal value" 并返回垃圾系数。
    X_df = X_df.replace([np.inf, -np.inf], np.nan)
    keep = [c for c in X_df.columns if X_df[c].notna().sum() > max(5, 0.5 * len(X_df))]
    if not keep:
        return z
    X = X_df[keep].astype(float)
    med = X.median()
    if not np.all(np.isfinite(med.values)):
        keep = [c for c in keep if np.isfinite(float(med[c]))]
        if not keep:
            return z
        X = X[keep]
        med = X.median()
    X = X.fillna(med)
    # 全 NaN 列被填完后仍可能残留脏值，最后再兜一次底
    if not np.all(np.isfinite(X.values)):
        return z
    # 🟠 P1-3 修复（2026-09-26）：先剔**常数列**。
    #    实测条件数 1.47e+26（秩亏）的根因常常不是"忘了 drop_first"，
    #    而是某一列填完中位数后变成常数（该风格维度对所有标的都相同 ——
    #    RBSA 失败被填成均匀权重时就是这个形态），它与截距完全共线。
    #    常数列不含任何横截面信息，直接删掉即可，不必整层放弃。
    _std = X.std(axis=0)
    keep_cols2 = [c for c in X.columns if float(_std.get(c, 0.0) or 0.0) > 1e-8]
    dropped_const = [c for c in X.columns if c not in keep_cols2]
    if dropped_const:
        print(f"[neutralize] 剔除常数列 {dropped_const}（无横截面区分度）")
    X = X[keep_cols2]
    if X.shape[1] == 0:
        print("[neutralize] 剔除常数列后无可用解释变量，本次跳过中性化")
        return z
    Xv = np.column_stack([np.ones(len(X)), X.values])
    try:
        cond = float(np.linalg.cond(Xv.T.dot(Xv)))
    except Exception:
        cond = float("inf")
    ridge = 0.0
    if not np.isfinite(cond) or cond > float(cond_max):
        # 🟠 P1-3 修复续：旧实现在这里**直接 return z**，等于整层中性化静默失效
        #    —— 日志里只有一句告警，下游却以为中性化已经做过。
        #    现在降级到岭回归（Tikhonov 正则）：仍剥离大部分共同暴露，
        #    只是系数被收缩，比"完全不中性化"更接近设计意图。
        ridge = max(1e-6, float(np.trace(Xv.T.dot(Xv))) / max(len(Xv), 1) * 1e-4)
        print(f"[neutralize] 设计矩阵条件数 {cond:.3e} > {cond_max:.0e}，"
              f"降级为岭回归（λ={ridge:.2e}）—— 不再是「静默跳过」")
    out = z.copy()
    for c in cols:
        if c not in out.columns:
            continue
        y = pd.to_numeric(out[c], errors="coerce").replace([np.inf, -np.inf], np.nan)
        mask = y.notna().values
        if mask.sum() < max(8, 0.5 * len(y)):
            continue
        try:
            yv = y.values[mask].astype(float)
            Xs = Xv[mask]
            if not (np.all(np.isfinite(Xs)) and np.all(np.isfinite(yv))):
                continue
            if ridge > 0:
                # 岭回归：β = (X'X + λI)^{-1} X'y（X 为本因子有效样本的子阵）
                A = Xs.T.dot(Xs) + ridge * np.eye(Xs.shape[1])
                beta = np.linalg.solve(A, Xs.T.dot(yv))
            else:
                beta, *_ = np.linalg.lstsq(Xs, yv, rcond=None)
            resid = yv - Xs.dot(beta)
            if not np.all(np.isfinite(resid)):
                continue
        except Exception:
            continue
        sd = float(np.nanstd(resid))
        vals = pd.Series(np.nan, index=z.index)
        vals.loc[mask] = (resid / sd) if sd > 0 else 0.0
        out[c] = vals
    return out


def build_style_exog(style_w: Dict[str, Sequence[float]],
                     order: Optional[Sequence[str]] = None,
                     drop_first: bool = True) -> pd.DataFrame:
    """把 RBSA 风格权重整理成中性化的解释变量（🔧 v1.1 P1-4）。

    `drop_first=True` 时去掉第一个风格维度作为基准组 —— 因为 Σ_k w_k = 1，
    全量入回归 + 截距会造成完全共线性。
    """
    if not style_w:
        return pd.DataFrame()
    keys = list(order) if order else None
    rows = {}
    for code, w in style_w.items():
        if w is None:
            continue
        try:
            v = [float(x) for x in w]
        except Exception:
            continue
        if not v:
            continue
        # ⚠️ `float(nan)` / `float(inf)` **不会抛异常**，NaN 会一路混进中性化的
        #    设计矩阵。随后 np.linalg.lstsq 收到 NaN → LAPACK 打印
        #    "On entry to DLASCL parameter number 4 had an illegal value"
        #    并返回垃圾系数（实测回测日志里刷了 4 次）。
        #    风格权重来自 nnls 归一化，理论上有限；这里兜底挡住任何脏值。
        if not np.all(np.isfinite(v)):
            continue
        rows[code] = v
    if not rows:
        return pd.DataFrame()
    n_dim = min(len(v) for v in rows.values())
    if keys is None:
        keys = [f"style_{i}" for i in range(n_dim)]
    keys = list(keys)[:n_dim]
    if drop_first and n_dim > 1:
        keys = keys[1:]
        start = 1
    else:
        start = 0
    data = {}
    for i, k in enumerate(keys):
        data[k] = {code: v[start + i] for code, v in rows.items()}
    return pd.DataFrame(data)


def symmetric_orthogonalize(z: pd.DataFrame, cond_max: float = 1e8) -> pd.DataFrame:
    """对称正交 Z·S^{-1/2}（说明书 §4.5，Löwdin）。病态矩阵直接放弃。"""
    if z.empty or z.shape[1] < 2:
        return z
    X = z.fillna(0.0).astype(float).values
    n = X.shape[0]
    S = X.T.dot(X) / float(n)
    try:
        w, U = np.linalg.eigh(S)
        if np.min(np.abs(w)) <= 1e-12 or np.max(np.abs(w)) / max(np.min(np.abs(w)), 1e-12) > cond_max:
            return z
        Sinv = U.dot(np.diag(1.0 / np.sqrt(np.abs(w)))).dot(U.T)
    except Exception:
        return z
    return pd.DataFrame(X.dot(Sinv), index=z.index, columns=z.columns)


def preprocess_factors(raw: pd.DataFrame, exog: Optional[pd.DataFrame] = None,
                       neutralize_cols: Optional[Iterable[str]] = None,
                       mad_n: float = 5.0, orthogonalize: bool = False,
                       max_missing_rate: float = 0.20) -> pd.DataFrame:
    """§4 全流程（🔧 v1.1 顺序修正）：

        缺失值(§4.1) → 区间映射(§4.6，原始值) → 去极值(§4.2)
        → 标准化(§4.3) → 方向统一(§4.6) → 中性化(§4.4) → 正交化(§4.5)

    必须在**子池 U_c(t) 内**调用（P0-1）。
    """
    if raw.empty:
        return raw
    z = fill_missing(raw, max_missing_rate=max_missing_rate)
    z = map_interval_factors(z)          # 区间映射必须在原始值上做
    z = winsorize_mad(z, n=mad_n)
    z = standardize(z)
    z = direction_unify(z)
    if exog is not None and neutralize_cols:
        z = neutralize(z, exog, cols=neutralize_cols)
    if orthogonalize:
        z = symmetric_orthogonalize(z)
    return z
