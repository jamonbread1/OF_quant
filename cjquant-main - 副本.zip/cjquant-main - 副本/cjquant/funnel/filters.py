# -*- coding: utf-8 -*-
"""L2 准入层：说明书 §2 的 H1~H8 硬性剔除（0/1 判定，不参与打分）。

⚠️ 每条规则必须是三种结论之一：通过 / 剔除 / **未校验(unverified)**。
   数据不可得时**既不拦截也不假装通过**，而是记进 unverified 清单由上层显式列出 ——
   把"没数据"当成"没问题"会让回测好看，但实盘风险一条不少。

unverified 三类成因（处置不同，详见 docs/设计说明-持仓与准入.md）：
   1. 本机尚未同步 → 跑 data_ops 同步即可补齐；
   2. 字段无历史、用今日快照判历史会前视（H4）→ 仅在快照有效期 ±7 天内启用；
   3. 数据源根本没有该字段 → 长期记未校验，除非接入新源。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

# 说明书 §1.3 的 Δ（自然日）
LAG_QUARTER_DAYS = 25
LAG_HALF_YEAR_DAYS = 60
LAG_YEAR_DAYS = 90

# 说明书 §2 H5 的各类型综合费率上限（%）
TC_MAX_BY_TYPE: Dict[str, float] = {
    "指数": 0.8, "增强": 0.8,
    "股票": 1.8, "偏股": 1.8, "灵活配置": 1.8,
    "偏债": 1.2, "债券": 0.7, "纯债": 0.7,
    "QDII": 1.8, "黄金": 0.7, "商品": 0.7,
}
TC_MAX_DEFAULT = 1.8


@dataclass
class FilterConfig:
    min_age_years: float = 3.0          # H1
    min_age_years_soft: float = 2.0     # 2~3 年 → Flag_YoungFund（降权而非剔除）
    tenure_min_days: int = 504          # H2 现任经理可考察任期下限（自然日，≈2 年）
    aum_min_yi: float = 2.0             # H3
    aum_max_yi: float = 300.0           # H3
    liq_warn_yi: float = 0.5            # 连续 2 期低于此值 → 清盘预警
    liq_shock_yi: float = 0.8           # 单期 <0.8 亿且缩水 >30% → 预警
    buy_fee_max: float = 0.015          # H5 折后申购费率上限
    style_match_min: float = 0.6        # H7
    miss_rate_max: float = 0.01         # H8
    max_gap_days: int = 5               # H8
    jump_abs: float = 0.25              # H8 单日跳变阈值


@dataclass
class FundFacts:
    """决策日 t 上，一只基金可获得的全部事实（全部已 PIT 截断）。"""
    code: str
    nav: Optional[pd.Series] = None            # 复权净值，右端点 t-1
    setup_date: Optional[str] = None
    liquidation_date: Optional[str] = None
    fund_type: Optional[str] = None
    fund_name: Optional[str] = None
    scale_yi: Optional[float] = None           # PIT 规模（亿元）
    scale_hist: Sequence[Tuple[str, float]] = ()   # [(report_date, scale_yi)]，已按 PIT 过滤
    fee: Optional[dict] = None                 # mgmt/custody/sales_service/buy_rate...
    tradable: Optional[bool] = None            # None=未知（不拦）
    manager_tenure_days: Optional[int] = None  # H2：现任经理可考察任期（自然日）
    limited_purchase: Optional[bool] = None    # H4：限大额（软旗标，不剔除）
    close_ended: Optional[str] = None          # H4：下一开放日；非 None ⇒ 定开/持有期
    style_match: Optional[float] = None        # H7（需 RBSA）
    style_r2: Optional[float] = None
    style_na_reason: Optional[str] = None      # H7 未校验原因：not_applicable / rbsa_failed
    inst_ratio: Optional[float] = None         # H6：机构持有比例（小数）


@dataclass
class FilterResult:
    passed: bool
    reasons: List[str] = field(default_factory=list)      # 被剔除的原因
    unverified: List[str] = field(default_factory=list)   # 数据缺失、本次未校验的规则
    flags: List[str] = field(default_factory=list)        # 软性旗标（降权/观察）


def _age_years(asof: pd.Timestamp, setup: Optional[str], nav: Optional[pd.Series]) -> Optional[float]:
    if setup:
        try:
            return (asof - pd.Timestamp(str(setup)[:10])).days / 365.25
        except Exception:
            return None
    if nav is not None and len(nav) > 0:
        # 用净值首日代理成立日（不如事实准，但比"不算"强）
        try:
            return (asof - pd.Timestamp(nav.index[0])).days / 365.25
        except Exception:
            return None
    return None


def _data_quality(nav: pd.Series, cfg: FilterConfig,
                  calendar: Optional[pd.DatetimeIndex] = None) -> Tuple[Optional[float], int, bool]:
    """(缺失率, 最长连续缺失交易日, 是否有异常单日跳变)。

    ⚠️ `calendar` 必须是**市场自身的交易日历**，不能用 `freq="B"` 生成：
        A 股/场外基金一年约 243 个交易日，而周一~周五约 261 天。
        用 freq="B" 当基准，一条**完整无缺失**的净值序列也会被算出约 7% 的
        缺失率 → 远超 H8 的 1% 阈值 → 整个候选池被误杀光。
        实测：漏斗回测因此每个月都是"准入通过 0、零成交"，而调度任务却正常
        （任务走的 create_universe_panel(freq="B") 已把非交易日填满）。
    """
    if nav is None or len(nav) < 30:
        return None, 0, False
    s = nav.dropna()
    if len(s) < 2:
        return None, 0, False
    if calendar is not None and len(calendar) > 0:
        cal = pd.DatetimeIndex(pd.Index(calendar).dropna().unique()).sort_values()
        idx = cal[(cal >= s.index.min()) & (cal <= s.index.max())]
    else:
        idx = pd.date_range(s.index.min(), s.index.max(), freq="B")
    if len(idx) == 0:
        return None, 0, False
    miss_rate = 1.0 - len(s) / float(len(idx))
    # 最长连续缺失
    filled = s.reindex(idx)
    isna = filled.isna().values
    gap = cur = 0
    for flag in isna:
        cur = cur + 1 if flag else 0
        gap = max(gap, cur)
    rets = s.pct_change().dropna()
    jump = bool((rets.abs() > cfg.jump_abs).any()) if len(rets) else False
    return float(miss_rate), int(gap), jump


def _tc_of(fee: Optional[dict]) -> Optional[float]:
    if not fee:
        return None
    vals = [fee.get(k) for k in ("mgmt_rate", "custody_rate", "sales_service")]
    vals = [float(v) for v in vals if v is not None]
    return sum(vals) if vals else None


def _tc_max_for(fund_type: Optional[str]) -> float:
    t = str(fund_type or "")
    for key, cap in TC_MAX_BY_TYPE.items():
        if key in t:
            return cap
    return TC_MAX_DEFAULT


def hard_filters(facts: FundFacts, asof: pd.Timestamp,
                 cfg: Optional[FilterConfig] = None,
                 calendar: Optional[pd.DatetimeIndex] = None) -> FilterResult:
    """说明书 §2 的 8 条硬性剔除。返回 FilterResult（含未校验清单）。

    calendar: 市场交易日历（用于 H8 缺失率）。传 None 会退回 freq="B"，
    在 A 股/场外口径下会把完整序列误判为高缺失（见 `_data_quality` 的说明）。
    """
    cfg = cfg or FilterConfig()
    reasons: List[str] = []
    unverified: List[str] = []
    flags: List[str] = []

    # ---------- H1 成立年限 ----------
    age = _age_years(asof, facts.setup_date, facts.nav)
    if age is None:
        unverified.append("H1(成立日缺失)")
    else:
        if age < cfg.min_age_years_soft:
            reasons.append(f"H1 成立不足{cfg.min_age_years_soft}年(age={age:.1f})")
        elif age < cfg.min_age_years:
            flags.append("Flag_YoungFund")

    # ---------- H2 基金经理任期 ----------
    # 数据源：F10 jjjl「基金经理变动一览」（fund_reports.fetch_manager_tenure）。
    # 口径见 ReportStore.manager_tenure_days —— 取**现任经理们最早的任职起始**，
    # 因为 F10 每行是"一次成员变更"，只看最后一行会把老经理误判成刚上任。
    td = facts.manager_tenure_days
    if td is None:
        unverified.append("H2(经理任期无数据源)")
    elif int(td) < int(cfg.tenure_min_days):
        reasons.append(f"H2 现任经理任期{int(td)}日 < {cfg.tenure_min_days}日")

    # ---------- H3 规模区间与清盘预警 ----------
    if facts.liquidation_date:
        reasons.append(f"H3 已清盘({str(facts.liquidation_date)[:10]})")
    if facts.scale_yi is None:
        unverified.append("H3(规模缺失)")
    else:
        if facts.scale_yi < cfg.aum_min_yi:
            reasons.append(f"H3 规模{facts.scale_yi:.2f}亿 < {cfg.aum_min_yi}亿")
        elif facts.scale_yi > cfg.aum_max_yi:
            reasons.append(f"H3 规模{facts.scale_yi:.0f}亿 > {cfg.aum_max_yi}亿")
    hist = [h for h in (facts.scale_hist or []) if h and h[1] is not None]
    if len(hist) >= 2:
        last2 = sorted(hist)[-2:]
        if all(float(v) < cfg.liq_warn_yi for _, v in last2):
            flags.append("Flag_Liquidation")
            reasons.append("H3 清盘预警(连续2期<0.5亿)")
        else:
            cur = float(last2[-1][1])
            prev = float(last2[-2][1])
            if cur < cfg.liq_shock_yi and prev > 0 and (cur / prev - 1.0) < -0.30:
                flags.append("Flag_Liquidation")
                reasons.append("H3 清盘预警(规模<0.8亿且缩水>30%)")
    else:
        unverified.append("H3(规模历史不足2期)")

    # ---------- H4 可交易性与容量 ----------
    # ⚠️ `tradable` 只在快照有效期内才被 pipeline 填上：申赎状态**没有历史**
    #    （东财只给当日），拿今天的快照去判历史决策日属于前视偏差。None 表示
    #    "该决策日的时点状态不可得"，如实记未校验，而不是假装通过。
    if facts.tradable is False:
        reasons.append("H4 暂停申购/赎回")
    elif facts.tradable is None:
        unverified.append("H4(申赎状态缺失)")
    elif facts.limited_purchase:
        # 限大额不剔除（仍可申购，只是有额度），但要点名 —— 大额资金实际买不进去。
        flags.append("Flag_LimitedPurchase")
    # H4 定开/持有期（修复方案 v1.0 §3.2）：`下一开放日` 是免费的结构化代理 ——
    # 实测开放基金=NaT，定开基金=具体日期。非 NULL 即"有封闭期/开放期安排"。
    # 保守口径：距下一开放日 > 90 天 ⇒ 现在买进去要锁很久，剔除；否则只标记。
    if facts.close_ended:
        try:
            gap = (pd.Timestamp(str(facts.close_ended)[:10])
                   - pd.Timestamp(asof).normalize()).days
        except Exception:
            gap = None
        if gap is not None and gap > 90:
            reasons.append(f"H4 定开/持有期，距下一开放日>{gap}天")
        else:
            flags.append("Flag_CloseEnded")
    elif any(k in str(facts.fund_name or "") for k in ("持有期", "定开", "封闭", "锁定")):
        # 名称兜底：部分持有期基金在批量接口里 next_open_date 为空
        flags.append("Flag_CloseEnded")

    # ---------- H5 费率与持有期约束 ----------
    tc = _tc_of(facts.fee)
    if tc is None:
        unverified.append("H5(费率缺失)")
    else:
        cap = _tc_max_for(facts.fund_type)
        if tc > cap:
            reasons.append(f"H5 综合费率{tc:.2f}% > 上限{cap}%")
    buy = (facts.fee or {}).get("buy_rate_disc")
    if buy is None:
        unverified.append("H5(申购费率缺失)")
    else:
        try:
            if float(buy) / 100.0 > cfg.buy_fee_max:
                reasons.append(f"H5 折后申购费{float(buy):.2f}% > {cfg.buy_fee_max*100:.1f}%")
        except (TypeError, ValueError):
            unverified.append("H5(申购费率不可解析)")

    # ---------- H6 持有人结构 ----------
    # 数据源：F10 cyrjg（半年报/年报口径，带 PIT 可用日）。
    if facts.inst_ratio is None:
        unverified.append("H6(该基金无持有人结构数据)")
    else:
        if facts.inst_ratio > 0.80:
            reasons.append(f"H6 机构占比{facts.inst_ratio:.0%} > 80%")

    # ---------- H7 风格纯净度 ----------
    # ⚠️ 必须同时判 nan：style_match 在「向量长度不匹配 / 范数为 0」时返回 nan，
    #    而 nan 既不是 None 也不 < 阈值 —— 只判 None 会让这类基金**静默通过**
    #    H7 且不计入未校验清单（最坏的一种：假装校验过了）。
    sm = facts.style_match
    if sm is None or not np.isfinite(float(sm)):
        # H7 分级（修复方案 v1.0 §3.6）："类型不适用"是**设计意图**
        # （货币/FOF/QDII/商品的收益来源无法用 5 个风格因子表达），
        # 与"RBSA 真失败"（要修的）必须分开列，否则后者会被前者淹没。
        if getattr(facts, "style_na_reason", None) == "not_applicable":
            unverified.append("H7(类型不适用风格约束)")
        else:
            unverified.append("H7(风格暴露缺失)")
    else:
        if float(sm) < cfg.style_match_min:
            reasons.append(f"H7 风格纯净度{float(sm):.2f} < {cfg.style_match_min}")

    # ---------- H8 数据质量 ----------
    miss_rate, gap, jump = _data_quality(facts.nav, cfg, calendar=calendar)
    if miss_rate is None:
        reasons.append("H8 净值序列过短(<30点)")
    else:
        if miss_rate > cfg.miss_rate_max:
            reasons.append(f"H8 缺失率{miss_rate:.2%} > {cfg.miss_rate_max:.0%}")
        if gap > cfg.max_gap_days:
            reasons.append(f"H8 连续缺失{gap}日 > {cfg.max_gap_days}日")
        if jump:
            # 无法区分分红/拆分导致的跳变（无分红日历）—— 只做旗标，不直接剔除，
            # 避免把高分红基金误杀；说明书原文是"剔除"，此处注明放宽理由。
            flags.append("Flag_NavJump")

    return FilterResult(passed=not reasons, reasons=reasons,
                        unverified=sorted(set(unverified)), flags=sorted(set(flags)))
