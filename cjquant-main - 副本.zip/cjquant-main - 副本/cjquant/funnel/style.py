# -*- coding: utf-8 -*-
"""L3-D4 风格暴露：风格因子指数 + RBSA（约束最小二乘）。

⚠️ 指数源必须用新浪/腾讯双源回退（`stock_zh_index_daily` / `_tx`），
   不要换回 `ak.index_zh_a_hist`：它走 `80.push2.eastmoney.com`，
   实测直连与走代理**均不可达**（与该域名是否走代理无关）。
   另注：主域名 push2.eastmoney.com 走代理反而能通、直连 502，
   "代理"对不同域名影响相反，排查时别一概而论。

指数对应说明书 §3.3：大盘成长 sh000918 / 大盘价值 sh000919 / 中盘 sh000905
/ 小盘 sh000852 / 利率债 sh000012。
"""
from __future__ import annotations

import os
import time
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

STYLE_INDEXES: Dict[str, str] = {
    "大盘成长": "sh000918",
    "大盘价值": "sh000919",
    "中盘": "sh000905",
    "小盘": "sh000852",
    "利率债": "sh000012",
}

BENCHMARK_SYMBOLS: Dict[str, str] = {
    "沪深300": "sh000300",
    "中证800": "sh000906",
}

_CACHE_TTL = 24 * 3600

# 指数数据的末值允许的最大滞后（自然日）。超过就认为该源已停更。
_STALE_DAYS = 20


def _fetch_index_sina(symbol: str) -> pd.Series:
    """新浪源。对多数指数可用，但实测**部分指数已停更**（见 load_index_prices）。"""
    import akshare as ak
    df = ak.stock_zh_index_daily(symbol=symbol)
    return pd.Series(df["close"].values,
                     index=pd.to_datetime(df["date"])).sort_index()


def _fetch_index_tx(symbol: str) -> pd.Series:
    """腾讯源。指数覆盖面与新浪相同、数值口径一致，且对新浪停更的那两个是活的。"""
    import akshare as ak
    df = ak.stock_zh_index_daily_tx(symbol=symbol)
    if df is None or len(df) == 0:
        raise RuntimeError("empty")
    col = "close" if "close" in df.columns else df.columns[-1]
    dcol = "date" if "date" in df.columns else df.columns[0]
    return pd.Series(pd.to_numeric(df[col], errors="coerce").values,
                     index=pd.to_datetime(df[dcol])).dropna().sort_index()


# 取数源按序尝试；只要拿到"足够新"的数据就停止，否则取各源里末值最新的那份。
INDEX_SOURCES = (("sina", _fetch_index_sina), ("tx", _fetch_index_tx))


def _project_root() -> str:
    d = os.path.dirname(os.path.abspath(__file__))
    while True:
        if os.path.exists(os.path.join(d, "run_gui.py")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            return os.path.dirname(os.path.dirname(d))
        d = parent


def _cache_dir() -> str:
    p = os.path.join(_project_root(), ".cache", "cjquant", "funnel")
    os.makedirs(p, exist_ok=True)
    return p


def load_index_prices(symbol: str, use_cache: bool = True) -> pd.Series:
    """取单个指数的收盘价序列（date index）。多源回退 + 陈旧数据自动绕开。

    ⚠️ 为什么必须多源：新浪源对**部分指数已停止更新** —— 本机实测
       沪深300成长(sh000918) 末值停在 2021-02-04、沪深300价值(sh000919) 停在 2019-01-30。
       而这两个指数正是 D4 风格族与 H7 的输入：只用新浪源的话，"最近 756 个交易日"
       的窗口整段是 NaN → RBSA 恒失败 → H7 与 style_r2 永久失效
       （表现为日志里 D4 只有 1 个维度可用）。腾讯源对同一指数给到最新交易日，
       数值口径一致，所以这里做多源回退而不是换指数（换指数会改变策略定义）。

    ⚠️ 缓存也要看新鲜度，不能只看 mtime：修好数据源后，旧缓存（mtime 很新、
       但内容是停更源的旧序列）会把修复挡住。
    """
    path = os.path.join(_cache_dir(), f"idx_{symbol}.csv")
    if use_cache and os.path.exists(path):
        try:
            if time.time() - os.path.getmtime(path) < _CACHE_TTL:
                s = pd.read_csv(path, index_col=0, parse_dates=True).iloc[:, 0]
                if len(s) > 0:
                    s = s.sort_index()
                    if (pd.Timestamp.today().normalize() - s.index.max()).days <= _STALE_DAYS:
                        return s
        except Exception:
            pass

    best: Optional[pd.Series] = None
    for _name, fn in INDEX_SOURCES:
        try:
            s = fn(symbol)
        except Exception:
            continue
        if s is None or len(s) < 2:
            continue
        s = s.dropna().sort_index()
        if best is None or s.index.max() > best.index.max():
            best = s
        if (pd.Timestamp.today().normalize() - s.index.max()).days <= _STALE_DAYS:
            break                      # 已经足够新，不必再打下一个源
    if best is None:
        raise RuntimeError(f"指数 {symbol} 在全部数据源上均取数失败")
    best.name = symbol
    try:
        best.to_csv(path, encoding="utf-8-sig")
    except Exception:
        pass
    return best


# ⚠️ 2026-09-26：这里原来有两组同名的 `load_style_prices` / `load_benchmark_prices`
# 定义（AST 检查发现 Line133/155 与 Line170/192 重复）。Python 会用**后定义的**
# 覆盖先定义的，所以先写那一组是纯粹不可达的死代码，且两者文档字符串略有出入，
# 排查时极易照着失效的那份理解。现删除前面那组，运行时行为完全不变。


def load_style_prices(symbols: Optional[Dict[str, str]] = None,
                      start: Optional[str] = None,
                      end: Optional[str] = None,
                      use_cache: bool = True) -> pd.DataFrame:
    """风格因子**收盘价**宽表（择时/诊断用；RBSA 用它的收益率版本）。"""
    mapping = dict(symbols or STYLE_INDEXES)
    cols: Dict[str, pd.Series] = {}
    for name, sym in mapping.items():
        try:
            cols[name] = load_index_prices(sym, use_cache=use_cache)
        except Exception:
            continue
    if not cols:
        return pd.DataFrame()
    px = pd.DataFrame(cols).sort_index()
    if start:
        px = px[px.index >= pd.Timestamp(start)]
    if end:
        px = px[px.index <= pd.Timestamp(end)]
    return px


def load_benchmark_prices(name: str = "沪深300", start: Optional[str] = None,
                          end: Optional[str] = None, use_cache: bool = True) -> pd.Series:
    """基准指数收盘价（均线偏离/趋势开关要用**价格**而不是收益率）。"""
    sym = BENCHMARK_SYMBOLS.get(name, "sh000300")
    try:
        s = load_index_prices(sym, use_cache=use_cache)
    except Exception:
        return pd.Series(dtype=float)
    if start:
        s = s[s.index >= pd.Timestamp(start)]
    if end:
        s = s[s.index <= pd.Timestamp(end)]
    return s


def load_style_returns(symbols: Optional[Dict[str, str]] = None,
                       start: Optional[str] = None,
                       end: Optional[str] = None,
                       use_cache: bool = True) -> pd.DataFrame:
    """风格因子日收益矩阵（列=风格名，行=日期）。取不到的列直接缺失（不填 0）。"""
    mapping = dict(symbols or STYLE_INDEXES)
    cols: Dict[str, pd.Series] = {}
    for name, sym in mapping.items():
        try:
            s = load_index_prices(sym, use_cache=use_cache)
            cols[name] = s
        except Exception:
            continue
    if not cols:
        return pd.DataFrame()
    px = pd.DataFrame(cols).sort_index()
    if start:
        px = px[px.index >= pd.Timestamp(start)]
    if end:
        px = px[px.index <= pd.Timestamp(end)]
    return px.pct_change().dropna(how="all")


def load_benchmark_returns(name: str = "沪深300", start: Optional[str] = None,
                           end: Optional[str] = None, use_cache: bool = True) -> pd.Series:
    sym = BENCHMARK_SYMBOLS.get(name)
    if not sym:
        return pd.Series(dtype=float)
    s = load_index_prices(sym, use_cache=use_cache)
    if start:
        s = s[s.index >= pd.Timestamp(start)]
    if end:
        s = s[s.index <= pd.Timestamp(end)]
    return s.pct_change().dropna()


# ---------------------------------------------------------------------------
# RBSA
# ---------------------------------------------------------------------------

def solve_style_exposure(fund_ret: pd.Series, style_ret: pd.DataFrame,
                         window: int = 756) -> Optional[np.ndarray]:
    """约束最小二乘 min‖r - F·w‖², s.t. w ≥ 0, Σw = 1。

    实现：scipy.optimize.nnls 求非负解后归一化到和为 1。
    （与 SLSQP 在绝大多数样本上一致，但快 1~2 个数量级，适合回测里逐月逐基金调用。）
    """
    if fund_ret is None or style_ret is None or style_ret.empty:
        return None
    fr = pd.to_numeric(pd.Series(fund_ret), errors="coerce")
    idx = style_ret.index.intersection(fr.dropna().index)
    idx = idx[-window:] if len(idx) > window else idx
    if len(idx) < 60:
        return None
    F_df = style_ret.loc[idx].apply(pd.to_numeric, errors="coerce")
    r_s = fr.loc[idx]
    n = len(idx)
    # 列筛选：窗口内可用率 < 90% 的因子不参与回归（权重留 0，维度不变）。
    keep = [c for c in F_df.columns if int(F_df[c].notna().sum()) >= 0.9 * n]
    if len(keep) < 2:
        return None
    usable = F_df[keep]
    # 行筛选：只保留"基金收益 + 参与回归的因子"都齐全的观测日。
    mask = usable.notna().all(axis=1).values & r_s.notna().values
    if int(mask.sum()) < 60:
        return None
    F = usable.values[mask].astype(float)
    r = r_s.values[mask].astype(float)
    if not (np.all(np.isfinite(F)) and np.all(np.isfinite(r))):
        return None
    try:
        from scipy.optimize import nnls
        w_sub, _ = nnls(F, r)
    except Exception:
        return None
    total = float(w_sub.sum())
    if not np.isfinite(total) or total <= 0:
        return None
    # 展开回 style_ret 的原始列序，保证返回向量的**长度与列序恒定** ——
    # 调用方（style_match / style_r2）按位置对齐，维度一变就会静默返回 nan。
    w = np.zeros(len(F_df.columns), dtype=float)
    pos = {c: i for i, c in enumerate(F_df.columns)}
    for j, c in enumerate(keep):
        w[pos[c]] = w_sub[j]
    return w / w.sum()


def style_r2(fund_ret: pd.Series, style_ret: pd.DataFrame, w: np.ndarray,
             window: int = 756) -> float:
    """R² = 1 - SSE/SST（说明书 §3.3）。"""
    idx = style_ret.index.intersection(fund_ret.dropna().index)
    idx = idx[-window:] if len(idx) > window else idx
    if len(idx) < 60 or w is None:
        return float("nan")
    F_df = style_ret.loc[idx].apply(pd.to_numeric, errors="coerce")
    r_s = pd.to_numeric(pd.Series(fund_ret), errors="coerce").loc[idx]
    wv = np.asarray(w, dtype=float)
    if F_df.shape[1] != len(wv):
        return float("nan")
    # ⚠️ 必须先做行筛选：`F.dot(w)` 遇到任一分量为 NaN 会把**整个预测序列**变成 NaN，
    #    SSE/SST 全成 nan → R² 失真。风格因子的可得区间天然不齐（中证1000 自 2014
    #    才有数据），所以这里只保留全齐的观测日，而不是让 nan 扩散。
    mask = F_df.notna().all(axis=1).values & r_s.notna().values
    if int(mask.sum()) < 60:
        return float("nan")
    F = F_df.values[mask].astype(float)
    r = r_s.values[mask].astype(float)
    pred = F.dot(wv)
    sse = float(np.sum((r - pred) ** 2))
    sst = float(np.sum((r - r.mean()) ** 2))
    if sst <= 0:
        return float("nan")
    return 1.0 - sse / sst


def style_drift(w_prev: np.ndarray, w_curr: np.ndarray) -> float:
    """相邻两期风格暴露的 L2 距离（说明书 §3.3 Drift）。"""
    if w_prev is None or w_curr is None:
        return float("nan")
    if len(w_prev) != len(w_curr):
        return float("nan")
    return float(np.sqrt(np.sum((np.asarray(w_curr) - np.asarray(w_prev)) ** 2)))


def style_consistency(w_prev: np.ndarray, w_curr: np.ndarray) -> float:
    """StyleConsist = cos 相似度（说明书 §3.3）。"""
    if w_prev is None or w_curr is None:
        return float("nan")
    a = np.asarray(w_prev, dtype=float)
    b = np.asarray(w_curr, dtype=float)
    na, nb = float(np.linalg.norm(a)), float(np.linalg.norm(b))
    if na == 0 or nb == 0:
        return float("nan")
    return float(np.dot(a, b) / (na * nb))


def style_match(w_cls: Sequence[float], w_rbsa: np.ndarray) -> float:
    """H7 StyleMatch = cos(类型标准风格向量, RBSA 实际暴露)（说明书 §2 H7）。"""
    if w_rbsa is None:
        return float("nan")
    a = np.asarray(list(w_cls), dtype=float)
    b = np.asarray(w_rbsa, dtype=float)
    if len(a) != len(b):
        return float("nan")
    na, nb = float(np.linalg.norm(a)), float(np.linalg.norm(b))
    if na == 0 or nb == 0:
        return float("nan")
    return float(np.dot(a, b) / (na * nb))


# 类型 -> 标准风格向量（列顺序与 STYLE_INDEXES 一致：大盘成长/大盘价值/中盘/小盘/利率债）
# 这是**经验设定**，不是数据源事实 —— 只有当 fund_type 能明确归类时才使用。
STYLE_VECTOR_BY_TYPE: Dict[str, List[float]] = {
    "股票型": [0.35, 0.25, 0.25, 0.15, 0.0],
    "偏股混合": [0.30, 0.25, 0.25, 0.20, 0.0],
    "灵活配置": [0.20, 0.20, 0.20, 0.15, 0.25],
    "偏债混合": [0.10, 0.10, 0.10, 0.05, 0.65],
    "混合型": [0.25, 0.20, 0.20, 0.15, 0.20],
    "债券型": [0.0, 0.0, 0.0, 0.0, 1.0],
    "指数型": [0.30, 0.30, 0.25, 0.15, 0.0],
}

# ⚠️ `STYLE_VECTOR_BY_TYPE` 是**归一化后的类型名**，不能拿数据源原值直接查。
#    实测 master 里的 `fund_type` 是「混合型-偏股」「指数型-股票」「债券型-长债」
#    这种"大类-子类"形式（见 fund_master.fetch_fund_list），
#    而 dict 的键是「偏股混合」「指数型」——`dict.get()` 精确匹配永远落空，
#    结果是 **H7 被判为「风格暴露缺失」而永不生效**（RBSA 其实已经算出来了）。
#    这里改成按序的子串规则；顺序敏感，先匹配更具体的子类。
_STYLE_TYPE_RULES: List[Tuple[str, Optional[str]]] = [
    ("偏股", "偏股混合"),
    ("灵活", "灵活配置"),
    ("偏债", "偏债混合"),
    ("混合型", "混合型"),
    ("指数型-固收", "债券型"),      # 债券指数：用利率债权重做纯净度参照
    ("指数型", "指数型"),
    ("股票型", "股票型"),
    ("债券型", "债券型"),
]


# 商品/贵金属类关键词。这 5 个风格因子（大盘成长/价值/中盘/小盘/利率债）
# **无法表达**它们的收益来源（黄金由美元与实际利率驱动、原油由供需驱动），
# 硬套股票风格向量会算出近乎 0 的余弦相似度 → 被 H7 误杀。
# 实测：4 只黄金 ETF 联接的 style_match = 0.03~0.04，整类被剔除，
# 导致 §7.1 的 ALT 类别（危机对冲）从组合里彻底消失 —— 而它正是熊市里的减震器。
_COMMODITY_KW: Tuple[str, ...] = ("黄金", "商品", "原油", "有色", "豆粕", "能源", "白银")


def style_vector_for(fund_type: Optional[str],
                     fund_name: Optional[str] = None) -> Optional[List[float]]:
    """把基金映射到标准风格向量；**不适用风格约束的返回 None**。

    None 的语义是"该类型不适合做风格纯净度约束"（货币 / FOF / QDII / 商品），
    H7 会因此记为未校验而非"通过"——刻意如此，不假装校验过。

    ⚠️ `fund_name` 必须传：黄金 ETF 联接的 `fund_type` 是「指数型-其他」，
    只看类型会命中"指数型"并被套上**股票**风格向量（实测相似度 0.03~0.04）。
    商品判断要**优先于**类型匹配。
    """
    name = str(fund_name or "")
    if any(k in name for k in _COMMODITY_KW):
        return None
    t = str(fund_type or "")
    if not t:
        return None
    for key, vec_key in _STYLE_TYPE_RULES:
        if key in t:
            return STYLE_VECTOR_BY_TYPE.get(vec_key)
    return None

STYLE_ORDER: List[str] = list(STYLE_INDEXES.keys())
