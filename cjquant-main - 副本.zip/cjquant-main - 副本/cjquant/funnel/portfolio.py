# -*- coding: utf-8 -*-
"""L5-A 组合构建（说明书 §7）：类别间风险平价 / 类别内分数加权 / 约束截断 / 波动率目标控仓。

⚠️ 口径提醒（§13.1）：权益类单只上限 **0.20** 是强制建议，不是可调偏好。
满仓单只时"回撤看起来没问题"，通常只是样本没触发过尾部情景。
"""
import math
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

TRADING_DAYS = 252


def softmax_weights(score: pd.Series, lam: float = 1.0,
                    standardize_first: bool = True) -> pd.Series:
    """§7.2 方案1：w_i ∝ exp(λ × ŝ_i)，其中 ŝ 为 Score 的**横截面标准化**。

    🔧 v1.1 尺度修正：λ 直接作用于 z 口径 Score 会导致权重极度集中。
        Score ∈ [−3, +3]（z 口径），exp(2×3)/exp(2×(−3)) = e^12 ≈ 1.6e5
        → 前 2~3 只必然触顶 w_max=0.20，最终权重几乎由截断规则而非分数决定。

    修正（推荐方案 1）：先标准化 ŝ_i = (Score − mean)/std，再 exp(λ·ŝ)。
        ŝ 标准差为 1 → exp(λ)/exp(−λ) = e^{2λ}，λ=1.0 时比值 ≈ 7.4，集中度合理。
    参数含义：Score 为 z 口径时 λ ∈ [0.5,1.0]；已标准化(std=1)时 λ ∈ [1.0,2.0]。
    诊断：跑完统计触顶 w_max 的标的数，>30% 触顶说明 λ 过大。
    """
    if score is None or len(score) == 0:
        return pd.Series(dtype=float)
    s = pd.to_numeric(score, errors="coerce").dropna()
    if s.empty:
        return pd.Series(dtype=float)
    if standardize_first and len(s) > 1:
        mu, sd = float(s.mean()), float(s.std())
        if sd and np.isfinite(sd) and sd > 0:
            s = (s - mu) / sd
    x = float(lam) * (s - s.max())          # 减最大值防溢出（平移不变，不影响结果）
    w = np.exp(x)
    tot = float(w.sum())
    return w / tot if tot > 0 else pd.Series(1.0 / len(s), index=s.index)


def _cap_iterative(w: pd.Series, w_max: float, w_min: float,
                   group_of: Optional[Dict[str, str]] = None,
                   group_cap: float = 0.30, max_iter: int = 50,
                   min_names: int = 0) -> pd.Series:
    """截断-再分配迭代（§7.3），顺序严格按 v1.1 补充的完整顺序：

        C1 单只上限 → C2 下界清理 → C3/C3b/C4 分组上限 → C5 最少标的数复检 → 归一化

    🔧 v1.1 前置检查：w_max × N < 1 时无解（N 只基金装不下 100% 仓位），
    必须先扩池或提高 w_max，否则循环不收敛。
    """
    out = pd.to_numeric(w, errors="coerce").fillna(0.0).astype(float)
    if out.sum() <= 0:
        return out
    out = out / out.sum()
    n_pos = int((out > 0).sum())
    if n_pos and float(w_max) * n_pos < 1.0 - 1e-9:
        # 无解：只能在现有 N 下放宽 w_max，并明确告知
        print(f"[apply_caps] 警告：N={n_pos} < ceil(1/w_max)={math.ceil(1.0 / max(w_max, 1e-9))}，"
              f"单只上限无法同时满足，本次按 w_max 均分处理")
        out = pd.Series(1.0 / n_pos, index=out.index).where(out > 0, 0.0)
        return out / out.sum()
    # ---- C1 单只上限 ----
    for _ in range(int(max_iter)):
        viol = out[out > float(w_max) + 1e-12]
        if len(viol) == 0:
            break
        excess = float((viol - float(w_max)).sum())
        out.loc[viol.index] = float(w_max)
        elig = out[(out < float(w_max) - 1e-12)]
        if len(elig) == 0 or excess <= 0:
            break
        base = float(elig.sum())
        out.loc[elig.index] = elig + (excess * elig / base if base > 0 else excess / len(elig))
    # ---- C2 下界清理（会改变 N，须在分组上限之前做）----
    out[out < float(w_min)] = 0.0
    s = float(out.sum())
    if s > 0:
        out = out / s
    # ---- C3/C3b/C4 分组上限 ----
    if group_of:
        for _ in range(int(max_iter)):
            sums: Dict[str, float] = {}
            for code, val in out.items():
                g = group_of.get(code)
                if g:
                    sums[g] = sums.get(g, 0.0) + float(val)
            over = {g: v for g, v in sums.items() if v > float(group_cap) + 1e-12}
            if not over:
                break
            for g, v in over.items():
                members = [c for c in out.index if group_of.get(c) == g]
                excess = v - float(group_cap)
                base = float(out.loc[members].sum())
                if base <= 0:
                    continue
                out.loc[members] = out.loc[members] * (float(group_cap) / v)
                others = [c for c in out.index if group_of.get(c) != g and out[c] > 0]
                if others:
                    ob = float(out.loc[others].sum())
                    out.loc[others] = out.loc[others] + (
                        excess * out.loc[others] / ob if ob > 0 else 0.0)
    # ---- C5 最少标的数复检 ----
    if min_names and int((out > 0).sum()) < int(min_names):
        print(f"[apply_caps] 提示：有效标的 {int((out > 0).sum())} 只 < C5 下限 "
              f"{int(min_names)}，需扩池（当前不强行凑数）")
    s = float(out.sum())
    return out / s if s > 0 else out


def apply_caps(w: pd.Series, w_max: float = 0.20, w_min: float = 0.02,
               group_of: Optional[Dict[str, str]] = None,
               group_cap: float = 0.30, min_names: int = 0) -> pd.Series:
    """单只上下限 + 单管理人/单风格上限（§7.3 C1~C5）。"""
    if w is None or len(w) == 0:
        return w
    return _cap_iterative(w, w_max=w_max, w_min=w_min, group_of=group_of,
                          group_cap=group_cap, min_names=min_names)


def apply_bounds(w: pd.Series, bounds: Dict[str, Tuple[float, float]],
                 max_iter: int = 50) -> pd.Series:
    """§7.1 边界截断后的再分配（原设计缺失，v1.1 补齐）。

    ERC 解 + 边界截断可能不可行：例 ERC 给 w_EQ=0.70(截到0.65)、w_BOND=0.10(提到0.20)、
    w_ALT=0.12、w_QDII=0.08 → BOND 需 +0.10 而 EQ 只释放 0.05，缺口无处填补 → Σw≠1。

    规则：截断后**只在未触界的类别间**按当前权重比例分配缺口；
    全部触界仍不可行 → 按边界中值归一化并记 Flag_ClassBoundsInfeasible。
    """
    if w is None or not len(w) or not bounds:
        return w
    out = pd.to_numeric(w, errors="coerce").astype(float).copy()
    out = out / out.sum() if out.sum() > 0 else out
    for _ in range(int(max_iter)):
        free: List[str] = []
        for a in out.index:
            lo, hi = bounds.get(a, (0.0, 1.0))
            lo, hi = float(lo), float(hi)
            if out[a] < lo:
                out[a] = lo
            elif out[a] > hi:
                out[a] = hi
            else:
                free.append(a)
        gap = 1.0 - float(out.sum())
        if abs(gap) < 1e-8:
            break
        if not free:
            print("[apply_bounds] Flag_ClassBoundsInfeasible：全部类别触界，"
                  "本期按边界中值归一化")
            mid = pd.Series({a: sum(bounds.get(a, (0.0, 1.0))) / 2.0 for a in out.index})
            s = float(mid.sum())
            out = mid / s if s > 0 else out
            break
        tot = float(out.loc[free].sum())
        if tot <= 0:
            out.loc[free] = gap / len(free)
        else:
            # 按当前权重**比例**分配（原式用 gap/len(free) 等额分配，破坏了相对结构）
            out.loc[free] = out.loc[free] + gap * (out.loc[free] / tot)
    return out


def marginal_risk_contribution(w: pd.Series, cov: pd.DataFrame) -> pd.Series:
    """🔧 v1.1 P1-2：MC_a(w) = (Σw)_a / σ_p（边际风险贡献 ∂σ_p/∂w_a）。

    原式 MC_a = (Σw)_a 缺了除以 σ_p：
        Σ_a RC_a = Σ_a w_a(Σw)_a = w^TΣw = σ_p² ≠ σ_p
    与"Σ_a RC_a = σ_p"自相矛盾，量纲错成平方级。
    """
    if w is None or cov is None or cov.empty:
        return pd.Series(dtype=float)
    names = [c for c in w.index if c in cov.index]
    if not names:
        return pd.Series(dtype=float)
    wv = pd.to_numeric(w.loc[names], errors="coerce").fillna(0.0).values.astype(float)
    S = cov.loc[names, names].values.astype(float)
    sw = S.dot(wv)
    var = float(wv.dot(sw))
    if var <= 0:
        return pd.Series(0.0, index=names)
    sigma_p = math.sqrt(var)
    return pd.Series(sw / sigma_p, index=names)


def risk_contributions(w: pd.Series, cov: pd.DataFrame) -> pd.Series:
    """RC_a = w_a × MC_a，满足 Σ_a RC_a = σ_p。

    风险贡献**占比**应为 RC_a / σ_p ∈ [0,1]（Σ = 1）—— 直接拿 RC 当占比会得到平方量级。
    """
    mc = marginal_risk_contribution(w, cov)
    if mc.empty:
        return mc
    names = list(mc.index)
    wv = pd.to_numeric(w.loc[names], errors="coerce").fillna(0.0)
    return mc * wv


def risk_shares(w: pd.Series, cov: pd.DataFrame) -> pd.Series:
    """风险贡献占比 RC_a / σ_p ∈ [0,1]，Σ = 1（用于监控与报告）。"""
    rc = risk_contributions(w, cov)
    if rc.empty:
        return rc
    tot = float(rc.sum())
    return rc / tot if tot > 0 else rc


def erc_weights(cov: pd.DataFrame, bounds: Optional[Dict[str, tuple]] = None,
                iters: int = 500, tol: float = 1e-10) -> pd.Series:
    """§7.1 等风险贡献（ERC）：迭代 w_a ∝ w_a / (Σw)_a，再按类别边界截断。

    为什么不用资金等权（§7.1 的提醒）：股基年化波动 20%、债基 4%，
    各配 50% 时组合 **96% 以上的风险来自股基**。ERC 按风险贡献分配才能真正分散。
    """
    if cov is None or cov.empty:
        return pd.Series(dtype=float)
    names = list(cov.index)
    S = cov.loc[names, names].values.astype(float)
    n = len(names)
    w = np.ones(n) / n
    for _ in range(int(iters)):
        sw = S.dot(w)
        sw = np.where(sw <= 1e-12, 1e-12, sw)
        new = w / sw
        new = new / new.sum()
        if np.max(np.abs(new - w)) < tol:
            w = new
            break
        w = new
    out = pd.Series(w, index=names)
    if bounds:
        out = apply_bounds(out, {k: tuple(bounds[k]) for k in out.index if k in bounds})
    s = float(out.sum())
    return out / s if s > 0 else out


def realized_vol(rets: pd.Series, window: int = 126, ewma_lambda: float = 0.94) -> float:
    """§7.4 已实现波动率：默认等权 126 日（与中泰口径一致），EWMA 亦可。"""
    if rets is None:
        return float("nan")
    r = pd.Series(rets).dropna()
    if len(r) < 20:
        return float("nan")
    if window and window > 0:
        r = r.iloc[-int(window):]
    return float(r.std() * math.sqrt(TRADING_DAYS))


def vol_target_leverage(port_rets: pd.Series, sigma_target: float = 0.11,
                        l_min: float = 0.30, l_max: float = 1.00,
                        window: int = 126) -> float:
    """§7.4 L_t = clip(σ_target / σ̂_t, L_min, L_max)。场外不做杠杆，L_max 封顶 1。

    ⚠️ 口径（§13.3）：多资产组合 σ_target=0.10~0.12；纯股票池 0.20~0.25。
    拿多资产组合去用 25% 会让 L_t 恒等于 1 —— 风控层等于不存在。
    """
    vol = realized_vol(port_rets, window=window)
    if not vol or math.isnan(vol) or vol <= 1e-9:
        return float(l_max)
    return float(min(max(float(sigma_target) / vol, float(l_min)), float(l_max)))


def _as_weights(w) -> pd.Series:
    """把任意"权重入参"安全转成 float Series。

    ⚠️ 不能写 `w_old or {}`：Series 的 `__bool__` 对**空 Series 也一样**抛
    ValueError（真值模糊）。回测第二期之后 current_weights 可能就是空 Series，
    那样 limit_turnover 会直接把整个回测打挂。
    """
    if w is None:
        return pd.Series(dtype=float)
    if isinstance(w, pd.Series):
        return pd.to_numeric(w, errors="coerce").fillna(0.0).astype(float)
    try:
        return pd.Series(dict(w), dtype=float)
    except Exception:
        return pd.Series(dtype=float)


def turnover_of(w_new: pd.Series, w_old: pd.Series) -> float:
    """§9.4 Turnover = 0.5 × Σ|Δw|（单边）。"""
    if w_new is None or len(w_new) == 0:
        return 0.0
    old = _as_weights(w_old).reindex(w_new.index).fillna(0.0)
    new = pd.to_numeric(w_new, errors="coerce").fillna(0.0)
    return float(0.5 * (new - old).abs().sum())


def limit_turnover(w_new: pd.Series, w_old: pd.Series, to_max: float = 0.35) -> pd.Series:
    """§9.4 部分调仓：换手超上限时，按"边际收益/边际成本"最高的先调（此处用分数差近似）。

    实现：按 |Δw| 从大到小执行，累计 Turnover 达到 TO_max 即停，其余留待下期。
    """
    if w_new is None or len(w_new) == 0:
        return w_new
    old = _as_weights(w_old).reindex(w_new.index).fillna(0.0)
    new = pd.to_numeric(w_new, errors="coerce").fillna(0.0)
    delta = new - old
    order = delta.abs().sort_values(ascending=False).index
    out = old.copy()
    used = 0.0
    for code in order:
        step = 0.5 * abs(float(delta[code]))
        if used + step > float(to_max) + 1e-12:
            continue
        used += step
        out[code] = float(new[code])
    s = float(out.sum())
    return out / s if s > 0 else out
