# -*- coding: utf-8 -*-
"""L4 池构建层：说明书 §6 的两级加权打分 / 旗标降权 / 分档 / 缓冲带 / 去冗余。

打分口径（MVP）：**维度内等权 + 维度间手册权重**。
不用 IC 加权是因为还没有足够长的 IC 序列（说明书 §5.4 明确建议从等权 Baseline 起步）。

**缺失即缺席**：某只基金在某维度上没有任何可得因子时，该维度不参与它的总分，
权重在剩余维度间重新归一化 —— 既不用 0 假装中性，也不因缺数据被惩罚性扣分。
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

import numpy as np
import pandas as pd

from .factors import DIM_WEIGHTS, FACTOR_DIM, INTERVAL_FACTORS

# 说明书 §6.2 的旗标降权表（penalty 列仅用于**换算** λ_f，不再直接乘分数）
PENALTY_TABLE: Dict[str, float] = {
    "Flag_FM_change": 0.0,      # 经理变更（当前无数据源，不会触发）
    "Flag_BetDriven": 0.5,      # 赛道押注型（当前无 Brinson，不会触发）
    "Flag_Opaque": 0.8,         # RBSA R² < 子池阈值
    "Flag_YoungFund": 0.85,     # 成立 2~3 年
    "Flag_SizeShock": 0.85,     # 单季规模翻倍
    "Flag_SingleTrack": 0.7,    # 单一行业占比过大
    "Flag_Liquidation": 0.0,    # 清盘预警
}

# 🔧 v1.1 P0-2：penalty = 0.0 时的替代惩罚量 λ_HARD（约 3 个标准差 ≈ 实质出局）
LAMBDA_HARD: float = 3.0
# 多旗标叠加时 λ 相加，设总惩罚上限避免数值失控（§6.2 实现要点 2）
LAMBDA_CAP: float = 4.0

# §6.3 一票否决：命中任一即入 Black（先于 Core/Backup/Watch 判定）
HARD_BLACK_FLAGS: Set[str] = {
    "Flag_Liquidation",     # 清盘预警
    "Flag_FM_change",       # 基金经理变更
    "Flag_BetDepBlack",     # BetDep > 0.70 且 TotalSelect < 0
    "Flag_Suspended",       # 暂停申购/赎回
    "Flag_Violation",       # 重大违规公告
    "Flag_Laggard",         # 连续 2 期同类排名后 1/2
}

# §6.3 Core 档的排除性旗标（命中则最高只能到 Backup）
CORE_EXCLUDE_FLAGS: Set[str] = {"Flag_BetDriven", "Flag_SingleTrack", "Flag_Opaque"}

# 仅作中性化变量、不参与打分的因子
NON_SCORING = {"size_pct", "ln_size", "omega", "mom_12_3",
               "mom_3_6", "mom_6_12", "mom_12_24"}


def penalty_to_lambda(penalty: float) -> float:
    """§6.2：λ_f = −ln(penalty_f)；penalty=0 用 λ_HARD=3.0 替代。"""
    try:
        p = float(penalty)
    except Exception:
        return 0.0
    if p <= 0.0:
        return float(LAMBDA_HARD)
    if p >= 1.0:
        return 0.0
    return float(-math.log(p))


def flag_lambdas(flags: Sequence[str],
                 table: Optional[Dict[str, float]] = None) -> Tuple[float, Dict[str, float]]:
    """返回 (总惩罚量（已封顶 4.0）, {旗标: λ})。"""
    table = dict(table or PENALTY_TABLE)
    detail: Dict[str, float] = {}
    for f in flags or ():
        if f in table:
            detail[f] = penalty_to_lambda(table[f])
    total = float(sum(detail.values()))
    if total > LAMBDA_CAP:
        # 按比例压缩到上限，保持各旗标之间的相对强度
        scale = LAMBDA_CAP / total
        detail = {k: v * scale for k, v in detail.items()}
        total = LAMBDA_CAP
    return total, detail


@dataclass
class PoolParams:
    """说明书 §6.4 池参数。

    🔧 v1.1 口径澄清：以下 N 均为**每子池**口径，不是全部子池合计。
    §6.6 的 5 个子池各自独立跑 L2~L4，合计约 15+8+10+4+6 = 43 只（不含货币池）。
    """
    theta_in: float = 0.90        # 新成员入池分位门槛
    theta_keep: float = 0.70      # 老成员留池分位门槛
    n_target: int = 25
    n_min: int = 18
    n_max: int = 35
    min_hold_days: int = 90       # 最短持有期（对抗 <7 日 1.5% 惩罚性赎回费）
    rho_max: float = 0.90         # 去冗余相关上限

    @classmethod
    def for_subpool(cls, n_target: int, base: Optional["PoolParams"] = None,
                    **kw) -> "PoolParams":
        """按子池目标容量生成参数（小池的 N_min/N_max 按比例缩，§6.4）。

            N_min = max(3, round(0.7 × N_target))
            N_max = round(1.4 × N_target)
        """
        b = base or cls()
        n = max(1, int(n_target))
        return cls(
            theta_in=kw.get("theta_in", b.theta_in),
            theta_keep=kw.get("theta_keep", b.theta_keep),
            n_target=n,
            n_min=kw.get("n_min", max(3, int(round(0.7 * n)))),
            n_max=kw.get("n_max", int(round(1.4 * n))),
            min_hold_days=kw.get("min_hold_days", b.min_hold_days),
            rho_max=kw.get("rho_max", b.rho_max),
        )


def dim_score(z: pd.DataFrame, dim: str) -> pd.Series:
    """维度内等权合成；该维度全缺失的基金返回 NaN（不是 0）。"""
    cols = [c for c in z.columns if FACTOR_DIM.get(c) == dim and c not in NON_SCORING]
    cols = [c for c in cols if z[c].notna().any()]
    if not cols:
        return pd.Series(np.nan, index=z.index)
    sub = z[cols]
    return sub.mean(axis=1, skipna=True).where(sub.notna().any(axis=1))


def two_level_score(z: pd.DataFrame, dim_weights: Optional[Dict[str, float]] = None) -> pd.Series:
    """两级加权：维度内等权 → 维度间按手册权重（可用维度归一化）。"""
    if z.empty:
        return pd.Series(dtype=float)
    w = dict(dim_weights or DIM_WEIGHTS)
    total = pd.Series(0.0, index=z.index)
    wsum = pd.Series(0.0, index=z.index)
    for dim, weight in w.items():
        ds = dim_score(z, dim)
        valid = ds.notna()
        if not valid.any():
            continue
        total = total.add((ds.fillna(0.0) * float(weight)).where(valid, 0.0), fill_value=0.0)
        wsum = wsum + valid.astype(float) * float(weight)
    score = total / wsum.where(wsum > 0, np.nan)
    return score


def apply_penalty(score: pd.Series, flags: Dict[str, Sequence[str]],
                  table: Optional[Dict[str, float]] = None) -> pd.Series:
    """🔧 v1.1 P0-2：Score^{final}_i = Score_i − Σ_f λ_f（**加法**，不是乘法）。

    为什么不能用乘法（说明书 §6.2 的原式缺陷）：
        Score 是 z 口径，有正有负。乘 <1 的系数对负数而言是"向 0 收敛"，
        而在 z 排序中向 0 收敛就是**变好**。
            基金 A 得分 −1.0（很差），触发 Flag_Opaque(0.8)
            → −1.0 × 0.8 = −0.8 → 排名【上升】
            penalty = 0.0（经理变更）→ 得分变 0.0，即 z 分布的中位数附近，
            可能高于它原本的负分 —— 本该出局的基金排到了池子中部。

    加法方案 λ_f = −ln(penalty_f) 保持惩罚的相对强度排序，且对正负 Score 一视同仁。
    副作用（可接受）：exp(λ·Score) 归一化后对 Score 的**整体平移**不变，
    所以加法惩罚只通过**相对差异**影响权重（§7.2 平移不变性提示）。
    """
    if score is None or score.empty:
        return score
    out = pd.to_numeric(score, errors="coerce").astype(float).copy()
    for code, flist in (flags or {}).items():
        if code not in out.index or not flist:
            continue
        lam, _ = flag_lambdas(flist, table)
        if lam:
            cur = out.loc[code]
            if not pd.isna(cur):
                out.loc[code] = cur - lam
    return out


def rank_pct(score: pd.Series) -> pd.Series:
    return score.rank(pct=True)


def assign_tiers(pct: pd.Series, flags: Optional[Dict[str, Sequence[str]]] = None,
                 core: float = 0.90, backup: float = 0.80, watch: float = 0.60
                 ) -> Dict[str, str]:
    """说明书 §6.3 分档（🔧 v1.1 判定顺序修正）。

    顺序：**先判 Black，再判 Core/Backup/Watch** —— Black 一票否决，
    不依赖"分数足够低所以排不进前段"这种脆弱假设
    （λ_HARD=3.0 的基金必须显式排除，不能指望它自己排不进前 10%）。

    Core 额外要求：无 Flag_BetDriven / Flag_SingleTrack / Flag_Opaque
    （v1.1 明确了旧版"无 Flag_*Driven"这个含义不清的通配写法）。
    """
    flags = flags or {}
    out: Dict[str, str] = {}
    for code, p in pct.items():
        fl = set(flags.get(code, ()))
        if fl & HARD_BLACK_FLAGS:
            out[code] = "Black"
            continue
        if pd.isna(p):
            out[code] = "Out"
            continue
        p = float(p)
        if p >= core:
            out[code] = "Core" if not (fl & CORE_EXCLUDE_FLAGS) else "Backup"
        elif p >= backup:
            out[code] = "Backup"
        elif p >= watch or fl:
            out[code] = "Watch"
        else:
            out[code] = "Out"
    return out


def build_pool(pct: pd.Series, prev_members: Sequence[str],
               entry_dates: Dict[str, str], asof: str,
               params: Optional[PoolParams] = None,
               blacklist: Optional[Set[str]] = None,
               tiers: Optional[Dict[str, str]] = None) -> Tuple[List[str], Dict[str, str], List[str]]:
    """说明书 §6.4 双阈值缓冲带 + 容量控制 + 最短持有期。

    返回 (本期成员（按分位降序）, 更新后的入池日字典, 诊断旗标列表)。

    🔧 v1.1：容量不足时的补齐顺序改为 **Core > Backup > Watch**（§6.3 档位用途 (a)）；
    仍不足则接受 N < N_min 并记 `Flag_PoolUnderfilled`，**不得用低质量标的凑数**。
    """
    p = params or PoolParams()
    blacklist = set(blacklist or ())
    diags: List[str] = []
    if pct is None or pct.empty:
        return [], dict(entry_dates or {}), ["Flag_PoolUnderfilled"]
    prev = set(prev_members or ())
    entry = dict(entry_dates or {})
    asof_d = pd.Timestamp(str(asof)[:10])

    # Black 一票否决：即便在最短持有期内也要移出（§6.4 优先级 1：事件触发 > MinHold）
    black = {c for c in pct.index
             if c in blacklist or str((tiers or {}).get(c, "")) == "Black"}

    kept: List[str] = []
    for code in pct.index:
        if code in black:
            continue
        if code in prev:
            if float(pct[code]) >= p.theta_keep:
                kept.append(code)
            else:
                ent = entry.get(code)
                if ent:
                    try:
                        if (asof_d - pd.Timestamp(str(ent)[:10])).days < p.min_hold_days:
                            kept.append(code)   # 最短持有期未满 → 强制保留
                    except Exception:
                        pass
    new = [c for c in pct.index
           if c not in prev and c not in black and float(pct[c]) >= p.theta_in]

    members = sorted(set(kept) | set(new), key=lambda c: -float(pct[c]))
    if len(members) > p.n_max:
        members = members[:p.n_max]
    if len(members) < p.n_min:
        # §6.3：补齐优先级 Core > Backup > Watch，同档内按分位降序
        rank = {"Core": 0, "Backup": 1, "Watch": 2, "Out": 3}
        cand = [c for c in pct.index if c not in set(members) and c not in black]
        cand.sort(key=lambda c: (rank.get(str((tiers or {}).get(c, "Out")), 3),
                                 -float(pct[c])))
        for c in cand:
            members.append(c)
            if len(members) >= p.n_min:
                break
        members = sorted(members, key=lambda c: -float(pct[c]))
    if len(members) < p.n_min:
        diags.append("Flag_PoolUnderfilled")

    for c in members:
        entry.setdefault(c, str(asof)[:10])
    for c in list(entry):
        if c not in members:
            entry.pop(c, None)
    return members, entry, diags


def decorrelate_with_refill(members: Sequence[str], corr: pd.DataFrame, pct: pd.Series,
                            pool_params: Optional[PoolParams] = None,
                            tiers: Optional[Dict[str, str]] = None
                            ) -> Tuple[List[str], List[str]]:
    """🔧 v1.1 §6.5 去冗余 + **补齐回路**（原设计缺失）。

    原流程：cap_size(→N_max) → greedy_decorrelate(→可能只剩 12)
            → 池规模跌破 N_min 而补仓逻辑已经跑完，无法再补。

    修正流程（迭代式）：
        Pool = greedy_decorrelate(cap_size(S, N_max), ρ_max)
        while |Pool| < N_min 且仍有未尝试候选:
            batch = 从 Backup/Watch 按 Score 降序取下一批
            batch = [i for i in batch if max_{j∈Pool} ρ_ij ≤ ρ_max]
            Pool += batch[:N_target − |Pool|]
            if batch 为空: 记 Flag_DecorrelateStarved 并 break
        Pool = cap_size(Pool, N_target)

    ⚠️ 关键纪律：宁可池子小一些，也**不为凑数放宽 ρ_max**
    （放宽 = 表面分散、实质集中）。
    """
    p = pool_params or PoolParams()
    diags: List[str] = []
    if not members:
        return [], diags
    if corr is None or corr.empty:
        return list(members)[:p.n_target], diags

    rank = {"Core": 0, "Backup": 1, "Watch": 2, "Out": 3}
    ordered = sorted(members, key=lambda c: -float(pct.get(c, 0.0)))

    def _max_corr(c: str, pool: List[str]) -> float:
        vals = []
        for o in pool:
            try:
                v = float(corr.loc[c, o])
            except Exception:
                continue
            if np.isfinite(v):
                vals.append(v)
        return max(vals) if vals else 0.0

    out: List[str] = []
    for c in ordered:
        if len(out) >= p.n_max:
            break
        if _max_corr(c, out) <= p.rho_max:
            out.append(c)

    tried = set(ordered)
    while len(out) < p.n_min:
        cand = [c for c in pct.index
                if c not in tried and c not in set(out)
                and str((tiers or {}).get(c, "Out")) != "Black"]
        if not cand:
            break
        cand.sort(key=lambda c: (rank.get(str((tiers or {}).get(c, "Out")), 3),
                                 -float(pct.get(c, 0.0))))
        need = max(0, int(p.n_target) - len(out))
        batch = [c for c in cand[:max(need * 2, need)]
                 if _max_corr(c, out) <= p.rho_max]
        if not batch:
            diags.append("Flag_DecorrelateStarved")
            break
        tried.update(cand[:max(need * 2, need)])
        for c in batch[:need]:
            if len(out) >= int(p.n_target):
                break
            out.append(c)

    out = sorted(out, key=lambda c: -float(pct.get(c, 0.0)))
    return out[:p.n_target], diags


def greedy_decorrelate(members: Sequence[str], corr: pd.DataFrame, pct: pd.Series,
                       rho_max: float = 0.90, n_target: int = 25) -> List[str]:
    """说明书 §6.5 贪心去冗余：按分位从高到低，与已入池者相关 > ρ_max 则跳过。

    注：完整流程请用 `decorrelate_with_refill`（含 v1.1 的补齐回路）。
    """
    if corr is None or corr.empty:
        return list(members)[:n_target]
    ordered = sorted(members, key=lambda c: -float(pct.get(c, 0.0)))
    out: List[str] = []
    for c in ordered:
        if len(out) >= n_target:
            break
        ok = True
        for o in out:
            try:
                if float(corr.loc[c, o]) > rho_max:
                    ok = False
                    break
            except Exception:
                continue
        if ok:
            out.append(c)
    return out


def pool_avg_corr(members: Sequence[str], corr: pd.DataFrame) -> float:
    """池平均相关度（说明书 §6.5 分散性诊断，>0.85 需告警）。"""
    cs = [c for c in members if c in corr.index]
    if len(cs) < 2:
        return float("nan")
    sub = corr.loc[cs, cs].values
    iu = np.triu_indices(len(cs), k=1)
    vals = sub[iu]
    vals = vals[~np.isnan(vals)]
    return float(vals.mean()) if len(vals) else float("nan")
