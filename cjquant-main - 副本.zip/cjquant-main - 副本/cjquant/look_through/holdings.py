"""真实季报持仓源（生产级）：天天基金投资组合 -> 行业穿透。

替代旧 run_look_through 写死 3 只 + hash 伪造。
- 股票持仓：fund_portfolio_hold_em(symbol, date) 取最新季度前十大
- 行业配置：fund_portfolio_industry_allocation_em(symbol, date) 取最新截止时间，用市值归一
- 风格：无免费风格库，用行业启发式映射（透明标注，非精确），需 Wind/申万二期替换
- 债券/货基：股票持仓为空时记为债券/货币，不伪造个股
"""
import logging
import pandas as pd
from typing import Dict, Optional, Tuple
from datetime import datetime
from cjquant.data import net

logger = logging.getLogger(__name__)

# 行业 -> 风格启发式（透明近似，二期接 Wind 风格因子替换）
GROWTH_INDUSTRIES = {
    "制造业", "信息传输、软件和信息技术服务业", "科学研究和技术服务业",
    "卫生和社会工作", "文化、体育和娱乐业",
    "新能源/科技", "电子/半导体", "医药/医疗",
}
VALUE_INDUSTRIES = {
    "金融业", "采矿业", "电力、热力、燃气及水生产和供应业",
    "交通运输、仓储和邮政业", "房地产业", "建筑业",
    "银行/金融", "水电/公用事业", "煤炭/能源",
}


def style_of_industry(ind: str) -> str:
    s = str(ind)
    for g in GROWTH_INDUSTRIES:
        if g in s or s in g:
            return "成长"
    for v in VALUE_INDUSTRIES:
        if v in s or s in v:
            return "价值"
    return "均衡"


class RealHoldingsProvider:
    def __init__(self, max_retries: int = 2, retry_delay: float = 1.0, cache_dir: Optional[str] = "./.cache/cjquant"):
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.cache_dir = cache_dir
        if cache_dir:
            import os
            os.makedirs(cache_dir, exist_ok=True)

    # 三份几乎一样的重试循环（本类 + public._get_raw_data + nav_bulk）之前各自实现，
    # 现在统一走 cjquant.data.net：共用超时/退避/确定性失败判定。
    def _fetch_hold(self, code6: str, year: str) -> Optional[pd.DataFrame]:
        try:
            return net.ak_call("fund_portfolio_hold_em", symbol=code6,
                               date=year, max_retries=self.max_retries)
        except Exception as e:
            logger.warning(f"{code6} 持仓拉取失败 year={year}: {net.short_err(e)}")
            return None

    def _fetch_industry(self, code6: str, year: str) -> Optional[pd.DataFrame]:
        try:
            return net.ak_call("fund_portfolio_industry_allocation_em",
                               symbol=code6, date=year, max_retries=self.max_retries)
        except Exception as e:
            logger.warning(f"{code6} 行业配置拉取失败 year={year}: {net.short_err(e)}")
            return None

    def _latest_stock_holdings(self, code6: str) -> Tuple[pd.DataFrame, str]:
        """返回 (最新季度持仓df, 季度标签)。为空则 (empty, '')。"""
        now_year = datetime.now().year
        for y in ("", str(now_year), str(now_year - 1), str(now_year - 2)):
            df = self._fetch_hold(code6, y)
            if df is not None and not df.empty and "季度" in df.columns:
                # 取最新季度（按字符串排序取最后，季报标签含年月可比）
                try:
                    latest_q = sorted(df["季度"].astype(str).unique())[-1]
                    sub = df[df["季度"] == latest_q].copy()
                    return sub, str(latest_q)
                except Exception:
                    return df, ""
        return pd.DataFrame(), ""

    def _latest_industry(self, code6: str) -> Tuple[Dict[str, float], str]:
        """返回 (行业权重dict, 截止时间)。权重由市值归一（接口占比常为NaN）。"""
        now_year = datetime.now().year
        for y in (str(now_year), str(now_year - 1), str(now_year - 2)):
            df = self._fetch_industry(code6, y)
            if df is not None and not df.empty:
                try:
                    # 取最新截止时间
                    df["截止时间"] = pd.to_datetime(df["截止时间"])
                    latest = df["截止时间"].max()
                    sub = df[df["截止时间"] == latest].copy()
                    sub["市值"] = pd.to_numeric(sub["市值"], errors="coerce").fillna(0)
                    tot = sub["市值"].sum()
                    if tot > 0:
                        w = (sub.groupby("行业类别")["市值"].sum() / tot).to_dict()
                        return {str(k): float(v) for k, v in w.items()}, str(latest.date())
                except Exception as e:
                    logger.warning(f"{code6} 行业解析失败: {e}")
                    continue
        return {}, ""

    def get_fund_exposure(self, fund_code: str) -> Dict:
        """单基金真实穿透。返回 dict(含 source 标记 real/fallback_bond/empty)。"""
        code6 = str(fund_code).split(".")[0].zfill(6)
        stock_df, quarter = self._latest_stock_holdings(code6)
        ind_w, ind_date = self._latest_industry(code6)
        top = []
        if stock_df is not None and not stock_df.empty:
            try:
                s = stock_df.copy()
                s["占净值比例"] = pd.to_numeric(s["占净值比例"], errors="coerce")
                s = s.sort_values("占净值比例", ascending=False).head(10)
                for _, r in s.iterrows():
                    top.append({
                        "stock_code": str(r.get("股票代码", "")),
                        "stock_name": str(r.get("股票名称", "")),
                        "weight": round(float(r.get("占净值比例", 0) or 0) / 100.0, 6),
                    })
            except Exception:
                pass
        if ind_w:
            style: Dict[str, float] = {}
            for ind, w in ind_w.items():
                style[style_of_industry(ind)] = style.get(style_of_industry(ind), 0) + w
            return {
                "fund_code": fund_code, "source": "real",
                "quarter": quarter, "industry_date": ind_date,
                "industry": ind_w, "style": style, "top_holdings": top,
            }
        # 股票持仓/行业均空：判为债基/货基，不伪造个股
        return {
            "fund_code": fund_code, "source": "fallback_bond" if not top else "empty",
            "quarter": quarter, "industry_date": ind_date,
            "industry": {"债券/货币": 1.0}, "style": {"稳健": 1.0}, "top_holdings": top,
        }
