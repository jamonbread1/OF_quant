class CJQuantDataError(Exception):
    pass

class DataFetchError(CJQuantDataError):
    pass

class FundNoNavPageError(DataFetchError):
    """该代码在数据源没有独立净值页（确定性失败，重试无意义）。

    典型来源：东财 pingzhongdata 对不存在的代码返回 HTTP 200 + HTML 错误页，
    akshare 把 HTML 交给 JS 引擎执行就会抛 `SyntaxError: Unexpected token '<'`。
    常见于「(后端)」收费份额（如 000002 = 华夏成长混合(后端)）与未发行/已下架代码。
    """


class DataFormatError(CJQuantDataError):
    pass

class AlignmentError(CJQuantDataError):
    pass

class DataCleaningError(CJQuantDataError):
    pass

class UniverseError(CJQuantDataError):
    pass