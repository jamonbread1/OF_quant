"""动态基金池：幸存者偏差 + 新基金 + 申赎状态过滤（生产级）。

规范来源：用户策略文档 §2.4 / §2.6 / §2.7
- 清盘推断：最后净值日距今(或距 asof)>60天 -> 已清盘
- 新基金：首个净值日距 asof < min_history_days(默认180) -> 排除
- 申赎状态：快照 purchase=='封闭期' 不可买，redeem=='封闭期' 不可卖
- 规模：仅硬过滤（<2亿排除，>300亿可选排除），规模源缺失时跳过并告警

PIT 要求：asof=T 时只用 <=T 已知信息判定资格。
"""
import logging
import pandas as pd
from typing import Dict, List, Optional
from .exceptions import UniverseError

logger = logging.getLogger(__name__)

LIQUIDATE_GAP_DAYS = 60


class DynamicUniverse:
    def __init__(
        self,
        min_history_days: int = 180,
        liquidate_gap_days: int = LIQUIDATE_GAP_DAYS,
        min_scale_yi: float = 2.0,
        max_scale_yi: Optional[float] = 300.0,
    ):
        self.min_history_days = min_history_days
        self.liquidate_gap_days = liquidate_gap_days
        self.min_scale_yi = min_scale_yi
        self.max_scale_yi = max_scale_yi

    @staticmethod
    def infer_liquidation_date(last_nav_date: pd.Timestamp, gap_days: int = LIQUIDATE_GAP_DAYS) -> Optional[pd.Timestamp]:
        """最后净值日距今超 gap -> 视为清盘日=last_nav_date，否则 None（存续）。"""
        try:
            last = pd.to_datetime(last_nav_date)
            if (pd.Timestamp.now(tz=None) - last.tz_localize(None)).days > gap_days:
                return last
            return None
        except Exception:
            return None

    def eligible_at(
        self,
        asof: pd.Timestamp,
        first_nav: pd.Timestamp,
        last_nav: pd.Timestamp,
        purchase_status: Optional[str] = None,
        scale_yi: Optional[float] = None,
    ) -> bool:
        """单基金在 asof 是否可纳入（买入候选）。"""
        try:
            asof = pd.to_datetime(asof)
            first = pd.to_datetime(first_nav)
            last = pd.to_datetime(last_nav)
        except Exception:
            return False
        # 新基金：历史不足
        if (asof - first).days < self.min_history_days:
            return False
        # 已清盘：asof 已超最后净值 + gap（PIT：用 asof 而非 now 判定）
        if (asof - last).days > self.liquidate_gap_days:
            return False
        # 封闭不可买
        if purchase_status and "封闭" in str(purchase_status):
            return False
        # 规模硬约束
        if scale_yi is not None:
            try:
                s = float(scale_yi)
                if s < self.min_scale_yi:
                    return False
                if self.max_scale_yi is not None and s > self.max_scale_yi:
                    return False
            except (TypeError, ValueError):
                pass
        return True

    def build_eligible_set(
        self,
        asof: pd.Timestamp,
        nav_panel: pd.DataFrame,
        status_map: Optional[Dict[str, str]] = None,
        scale_map: Optional[Dict[str, float]] = None,
        master=None,
    ) -> List[str]:
        """基于宽表(已对齐) + 状态/规模map，返回 asof 可买清单。

        master: 可选 FundMasterDB。传入时改用「基础库真实事实」判定（成立日/清盘日/规模 PIT），
                不再依赖宽表首末值代理，也就不受 panel 起点影响；传 None 则完全走旧逻辑。
                库中缺记录的基金自动按只降级回旧逻辑，保证过渡期行为连续。

        nav_panel: columns=基金代码, index=日期, values=adj_nav
        用每列首/末有效值代理 setup/liquidate（PIT安全：只看 <=asof 段）。
        """
        if nav_panel.empty:
            raise UniverseError("nav_panel 为空，无法构建基金池")
        if master is not None:
            return self._eligible_from_master(asof, nav_panel, master, status_map, scale_map)
        asof = pd.to_datetime(asof)
        hist = nav_panel[nav_panel.index <= asof]
        if hist.empty:
            return []
        eligible: List[str] = []
        panel_start = nav_panel.index[0]
        for code in hist.columns:
            s = hist[code].dropna()
            if s.empty:
                continue
            first, last = s.index[0], s.index[-1]
            # 截断保护：若首个有效值即 panel 起点，说明真实成立日在 panel 之前，
            # 无法判定新基金，跳过 min_history（视为老基金），只判清盘/状态/规模。
            # 调用方须保证 panel 起始早于策略起始 >= min_history，否则新基金会被误放行。
            if first <= panel_start + pd.Timedelta(days=5):
                ok = self.eligible_at(
                    asof, asof - pd.Timedelta(days=self.min_history_days + 1), last,
                    purchase_status=(status_map or {}).get(code),
                    scale_yi=(scale_map or {}).get(code),
                )
            else:
                # PIT：last 必须就是 asof 附近？若 last << asof 说明已停更/清盘，eligible_at 会剔除
                ok = self.eligible_at(
                    asof, first, last,
                    purchase_status=(status_map or {}).get(code),
                    scale_yi=(scale_map or {}).get(code),
                )
            if ok:
                eligible.append(code)
        logger.info(f"[{asof.date()}] 动态池 {len(eligible)}/{len(hist.columns)} 只可买")
        return eligible

    def _eligible_from_master(
        self,
        asof: pd.Timestamp,
        nav_panel: pd.DataFrame,
        master,
        status_map: Optional[Dict[str, str]] = None,
        scale_map: Optional[Dict[str, float]] = None,
    ) -> List[str]:
        """基础库模式：成立日/清盘日/规模都查真实事实，不依赖 panel 首末值代理。"""
        asof_ts = pd.to_datetime(asof)
        hist = nav_panel[nav_panel.index <= asof_ts]
        if hist.empty:
            return []
        asof_d = asof_ts.date()
        panel_start = nav_panel.index[0]

        eligible: List[str] = []
        n_master = n_proxy = 0
        for code in hist.columns:
            s = hist[code].dropna()
            if s.empty:
                continue
            last = s.index[-1].date()
            row = master.get_fund(code)
            setup_raw = row.get("setup_date") if row else None

            if not setup_raw:
                # 库里没有这笔事实 -> 该只降级回旧代理逻辑（过渡期行为连续）
                first = s.index[0]
                if first <= panel_start + pd.Timedelta(days=5):
                    ok = self.eligible_at(
                        asof_d, asof_d - pd.Timedelta(days=self.min_history_days + 1), last,
                        purchase_status=(status_map or {}).get(code),
                        scale_yi=(scale_map or {}).get(code),
                    )
                else:
                    ok = self.eligible_at(
                        asof_d, first, last,
                        purchase_status=(status_map or {}).get(code),
                        scale_yi=(scale_map or {}).get(code),
                    )
                n_proxy += 1
            else:
                setup = pd.to_datetime(setup_raw).date()
                # 清盘：asof 已过清盘日 -> 排除（这条正是消除幸存者偏差的关键）
                liq_raw = row.get("liquidation_date")
                ok = True
                if liq_raw:
                    try:
                        if (asof_d - pd.to_datetime(liq_raw).date()).days > 0:
                            ok = False
                    except Exception:
                        pass
                if ok:
                    status = master.status_asof(code, asof_d)
                    if status is None:
                        status = (status_map or {}).get(code)
                    ok = self.eligible_at(
                        asof_d, setup, last,
                        purchase_status=status,
                        scale_yi=master.scale_asof(code, asof_d),
                    )
                n_master += 1

            if ok:
                eligible.append(code)

        logger.info(
            f"[{asof_d}] 动态池(基础库) {len(eligible)}/{len(hist.columns)} 可买 "
            f"[事实={n_master} 降级代理={n_proxy}]"
        )
        return eligible

    @staticmethod
    def parse_snapshot_status(snapshot: pd.DataFrame) -> Dict[str, str]:
        """每日快照 -> {fund_code: 申购状态}。兼容列名漂移。"""
        if snapshot is None or snapshot.empty:
            return {}
        code_col = "fund_code" if "fund_code" in snapshot.columns else "基金代码"
        buy_col = None
        for c in snapshot.columns:
            if "申购" in str(c):
                buy_col = c
                break
        if buy_col is None:
            return {}
        out = {}
        for _, r in snapshot.iterrows():
            try:
                out[str(r[code_col])] = str(r[buy_col])
            except Exception:
                continue
        return out
