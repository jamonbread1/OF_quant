# -*- coding: utf-8 -*-
"""legacy → market.db 迁移导入器（幂等，可重复执行做增量吸收）。

数据来源与清洗规则
------------------
fund_master.db → fund（主档富信息）+ fund_scale + snapshot_daily(吸收最新快照)
nav_bulk.db    → fund_nav（82 万行）+ fund(统计列由 refresh_stats 重算)
fund_reports.db→ fund_fee / fund_manager / fund_manager_announce / fund_holder
                 / fund_holdings / fund_industry / subscribe_status_daily

清洗动作：
  * 代码统一 6 位（_c6：剥 .OF、左补零）
  * 日期统一 YYYY-MM-DD 前 10 位
  * 数值列 try-float，失败置 NULL（不猜）
  * 外键兜底：子表数据先 INSERT OR IGNORE 主档 stub 行
  * 幂等：全部 ON CONFLICT ... DO UPDATE，重复执行只覆盖同主键行
"""
import os
import sqlite3
from datetime import datetime
from typing import Dict, Optional

from .market_db import MarketDB, _c6, _now

_STORE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "store")


def _open(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn


def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
    r = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                     (name,)).fetchone()
    return r is not None


def import_fund_master(mk: MarketDB, db_path: str = None) -> Dict[str, int]:
    """fund_master.db → fund 主档 + fund_scale。"""
    p = db_path or os.path.join(_STORE, "fund_master.db")
    if not os.path.exists(p):
        return {"funds": 0, "scale": 0}
    conn = _open(p)
    n_fund = n_scale = 0
    try:
        if _table_exists(conn, "fund_master"):
            rows = [dict(r) for r in conn.execute("SELECT * FROM fund_master").fetchall()]
            payload = [{
                "fund_code": r["fund_code"], "fund_name": r.get("fund_name"),
                "fund_type": r.get("fund_type"), "company": r.get("company"),
                "manager": r.get("manager"),
                "setup_date": (r.get("setup_date") or "")[:10] or None,
                "liquidation_date": (r.get("liquidation_date") or "")[:10] or None,
                "end_date": (r.get("end_date") or "")[:10] or None,
                "scale_yi": r.get("scale_yi"),
            } for r in rows]
            n_fund = mk.upsert_funds(payload)
        if _table_exists(conn, "fund_scale"):
            data = []
            for r in conn.execute("SELECT * FROM fund_scale").fetchall():
                r = dict(r)                      # sqlite3.Row 没有 .get()
                c = _c6(r["fund_code"])
                if not c or not r["report_date"]:
                    continue
                try:
                    sc = None if r["scale_yi"] is None else float(r["scale_yi"])
                    sh = None if r["shares_yi"] is None else float(r["shares_yi"])
                except (TypeError, ValueError):
                    sc = sh = None
                if sc is None and sh is None:
                    continue
                data.append((c, str(r["report_date"])[:10], sc, sh,
                             r.get("source") or "master_migration", _now()))
            if data:
                mk._ensure_fund_row_bulk(codes=[d[0] for d in data])
                with mk._lock:
                    mk.conn.executemany(
                        "INSERT INTO fund_scale (fund_code, report_date, scale_yi, "
                        "shares_yi, source, updated_at) VALUES (?,?,?,?,?,?) "
                        "ON CONFLICT(fund_code, report_date) DO UPDATE SET "
                        "scale_yi=excluded.scale_yi, shares_yi=excluded.shares_yi, "
                        "source=excluded.source, updated_at=excluded.updated_at", data)
                    mk.conn.commit()
                n_scale = len(data)
    finally:
        conn.close()
    return {"funds": n_fund, "scale": n_scale}


_SYNC_CURSOR_KEY = "nav_import_cursor"


def _get_cursor(mk: MarketDB) -> Optional[str]:
    try:
        r = mk.conn.execute("SELECT value FROM market_meta WHERE key=?",
                            (_SYNC_CURSOR_KEY,)).fetchone()
        v = r[0] if r else None
    except Exception:
        return None
    # ⚠️ 空串/空白一律视为"没有位点"：
    # 若当成一个有效值，`updated_at > ''` 会匹配**全部行**，
    # 于是名义上跑的是增量、实际每次仍是全量重导，却完全看不出来
    # （日志会显示"变动 83 万行"但 incremental=True，极易误判为正常）。
    return v if v and str(v).strip() else None


def _set_cursor(mk: MarketDB, value: str) -> None:
    try:
        mk.conn.execute(
            "INSERT INTO market_meta(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (_SYNC_CURSOR_KEY, value))
        mk.conn.commit()
    except Exception:
        pass


def import_nav_bulk(mk: MarketDB, db_path: str = None,
                    batch: int = 20000, force_full: bool = False) -> Dict[str, int]:
    """nav_bulk.db → fund_nav（**行级增量**，首次自动全量）。

    为什么必须改成增量
    ------------------
    原实现每次都把 nav_daily_bulk **整表**重导一遍。当前 83 万行跑 5s 还能忍，
    但库的目标规模是全市场 2.7 万只 × 上千交易日 = 数千万行，
    那时候每晚全量重导会变成小时级，直接占满调度窗口。

    增量依据：nav_daily_bulk.updated_at（由 NavBulkStore 维护）。
    每晚只有"本批刷过的基金"有更新，且每只只多 1~2 天 →
    实测从 83 万行降到几百行。

    位点语义
    --------
    `market_meta.nav_import_cursor` 记住"上次同步开始的时刻"，
    本次只导 `updated_at > cursor` 的行。
    * cursor 为空（首次 / 库重建）→ 自动全量；
    * 取数位点用**本次同步开始的时刻**，而不是"导入完的时刻"——
      否则同步期间写入的行会落在窗口外被永久漏掉；
    * 时间戳定长微秒（见 NavBulkStore.upsert_nav），保证字符串比较可靠。

    ⚠️ 幂等兜底：即使位点出错漏了几行，也只会"不更新"而不会写坏数据，
    需要全量重建时传 `force_full=True` 即可。
    """
    p = db_path or os.path.join(_STORE, "nav_bulk.db")
    if not os.path.exists(p):
        return {"funds": 0, "nav_rows": 0}
    conn = _open(p)
    funds = set()
    total = 0
    cursor = None if force_full else _get_cursor(mk)
    # 位点取"同步开始前"的时刻：导入过程中若有人写入也不会被漏
    sync_start = datetime.now().isoformat(timespec="microseconds")
    incremental = cursor is not None
    try:
        if not _table_exists(conn, "nav_daily_bulk"):
            return {"funds": 0, "nav_rows": 0}
        cols = {r["name"] for r in conn.execute(
            "PRAGMA table_info(nav_daily_bulk)").fetchall()}
        if incremental and "updated_at" not in cols:
            # 老库还没升级出该列 —— 退回全量，宁可慢也不能漏数据
            incremental = False
            cursor = None
        if incremental:
            sql = ("SELECT fund_code, date, adj_nav, unit_nav FROM nav_daily_bulk "
                   "WHERE updated_at > ? ORDER BY fund_code, date")
            cur = conn.execute(sql, (cursor,))
        else:
            cur = conn.execute(
                "SELECT fund_code, date, adj_nav, unit_nav FROM nav_daily_bulk "
                "ORDER BY fund_code, date")
        buf: list = []
        while True:
            rows = cur.fetchmany(batch)
            if not rows:
                break
            for r in rows:
                c = _c6(r["fund_code"])
                if not c or not r["date"]:
                    continue
                funds.add(c)
                try:
                    adj = None if r["adj_nav"] is None else float(r["adj_nav"])
                    unit = None if r["unit_nav"] is None else float(r["unit_nav"])
                except (TypeError, ValueError):
                    continue
                if adj is None and unit is None:
                    continue
                buf.append((c, str(r["date"])[:10], unit, None, adj, None, None,
                            "standard", "bulk_migration", _now()))
            if buf:
                mk._ensure_fund_row_bulk(codes=funds)
                with mk._lock:
                    mk.conn.executemany(
                        "INSERT INTO fund_nav (fund_code, nav_date, unit_nav, acc_nav, "
                        "adj_nav, daily_return, shares, nav_type, source, updated_at) "
                        "VALUES (?,?,?,?,?,?,?,?,?,?) "
                        "ON CONFLICT(fund_code, nav_date) DO UPDATE SET "
                        "unit_nav=excluded.unit_nav, adj_nav=excluded.adj_nav, "
                        "source=excluded.source, updated_at=excluded.updated_at", buf)
                    mk.conn.commit()
                total += len(buf)
                buf = []
        # 只有在真的同步成功之后才推进位点：中途异常时不推进，
        # 下次仍会重导这批，不会静默丢数据。
        _set_cursor(mk, sync_start)
    finally:
        conn.close()
    return {"funds": len(funds), "nav_rows": total,
            "incremental": incremental, "cursor": sync_start}


def import_fund_reports(mk: MarketDB, db_path: str = None) -> Dict[str, int]:
    """fund_reports.db → 费率/经理/公告/持有人/持仓/行业/申赎快照。"""
    p = db_path or os.path.join(_STORE, "fund_reports.db")
    if not os.path.exists(p):
        return {}
    conn = _open(p)
    out: Dict[str, int] = {}
    try:
        now = _now()

        # ---- fund_fee ----
        if _table_exists(conn, "fund_fee"):
            fees = [dict(r) for r in conn.execute("SELECT * FROM fund_fee").fetchall()]
            for r in fees:
                mk.upsert_fee(r["fund_code"], {
                    "buy_rate_raw": r.get("buy_rate_raw"),
                    "buy_rate_disc": r.get("buy_rate_disc"),
                    "mgmt_rate": r.get("mgmt_rate"),
                    "custody_rate": r.get("custody_rate"),
                    "sales_service": r.get("sales_service"),
                    "subscribe_stat": r.get("subscribe_stat"),
                    "redeem_stat": r.get("redeem_stat"),
                }, source="reports_migration")
            out["fees"] = len(fees)

        # ---- fund_manager ----
        if _table_exists(conn, "fund_manager_hist"):
            data = []
            codes = set()
            for r in conn.execute("SELECT * FROM fund_manager_hist").fetchall():
                r = dict(r)                      # sqlite3.Row 没有 .get()
                c = _c6(r["fund_code"])
                if not c or not r["start_date"]:
                    continue
                # 旧行 managers 是逗号分隔的"该段在任全体"，拆成每人一行
                for nm in str(r["managers"] or "").split(","):
                    nm = nm.strip()
                    if not nm:
                        continue
                    codes.add(c)
                    data.append((c, nm, str(r["start_date"])[:10],
                                 (str(r["end_date"])[:10] if r["end_date"] else None),
                                 now))
            if data:
                mk._ensure_fund_row_bulk(codes=codes)
                with mk._lock:
                    mk.conn.executemany(
                        "INSERT INTO fund_manager (fund_code, manager_name, start_date, "
                        "end_date, updated_at) VALUES (?,?,?,?,?) "
                        "ON CONFLICT(fund_code, manager_name, start_date) DO UPDATE SET "
                        "end_date=excluded.end_date, updated_at=excluded.updated_at",
                        data)
                    mk.conn.commit()
                out["manager_rows"] = len(data)

        # ---- fund_manager_announce ----
        if _table_exists(conn, "fund_manager_announce"):
            data, codes = [], set()
            for r in conn.execute("SELECT * FROM fund_manager_announce").fetchall():
                r = dict(r)
                c = _c6(r["fund_code"])
                if not c or not r["ann_date"]:
                    continue
                codes.add(c)
                data.append((c, str(r["ann_date"])[:10],
                             str(r.get("title") or ""), now))
            if data:
                mk._ensure_fund_row_bulk(codes=codes)
                with mk._lock:
                    mk.conn.executemany(
                        "INSERT OR IGNORE INTO fund_manager_announce "
                        "(fund_code, ann_date, title, updated_at) VALUES (?,?,?,?)",
                        data)
                    mk.conn.commit()
                out["announce_rows"] = len(data)

        # ---- fund_holder ----
        if _table_exists(conn, "fund_holder_struct"):
            data, codes = [], set()
            for r in conn.execute("SELECT * FROM fund_holder_struct").fetchall():
                r = dict(r)
                c = _c6(r["fund_code"])
                if not c or not r["report_date"]:
                    continue
                codes.add(c)
                data.append((c, str(r["report_date"])[:10], r.get("inst_ratio"),
                             r.get("person_ratio"), r.get("internal_ratio"),
                             r.get("total_shares"),
                             (str(r["avail_date"])[:10] if r["avail_date"] else None),
                             now))
            if data:
                mk._ensure_fund_row_bulk(codes=codes)
                with mk._lock:
                    mk.conn.executemany(
                        "INSERT INTO fund_holder (fund_code, report_date, inst_ratio, "
                        "person_ratio, internal_ratio, total_shares, avail_date, "
                        "updated_at) VALUES (?,?,?,?,?,?,?,?) "
                        "ON CONFLICT(fund_code, report_date) DO UPDATE SET "
                        "inst_ratio=excluded.inst_ratio, "
                        "person_ratio=excluded.person_ratio, "
                        "internal_ratio=excluded.internal_ratio, "
                        "total_shares=excluded.total_shares, "
                        "avail_date=excluded.avail_date, updated_at=excluded.updated_at",
                        data)
                    mk.conn.commit()
                out["holder_rows"] = len(data)

        # ---- fund_holdings ----
        if _table_exists(conn, "fund_holdings"):
            data, codes = [], set()
            for r in conn.execute("SELECT * FROM fund_holdings").fetchall():
                r = dict(r)
                c = _c6(r["fund_code"])
                if not c or not r["report_date"]:
                    continue
                codes.add(c)
                data.append((c, str(r["report_date"])[:10],
                             str(r.get("stock_code") or ""), str(r.get("stock_name") or ""),
                             r.get("weight"), r.get("shares"), r.get("market_val"),
                             r.get("report_kind"),
                             (str(r["avail_date"])[:10] if r["avail_date"] else None),
                             now))
            if data:
                mk._ensure_fund_row_bulk(codes=codes)
                with mk._lock:
                    # PK (fund_code, report_date, stock_code)：同键多行会被忽略
                    mk.conn.executemany(
                        "INSERT OR IGNORE INTO fund_holdings (fund_code, report_date, "
                        "stock_code, stock_name, weight, shares, market_val, "
                        "report_kind, avail_date, updated_at) "
                        "VALUES (?,?,?,?,?,?,?,?,?,?)", data)
                    mk.conn.commit()
                out["holding_rows"] = len(data)

        # ---- fund_industry ----
        if _table_exists(conn, "fund_industry"):
            data, codes = [], set()
            for r in conn.execute("SELECT * FROM fund_industry").fetchall():
                r = dict(r)
                c = _c6(r["fund_code"])
                if not c or not r["report_date"] or not r["industry"]:
                    continue
                codes.add(c)
                data.append((c, str(r["report_date"])[:10], str(r["industry"]),
                             r.get("weight"),
                             (str(r["avail_date"])[:10] if r["avail_date"] else None),
                             now))
            if data:
                mk._ensure_fund_row_bulk(codes=codes)
                with mk._lock:
                    mk.conn.executemany(
                        "INSERT OR IGNORE INTO fund_industry (fund_code, report_date, "
                        "industry, weight, avail_date, updated_at) VALUES (?,?,?,?,?,?)",
                        data)
                    mk.conn.commit()
                out["industry_rows"] = len(data)

        # ---- subscribe_status_daily ----
        if _table_exists(conn, "subscribe_status_daily"):
            import pandas as pd
            df = pd.DataFrame([dict(r) for r in conn.execute(
                "SELECT * FROM subscribe_status_daily").fetchall()])
            if not df.empty:
                out["snapshot_rows"] = mk.upsert_subscribe_snapshot(df)
    finally:
        conn.close()
    return out


def import_full_market(mk: MarketDB) -> int:
    """联网拉全市场名录（含清盘）→ fund 主档。失败返回 0（库内数据不动）。"""
    from .market_db import fetch_full_market_list
    rows = fetch_full_market_list()
    if not rows:
        return 0
    return mk.upsert_funds(rows)


def absorb_legacy(mk: MarketDB, parts=("master", "nav", "reports"),
                  refresh: bool = True) -> Dict[str, int]:
    """把 legacy 三库已写入的数据吸收进 market.db（幂等，可重复调用）。

    Phase C 的中枢：各数据任务仍然用成熟的 legacy 写入逻辑（断点续跑、
    错误重试、进度表都在 legacy 侧），**跑完立刻调这个**，market.db 就成为
    唯一权威读源；legacy 退化为"写入暂存区"，随时可归档。

    parts: 只吸收指定来源，避免每次都全量扫（净值 82 万行最贵）。
        "master"  → fund_master.db（主档富信息 + 规模历史）
        "nav"     → nav_bulk.db（日频净值）
        "reports" → fund_reports.db（费率/经理/公告/持有人/持仓/行业/快照）
    """
    res: Dict[str, int] = {}
    if "master" in parts:
        res.update(import_fund_master(mk))
    if "nav" in parts:
        res.update(import_nav_bulk(mk))
    if "reports" in parts:
        res.update(import_fund_reports(mk))
    if refresh:
        res["status_counts"] = mk.refresh_stats().get("total", 0)
    return res


def legacy_read_audit(root: str = None) -> Dict[str, list]:
    """审计：还有哪些代码在直接读 legacy 三库（退役前必须清零的清单）。

    不做任何修改，只返回 {库文件名: [命中文件, ...]}，供人工判断
    「能否归档」。命中 legacy 的语句只要还在，归档就会立刻打断功能。
    """
    import re
    root = root or os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    targets = {"fund_master.db": [], "nav_bulk.db": [], "fund_reports.db": []}
    pat = re.compile(r"fund_master\.db|nav_bulk\.db|fund_reports\.db")
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d not in
                  ("__pycache__", ".git", "node_modules", "archive", ".cache")]
        for fn in fns:
            if not fn.endswith(".py"):
                continue
            p = os.path.join(dp, fn)
            try:
                with open(p, encoding="utf-8", errors="ignore") as f:
                    lines = f.readlines()
            except Exception:
                continue
            for ln in lines:
                s = ln.strip()
                # 注释/docstring 里的库名只是说明文字，不构成真实依赖
                if not s or s.startswith("#") or s.startswith('"""') or s.startswith("'"):
                    continue
                for m in pat.findall(ln):
                    rel = os.path.relpath(p, root)
                    if rel not in targets[m]:
                        targets[m].append(rel)
    return targets


def archive_legacy(store_dir: str = None, dry_run: bool = True) -> Dict:
    """把 legacy 三库移到 store/archive/（真退役动作，默认 dry_run）。

    ⚠️ 归档前必须先跑 legacy_read_audit() 确认没有代码再读它们。
    默认 dry_run=True：只报告将要移动什么，不动文件。
    """
    store_dir = store_dir or _STORE
    arc = os.path.join(store_dir, "archive")
    moved, planned = [], []
    for name in ("fund_master.db", "nav_bulk.db", "fund_reports.db"):
        src = os.path.join(store_dir, name)
        if not os.path.exists(src):
            continue
        dst = os.path.join(arc, name)
        planned.append({"file": name, "bytes": os.path.getsize(src)})
        if not dry_run:
            os.makedirs(arc, exist_ok=True)
            os.replace(src, dst)
            moved.append(name)
    return {"dry_run": dry_run, "planned": planned, "moved": moved,
            "archive_dir": arc}


def migrate_all(mk: MarketDB, with_network: bool = True,
                force_full: bool = False) -> Dict[str, int]:
    """一键迁移/增量吸收（维持任务每日调用）。

    force_full=True 时净值部分走**全量重导**（忽略同步位点）。
    用于：怀疑增量漏了数据、或重建 market.db 之后需要把历史全部搬回来。
    """
    t0 = datetime.now()
    res: Dict[str, int] = {}
    res.update(import_fund_master(mk))
    res.update(import_nav_bulk(mk, force_full=force_full))
    res.update(import_fund_reports(mk))
    if with_network:
        res["market_list"] = import_full_market(mk)
    status = mk.refresh_stats()
    res["status_counts"] = status.get("total", 0)
    res["seconds"] = int((datetime.now() - t0).total_seconds())
    return res
