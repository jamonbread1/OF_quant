# -*- coding: utf-8 -*-
"""基金代码归一化（P0-5 修复的统一出口）。

🔴 问题（2026-09-26 评审）：项目里同时存在两种代码口径 ——
    * `004401`  （6 位裸码，来自 `res.pool` / `res.final_weights`）
    * `004401.OF`（带后缀，来自 `app/portfolio.json` 的持仓快照、现金载体 `000605.OF`）

    后果不止"看起来不整齐"（实测 2026-09-26 的生产决策）：
        held  = {"004401.OF": 868.96}
        picks = ["000370", ..., "004401", ...]        # 裸码
        to_sell = [c for c in held if c not in set(picks)]  → 004401.OF 全额赎回
        to_buy  = [c for c in picks if c not in held]       → 004401   又买回来
    即：**模型给它 20% 权重，执行层却把它全额赎回再全额申购**。
    每月重复一次 → 白付 0.5%~0.75% 赎回费 + 重复申购费，且持有期被清零，
    永远够不到"持有 ≥180 天赎回费为 0"。这是当前赎回成本居高不下的直接来源。

纪律：
  * **系统内部一律用 6 位裸码**；`.OF` 只在对外（下单文件/展示）时附加。
  * 所有跨模块边界（持仓快照、池成员、权重索引、费率表、成交记录）进入时
    先过 `norm_code`，比较时用 `norm_code`。
"""
from typing import Iterable, List, Optional, Sequence

SUFFIXES = (".OF", ".of", ".SH", ".SZ", ".sh", ".sz")


def norm_code(code: Optional[str]) -> str:
    """`004401.OF` / ` 4401 ` / `004401` → `004401`；非数字原样返回（便于诊断）。"""
    if code is None:
        return ""
    c = str(code).strip()
    for s in SUFFIXES:
        if c.endswith(s):
            c = c[: -len(s)]
            break
    c = c.strip()
    return c.zfill(6) if c.isdigit() else c


def norm_codes(codes: Optional[Iterable]) -> List[str]:
    if not codes:
        return []
    return [norm_code(c) for c in codes if norm_code(c)]


def norm_map(mapping: Optional[dict]) -> dict:
    """把 dict 的键归一化（后出现者覆盖前者，避免 004401 / 004401.OF 并存）。"""
    out = {}
    for k, v in (mapping or {}).items():
        k2 = norm_code(k)
        if k2:
            out[k2] = v
    return out


def norm_index(seq: Optional[Sequence]):
    """归一化 pandas Index / Series.index。pandas 可用时返回 Index，否则返回 list。"""
    if seq is None:
        return seq
    try:
        import pandas as pd
        return pd.Index([norm_code(c) for c in seq])
    except Exception:
        return [norm_code(c) for c in seq]
