# -*- coding: utf-8 -*-
"""nav_bulk.db 的只读取数通道（不写库、不联网）。

⚠️ 只按 `nav_daily_bulk` 的**真实数据行**判断有没有净值，不要看 bulk_progress
进度表 —— 进度表会被重建/回退，拿它回答"本地有没有"会与取数结果说两套话。
⚠️ 库不存在 / 无此基 / 行数不足 → 抛 LookupError，由 DataPipeline 回落联网。
"""
from __future__ import annotations

import os
import sqlite3
from typing import Dict, List, Optional

import pandas as pd

from ..nav_bulk import DEFAULT_BULK_DB, _norm

# 输出列名与 PublicFundProvider 保持一致，下游（清洗 / 对齐 / PIT）无需改动
OUT_COLUMNS = ["fund_code", "unit_nav", "acc_nav", "adj_nav", "adj_method"]


class BulkNavProvider:
    """从 nav_bulk.db 读单只基金的净值序列（纯本地、无网络）。"""

    def __init__(self, db_path: Optional[str] = None, min_rows: int = 60):
        self.db_path = db_path or DEFAULT_BULK_DB
        self.min_rows = int(min_rows)

    # ---------- 基础 ----------
    def available(self) -> bool:
        return bool(self.db_path) and os.path.exists(self.db_path)

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    # ---------- 读 ----------
    def fetch(self, fund_code: str, start_date: Optional[str] = None,
              end_date: Optional[str] = None) -> pd.DataFrame:
        """返回与 PublicFundProvider.fetch 同构的 DataFrame（date 索引）。

        行数不足 `min_rows` 时抛 LookupError —— 交给上层回落联网，
        避免"库里只有 3 行脏数据"被当成有效序列喂进回测。
        """
        if not self.available():
            raise LookupError(f"bulk 库不存在: {self.db_path}")
        code = _norm(fund_code)
        sql = "SELECT date, unit_nav, adj_nav FROM nav_daily_bulk WHERE fund_code = ?"
        args: List[object] = [code]
        if start_date:
            sql += " AND date >= ?"
            args.append(str(start_date)[:10])
        if end_date:
            sql += " AND date <= ?"
            args.append(str(end_date)[:10])
        sql += " ORDER BY date"

        conn = self._conn()
        try:
            rows = conn.execute(sql, args).fetchall()
        finally:
            conn.close()
        if len(rows) < self.min_rows:
            raise LookupError(f"{code} bulk 库仅 {len(rows)} 行 < {self.min_rows}")

        df = pd.DataFrame([dict(r) for r in rows])
        df["date"] = pd.to_datetime(df["date"])
        df = df.set_index("date").sort_index()
        df["fund_code"] = code
        # bulk 库不存累计净值：用复权净值占位。下游只用 adj_nav 算收益，
        # acc_nav 缺失不影响任何算子；留列是为了保持列结构一致。
        df["acc_nav"] = df["adj_nav"]
        df["adj_method"] = "bulk"
        return df[OUT_COLUMNS]

    def local_nav_index(self, min_rows: int = 0) -> Dict[str, Dict]:
        """{code: {rows, first_date, last_date}}（纯本地，不联网）。"""
        out: Dict[str, Dict] = {}
        if not self.available():
            return out
        n = int(min_rows)
        sql = ("SELECT fund_code, COUNT(*) AS n, MIN(date) AS d0, MAX(date) AS d1 "
               "FROM nav_daily_bulk GROUP BY fund_code")
        if n > 0:
            sql += f" HAVING n >= {n}"
        conn = self._conn()
        try:
            for r in conn.execute(sql).fetchall():
                out[str(r["fund_code"])] = {
                    "rows": int(r["n"]),
                    "first_date": str(r["d0"]),
                    "last_date": str(r["d1"]),
                }
        finally:
            conn.close()
        return out


def merge_nav_index(*indexes: Dict[str, Dict]) -> Dict[str, Dict]:
    """合并多个来源的本地净值索引，同一代码取**行数更多**的那份。

    .cache 与 bulk 可能同时有某只基金；取更全的一份，避免选池时
    因"bulk 有 3000 行但 .cache 只有 200 行"而误判样本不足。
    """
    out: Dict[str, Dict] = {}
    for idx in indexes:
        for code, meta in (idx or {}).items():
            prev = out.get(code)
            if prev is None or int(meta.get("rows") or 0) > int(prev.get("rows") or 0):
                out[code] = dict(meta)
    return out
