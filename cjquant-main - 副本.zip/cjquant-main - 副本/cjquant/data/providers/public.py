import os
import re
import time
import logging
import pandas as pd
from typing import Optional, Dict
from .base import BaseProvider
from ..schema import FundDataSchema
from ..exceptions import DataFetchError, FundNoNavPageError
from .. import net

logger = logging.getLogger(__name__)

# 复权递推：a(t) = a(t-1) * [u(t)*s(t) + d(t)] / u(t-1)，a(0)=u(0)
# u=单位净值，s=拆分比例(默认1)，d=每份分红(除息日)


def _parse_dividend_per_share(raw: str) -> float:
    """解析 '每10份派现金0.1000元' -> 0.01。解析失败返回 0.0。"""
    if raw is None:
        return 0.0
    s = str(raw)
    nums = re.findall(r"([0-9]+\.?[0-9]*)", s)
    if not nums:
        return 0.0
    try:
        # 取最后一个数字为分红金额（避开开头的“10份”）
        val10 = float(nums[-1])
    except ValueError:
        return 0.0
    # 接口字段为“每10份”，统一折为每份
    if "10" in s:
        return val10 / 10.0
    return val10


def _compute_adj_nav(
    unit_series: pd.Series,
    dividends: Dict[pd.Timestamp, float],
    splits: Dict[pd.Timestamp, float],
) -> pd.Series:
    """给定单位净值序列 + 除息日分红map + 拆分map，前向递推复权序列。"""
    unit_series = unit_series.sort_index()
    adj = pd.Series(index=unit_series.index, dtype=float)
    prev_adj = None
    prev_u = None
    for dt, u in unit_series.items():
        if pd.isna(u) or u is None or float(u) <= 0:
            adj.loc[dt] = float("nan") if prev_adj is None else prev_adj
            continue
        u = float(u)
        if prev_adj is None:
            prev_adj = u
            prev_u = u
            adj.loc[dt] = prev_adj
            continue
        s = float(splits.get(dt, 1.0)) if splits else 1.0
        d = float(dividends.get(dt, 0.0)) if dividends else 0.0
        if prev_u is None or prev_u <= 0:
            prev_adj = u
            prev_u = u
            adj.loc[dt] = prev_adj
            continue
        try:
            prev_adj = prev_adj * (u * s + d) / prev_u
        except ZeroDivisionError:
            prev_adj = u
        adj.loc[dt] = prev_adj
        prev_u = u
    return adj


def _is_no_nav_page_error(err: BaseException) -> bool:
    """向后兼容别名。判定逻辑已下沉到统一访问层 `cjquant.data.net`，
     fund_master / lsjz 等模块现在共用同一份规则。"""
    return net.is_no_nav_page_error(err)


def _require_frame(df, indicator: str):
    """结果校验器：None / 空表一律视为失败（交给统一层退避重试）。

    提取出来是为了让「空表算失败」这条规则只有一处定义 ——
    改造前 public/list/snapshot/index 四处各写一遍 `if df is None or df.empty`。
    """
    if df is None or getattr(df, "empty", False):
        raise DataFetchError(f"接口返回空数据 (Indicator: {indicator})")
    return df


def _to_compact_date(value: Optional[str]) -> Optional[str]:
    """'2024-01-01' / '2024/01/01' -> '20240101'（index_zh_a_hist 要求的紧凑格式）。

    兼容已经是紧凑格式的入参，None 原样返回。解析不出来就原样返回，
    让接口自己去报错 —— 好过我们悄悄丢掉用户的过滤条件。
    """
    if value is None:
        return None
    s = str(value).strip()
    if len(s) == 8 and s.isdigit():
        return s
    try:
        return pd.to_datetime(s).strftime("%Y%m%d")
    except Exception:
        return value


class PublicFundProvider(BaseProvider):
    """公募基金 Provider（生产级：真复权 + 缓存 + 容错降级）。"""

    def __init__(
        self,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        cache_dir: Optional[str] = None,
        cache_ttl_seconds: int = 86400,
        adjust: bool = True,
        fail_fast_on_missing_page: bool = True,
    ):
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.cache_dir = cache_dir
        self.cache_ttl_seconds = cache_ttl_seconds
        self.adjust = adjust
        # 数据源明确说"没这个页"时不再空转重试（可关掉以排查偶发限流）
        self.fail_fast_on_missing_page = fail_fast_on_missing_page
        if cache_dir:
            os.makedirs(cache_dir, exist_ok=True)

    # ---------- 底层 ----------
    def _get_raw_data(self, fund_code: str, indicator: str) -> pd.DataFrame:
        """抓单个 indicator；重试/退避/错误归类全部由统一访问层负责。

        改造前这里自带一个手写 for + time.sleep 的重试循环，与
        look_through/holdings.py、nav_bulk.py 里那两个是三份几乎一样的代码。
        """
        try:
            return net.ak_call(
                "fund_open_fund_info_em",
                symbol=fund_code,
                indicator=indicator,
                validator=lambda df: _require_frame(df, indicator),
                fail_fast=self.fail_fast_on_missing_page,
            )
        except FundNoNavPageError as e:
            # 确定性失败：该代码在数据源没有净值数据，重试只会浪费时间。
            # 统一层给出的是归类，这里补上**面向用户**的解释 —— 这条消息会一路
            # 显示到前端（app/main.py 把它放进 excluded[].reason），不能只有技术细节。
            raise FundNoNavPageError(
                f"{fund_code} 无独立净值页（数据源返回 HTML 错误页或 JS 缺净值变量），"
                f"该代码可能是「(后端)」收费份额或已下架，请换用其前端份额代码"
            ) from e
        except DataFetchError as e:
            raise DataFetchError(
                f"获取公募数据失败: {fund_code} [{indicator}] {net.short_err(e)}") from e

    def _get_raw_optional(self, fund_code: str, indicator: str) -> Optional[pd.DataFrame]:
        """分红/拆分等辅助数据：失败返回 None，不阻断主流程（降级为累计净值）。

        ⚠️ max_retries=1：这是**可选**字段，而"没有分红/没有拆分"是绝大多数基金的
        正常状态 —— 接口返回空表是**预期答案**，不是故障。
        【2026-09-26 踩坑】这里一度走了默认的 3 次重试：实测单只基金的增量刷新从
        ~20s 涨到 ~150s，全靠等待注定拿不到的数据。梯级退避对"预期为空"的调用
        是纯负收益，只有「主指标」（单位/累计净值）才值得重试。
        """
        try:
            return net.ak_call(
                "fund_open_fund_info_em",
                symbol=fund_code, indicator=indicator,
                validator=lambda df: _require_frame(df, indicator),
                max_retries=1,
            )
        except Exception as e:
            # 用 debug 而不是 warning：绝大多数基金本来就没有拆分/分红记录，
            # 返回空表是**预期答案**。实测一次 284 只的增量刷新会打出 568 条
            # 这种 warning，把真正需要人看的错误（如连续失败、源异常）彻底淹没。
            logger.debug(f"{fund_code} 无 {indicator}（降级为累计净值）: {net.short_err(e)}")
            return None

    def _cache_path(self, fund_code: str) -> Optional[str]:
        if not self.cache_dir:
            return None
        safe = re.sub(r"[^0-9A-Za-z.\-]", "_", fund_code)
        return os.path.join(self.cache_dir, f"public_{safe}.csv")

    def _load_cache(self, fund_code: str) -> Optional[pd.DataFrame]:
        path = self._cache_path(fund_code)
        if not path or not os.path.exists(path):
            return None
        try:
            age = time.time() - os.path.getmtime(path)
            if age > self.cache_ttl_seconds:
                return None
            df = pd.read_csv(path, index_col=0, parse_dates=True)
            if df.empty:
                return None
            return df
        except Exception as e:
            logger.warning(f"缓存读取失败 {fund_code}: {e}")
            return None

    def _save_cache(self, fund_code: str, df: pd.DataFrame):
        path = self._cache_path(fund_code)
        if not path:
            return
        try:
            df.to_csv(path, encoding="utf-8-sig")
        except Exception as e:
            logger.warning(f"缓存写入失败 {fund_code}: {e}")

    def local_nav_index(self) -> Dict[str, Dict]:
        """扫描本地缓存，返回 {code: {"rows","first_date","last_date"}}（纯本地，不联网）。

        这是「本地净值可得性」的**权威来源**：回测/研究取数走的就是这份缓存，
        缓存里有 = 取数不用联网。
        注意不要改用 nav_bulk 的进度表来回答"本地有没有净值"——预热库可能被
        重建/回退（2026-09-18 实测发生过：62 只缩回 41 只），而 .cache 里那批
        数据还原封不动。选池跟着取数路径走，两者才不会说两套话。
        """
        out: Dict[str, Dict] = {}
        if not self.cache_dir or not os.path.isdir(self.cache_dir):
            return out
        for fn in os.listdir(self.cache_dir):
            if not (fn.startswith("public_") and fn.endswith(".csv")):
                continue
            code = fn[len("public_"):-len(".csv")]
            if "." not in code:
                code += ".OF"
            try:
                # 只读日期列，够判断行数与覆盖区间。
                # 注意：usecols=[0]+index_col=0 之后不再有数据列，此时 df.empty 为 True
                # （它的语义是"任一轴为空"），不能用 df.empty 判断，要用行数。
                df = pd.read_csv(os.path.join(self.cache_dir, fn), index_col=0, usecols=[0])
            except Exception as e:
                logger.warning(f"本地净值缓存读取失败 {fn}: {e}")
                continue
            if len(df.index) == 0:
                continue
            idx = df.index
            try:
                out[code] = {"rows": int(len(idx)),
                             "first_date": str(idx[0])[:10],
                             "last_date": str(idx[-1])[:10]}
            except Exception:
                continue
        return out

    @staticmethod
    def _cache_covers(cached: pd.DataFrame, start_date, end_date) -> bool:
        """缓存是否覆盖本次请求区间。

        存在的意义：历史上缓存曾被写成窄表（见 fetch 里的注释），若不加这道校验，
        更宽的请求会命中窄缓存并被静默截断，表现成「策略历史不足、回测零成交」。
        区间不覆盖 -> 视为缓存未命中，走网络重取。
        注：对已停更/清盘基金，"末日不覆盖"会一直成立，因此每次都会重取一次网络 ——
        这是有意选择：宁可多一次请求，也不拿截断数据算回测。
        """
        if cached is None or cached.empty:
            return False
        try:
            if start_date and pd.to_datetime(start_date) < cached.index[0] - pd.Timedelta(days=3):
                return False
            if end_date:
                end_req = pd.to_datetime(end_date)
                today = pd.Timestamp.now().normalize()
                if end_req > today:
                    end_req = today
                if end_req - cached.index[-1] > pd.Timedelta(days=10):
                    return False
        except Exception:
            return False
        return True

    # ---------- 复权解析 ----------
    def _parse_dividends(self, df_div: Optional[pd.DataFrame]) -> Dict[pd.Timestamp, float]:
        """分红详情 -> {除息日: 每份分红}。字段：除息日 / 每10份分红。"""
        out: Dict[pd.Timestamp, float] = {}
        if df_div is None or df_div.empty:
            return out
        # 兼容列名漂移：按关键字定位
        ex_col = None
        div_col = None
        for c in df_div.columns:
            s = str(c)
            if "除息" in s and ex_col is None:
                ex_col = c
            if "10份" in s and div_col is None:
                div_col = c
        if ex_col is None or div_col is None:
            logger.warning(f"分红表列名无法识别: {list(df_div.columns)}")
            return out
        for _, row in df_div.iterrows():
            try:
                dt = pd.to_datetime(row[ex_col]).tz_localize(None)
                amt = _parse_dividend_per_share(row[div_col])
                if amt > 0:
                    # 同日多次分红累加
                    out[dt] = out.get(dt, 0.0) + amt
            except Exception:
                continue
        return out

    def _parse_splits(self, df_split: Optional[pd.DataFrame]) -> Dict[pd.Timestamp, float]:
        """拆分详情 -> {日期: 拆分比例}。解析失败则返回空（默认1.0）。"""
        out: Dict[pd.Timestamp, float] = {}
        if df_split is None or df_split.empty:
            return out
        # 拆分表结构各期不一，做最大努力解析：找日期列 + 比例列
        date_col = None
        ratio_col = None
        for c in df_split.columns:
            s = str(c)
            if ("日" in s or "date" in s.lower()) and date_col is None:
                # 优先含“拆分”“除权”的日期列
                date_col = c
            if ("拆" in s or "比例" in s or "倍" in s) and ratio_col is None:
                ratio_col = c
        if date_col is None:
            date_col = df_split.columns[0]
        if ratio_col is None or ratio_col == date_col:
            return out
        for _, row in df_split.iterrows():
            try:
                dt = pd.to_datetime(row[date_col]).tz_localize(None)
                m = re.search(r"([0-9]+\.?[0-9]*)", str(row[ratio_col]))
                if m:
                    r = float(m.group(1))
                    if 0 < r < 100:
                        out[dt] = r
            except Exception:
                continue
        return out

    # ---------- 主接口（保持向后兼容） ----------
    def fetch(
        self,
        fund_code: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        adjust: Optional[bool] = None,
        use_cache: bool = True,
    ) -> pd.DataFrame:
        code = str(fund_code).split(".")[0].zfill(6)
        do_adjust = self.adjust if adjust is None else adjust

        if use_cache:
            cached = self._load_cache(code)
            if cached is not None and self._cache_covers(cached, start_date, end_date):
                out = cached
                if start_date:
                    out = out[out.index >= pd.to_datetime(start_date)]
                if end_date:
                    out = out[out.index <= pd.to_datetime(end_date)]
                # 缓存已是标准格式，直接 validate 后返回
                try:
                    return FundDataSchema.validate(out.copy())
                except Exception:
                    pass  # 缓存损坏则继续走网络

        # ⚠️ 货币基金在这里会抛 FundNoNavPageError（东财对货基没有净值页），
        #    必须捕获后走下面的货基通道，而不是让 fetch 直接失败。
        try:
            df_unit = self._get_raw_data(code, "单位净值走势")
        except Exception:
            df_unit = pd.DataFrame()
        try:
            df_acc = self._get_raw_data(code, "累计净值走势")
        except Exception:
            df_acc = pd.DataFrame()

        # 货币基金通道（学自 FundVal-Live 的东财移动端接口）：
        # 普通"单位净值走势"对货基返回空（东财对货基展示的是万份收益/7日年化，
        # 没有净值走势），但移动端 FundMNHisNetList **有货基的历史收益序列**——
        # 实测（2026-09-19）：DWJZ=7日年化%、LJJZ=万份收益（元），
        # 天弘余额宝 000198 → 7日年化 2.27%、万份收益 0.823，量级正确。
        if df_unit is None or df_unit.empty or df_acc is None or df_acc.empty:
            mm = self._fetch_money_nav_history(code)
            if mm is not None and not mm.empty:
                full = mm
                try:
                    self._save_cache(code, FundDataSchema.validate(full.copy()))
                except Exception:
                    pass
                out = full
                if start_date:
                    out = out[out.index >= pd.to_datetime(start_date)]
                if end_date:
                    out = out[out.index <= pd.to_datetime(end_date)]
                if out.empty:
                    return out
                return FundDataSchema.validate(out.copy())

        df_unit["date"] = pd.to_datetime(df_unit["净值日期"])
        df_acc["date"] = pd.to_datetime(df_acc["净值日期"])

        df = pd.merge(
            df_unit[["date", "单位净值"]],
            df_acc[["date", "累计净值"]],
            on="date",
            how="outer",
        ).set_index("date").sort_index()

        df["累计净值"] = df["累计净值"].fillna(df["单位净值"])
        df["单位净值"] = pd.to_numeric(df["单位净值"], errors="coerce")

        # 真复权：a(t)=a(t-1)*[u(t)*s+d]/u(t-1)
        adj_method = "acc_fallback"
        if do_adjust:
            df_div = self._get_raw_optional(code, "分红送配详情")
            df_split = self._get_raw_optional(code, "拆分详情")
            dividends = self._parse_dividends(df_div)
            splits = self._parse_splits(df_split)
            if dividends or splits:
                try:
                    unit_s = df["单位净值"].copy()
                    adj_vals = _compute_adj_nav(unit_s, dividends, splits)
                    # 锚定：首个有效复权点对齐，避免与累计口径断层过大时难以排查
                    df["复权净值"] = adj_vals
                    adj_method = f"dividend_split(n_div={len(dividends)},n_split={len(splits)})"
                except Exception as e:
                    logger.warning(f"{code} 复权计算失败，回退累计净值: {e}")
                    df["复权净值"] = df["累计净值"]
            else:
                df["复权净值"] = df["累计净值"]
        else:
            df["复权净值"] = df["累计净值"]

        standard_df = pd.DataFrame(
            {
                FundDataSchema.CODE: f"{code}.OF",
                FundDataSchema.UNIT_NAV: df["单位净值"],
                FundDataSchema.ACC_NAV: df["累计净值"],
                FundDataSchema.ADJ_NAV: df["复权净值"],
            }
        )
        # 记录复权口径供排查（透传列，validate 会保留）
        standard_df["adj_method"] = adj_method

        # 先固化"全量"再按请求区间切片返回。
        # 【踩过的坑】这里原先注释写的是"缓存存全量（不过滤日期）"，代码却是先过滤再存，
        # 于是任何一次窄区间请求都会把缓存写成窄表；24h TTL 内后续更宽的请求命中该窄缓存，
        # 数据被静默截断 → 策略历史不足 → 整个回测输出「候选不足，跳过」、一笔不成交。
        full = standard_df
        try:
            self._save_cache(code, FundDataSchema.validate(full.copy()))
        except Exception:
            pass

        out = full
        if start_date:
            out = out[out.index >= pd.to_datetime(start_date)]
        if end_date:
            out = out[out.index <= pd.to_datetime(end_date)]
        if out.empty:
            return out
        return FundDataSchema.validate(out.copy())

    # ---------- 货币基金移动端通道（学自 FundVal-Live 项目） ----------
    _MOBILE_NAV_URL = "https://fundmobapi.eastmoney.com/FundMNewApi/FundMNHisNetList"
    _MOBILE_HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (iPhone; CPU iPhone OS 14_3 like Mac OS X) "
            "AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 eastmoney/6.2.8"
        ),
    }

    def _fetch_money_nav_history(self, code: str) -> Optional[pd.DataFrame]:
        """货币基金历史收益 → 合成单位净值曲线。

        接口：FundMNHisNetList（东财 App 移动端，公开无鉴权）。
        实测返回字段（2026-09-19 自洽性检验确定）：对货基
          **DWJZ = 当日万份收益（元）**，**LJJZ = 7日年化（%）**
        （不是普通基金的"单位净值/累计净值"！）。验证：000009 万份 0.3105 元
        → 年化 1.13% ≈ 其 7日年化 1.147%；000198 万份 0.2274 → 0.83% ≈ 0.823%。
        ⚠️ 必须带东财 App 的 User-Agent，普通 UA 返回空。

        为什么折算成净值而不是直接存收益：下游（回测引擎/风控/净值面板）全部
        按"净值序列"消费，把万份收益折算成日收益率再复利累积成 unit_nav，
        下游零改动。首日锚定 1.0。
        """
        # 走统一访问层：共享连接池 + 统一超时 + 退避重试。
        # 改造前这里是一次裸 requests.get，**完全没有重试** —— 货基通道本来就是
        # 「单位净值走势取不到」之后的兜底路径，偏偏它自己最脆，挂一次整只货基当天就没有净值。
        #
        # ⚠️ 这里**故意不加**进程内缓存：上层 fetch(use_cache=False) 的语义是
        # "这次必须拿新的"（cash_vehicle_warmup 每晚都用它拉最新货基收益、
        # 持仓页「刷新净值」按钮也走这条路）。在访问层偷偷缓存会把用户的
        # 显式刷新变成"点了没反应"，属于静默改变对外行为。
        params = {
            "FCODE": code, "IsShareNet": "true", "MobileKey": "1", "appType": "ttjj",
            "appVersion": "6.2.8", "cToken": "1", "deviceid": "1",
            "pageIndex": "1", "pageSize": "100000", "plat": "Iphone",
            "product": "EFund", "serverVersion": "6.2.8", "uToken": "1",
            "userId": "1", "version": "6.2.8",
        }
        try:
            payload = net.http_get_json(self._MOBILE_NAV_URL, params=params,
                                        headers=self._MOBILE_HEADERS)
            datas = (payload or {}).get("Datas") or []
        except Exception as e:
            logger.warning(f"[货币通道] {code} 移动端净值获取失败: {net.short_err(e)}")
            return None
        if not datas:
            return None
        rows = []
        for d in datas:
            try:
                dt = pd.to_datetime(str(d.get("FSRQ")))
                # 万份收益（DWJZ，元/万份/日）→ 日收益率 = 万份收益/10000；
                # 缺失时用 7日年化（LJJZ，%）/100/365 当日近似
                income = pd.to_numeric(d.get("DWJZ"), errors="coerce")
                ann7 = pd.to_numeric(d.get("LJJZ"), errors="coerce")
                if pd.notna(income) and income > 0:
                    daily_ret = float(income) / 10000.0
                elif pd.notna(ann7) and ann7 > 0:
                    daily_ret = float(ann7) / 100.0 / 365.0
                else:
                    daily_ret = 0.0
                rows.append((dt, daily_ret))
            except Exception:
                continue
        if not rows:
            return None
        rows.sort(key=lambda x: x[0])
        navs, nav = [], 1.0
        for dt, ret in rows:
            nav *= (1.0 + ret)
            navs.append((dt, round(nav, 6)))
        df = pd.DataFrame(navs, columns=["date", "nav"]).set_index("date").sort_index()
        standard = pd.DataFrame(
            {
                FundDataSchema.CODE: f"{code}.OF",
                FundDataSchema.UNIT_NAV: df["nav"],
                FundDataSchema.ACC_NAV: df["nav"],
                FundDataSchema.ADJ_NAV: df["nav"],
            }
        )
        # 口径标记（透传列）：排查时能一眼看出这是货基折算曲线，不是真实净值
        standard["adj_method"] = "money_market(万份收益折算,来源=东财移动端)"
        logger.info(f"[货币通道] {code} 折算净值 {len(standard)} 天"
                    f"（{df.index.min():%Y-%m-%d} ~ {df.index.max():%Y-%m-%d}）")
        return standard

    # ---------- 基金池 / 快照 / 基准（Phase1 新增） ----------
    def list_all_funds(self) -> pd.DataFrame:
        """全量基金列表（含已清盘，用于幸存者偏差治理）。

        ⚠️ 全市场名单在这一个方法、market_db.fetch_full_market_list、
        fund_master.fetch_fund_list **三处各自抓一遍**（每次 ≈2.7 万行）。
        这里统一走 net.cached_call：同进程、TTL 内只发一次真请求。
        """
        df = net.cached_call(
            "ak.fund_name_em()",
            lambda: net.ak_call("fund_name_em",
                                validator=lambda d: _require_frame(d, "fund_name_em")),
        )
        # standard cols：基金代码/简称/类型
        df = df.copy()
        rename = {"基金代码": "fund_code", "基金简称": "fund_name", "基金类型": "fund_type"}
        for k, v in rename.items():
            if k in df.columns:
                df[v] = df[k]
        df["fund_code"] = df["fund_code"].astype(str).str.zfill(6) + ".OF"
        return df

    def get_daily_snapshot(self) -> pd.DataFrame:
        """每日全量快照：含申购/赎回状态，用于动态池过滤。列名含日期，需动态解析。"""
        df = net.cached_call(
            "ak.fund_open_fund_daily_em()",
            lambda: net.ak_call(
                "fund_open_fund_daily_em",
                validator=lambda d: _require_frame(d, "daily snapshot")),
        )
        df = df.copy()
        # 归一化代码
        df["fund_code"] = df["基金代码"].astype(str).str.zfill(6) + ".OF"
        return df

    def get_rank_history(self, fund_code: str) -> Optional[pd.DataFrame]:
        """同类排名历史（辅助筛选），失败返回 None。"""
        for indicator in ("同类排名百分比", "同类排名走势"):
            try:
                df = net.ak_call("fund_open_fund_info_em",
                                 symbol=fund_code.split(".")[0],
                                 indicator=indicator,
                                 max_retries=1)
                if df is not None and not df.empty:
                    return df
            except Exception:
                continue
        return None

    def get_index_history(
        self, index_code: str = "000300", start_date: Optional[str] = None, end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """基准指数行情（Alpha/择时用），默认沪深300。

        ⚠️ 日期格式踩过的坑：`ak.index_zh_a_hist` 要的是 **紧凑格式 20240101**，
        本项目内部统一传 "2024-01-01"。改造前直接把原样字符串传下去，
        带横杠会被接口判为无效参数并返回空表 —— 表现成"指数取不到"而不是参数格式错。
        这里做一次归一。

        ⚠️ 源的选择（2026-09-26 实测复核）：`index_zh_a_hist` 走
        **80.push2.eastmoney.com**，该子域名在本机**直连与走代理均不可达**
        （直连 ConnectionError / 代理 ProxyError），因此本方法现在就是不可用的。
        funnel/style.py 改用新浪/腾讯双源回退正是为此。
        本方法当前零调用（见 HANDOVER §6）；**若日后要启用，必须先确认该域名可达**，
        或改为复用 funnel/style.py 的多源 loader —— 不要各自_SRC 各写一份。
        """
        df = net.ak_call(
            "index_zh_a_hist",
            symbol=index_code, period="daily",
            start_date=_to_compact_date(start_date),
            end_date=_to_compact_date(end_date),
            validator=lambda d: _require_frame(d, f"index {index_code}"),
        )
        df = df.copy()
        df["date"] = pd.to_datetime(df["日期"])
        return df.set_index("date").sort_index()
