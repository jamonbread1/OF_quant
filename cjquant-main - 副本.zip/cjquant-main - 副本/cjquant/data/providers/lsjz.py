# -*- coding: utf-8 -*-
"""f10/lsjz 分页净值源（纯 JSON，无需 JS 引擎）。

相比 pingzhongdata 的优势：
- 无净值页的代码返回 `TotalCount=0`，是干净的"无页"信号（而非 HTML 错误页）；
- 记录自带历史申购/赎回状态（SGZT/SHZT），是目前唯一的免费历史状态源；
- 分红行带 `FHFCZ10`（每10份派现）。

⚠️ 服务端忽略 pageSize>20，一页固定 20 行；老基金全史约 300 页，
   只适合按需/缓存落库，不要逐 bar 调用。
"""
from __future__ import annotations

import logging

import pandas as pd

from ..exceptions import DataFetchError, FundNoNavPageError
from .. import net

logger = logging.getLogger(__name__)

LSJZ_URL = "https://api.fund.eastmoney.com/f10/lsjz"
LSJZ_HEADERS = {"Referer": "https://fundf10.eastmoney.com/"}
PAGE_SIZE = 20  # 实测：更大的 pageSize 会被服务端静默截断到 20
# 超时统一交给访问层（HTTP_CONFIG.timeout）。这里保留常量的原因：它是「服务端只回
# 20 行」这条实测结论的一部分，不属于网络调优参数。


def _fetch_page(code6: str, page: int, page_size: int = PAGE_SIZE) -> dict:
    """取单页（20 行）。走统一访问层的共享连接池，翻页复用同一条 TCP 连接。"""
    try:
        r = net.http_get(LSJZ_URL,
                         params={"fundCode": code6, "pageIndex": page,
                                 "pageSize": page_size},
                         headers=LSJZ_HEADERS)
        return r.json()
    except Exception as e:
        raise DataFetchError(f"lsjz 请求失败 {code6} p{page}: {net.short_err(e)}") from e


def fetch_lsjz_history(code: str, max_pages: int = 400,
                       session=None) -> pd.DataFrame:
    """拉单只基金全史。返回列：
    date / unit_nav / acc_nav / daily_return / purchase_status /
    redeem_status / div10（每10份派现，无分红行为空）。

    无净值页的代码抛 FundNoNavPageError（调用方可直接放弃，不重试）。
    """
    code6 = str(code).split(".")[0].zfill(6)
    try:
        first = _fetch_page(code6, 1)
        total = int(first.get("TotalCount") or 0)
        rows = list((first.get("Data") or {}).get("LSJZList") or [])
        if total == 0 or not rows:
            # 干净的"无此页"信号：这是数据源给的答案，调用方应直接放弃该代码
            raise FundNoNavPageError(f"{code6} 在 lsjz 无净值记录（TotalCount=0）")
        pages = min(max(1, -(-total // PAGE_SIZE)), int(max_pages))
        for p in range(2, pages + 1):
            d = _fetch_page(code6, p)
            chunk = (d.get("Data") or {}).get("LSJZList") or []
            if not chunk:
                break
            rows.extend(chunk)
    finally:
        pass

    recs = []
    for x in rows:
        try:
            recs.append({
                "date": pd.to_datetime(x.get("FSRQ")),
                "unit_nav": pd.to_numeric(x.get("DWJZ"), errors="coerce"),
                "acc_nav": pd.to_numeric(x.get("LJJZ"), errors="coerce"),
                "daily_return": pd.to_numeric(x.get("JZZZL"), errors="coerce"),
                "purchase_status": (x.get("SGZT") or "").strip(),
                "redeem_status": (x.get("SHZT") or "").strip(),
                "div10": pd.to_numeric(x.get("FHFCZ10"), errors="coerce"),
            })
        except Exception:
            continue
    df = pd.DataFrame(recs).dropna(subset=["date"]).sort_values("date")
    df = df[~df["date"].duplicated(keep="last")].set_index("date").sort_index()
    if df.empty:
        raise DataFetchError(f"lsjz 解析出 0 行有效数据 {code6}")
    return df
