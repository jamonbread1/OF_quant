# -*- coding: utf-8 -*-
"""基金定期报告数据仓（持仓 / 行业配置 / 费率）+ PIT 可用日算子。

D5 持仓健康族与 D6 容量费用族依赖定期报告，而它不在净值里、也不在
fund_master（只有成立日/清盘日/规模/类型）里，故单独建库。

数据源：
  * 持仓/行业：`ak.fund_portfolio_hold_em` / `_industry_allocation_em(symbol, date=年)`
    ⚠️ 持仓给的是**全部持仓**（年报半年报口径）与季报前十大混合，按报告期分别落库。
  * 运作费率：`fundf10.eastmoney.com/jjfl_{code}.html`
  * 申购费折后：`pingzhongdata/{code}.js` 的 `fund_sourceRate` / `fund_Rate`
  * 经理任期：`fundf10.eastmoney.com/jjjl_{code}.html`（H2）
  * 持有人结构：`FundArchivesDatas.aspx?type=cyrjg`（H6）

⚠️ 两个踩过的坑：
  * jjjl **页面**可用。旧结论"接口已失效"指的是 akshare 的现任经理快照，不是这个页面。
  * `cyrjg_{code}.html` 里的持有人结构只是一张 `<img id="cyrjgpng">` 图片，
    没有可解析数值；真数据在 `FundArchivesDatas.aspx?type=cyrjg` 返回的 JS 里。

PIT 可用日（手册 §1.3）：avail(d) = d_end + Δ，
季报 25 / 半年报 60 / 年报 90 自然日。宁可晚，不能早。
"""
import json
import os
import re
import sqlite3
import threading
from datetime import datetime, timedelta
from typing import Dict, Iterable, List, Optional

import pandas as pd

from . import net
from .exceptions import DataFetchError

DEFAULT_REPORTS_DB = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "store", "fund_reports.db")

# 手册 §1.3 的 Δ（自然日）
LAG_DAYS = {"Q": 25, "H": 60, "Y": 90}

# 费率/申赎状态的重抓周期（天）。申购状态每天都在变（暂停申购、限大额），
# 永久沿用首次快照会让 H4 的时点判断彻底失灵，所以按周期刷新，
# 而不是"抓过一次就永远跳过"。
FEE_REFRESH_DAYS = 7

SCHEMA = """
CREATE TABLE IF NOT EXISTS fund_holdings (
    fund_code   TEXT NOT NULL,
    report_date TEXT NOT NULL,        -- 报告期末（如 2025-12-31）
    report_kind TEXT,                 -- Q / H / Y
    seq         INTEGER,
    stock_code  TEXT,
    stock_name  TEXT,
    weight      REAL,                 -- 占净值比例（小数，0.0532 = 5.32%）
    shares      REAL,                 -- 持股数（万股）
    market_val  REAL,                 -- 持仓市值（万元）
    avail_date  TEXT,                 -- PIT 可用日
    updated_at  TEXT,
    PRIMARY KEY (fund_code, report_date, stock_code)
);
CREATE INDEX IF NOT EXISTS idx_hold_avail ON fund_holdings(fund_code, avail_date);
CREATE INDEX IF NOT EXISTS idx_hold_rep ON fund_holdings(fund_code, report_date);

CREATE TABLE IF NOT EXISTS fund_industry (
    fund_code   TEXT NOT NULL,
    report_date TEXT NOT NULL,
    industry    TEXT NOT NULL,
    weight      REAL,                 -- 占净值比例（小数）
    avail_date  TEXT,
    updated_at  TEXT,
    PRIMARY KEY (fund_code, report_date, industry)
);
CREATE INDEX IF NOT EXISTS idx_ind_avail ON fund_industry(fund_code, avail_date);

CREATE TABLE IF NOT EXISTS fund_fee (
    fund_code     TEXT PRIMARY KEY,
    mgmt_rate     REAL,               -- 管理费率 %/年
    custody_rate  REAL,               -- 托管费率 %/年
    sales_service REAL,               -- 销售服务费率 %/年（C 类）
    buy_rate_raw  REAL,               -- 原申购费率 %
    buy_rate_disc REAL,               -- 折后申购费率 %
    subscribe_stat TEXT,              -- 申购状态
    redeem_stat    TEXT,              -- 赎回状态
    updated_at    TEXT
);

-- 抓取进度：避免每次重复打网络
CREATE TABLE IF NOT EXISTS report_progress (
    fund_code TEXT NOT NULL,
    kind      TEXT NOT NULL,          -- holdings / industry / fee / manager / holder
    scope     TEXT,                   -- 年份等
    status    TEXT,                   -- ok / fail / empty
    msg       TEXT,
    updated_at TEXT,
    PRIMARY KEY (fund_code, kind, scope)
);

-- H2 基金经理任期：F10 jjjl「基金经理变动一览」表
-- 每行是一次「成员变更」，managers 为该段在任的全部经理（逗号分隔），
-- end_date 为 NULL 表示该段仍然在任（源页面显示"至今"）。
CREATE TABLE IF NOT EXISTS fund_manager_hist (
    fund_code   TEXT NOT NULL,
    start_date  TEXT NOT NULL,        -- 起始期
    end_date    TEXT,                 -- 截止期；NULL = 至今
    managers    TEXT NOT NULL,        -- 该段在任经理（逗号分隔）
    span_days   INTEGER,              -- 源页面给出的任职期间（天），仅供核对
    updated_at  TEXT,
    PRIMARY KEY (fund_code, start_date, managers)
);
CREATE INDEX IF NOT EXISTS idx_mgr_start ON fund_manager_hist(fund_code, start_date);

-- H6 持有人结构：F10 cyrjg 数据接口（半年报 / 年报口径）
CREATE TABLE IF NOT EXISTS fund_holder_struct (
    fund_code      TEXT NOT NULL,
    report_date    TEXT NOT NULL,     -- 公告日期（6-30 / 12-31）
    inst_ratio     REAL,              -- 机构持有比例（小数）
    person_ratio   REAL,              -- 个人持有比例
    internal_ratio REAL,              -- 内部持有比例
    total_shares   REAL,              -- 总份额（亿份）
    avail_date     TEXT,              -- PIT 可用日
    updated_at     TEXT,
    PRIMARY KEY (fund_code, report_date)
);
CREATE INDEX IF NOT EXISTS idx_holder_avail ON fund_holder_struct(fund_code, avail_date);

-- H4 申赎状态每日快照：东财只提供"当日"状态，没有历史（修复方案 v1.0 §3.1）。
-- 唯一能拿到历史 PIT 的办法是自己每天落一份，攒成时间序列。
-- ⚠️ 绝不能用"现在的状态回填历史"——那正是 H4 想防的前视偏差。
CREATE TABLE IF NOT EXISTS subscribe_status_daily (
    fund_code      TEXT NOT NULL,
    stat_date      TEXT NOT NULL,        -- 快照日（取数日，YYYY-MM-DD）
    subscribe_stat TEXT,                 -- 开放申购 / 暂停申购 / 限大额 / 场内买入 ...
    redeem_stat    TEXT,                 -- 开放赎回 / 暂停赎回 ...
    next_open_date TEXT,                 -- 下一开放日；非 NULL ⇒ 定开/持有期产品
    daily_limit    REAL,                 -- 日累计限定金额（元）
    buy_rate_disc  REAL,                 -- 折后申购费率 %
    nav_latest     REAL,                 -- 当日最新净值（顺手存，数据新鲜度校验用）
    updated_at     TEXT,
    PRIMARY KEY (fund_code, stat_date)
);
CREATE INDEX IF NOT EXISTS idx_sub_date ON subscribe_status_daily(fund_code, stat_date);

-- H2 人事变动公告日（修复方案 v1.0 §3.3）：任职期 [start,end] 在决策日可得的前提
-- 是起始日之后的第一条人事公告日 <= asof。源：ak.fund_announcement_personnel_em。
CREATE TABLE IF NOT EXISTS fund_manager_announce (
    fund_code  TEXT NOT NULL,
    ann_date   TEXT NOT NULL,
    title      TEXT,
    updated_at TEXT,
    PRIMARY KEY (fund_code, ann_date, title)
);
CREATE INDEX IF NOT EXISTS idx_mgr_ann ON fund_manager_announce(fund_code, ann_date);
"""


def _c6(code: str) -> str:
    s = str(code or "").strip().upper()
    if "." in s:
        s = s.split(".")[0]
    return s.zfill(6) if s.isdigit() else s


def _as_date(x) -> Optional[datetime]:
    """统一转 datetime（注意：pd.Timestamp 是 datetime 子类，先判 datetime 再判 date）。"""
    if x is None:
        return None
    if isinstance(x, datetime):
        return x
    try:
        import datetime as _dt
        if isinstance(x, _dt.date):
            return datetime(x.year, x.month, x.day)
    except Exception:
        pass
    try:
        return pd.to_datetime(str(x)[:10]).to_pydatetime()
    except Exception:
        return None


def report_kind_of(report_date: str) -> str:
    """由报告期末推断报告种类：Q1/Q3 季报、Q2 半年报、Q4 年报。"""
    d = _as_date(report_date)
    if d is None:
        return "Q"
    return {3: "Q", 6: "H", 9: "Q", 12: "Y"}.get(d.month, "Q")


def avail_date(report_date, kind: Optional[str] = None) -> Optional[str]:
    """手册 §1.3 的 avail(d) = 报告期末 + Δ。返回 YYYY-MM-DD。"""
    d = _as_date(report_date)
    if d is None:
        return None
    k = kind or report_kind_of(report_date)
    return (d + timedelta(days=LAG_DAYS.get(k, 25))).strftime("%Y-%m-%d")


# ---------------------------------------------------------------------------
# 抓取层
# ---------------------------------------------------------------------------

def fetch_holdings(code: str, year: int) -> pd.DataFrame:
    """抓某基金某年的持仓明细（全部季度）。失败返回空 DataFrame。"""
    # 与 look_through/holdings.RealHoldingsProvider 同源（ datasets 一致、只是解析口径不同），
    # 统一走访问层拿统一重试与错误分类。这里保留"失败返回空 DataFrame"的原语义。
    try:
        df = net.ak_call("fund_portfolio_hold_em", symbol=_c6(code),
                         date=str(int(year)), max_retries=1)
    except Exception:
        return pd.DataFrame()
    if df is None or df.empty:
        return pd.DataFrame()
    rows = []
    for _, r in df.iterrows():
        label = str(r.get("季度") or "")
        m = re.search(r"(\d{4})\s*年\s*(\d)\s*季度", label)
        if not m:
            continue
        y, q = int(m.group(1)), int(m.group(2))
        rd = datetime(y, {1: 3, 2: 6, 3: 9, 4: 12}[q], {1: 31, 2: 30, 3: 30, 4: 31}[q])
        try:
            w = float(r.get("占净值比例") or 0.0) / 100.0     # 接口给百分数
        except (TypeError, ValueError):
            w = None
        rows.append({
            "report_date": rd.strftime("%Y-%m-%d"),
            "seq": r.get("序号"),
            "stock_code": str(r.get("股票代码") or "").strip(),
            "stock_name": str(r.get("股票名称") or "").strip(),
            "weight": w,
            "shares": r.get("持股数"),
            "market_val": r.get("持仓市值"),
        })
    return pd.DataFrame(rows)


def fetch_industry(code: str, year: int) -> pd.DataFrame:
    """抓某基金某年的行业配置。失败返回空 DataFrame。"""
    try:
        df = net.ak_call("fund_portfolio_industry_allocation_em", symbol=_c6(code),
                         date=str(int(year)), max_retries=1)
    except Exception:
        return pd.DataFrame()
    if df is None or df.empty:
        return pd.DataFrame()
    rows = []
    for _, r in df.iterrows():
        d = _as_date(r.get("截止时间"))
        if d is None:
            continue
        try:
            w = float(r.get("占净值比例") or 0.0) / 100.0
        except (TypeError, ValueError):
            w = None
        rows.append({"report_date": d.strftime("%Y-%m-%d"),
                     "industry": str(r.get("行业类别") or "").strip(),
                     "weight": w})
    return pd.DataFrame(rows)


def _http_get(url: str, referer: str = "", timeout: int = 15) -> str:
    """统一 GET（替代原先的裸 requests.get）。

    改造前这里一次裸请求、**无重试**：某个 F10 页面偶发 502，那只基金的费率/经理/
    持有人结构当天就整块缺失 —— 而且下游是「算不出就当未校验」，不报错，很难发现。
    现在统一走访问层的连接池 + 退避重试。
    """
    headers = {"User-Agent": net.HTTP_CONFIG.user_agent}
    if referer:
        headers["Referer"] = referer
    r = net.http_get(url, headers=headers, timeout=timeout)
    if r.status_code != 200:
        raise DataFetchError(f"HTTP {r.status_code}: {url}")
    r.encoding = "utf-8"
    return r.text or ""


def _pct(s) -> Optional[float]:
    """'1.20%（每年）' -> 1.20；'---' -> None（不填 0，避免假事实）。"""
    if s is None:
        return None
    t = str(s).replace("---", "").strip()
    m = re.search(r"([0-9]+\.?[0-9]*)", t)
    return float(m.group(1)) if m else None


def fetch_fee(code: str) -> Dict:
    """抓运作费率（jjfl 页面）+ 申购费折后（pingzhongdata）。全为百分数。"""
    c6 = _c6(code)
    out = {"mgmt_rate": None, "custody_rate": None, "sales_service": None,
           "buy_rate_raw": None, "buy_rate_disc": None,
           "subscribe_stat": None, "redeem_stat": None}
    try:
        html = _http_get(f"https://fundf10.eastmoney.com/jjfl_{c6}.html",
                         referer="https://fundf10.eastmoney.com/")
        for key, field in (("管理费", "mgmt_rate"), ("托管费", "custody_rate"),
                           ("销售服务费", "sales_service")):
            m = re.search(rf"{key}[^<]{{0,12}}</td>\s*<td[^>]*>([^<]+)</td>", html)
            if m:
                out[field] = _pct(m.group(1))
        for key, field in (("申购状态", "subscribe_stat"), ("赎回状态", "redeem_stat")):
            m = re.search(rf"{key}[^<]{{0,8}}</td>\s*<td[^>]*>([^<]+)</td>", html)
            if m:
                out[field] = m.group(1).strip()
    except Exception:
        pass
    try:
        js = _http_get(f"https://fund.eastmoney.com/pingzhongdata/{c6}.js",
                       referer=f"https://fund.eastmoney.com/{c6}.html")
        m1 = re.search(r'var\s+fund_sourceRate\s*=\s*"([^"]+)"', js)
        m2 = re.search(r'var\s+fund_Rate\s*=\s*"([^"]+)"', js)
        if m1:
            out["buy_rate_raw"] = _pct(m1.group(1))
        if m2:
            out["buy_rate_disc"] = _pct(m2.group(1))
    except Exception:
        pass
    return out


# ---------------------------------------------------------------------------
# 存储层
# ---------------------------------------------------------------------------

def _span_days(txt) -> Optional[int]:
    """把「1年又266天」这类任职期间解析成天数。"""
    s = str(txt or "")
    y = re.search(r"(\d+)\s*年", s)
    d = re.search(r"(\d+)\s*天", s)
    if not y and not d:
        return None
    return int(y.group(1) if y else 0) * 365 + int(d.group(1) if d else 0)


def fetch_manager_tenure(code: str) -> List[Dict]:
    """抓基金经理变动一览（F10 jjjl 页）。

    返回按源页面顺序的 [{"start_date","end_date","managers","span_days"}]，
    `end_date` 为 None 表示"至今"（在任）。

    ⚠️ PIT 说明：源表只有"起始期"、没有公告日，这里**用起始期当 PIT 可用日**。
    经理到任与公告通常同日或相差 1 天，属轻微乐观但可接受；若追求极致严谨的
    PIT，应改为 start_date + 1~2 自然日再参与 asof 比较。

    （`fundf10` 的 jjjl **页面**可用；早前记为"接口已失效"是因为查的是
    akshare 的现任基金快照，那个确实拿不到任职起始日与变更历史。）
    """
    c6 = _c6(code)
    try:
        html = _http_get(f"https://fundf10.eastmoney.com/jjjl_{c6}.html",
                         referer="https://fundf10.eastmoney.com/")
    except Exception:
        return []
    if not html:
        return []
    i = html.find("基金经理变动一览")
    seg = html[i: i + 20000] if i >= 0 else html
    rows = re.findall(
        r"<tr><td>(\d{4}-\d{2}-\d{2})</td><td>([^<]+)</td><td>(.*?)</td>"
        r"<td>([^<]*)</td>", seg, re.S)
    out = []
    for start, end, mgr_html, span in rows:
        names = [n.strip() for n in re.findall(r">([^<]+)</a>", mgr_html) if n.strip()]
        if not names:
            plain = re.sub(r"<[^>]+>", "", mgr_html).strip()
            if plain:
                names = [plain]
        if not names:
            continue
        out.append({"start_date": start,
                    "end_date": None if "至今" in end else end.strip(),
                    "managers": ",".join(names),
                    "span_days": _span_days(span)})
    return out


def fetch_holder_structure(code: str) -> List[Dict]:
    """抓持有人结构（半年报 / 年报口径）。

    ⚠️ 必须用数据接口 `FundArchivesDatas.aspx?type=cyrjg`：
        `fundf10.eastmoney.com/cyrjg_XXX.html` 那个页面里持有人结构只是一张
        `<img id="cyrjgpng">` **图片**，没有任何可解析的数值。
    """
    c6 = _c6(code)
    url = (f"https://fundf10.eastmoney.com/FundArchivesDatas.aspx?"
           f"type=cyrjg&code={c6}&topline=20")
    try:
        txt = _http_get(url, referer=f"https://fundf10.eastmoney.com/cyrjg_{c6}.html")
    except Exception:
        return []
    if not txt:
        return []
    rows = re.findall(
        r"<tr><td>(\d{4}-\d{2}-\d{2})</td>"
        r"<td[^>]*>([\d.]+)%</td>"
        r"<td[^>]*>([\d.]+)%</td>"
        r"<td[^>]*>([\d.]+)%</td>"
        r"<td[^>]*>([\d.,\-]+)</td>", txt)
    out = []
    for d, inst, person, internal, shares in rows:
        try:
            sh = None if shares.strip() in ("---", "") else float(shares.replace(",", ""))
        except ValueError:
            sh = None
        out.append({"report_date": d,
                    "inst_ratio": float(inst) / 100.0,
                    "person_ratio": float(person) / 100.0,
                    "internal_ratio": float(internal) / 100.0,
                    "total_shares": sh,
                    "avail_date": avail_date(d)})
    return out


def fetch_purchase_snapshot() -> pd.DataFrame:
    """全市场申购/赎回状态快照（修复方案 v1.0 §3.1，一次性 ≈27,565 只，1 个请求）。

    免费源：`ak.fund_purchase_em()`。实测列：
        基金代码 基金简称 基金类型 最新净值/万份收益 最新净值/万份收益-报告时间
        申购状态 赎回状态 下一开放日 购买起点 日累计限定金额 手续费

    ⚠️ 为什么必须用批量版而不是逐只抓 jjfl 页面：
       27,878 只 × 1 次 HTTP = 必被封 IP，且要跑 2 小时以上。
       这个接口一次请求拿全市场，每天一次即可攒出 H4 的历史序列。

    ⚠️ 列名一律按名称取，不用位置索引——字段口径漂移时要显式失败而不是静默给错数。
    """
    import numpy as np  # 下面 _num() 里要用 np.isfinite

    try:
        df = net.ak_call("fund_purchase_em", max_retries=2)
    except Exception:
        return pd.DataFrame()
    if df is None or df.empty:
        return pd.DataFrame()
    today = pd.Timestamp.today().normalize()

    def _num(x):
        try:
            v = float(str(x).replace(",", "").replace("%", ""))
            return v if np.isfinite(v) else None
        except (TypeError, ValueError):
            return None

    rows = []
    for _, r in df.iterrows():
        code = str(r.get("基金代码") or "").strip()
        if not code:
            continue
        nxt = r.get("下一开放日")
        try:
            nxt_s = (pd.to_datetime(nxt).strftime("%Y-%m-%d")
                     if nxt is not None and pd.notna(nxt) else None)
        except Exception:
            nxt_s = None
        rows.append({
            "fund_code": _c6(code),
            "stat_date": today.strftime("%Y-%m-%d"),
            "subscribe_stat": str(r.get("申购状态") or "").strip() or None,
            "redeem_stat": str(r.get("赎回状态") or "").strip() or None,
            "next_open_date": nxt_s,
            "daily_limit": _num(r.get("日累计限定金额")),
            "buy_rate_disc": _num(r.get("手续费")),   # 实测 000001 → 0.15（%）
            "nav_latest": _num(r.get("最新净值/万份收益")),
        })
    return pd.DataFrame(rows)


def fetch_manager_announcements(code: str) -> List[Dict]:
    """人事变动公告列表（含公告日）—— H2 的正确 PIT 锚点（修复方案 v1.0 §3.3）。

    免费源：`ak.fund_announcement_personnel_em(symbol=6位代码)`
    实测列：基金代码 / 公告标题 / 基金名称 / 公告日期 / 报告ID
    实测样例：000001 → 2013-06-29《关于调整…基金经理的公告》

    为什么需要它：F10 jjjl 的任职期只有"起始期"，没有公告日——
    用起始期当 PIT 可用日有轻微乐观偏差（经理到任与公告可能差几天）。
    公告日才是"市场在该时点真正可知"的锚。
    """
    try:
        df = net.ak_call("fund_announcement_personnel_em", symbol=_c6(code),
                         max_retries=1)
    except Exception:
        return []
    if df is None or df.empty:
        return []
    out = []
    for _, r in df.iterrows():
        d = _as_date(r.get("公告日期"))
        if d is None:
            continue
        out.append({"ann_date": d.strftime("%Y-%m-%d"),
                    "title": str(r.get("公告标题") or "")})
    return sorted(out, key=lambda x: x["ann_date"])


class ReportStore:
    """定期报告仓（SQLite）。纯本地读写 + 可注入抓取函数（便于离线测试）。"""

    def __init__(self, db_path: str = DEFAULT_REPORTS_DB, create: bool = True):
        self.db_path = db_path
        if db_path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        if create:
            with self._lock:
                self.conn.executescript(SCHEMA)
                self.conn.commit()

    # ---- 生命周期 ----
    def close(self):
        try:
            self.conn.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    # ---- 写入 ----
    def upsert_holdings(self, code: str, df: pd.DataFrame) -> int:
        if df is None or df.empty:
            return 0
        c = _c6(code)
        now = datetime.now().isoformat(timespec="seconds")
        rows = []
        for _, r in df.iterrows():
            rd = r.get("report_date")
            if not rd:
                continue
            k = report_kind_of(rd)
            rows.append((c, str(rd)[:10], k, r.get("seq"), str(r.get("stock_code") or ""),
                         str(r.get("stock_name") or ""), r.get("weight"),
                         r.get("shares"), r.get("market_val"), avail_date(rd, k), now))
        if not rows:
            return 0
        sql = ("INSERT INTO fund_holdings (fund_code,report_date,report_kind,seq,stock_code,"
               "stock_name,weight,shares,market_val,avail_date,updated_at) "
               "VALUES (?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(fund_code,report_date,stock_code) "
               "DO UPDATE SET report_kind=excluded.report_kind, seq=excluded.seq, "
               "stock_name=excluded.stock_name, weight=excluded.weight, shares=excluded.shares, "
               "market_val=excluded.market_val, avail_date=excluded.avail_date, "
               "updated_at=excluded.updated_at")
        with self._lock:
            self.conn.executemany(sql, rows)
            self.conn.commit()
        return len(rows)

    def upsert_industry(self, code: str, df: pd.DataFrame) -> int:
        if df is None or df.empty:
            return 0
        c = _c6(code)
        now = datetime.now().isoformat(timespec="seconds")
        rows = []
        for _, r in df.iterrows():
            rd = r.get("report_date")
            if not rd or not r.get("industry"):
                continue
            k = report_kind_of(rd)
            rows.append((c, str(rd)[:10], str(r["industry"]), r.get("weight"),
                         avail_date(rd, k), now))
        if not rows:
            return 0
        sql = ("INSERT INTO fund_industry (fund_code,report_date,industry,weight,avail_date,updated_at) "
               "VALUES (?,?,?,?,?,?) ON CONFLICT(fund_code,report_date,industry) "
               "DO UPDATE SET weight=excluded.weight, avail_date=excluded.avail_date, "
               "updated_at=excluded.updated_at")
        with self._lock:
            self.conn.executemany(sql, rows)
            self.conn.commit()
        return len(rows)

    def upsert_fee(self, code: str, fee: Dict) -> None:
        if not fee:
            return
        sql = ("INSERT INTO fund_fee (fund_code,mgmt_rate,custody_rate,sales_service,"
               "buy_rate_raw,buy_rate_disc,subscribe_stat,redeem_stat,updated_at) "
               "VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(fund_code) DO UPDATE SET "
               "mgmt_rate=COALESCE(excluded.mgmt_rate,fund_fee.mgmt_rate), "
               "custody_rate=COALESCE(excluded.custody_rate,fund_fee.custody_rate), "
               "sales_service=COALESCE(excluded.sales_service,fund_fee.sales_service), "
               "buy_rate_raw=COALESCE(excluded.buy_rate_raw,fund_fee.buy_rate_raw), "
               "buy_rate_disc=COALESCE(excluded.buy_rate_disc,fund_fee.buy_rate_disc), "
               "subscribe_stat=COALESCE(excluded.subscribe_stat,fund_fee.subscribe_stat), "
               "redeem_stat=COALESCE(excluded.redeem_stat,fund_fee.redeem_stat), "
               "updated_at=excluded.updated_at")
        with self._lock:
            self.conn.execute(sql, (_c6(code), fee.get("mgmt_rate"), fee.get("custody_rate"),
                                    fee.get("sales_service"), fee.get("buy_rate_raw"),
                                    fee.get("buy_rate_disc"), fee.get("subscribe_stat"),
                                    fee.get("redeem_stat"),
                                    datetime.now().isoformat(timespec="seconds")))
            self.conn.commit()

    def mark_progress(self, code: str, kind: str, scope: str, status: str, msg: str = "") -> None:
        with self._lock:
            self.conn.execute(
                "INSERT INTO report_progress (fund_code,kind,scope,status,msg,updated_at) "
                "VALUES (?,?,?,?,?,?) ON CONFLICT(fund_code,kind,scope) DO UPDATE SET "
                "status=excluded.status, msg=excluded.msg, updated_at=excluded.updated_at",
                (_c6(code), kind, str(scope), status, str(msg)[:200],
                 datetime.now().isoformat(timespec="seconds")))
            self.conn.commit()

    def progress(self, code: str, kind: str, scope: str) -> Optional[Dict]:
        cur = self.conn.execute(
            "SELECT * FROM report_progress WHERE fund_code=? AND kind=? AND scope=?",
            (_c6(code), kind, str(scope)))
        r = cur.fetchone()
        return dict(r) if r else None

    # ---- 查询（全部按 PIT） ----
    def report_dates(self, code: str, asof, kind_filter: Optional[str] = None,
                     table: str = "fund_holdings") -> List[str]:
        """到 asof 为止**已可用**的报告期（升序）。"""
        a = _as_date(asof)
        if a is None:
            return []
        q = f"SELECT DISTINCT report_date, avail_date FROM {table} WHERE fund_code=? AND avail_date<=?"
        rows = self.conn.execute(q, (_c6(code), a.strftime("%Y-%m-%d"))).fetchall()
        out = [r["report_date"] for r in rows if r["report_date"]]
        return sorted(out)

    def holdings_asof(self, code: str, asof) -> pd.DataFrame:
        """决策日可见的最新一期持仓明细（含 weight/shares/market_val）。"""
        ds = self.report_dates(code, asof, table="fund_holdings")
        if not ds:
            return pd.DataFrame()
        return self.holdings_at(code, ds[-1])

    def holdings_at(self, code: str, report_date: str) -> pd.DataFrame:
        cur = self.conn.execute(
            "SELECT stock_code, stock_name, weight, shares, market_val FROM fund_holdings "
            "WHERE fund_code=? AND report_date=? ORDER BY weight DESC",
            (_c6(code), str(report_date)[:10]))
        return pd.DataFrame([dict(r) for r in cur.fetchall()])

    def industry_asof(self, code: str, asof) -> pd.DataFrame:
        ds = self.report_dates(code, asof, table="fund_industry")
        if not ds:
            return pd.DataFrame()
        cur = self.conn.execute(
            "SELECT industry, weight FROM fund_industry WHERE fund_code=? AND report_date=? "
            "ORDER BY weight DESC", (_c6(code), ds[-1]))
        return pd.DataFrame([dict(r) for r in cur.fetchall()])

    def fee_of(self, code: str) -> Dict:
        cur = self.conn.execute("SELECT * FROM fund_fee WHERE fund_code=?", (_c6(code),))
        r = cur.fetchone()
        return dict(r) if r else {}

    # ---- H2 基金经理任期 ----
    def upsert_manager_history(self, code: str, rows: List[Dict]) -> int:
        if not rows:
            return 0
        c = _c6(code)
        now = datetime.now().isoformat(timespec="seconds")
        data = [(c, str(r["start_date"])[:10], r.get("end_date"),
                 str(r.get("managers") or ""), r.get("span_days"), now)
                for r in rows if r.get("start_date") and r.get("managers")]
        if not data:
            return 0
        sql = ("INSERT INTO fund_manager_hist "
               "(fund_code,start_date,end_date,managers,span_days,updated_at) "
               "VALUES (?,?,?,?,?,?) "
               "ON CONFLICT(fund_code,start_date,managers) DO UPDATE SET "
               "end_date=excluded.end_date, span_days=excluded.span_days, "
               "updated_at=excluded.updated_at")
        with self._lock:
            self.conn.executemany(sql, data)
            self.conn.commit()
        return len(data)

    def manager_tenure_days(self, code: str, asof) -> Optional[int]:
        """H2：现任经理团队的**可考察任期**（自然日）。

        口径：先取"至今在任"（end_date 为空）的经理姓名集合，再回看这些姓名
        **最早**出现在哪一段任职期（仅限 start_date <= asof 的段，保证 PIT），
        返回 asof 减去该起始日的天数。

        为什么不用最后一段的起始日：F10 每一行是"一次成员变更"，团队里加一个人
        就会新起一行。只看最后一行的话，一位管了 10 年、同事刚变动的老经理会被
        误判成"刚上任"（实测 110022：萧楠连续在任自 2015-01-10，而最后一行始于
        2025-04-12，按最后一行算只有 1.4 年）。说明书 H2 的意图是"经理有足够长的
        可考察历史"，故取现任经理们的最早起始。
        """
        a = _as_date(asof)
        if a is None:
            return None
        cur = self.conn.execute(
            "SELECT start_date, end_date, managers FROM fund_manager_hist "
            "WHERE fund_code=? AND start_date<=? ORDER BY start_date",
            (_c6(code), a.strftime("%Y-%m-%d"))).fetchall()
        if not cur:
            return None
        names = set()
        for r in cur:
            if not r["end_date"]:
                names.update(n.strip() for n in str(r["managers"] or "").split(",")
                             if n.strip())
        if not names:
            return None
        earliest = None
        for r in cur:
            seg = {n.strip() for n in str(r["managers"] or "").split(",") if n.strip()}
            if seg & names:
                d = _as_date(r["start_date"])
                if d and (earliest is None or d < earliest):
                    earliest = d
        if earliest is None:
            return None
        # 🔧 PIT 升级（修复方案 v1.0 §3.3）：某段任职期 [start, end] 在决策日可得
        # 的前提是**起始日之后的第一条人事公告日 <= asof**。公告日晚于 asof 说明
        # 这次变更在该时点还没公开，不能拿来算任期。
        try:
            anns = [r[0] for r in self.conn.execute(
                "SELECT ann_date FROM fund_manager_announce WHERE fund_code=? "
                "ORDER BY ann_date", (_c6(code),)).fetchall()]
        except Exception:
            anns = []
        if anns:
            after = [d for d in anns if d >= earliest.strftime("%Y-%m-%d")]
            avail = _as_date(after[0]) if after else earliest + timedelta(days=1)
        else:
            avail = earliest + timedelta(days=1)   # 无公告数据：保守 +1 天
        if avail > a:
            return None                             # 该时点还不可得 → 如实记未校验
        return int((a - earliest).days)

    # ---- H2 人事公告（PIT 锚点） ----
    def upsert_manager_announcements(self, code: str, rows: List[Dict]) -> int:
        if not rows:
            return 0
        c = _c6(code)
        now = datetime.now().isoformat(timespec="seconds")
        data = [(c, str(r["ann_date"])[:10], str(r.get("title") or ""), now)
                for r in rows if r.get("ann_date")]
        if not data:
            return 0
        sql = ("INSERT INTO fund_manager_announce (fund_code,ann_date,title,updated_at) "
               "VALUES (?,?,?,?) "
               "ON CONFLICT(fund_code,ann_date,title) DO UPDATE SET "
               "updated_at=excluded.updated_at")
        with self._lock:
            self.conn.executemany(sql, data)
            self.conn.commit()
        return len(data)

    # ---- H4 申赎状态每日快照 ----
    def upsert_subscribe_snapshot(self, df: pd.DataFrame) -> int:
        """落一张全市场快照（修复方案 v1.0 §3.1c）。幂等：按 (fund_code, stat_date) 覆盖。"""
        if df is None or df.empty:
            return 0
        now = datetime.now().isoformat(timespec="seconds")
        data = [(str(r["fund_code"]), str(r["stat_date"])[:10],
                 r.get("subscribe_stat"), r.get("redeem_stat"),
                 r.get("next_open_date"), r.get("daily_limit"),
                 r.get("buy_rate_disc"), r.get("nav_latest"), now)
                for _, r in df.iterrows() if r.get("fund_code") and r.get("stat_date")]
        if not data:
            return 0
        sql = ("INSERT INTO subscribe_status_daily (fund_code,stat_date,subscribe_stat,"
               "redeem_stat,next_open_date,daily_limit,buy_rate_disc,nav_latest,updated_at) "
               "VALUES (?,?,?,?,?,?,?,?,?) "
               "ON CONFLICT(fund_code,stat_date) DO UPDATE SET "
               "subscribe_stat=excluded.subscribe_stat, redeem_stat=excluded.redeem_stat, "
               "next_open_date=excluded.next_open_date, daily_limit=excluded.daily_limit, "
               "buy_rate_disc=excluded.buy_rate_disc, nav_latest=excluded.nav_latest, "
               "updated_at=excluded.updated_at")
        with self._lock:
            self.conn.executemany(sql, data)
            self.conn.commit()
        return len(data)

    def subscribe_status_asof(self, code: str, asof, max_lag_days: int = 10) -> Optional[Dict]:
        """H4：取 stat_date <= asof 的最近一条快照（修复方案 v1.0 §3.1c）。

        ⚠️ max_lag_days 是**新鲜度门槛**，不是 PIT 滞后补偿：
           找不到 <= asof 的快照时，不能往前找（那是未来数据），只能判 None。
           也不能无限制往前找太远的旧快照 —— 超过 max_lag_days 说明这段历史
           根本没采集过，如实返回 None（上层记"未校验"），而不是拿三个月前的
           状态冒充决策日状态。
        返回 dict(subscribe_stat/redeem_stat/next_open_date/daily_limit/stat_date) 或 None。
        """
        a = _as_date(asof)
        if a is None:
            return None
        try:
            r = self.conn.execute(
                "SELECT subscribe_stat, redeem_stat, next_open_date, daily_limit, stat_date "
                "FROM subscribe_status_daily WHERE fund_code=? AND stat_date<=? "
                "ORDER BY stat_date DESC LIMIT 1",
                (_c6(code), a.strftime("%Y-%m-%d"))).fetchone()
        except Exception:
            return None
        if r is None:
            return None
        if (a - _as_date(r["stat_date"])).days > int(max_lag_days):
            return None
        return {"subscribe_stat": r["subscribe_stat"], "redeem_stat": r["redeem_stat"],
                "next_open_date": r["next_open_date"], "daily_limit": r["daily_limit"],
                "stat_date": r["stat_date"]}

    # ---- H6 持有人结构 ----
    def upsert_holder_struct(self, code: str, rows: List[Dict]) -> int:
        if not rows:
            return 0
        c = _c6(code)
        now = datetime.now().isoformat(timespec="seconds")
        data = [(c, str(r["report_date"])[:10], r.get("inst_ratio"),
                 r.get("person_ratio"), r.get("internal_ratio"),
                 r.get("total_shares"), r.get("avail_date"), now)
                for r in rows if r.get("report_date")]
        if not data:
            return 0
        sql = ("INSERT INTO fund_holder_struct "
               "(fund_code,report_date,inst_ratio,person_ratio,internal_ratio,"
               "total_shares,avail_date,updated_at) VALUES (?,?,?,?,?,?,?,?) "
               "ON CONFLICT(fund_code,report_date) DO UPDATE SET "
               "inst_ratio=excluded.inst_ratio, person_ratio=excluded.person_ratio, "
               "internal_ratio=excluded.internal_ratio, "
               "total_shares=excluded.total_shares, "
               "avail_date=excluded.avail_date, updated_at=excluded.updated_at")
        with self._lock:
            self.conn.executemany(sql, data)
            self.conn.commit()
        return len(data)

    def inst_ratio_asof(self, code: str, asof) -> Optional[float]:
        """H6：取 avail_date <= asof 的最近一期机构持有比例（小数）。"""
        a = _as_date(asof)
        if a is None:
            return None
        r = self.conn.execute(
            "SELECT inst_ratio FROM fund_holder_struct "
            "WHERE fund_code=? AND avail_date IS NOT NULL AND avail_date<=? "
            "ORDER BY report_date DESC LIMIT 1",
            (_c6(code), a.strftime("%Y-%m-%d"))).fetchone()
        if r is None or r["inst_ratio"] is None:
            return None
        return float(r["inst_ratio"])

    def latest_holdings_date(self, code: str) -> Optional[str]:
        cur = self.conn.execute(
            "SELECT MAX(report_date) AS d FROM fund_holdings WHERE fund_code=?", (_c6(code),))
        r = cur.fetchone()
        return r["d"] if r and r["d"] else None

    def stats(self) -> Dict:
        def one(sql):
            try:
                return self.conn.execute(sql).fetchone()[0]
            except Exception:
                return 0
        return {
            "holding_rows": int(one("SELECT COUNT(*) FROM fund_holdings")),
            "industry_rows": int(one("SELECT COUNT(*) FROM fund_industry")),
            "funds_with_holdings": int(one("SELECT COUNT(DISTINCT fund_code) FROM fund_holdings")),
            "funds_with_fee": int(one("SELECT COUNT(*) FROM fund_fee")),
            "funds_with_manager": int(one("SELECT COUNT(DISTINCT fund_code) FROM fund_manager_hist")),
            "funds_with_holder": int(one("SELECT COUNT(DISTINCT fund_code) FROM fund_holder_struct")),
            "funds_with_mgr_ann": int(one("SELECT COUNT(DISTINCT fund_code) FROM fund_manager_announce")),
            "snapshot_days": int(one("SELECT COUNT(DISTINCT stat_date) FROM subscribe_status_daily")),
            "snapshot_funds": int(one("SELECT COUNT(DISTINCT fund_code) FROM subscribe_status_daily")),
        }


def default_store(create: bool = False) -> Optional[ReportStore]:
    """打开默认报告仓；不存在且 create=False → None（调用方降级，不要硬建）。"""
    try:
        if not create and not os.path.exists(DEFAULT_REPORTS_DB):
            return None
        return ReportStore(DEFAULT_REPORTS_DB, create=create)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# 同步（联网）—— 供 data_ops 任务与策略初始化调用
# ---------------------------------------------------------------------------

def sync_fund(store: ReportStore, code: str, years: Iterable[int],
              kinds: Iterable[str] = ("holdings", "industry", "fee",
                                      "manager", "holder", "manager_ann"),
              force: bool = False) -> Dict:
    """补齐一只基金的报告数据。带进度表，已 ok 的默认跳过。

    kinds 支持：holdings / industry / fee / manager(H2) / holder(H6) /
    manager_ann(H2 公告 PIT 锚点)。
    fee 与 manager、holder、manager_ann 都是"全历史一次性"抓取，scope 固定为 "-"。

    ⚠️ `fee` 的进度不能永久沿用：申购状态（开放/限大额/暂停）每天都在变，
    费率也可能调整。所以即使 `status == 'ok'`，超过 `FEE_REFRESH_DAYS` 也要重抓
    —— 否则 H4 的"暂停申购"永远停留在首次抓取那天的快照上。
    """
    res = {"code": _c6(code), "holdings": 0, "industry": 0, "fee": False,
           "manager": 0, "holder": 0, "manager_ann": 0, "skipped": []}
    kinds = list(kinds)
    for y in years:
        if "holdings" in kinds:
            p = store.progress(code, "holdings", y)
            if force or not p or p.get("status") != "ok":
                df = fetch_holdings(code, y)
                n = store.upsert_holdings(code, df)
                store.mark_progress(code, "holdings", y, "ok" if n else "empty", f"{n} rows")
                res["holdings"] += n
            else:
                res["skipped"].append(f"holdings:{y}")
        if "industry" in kinds:
            p = store.progress(code, "industry", y)
            if force or not p or p.get("status") != "ok":
                df = fetch_industry(code, y)
                n = store.upsert_industry(code, df)
                store.mark_progress(code, "industry", y, "ok" if n else "empty", f"{n} rows")
                res["industry"] += n
            else:
                res["skipped"].append(f"industry:{y}")
    if "fee" in kinds:
        if force or _needs_refresh(store.progress(code, "fee", "-"), FEE_REFRESH_DAYS):
            fee = fetch_fee(code)
            store.upsert_fee(code, fee)
            ok = any(fee.get(k) is not None for k in
                     ("mgmt_rate", "custody_rate", "buy_rate_disc"))
            store.mark_progress(code, "fee", "-", "ok" if ok else "empty", json.dumps(fee)[:180])
            res["fee"] = bool(ok)
        else:
            res["skipped"].append("fee")
    if "manager" in kinds:
        if force or _needs_refresh(store.progress(code, "manager", "-"), 30):
            rows = fetch_manager_tenure(code)
            n = store.upsert_manager_history(code, rows)
            store.mark_progress(code, "manager", "-", "ok" if n else "empty", f"{n} segs")
            res["manager"] = n
        else:
            res["skipped"].append("manager")
    if "holder" in kinds:
        if force or _needs_refresh(store.progress(code, "holder", "-"), 30):
            rows = fetch_holder_structure(code)
            n = store.upsert_holder_struct(code, rows)
            store.mark_progress(code, "holder", "-", "ok" if n else "empty", f"{n} periods")
            res["holder"] = n
        else:
            res["skipped"].append("holder")
    if "manager_ann" in kinds:
        # H2 的 PIT 公告锚点（修复方案 v1.0 §3.3）。公告是 append-only 的，
        # 抓过即可，30 天补一次抓新增。
        if force or _needs_refresh(store.progress(code, "manager_ann", "-"), 30):
            rows = fetch_manager_announcements(code)
            n = store.upsert_manager_announcements(code, rows)
            store.mark_progress(code, "manager_ann", "-", "ok" if n else "empty", f"{n} anns")
            res["manager_ann"] = n
        else:
            res["skipped"].append("manager_ann")
    return res


def _needs_refresh(prog: Optional[Dict], max_age_days: int) -> bool:
    """进度记录是否需要重抓：没抓过、抓失败过、或已过期。"""
    if not prog or prog.get("status") != "ok":
        return True
    ts = str(prog.get("updated_at") or "")[:19]
    d = _as_date(ts)
    if d is None:
        return True
    return (datetime.now() - d).days >= int(max_age_days)
