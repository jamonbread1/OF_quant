import logging
import pandas as pd
from typing import List, Dict, Optional
from .providers.public import PublicFundProvider
from .providers.bulk import BulkNavProvider, merge_nav_index
from .providers.private import PrivateFundLocalProvider
from .aligner import DataAligner
from .cleaner import FundDataCleaner
from .universe import DynamicUniverse

logger = logging.getLogger(__name__)


class DataPipeline:
    """生产级管线：拉取(真复权+缓存) -> 清洗(跳变/缺失) -> 对齐 -> PIT。"""

    def __init__(
        self,
        cache_dir: Optional[str] = None,
        adjust: bool = True,
        clean_outlier_threshold: float = 0.15,
        use_bulk: bool = True,
        bulk_db_path: Optional[str] = None,
    ):
        self.public_provider = PublicFundProvider(cache_dir=cache_dir, adjust=adjust)
        self.cleaner = FundDataCleaner(outlier_threshold=clean_outlier_threshold)
        self.universe = DynamicUniverse()
        self.adjust = adjust
        # 本地全市场净值库优先：命中就不联网（几百只标的时这是数量级的提速）
        self.bulk_provider = BulkNavProvider(db_path=bulk_db_path) if use_bulk else None
        # 统一数据仓（market.db）：Phase B 读端首选 —— 单库、含主档与净值、
        # 代码口径统一。不可用时自动回退 bulk → 联网，行为不变。
        self._market_db = None
        self._market_db_tried = False
        self._bulk_miss: set = set()

    # ---------- 统一数据仓（market.db）读端 ----------
    @property
    def market_db(self):
        """懒加载 market.db；不存在或异常一律返回 None（调用方回退旧路径）。"""
        if self._market_db_tried:
            return self._market_db
        self._market_db_tried = True
        try:
            from .market_db import default_market_db
            self._market_db = default_market_db()
        except Exception as e:
            logger.warning(f"market.db 不可用（回退旧数据路径）: {e}")
            self._market_db = None
        return self._market_db

    def _market_nav_df(self, fund_code: str, start_date=None, end_date=None):
        """从 market.db 取标准净值 DataFrame；无数据返回 None。"""
        mk = self.market_db
        if mk is None:
            return None
        try:
            s_adj = mk.nav_series(fund_code, start_date, end_date, col="adj_nav")
            if len(s_adj) < 2:
                return None
            s_unit = mk.nav_series(fund_code, start_date, end_date, col="unit_nav")
            s_acc = mk.nav_series(fund_code, start_date, end_date, col="acc_nav")
            df = pd.DataFrame({"adj_nav": s_adj})
            df["unit_nav"] = s_unit.reindex(df.index)
            df["acc_nav"] = s_acc.reindex(df.index)
            df["acc_nav"] = df["acc_nav"].fillna(df["unit_nav"]).fillna(df["adj_nav"])
            df["unit_nav"] = df["unit_nav"].fillna(df["adj_nav"])
            from .schema import FundDataSchema
            df[FundDataSchema.CODE] = str(fund_code).split(".")[0].zfill(6) + ".OF"
            return df
        except Exception as e:
            logger.warning(f"market.db 读取 {fund_code} 失败，回退: {e}")
            return None

    def get_public_fund(
        self,
        fund_code: str,
        start_date: str = None,
        end_date: str = None,
        clean: bool = True,
    ) -> pd.DataFrame:
        df = None
        # ① 统一数据仓（单库、口径统一、最快）
        if fund_code not in self._bulk_miss:
            df = self._market_nav_df(fund_code, start_date, end_date)
        if self.bulk_provider is not None and fund_code not in self._bulk_miss:
            try:
                df = self.bulk_provider.fetch(fund_code, start_date, end_date)
            except LookupError:
                self._bulk_miss.add(fund_code)     # 记下来，后续不再重复查库
                df = None
            except Exception as e:
                logger.warning(f"bulk 读取 {fund_code} 异常，回落联网: {e}")
                df = None
        if df is None or df.empty:
            df = self.public_provider.fetch(fund_code, start_date, end_date)
        if clean:
            df, report = self.cleaner.clean_single(df)
            if report.get("n_outlier"):
                logger.info(f"{fund_code} 清洗: {report}")
        return df

    def local_nav_index(self, min_rows: int = 0) -> Dict[str, Dict]:
        """「本地净值可得性」的权威口径：**取数路径能看到什么，池就有什么**。

        合并 .cache（PublicFundProvider）与 nav_bulk.db，同一代码取行数更多的一份。
        选池必须用这个，否则会出现"池里有 bulk 的 278 只、回测却只能拉到 5 只"。
        ⚠️ Phase B：market.db 的覆盖**优先并入**——它是唯一权威来源，
        且主档统计列（nav_rows/first/last_nav_date）已由 refresh_stats 维护。
        """
        mk = self.market_db
        if mk is not None:
            try:
                cov = mk.nav_coverage(min_rows=min_rows)
                if not cov.empty:
                    idx = {f"{str(r['fund_code']).zfill(6)}.OF": {
                        "rows": int(r["nav_rows"]),
                        "first_date": r["first_nav_date"],
                        "last_date": r["last_nav_date"],
                    } for _, r in cov.iterrows()}
                    idx = merge_nav_index(idx, self.public_provider.local_nav_index())
                    return idx
            except Exception as e:
                logger.warning(f"market.db 覆盖读取失败（回退旧口径）: {e}")
        idx = self.public_provider.local_nav_index()
        if min_rows > 0:
            idx = {k: v for k, v in idx.items() if int(v.get("rows") or 0) >= min_rows}
        if self.bulk_provider is not None:
            idx = merge_nav_index(idx, self.bulk_provider.local_nav_index(min_rows=min_rows))
        return idx

    def get_private_fund(self, fund_code: str, file_path: str, **kwargs) -> pd.DataFrame:
        provider = PrivateFundLocalProvider(file_path=file_path, column_mapping=kwargs.get('column_mapping'))
        df = provider.fetch(fund_code, kwargs.get('start_date'), kwargs.get('end_date'))
        if kwargs.get("clean", True):
            df, _ = self.cleaner.clean_single(df)
        return df

    def list_funds(self) -> pd.DataFrame:
        return self.public_provider.list_all_funds()

    def daily_snapshot(self) -> pd.DataFrame:
        return self.public_provider.get_daily_snapshot()

    def create_universe_panel(
        self,
        public_codes: List[str] = None,
        private_configs: Dict[str, str] = None,
        start_date: str = None,
        freq: str = 'B',
        resample_method: str = 'ffill',
        proxy_fund_code: str = None,  # 如果使用 proxy_mapping，可以指定一只公募指数基金做基准
        pit_lag: int = 0,  # 上线默认0(保持兼容)；策略信号必须传 pit_lag=1 防前视
        clean: bool = True,
    ) -> pd.DataFrame:
        data_pool = {}

        if public_codes:
            for code in public_codes:
                try:
                    data_pool[code] = self.get_public_fund(code, start_date, clean=clean)
                except Exception as e:
                    # 生产级：单只失败不阻断全池（反爬/停更常见），记日志后跳过
                    logger.warning(f"跳过基金 {code}: {e}")

        if private_configs:
            for code, path in private_configs.items():
                try:
                    df = self.get_private_fund(code, path, start_date=start_date)
                    data_pool[code] = df
                except Exception as e:
                    logger.warning(f"跳过私募 {code}: {e}")

        if not data_pool:
            from .exceptions import UniverseError
            raise UniverseError("所有基金拉取失败，无法构建宽表")

        proxy_series = None
        if resample_method == 'proxy_mapping':
            if not proxy_fund_code:
                raise ValueError("使用 proxy_mapping 时必须提供 proxy_fund_code (例如: 000300.OF 沪深300基准)")

            proxy_df = self.get_public_fund(proxy_fund_code, start_date, clean=clean)
            proxy_series = proxy_df['adj_nav']

        panel = DataAligner.align_to_panel(
            data_dict=data_pool,
            target_col='adj_nav',
            freq=freq,
            method=resample_method,
            proxy_data=proxy_series
        )
        if pit_lag and pit_lag > 0:
            panel = FundDataCleaner.apply_pit(panel, lag=pit_lag)
            panel = panel.dropna(how="all")  # PIT 首行全空，丢弃
        return panel

    def eligible_funds_at(
        self,
        asof: str,
        nav_panel: pd.DataFrame,
        status_map: Optional[Dict[str, str]] = None,
        scale_map: Optional[Dict[str, float]] = None,
        master=None,
    ) -> List[str]:
        """asof 日可用买入池（PIT安全）。

        master 可选，传入即用基金基础库的真实成立日/清盘日/规模判定，见 universe.build_eligible_set。
        """
        return self.universe.build_eligible_set(
            pd.to_datetime(asof), nav_panel, status_map=status_map,
            scale_map=scale_map, master=master
        )

data_api = DataPipeline()
