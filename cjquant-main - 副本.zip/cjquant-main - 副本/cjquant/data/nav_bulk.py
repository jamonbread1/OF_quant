# -*- coding: utf-8 -*-
"""全市场 NAV 批量库（分批预热的落库层）。

为什么存在
----------
策略要"全市场选池"，就必须先把几千只基金的复权净值落在本地。
实测（80 只抽样，2026-09-18）：
  * 全市场 27873 只 → 总行数 ≈ 0.3 亿行（均值 1213 行/只，中位 964，最长 6009）
  * 单行体积：CSV 80.1B / Parquet 12.9B / SQLite ≈ 40B
  * 落 SQLite ≈ 1.7 GB，Parquet ≈ 0.4 GB
  * 单只抓取 ~0.55s → **全量首轮 ≈ 4.3 小时**

所以 **存储不是瓶颈（50GB 上限下 SQLite 只占 ~3%），网络耗时才是**。
分批的目的因此是：①不阻塞调度 ②按价值优先（先用上合格标的）③可断点续跑。

选型：SQLite 单库（事务安全、增量 upsert 方便、无新依赖）。
Parquet 更省空间但增量更新要重写分区，收益（省 1.3GB）不值这个复杂度 —— 若日后
行数涨到十亿级再迁移。
"""
import logging
import os
import sqlite3
import threading
from datetime import date, datetime, timedelta
from typing import Dict, Iterable, List, Optional, Sequence

logger = logging.getLogger(__name__)

from .exceptions import FundNoNavPageError  # noqa: E402  (零依赖，直接导入以便类型判断)

DEFAULT_BULK_DB = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "store", "nav_bulk.db")

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS nav_daily_bulk (
    fund_code TEXT NOT NULL,
    date      TEXT NOT NULL,
    adj_nav   REAL,
    unit_nav  REAL,
    PRIMARY KEY (fund_code, date)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS idx_bulk_date ON nav_daily_bulk(date);

-- 预热进度：每只一行，成功后只在增量刷新时回写
CREATE TABLE IF NOT EXISTS bulk_progress (
    fund_code   TEXT PRIMARY KEY,
    status      TEXT,          -- ok / fail / skip
    rows        INTEGER,
    first_date  TEXT,
    last_date   TEXT,
    fail_count  INTEGER DEFAULT 0,
    updated_at  TEXT
) WITHOUT ROWID;

CREATE TABLE IF NOT EXISTS bulk_meta (
    key   TEXT PRIMARY KEY,
    value TEXT
) WITHOUT ROWID;
"""


def _norm(code: str) -> str:
    s = str(code).strip().upper()
    if "." in s:
        s = s.split(".")[0]
    return s.zfill(6) + ".OF" if s else ""


class NavBulkStore:
    """全市场 NAV 库的读写（纯本地，无网络）。"""

    def __init__(self, db_path: str = DEFAULT_BULK_DB, create: bool = True):
        self.db_path = db_path
        if db_path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        if create:
            with self._lock:
                self.conn.executescript(SCHEMA_SQL)
                self.conn.commit()
                self._ensure_updated_at()

    def _ensure_updated_at(self) -> None:
        """给 nav_daily_bulk 补 `updated_at` 列（存量库平滑升级）。

        为什么需要这一列：同步 nav_bulk → market.db 的 `import_nav_bulk` 原先
        **每次全表重导**（83 万行）。库涨到千万行时每晚会跑成小时级。
        有了行级更新时间，同步就能只导"上次同步之后变动过的行"
        （每晚每只基金只新增 1~2 天 → 几百行，而不是几十万行）。

        ⚠️ 必须回填存量行：新列默认是 NULL，若不过滤，首次增量会认为
        "没有行比 last_sync 新" 而把 83 万行历史**全部漏掉**。
        回填值取该基金 bulk_progress.updated_at（即它上次成功写入的时间），
        取不到就用当前时间。
        """
        cols = {r["name"] for r in self.conn.execute(
            "PRAGMA table_info(nav_daily_bulk)").fetchall()}
        if "updated_at" in cols:
            return
        now = datetime.now().isoformat(timespec="seconds")
        with self._lock:
            self.conn.execute("ALTER TABLE nav_daily_bulk ADD COLUMN updated_at TEXT")
            self.conn.execute(
                "UPDATE nav_daily_bulk SET updated_at = COALESCE("
                "  (SELECT p.updated_at FROM bulk_progress p "
                "   WHERE p.fund_code = nav_daily_bulk.fund_code), ?)",
                (now,))
            self.conn.commit()
        logger.info("[NavBulk] 已补充 nav_daily_bulk.updated_at 列并回填存量行")

    # ---------- 生命周期 ----------
    def close(self):
        try:
            self.conn.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    # ---------- 写入 ----------
    def upsert_nav(self, code: str, rows: Sequence[Dict]) -> int:
        """写入单只基金的净值序列（幂等，按 code+date 覆盖）。"""
        c = _norm(code)
        data = []
        first = last = None
        for r in rows:
            d = r.get("date")
            if d is None:
                continue
            ds = str(d)[:10]
            try:
                datetime.strptime(ds, "%Y-%m-%d")
            except ValueError:
                continue
            adj = r.get("adj_nav")
            unit = r.get("unit_nav")
            try:
                adj = None if adj is None else float(adj)
                unit = None if unit is None else float(unit)
            except (TypeError, ValueError):
                continue
            if adj is None and unit is None:
                continue
            data.append((c, ds, adj, unit))
            first = ds if first is None or ds < first else first
            last = ds if last is None or ds > last else last
        if not data:
            raise ValueError("净值为空或无有效行")
        # updated_at 是增量同步的位点依据（见 _ensure_updated_at 的说明）。
        # 整批共用一个时间戳：这批行要么都被同步走，要么都没同步，
        # 不会出现"同一批里一半同步了一半没同步"的中间态。
        # 定长微秒：增量位点靠字符串比较，长度/精度必须恒定，
        # 否则 "…19:44:22" 与 "…19:44:22.5" 的大小关系会出错。
        stamp = datetime.now().isoformat(timespec="microseconds")
        sql = ("INSERT INTO nav_daily_bulk (fund_code, date, adj_nav, unit_nav, updated_at) "
               "VALUES (?,?,?,?,?) "
               "ON CONFLICT(fund_code, date) DO UPDATE SET "
               "adj_nav=excluded.adj_nav, unit_nav=excluded.unit_nav, "
               "updated_at=excluded.updated_at")
        with self._lock:
            self.conn.executemany(sql, [d + (stamp,) for d in data])
            self.conn.execute(
                "INSERT INTO bulk_progress (fund_code, status, rows, first_date, last_date, "
                "fail_count, updated_at) VALUES (?,?,?,?,?,0,?) "
                "ON CONFLICT(fund_code) DO UPDATE SET status='ok', rows=excluded.rows, "
                "first_date=excluded.first_date, last_date=excluded.last_date, "
                "fail_count=0, updated_at=excluded.updated_at",
                (c, "ok", len(data), first, last, datetime.now().isoformat(timespec="seconds")))
            self.conn.commit()
        return len(data)

    def mark_fail(self, code: str, message: str = "", skip_after: int = 3) -> int:
        """记录一次失败；累计到 skip_after 次标记为 skip（不再重试）。返回累计失败次数。"""
        c = _norm(code)
        with self._lock:
            cur = self.conn.execute("SELECT fail_count FROM bulk_progress WHERE fund_code=?", (c,))
            row = cur.fetchone()
            n = int(row["fail_count"] or 0) + 1 if row else 1
            status = "skip" if n >= int(skip_after) else "fail"
            self.conn.execute(
                "INSERT INTO bulk_progress (fund_code, status, rows, fail_count, updated_at) "
                "VALUES (?,?,?,?,?) ON CONFLICT(fund_code) DO UPDATE SET "
                "status=excluded.status, fail_count=excluded.fail_count, updated_at=excluded.updated_at",
                (c, status, 0, n, datetime.now().isoformat(timespec="seconds")))
            self.conn.commit()
        if message:
            logger.warning("[NavBulk] %s 失败(%d/%d): %s", c, n, skip_after, str(message)[:120])
        return n

    def set_meta(self, key: str, value) -> None:
        with self._lock:
            self.conn.execute("INSERT INTO bulk_meta(key,value) VALUES(?,?) "
                              "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                              (key, str(value)))
            self.conn.commit()

    def get_meta(self, key: str) -> Optional[str]:
        cur = self.conn.execute("SELECT value FROM bulk_meta WHERE key=?", (key,))
        r = cur.fetchone()
        return r["value"] if r else None

    # ---------- 查询 ----------
    def pending_codes(self, candidates: Optional[Iterable[str]] = None,
                      limit: int = 0, skip_failed_after: int = 3) -> List[str]:
        """还没成功落库、且未放弃的代码。

        candidates 传入时按该顺序优先（用于"策略候选优先预热"）。
        """
        done = set()
        skipped = set()
        for r in self.conn.execute("SELECT fund_code, status, fail_count FROM bulk_progress"):
            if r["status"] == "ok":
                done.add(r["fund_code"])
            elif r["status"] == "skip" or int(r["fail_count"] or 0) >= int(skip_failed_after):
                # status 已是 skip 就一定要排除：它可能是按更早的阈值被判定的，
                # 不能因为当前阈值更宽又把它捡回来重试。
                skipped.add(r["fund_code"])
        out: List[str] = []
        seen = set()
        for raw in (candidates or []):
            c = _norm(raw)
            if c and c not in done and c not in skipped and c not in seen:
                seen.add(c)
                out.append(c)
        if limit and len(out) >= limit:
            return out[:limit]
        # 再从全量名单补（顺序稳定，便于断点续跑）
        cur = self.conn.execute("SELECT fund_code FROM bulk_universe ORDER BY fund_code") \
            if self._has_table("bulk_universe") else None
        universe = [r["fund_code"] for r in cur.fetchall()] if cur else []
        for c in universe:
            if c in done or c in skipped or c in seen:
                continue
            seen.add(c)
            out.append(c)
            if limit and len(out) >= limit:
                break
        return out

    def _has_table(self, name: str) -> bool:
        cur = self.conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,))
        return cur.fetchone() is not None

    def set_universe(self, codes: Iterable[str]) -> int:
        """登记待预热的全量名单（幂等）。"""
        with self._lock:
            self.conn.execute("CREATE TABLE IF NOT EXISTS bulk_universe "
                              "(fund_code TEXT PRIMARY KEY) WITHOUT ROWID")
            rows = [(_norm(c),) for c in codes if _norm(c)]
            self.conn.executemany("INSERT OR IGNORE INTO bulk_universe(fund_code) VALUES (?)", rows)
            self.conn.commit()
        return len(rows)

    def get_nav(self, code: str, start: Optional[str] = None,
                end: Optional[str] = None) -> List[Dict]:
        c = _norm(code)
        q = "SELECT date, adj_nav, unit_nav FROM nav_daily_bulk WHERE fund_code=?"
        args: List = [c]
        if start:
            q += " AND date >= ?"
            args.append(str(start)[:10])
        if end:
            q += " AND date <= ?"
            args.append(str(end)[:10])
        q += " ORDER BY date"
        return [dict(r) for r in self.conn.execute(q, args)]

    def progress(self, code: str) -> Optional[Dict]:
        cur = self.conn.execute("SELECT * FROM bulk_progress WHERE fund_code=?", (_norm(code),))
        r = cur.fetchone()
        return dict(r) if r else None

    def available_codes(self, min_rows: int = 250,
                        end_date: Optional[str] = None,
                        stale_days: int = 20) -> List[Dict]:
        """本地已确认「有足够长净值」的基金清单（纯本地，不联网）。

        这是给回测/选池用的：没有净值的基金在回测里根本无法成交，
        所以先用本地净值可得性筛一遍，比先按基本面筛再发现取不到数要省得多。

        min_rows   最少净值行数（约等于交易日数），默认 250（≈1 年）
        end_date   若给出，要求该基金的净值覆盖到这个日期附近
                   （已停更/清盘基金会被排除；未给则不做时间过滤）
        stale_days end_date 前多少天内的末值算「新鲜」
        返回 [{"fund_code", "rows", "first_date", "last_date"}, ...]，按行数降序
        """
        q = ("SELECT fund_code, rows, first_date, last_date FROM bulk_progress "
             "WHERE status = 'ok' AND COALESCE(rows, 0) >= ?")
        args: List = [int(min_rows)]
        if end_date:
            # 末值必须落在 end_date 之前（不能用未来数据）、且距 end_date 不超过 stale_days
            end_d = datetime.strptime(str(end_date)[:10], "%Y-%m-%d")
            cutoff = (end_d - timedelta(days=int(stale_days))).strftime("%Y-%m-%d")
            q += " AND last_date >= ? AND last_date <= ?"
            args.extend([cutoff, end_d.strftime("%Y-%m-%d")])
        q += " ORDER BY rows DESC, fund_code ASC"
        return [dict(r) for r in self.conn.execute(q, args)]

    def stale_codes(self, asof: Optional[str] = None,
                    stale_days: int = 3, limit: int = 0) -> List[str]:
        """已预热成功、但净值停更超过 `stale_days` 天的基金（需增量刷新）。

        ⚠️ 为什么需要这个：`pending_codes` 只返回「还没成功落库」的基金，
        一旦某只 `status=ok` 就再也不会被预热任务碰到 —— 净值永远停在首次
        拉取那天。场外基金每个交易日都有新净值，若不增量刷新，持仓页的
        「最新净值」会一直停留在几天甚至几周前。
        """
        asof_d = datetime.strptime(str(asof)[:10], "%Y-%m-%d") if asof else datetime.now()
        cutoff = (asof_d - timedelta(days=int(stale_days))).strftime("%Y-%m-%d")
        q = ("SELECT fund_code FROM bulk_progress WHERE status = 'ok' "
             "AND last_date < ? ORDER BY last_date ASC, fund_code ASC")
        if limit:
            q += " LIMIT ?"
            return [r["fund_code"] for r in self.conn.execute(q, (cutoff, int(limit)))]
        return [r["fund_code"] for r in self.conn.execute(q, (cutoff,))]

    def stats(self) -> Dict:
        def one(sql, args=()):
            return self.conn.execute(sql, args).fetchone()[0]
        total_rows = one("SELECT COUNT(*) FROM nav_daily_bulk")
        return {
            "nav_rows": int(total_rows),
            "funds_ok": int(one("SELECT COUNT(*) FROM bulk_progress WHERE status='ok'")),
            "funds_fail": int(one("SELECT COUNT(*) FROM bulk_progress WHERE status='fail'")),
            "funds_skip": int(one("SELECT COUNT(*) FROM bulk_progress WHERE status='skip'")),
            "db_gb": round(self.db_size_gb(), 3),
        }

    def db_size_gb(self) -> float:
        if self.db_path == ":memory:" or not os.path.exists(self.db_path):
            return 0.0
        total = os.path.getsize(self.db_path)
        for suffix in ("-wal", "-shm"):
            p = self.db_path + suffix
            if os.path.exists(p):
                total += os.path.getsize(p)
        return total / 1024 ** 3

    def over_quota(self, max_gb: float) -> bool:
        return self.db_size_gb() >= float(max_gb)


class NavBulkWarmup:
    """分批预热编排：把 PublicFundProvider 的净值灌进 NavBulkStore。

    抓取函数可注入，便于离线测试。每夜只处理 limit 只，失败自动累计并在
    达到阈值后放弃（避免"只有页面不存在"的份额代码拖住进度）。
    """

    def __init__(self, store: NavBulkStore,
                 fetcher=None,
                 sleep: float = 0.15,
                 skip_after_failures: int = 3,
                 max_gb: float = 40.0):
        self.store = store
        if fetcher is None:
            from cjquant.data.providers.public import PublicFundProvider
            prov = PublicFundProvider(cache_dir="./.cache/cjquant", adjust=True)

            def fetcher(code):       # type: ignore
                df = prov.fetch(code.split(".")[0], start_date=None, end_date=None)
                return [{"date": str(idx)[:10], "adj_nav": float(row["adj_nav"]),
                         "unit_nav": float(row["unit_nav"])}
                        for idx, row in df.iterrows()]
        self.fetcher = fetcher
        self.sleep = float(sleep)
        self.skip_after_failures = int(skip_after_failures)
        self.max_gb = float(max_gb)

    def run_batch(self, limit: int = 4000, priority: Optional[Iterable[str]] = None) -> Dict:
        """跑一批。返回统计；触及配额上限则提前停止。"""
        started = datetime.now()
        codes = self.store.pending_codes(candidates=priority, limit=limit,
                                         skip_failed_after=self.skip_after_failures)
        ok = fail = rows = 0
        for i, c in enumerate(codes):
            if self.store.over_quota(self.max_gb):
                logger.warning("[NavBulk] 触达配额上限 %.1fGB，本批提前停止", self.max_gb)
                break
            try:
                data = self.fetcher(c)
                rows += self.store.upsert_nav(c, data)
                ok += 1
            except Exception as e:
                fail += 1
                if isinstance(e, FundNoNavPageError):
                    # 确定性失败（无净值页/HTML 错误页/JS 缺净值变量）：
                    # 一次即放弃，不再按通用阈值跨 3 个批次重试。
                    # 全市场名单里有大量「(后端)」份额，逐夜累计会显著拖慢首轮预热。
                    self.store.mark_fail(c, f"{e}（确定性失败，直接放弃）", skip_after=1)
                else:
                    self.store.mark_fail(c, str(e), skip_after=self.skip_after_failures)
            if self.sleep:
                import time
                time.sleep(self.sleep)
            if (i + 1) % 200 == 0:
                logger.info("[NavBulk] 进度 %d/%d ok=%d fail=%d rows=%d",
                            i + 1, len(codes), ok, fail, rows)
        self.store.set_meta("last_batch_at", datetime.now().isoformat(timespec="seconds"))
        self.store.set_meta("last_batch_size", len(codes))
        res = {
            "picked": len(codes), "ok": ok, "fail": fail, "rows": rows,
            "seconds": round((datetime.now() - started).total_seconds(), 1),
            "db_gb": round(self.store.db_size_gb(), 3),
            "stats": self.store.stats(),
        }
        logger.info("[NavBulk] 本批完成 %s", res)
        return res
