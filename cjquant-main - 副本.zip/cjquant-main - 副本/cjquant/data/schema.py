import pandas as pd
from .exceptions import DataFormatError

class FundDataSchema:
    DATE = 'date'
    CODE = 'fund_code'
    UNIT_NAV = 'unit_nav'       
    ACC_NAV = 'acc_nav'         
    ADJ_NAV = 'adj_nav'         

    @classmethod
    def validate(cls, df: pd.DataFrame) -> pd.DataFrame:
        if df.empty:
            raise DataFormatError("输入的数据集为空。")

        required_cols = [cls.CODE, cls.UNIT_NAV, cls.ACC_NAV, cls.ADJ_NAV]
        
        if df.index.name != cls.DATE:
            if cls.DATE in df.columns:
                df = df.set_index(cls.DATE)
            else:
                raise DataFormatError(f"DataFrame 必须包含 '{cls.DATE}' 列或以此作为索引")
        
        try:
            df.index = pd.to_datetime(df.index).tz_localize(None)
        except TypeError:
            # 已经是 naive 或无法 localize 时直接转换
            df.index = pd.to_datetime(df.index)
        
        for col in required_cols:
            if col not in df.columns:
                raise DataFormatError(f"缺失标准列: {col}")
                
        for col in [cls.UNIT_NAV, cls.ACC_NAV, cls.ADJ_NAV]:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        
        df = df.dropna(subset=[cls.UNIT_NAV, cls.ACC_NAV, cls.ADJ_NAV])
        df = df[df[cls.UNIT_NAV] > 0].copy()
        
        df = df[~df.index.duplicated(keep='last')]
        
        df = df.sort_index()

        # 生产级：保留透传的元数据列（如 dividend/split 标记），只保证前四列顺序
        extra_cols = [c for c in df.columns if c not in required_cols]
        return df[required_cols + extra_cols]