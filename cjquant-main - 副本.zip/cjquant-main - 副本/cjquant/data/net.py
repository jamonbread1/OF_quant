# -*- coding: utf-8 -*-
"""统一网络 / 数据源访问层：本项目所有对外请求的唯一入口。

设计背景与取舍见 `docs/数据刷新与访问层.md`，这里只讲接口契约：

    ak_call(name, ...)      调 akshare 接口
    http_get(url, ...)      HTTP GET（共用连接池）
    http_get_json(url, ...) HTTP GET + JSON
    cached_call(key, fn)    进程内 TTL 缓存

错误二分（调用方据此决定重试还是放弃）：
    确定性失败 → FundNoNavPageError   数据源明确说"没有"，重试无意义
    可重试失败 → DataFetchError       抖动/限流/超时，已退避重试后仍失败
"""
from __future__ import annotations

import logging
import random
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Tuple

from .exceptions import DataFetchError, FundNoNavPageError

logger = logging.getLogger(__name__)

__all__ = [
    "HttpConfig", "HTTP_CONFIG", "configure",
    "ak_call", "http_get", "http_get_json", "cached_call",
    "is_no_nav_page_error", "is_deterministic_error", "short_err",
]


@dataclass
class HttpConfig:
    """网络层统一配置。改这里即改全项目，调用方不要再各写一份。"""

    timeout: Tuple[float, float] = (6.0, 20.0)   # (连接, 读取) 秒
    max_retries: int = 3          # 总尝试次数（含首次）
    retry_base_delay: float = 1.0  # 退避基数：第 n 次等 base * 2^(n-1)
    retry_max_delay: float = 8.0
    jitter: float = 0.3           # 抖动比例，避免多任务同时重试形成尖峰
    fail_fast_on_missing_page: bool = True   # 关掉可排查偶发限流被误判为确定性失败
    cache_ttl_seconds: int = 3600
    user_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    )


HTTP_CONFIG = HttpConfig()


def configure(**kwargs) -> HttpConfig:
    """运行时调参（测试/排查用）。例：configure(max_retries=1, timeout=(2, 5))。"""
    for k, v in kwargs.items():
        if hasattr(HTTP_CONFIG, k):
            setattr(HTTP_CONFIG, k, v)
    return HTTP_CONFIG


def is_no_nav_page_error(err: BaseException) -> bool:
    """数据源返回了 HTML 错误页 / JS 缺净值变量，而非网络抖动。

    ⚠️ 这些特征是实测出来的，不许改成看 HTTP 状态码：东财对没有净值页的代码
    返回的是 **HTTP 200 + text/html**，状态码看不出问题。
    """
    s = str(err).lower()
    return ("<!doctype html" in s or "unexpected token '<'" in s
            or "referenceerror" in s or "is not defined" in s)


def is_deterministic_error(err: BaseException) -> bool:
    """重试也不会变好的失败。"""
    if isinstance(err, FundNoNavPageError):
        return True
    return is_no_nav_page_error(err)


def short_err(e: BaseException, limit: int = 200) -> str:
    """异常压成一行。akshare 会把整页 HTML 塞进 message（实测近 4KB），会刷屏。"""
    s = " ".join(str(e).split())
    return s if len(s) <= limit else s[:limit] + "…"


def _backoff_delay(attempt: int) -> float:
    """指数退避 + 抖动。attempt 从 0 开始。"""
    base = min(HTTP_CONFIG.retry_base_delay * (2 ** attempt),
               HTTP_CONFIG.retry_max_delay)
    j = base * HTTP_CONFIG.jitter
    return max(0.0, base + random.uniform(-j, j))


_tls = threading.local()


def _session():
    """每线程一份 Session —— requests.Session 不是线程安全的。"""
    sess = getattr(_tls, "session", None)
    if sess is None:
        import requests
        sess = requests.Session()
        adapt = requests.adapters.HTTPAdapter(pool_connections=16,
                                              pool_maxsize=32)
        sess.mount("http://", adapt)
        sess.mount("https://", adapt)
        sess.headers.update({"User-Agent": HTTP_CONFIG.user_agent})
        _tls.session = sess
    return sess


def close_session() -> None:
    """关闭当前线程的会话（子进程退出/任务收尾时调用，防止句柄泄漏）。"""
    sess = getattr(_tls, "session", None)
    if sess is not None:
        try:
            sess.close()
        except Exception:
            pass
        _tls.session = None


def http_get(url: str, *, headers: Optional[Dict[str, str]] = None,
             timeout: Optional[Any] = None, **kwargs):
    """统一 GET，返回 `requests.Response`。连接错误 / 5xx / 429 会退避重试。"""
    def _once():
        try:
            r = _session().get(url, headers=headers,
                               timeout=timeout or HTTP_CONFIG.timeout, **kwargs)
        except Exception as e:
            raise DataFetchError(f"请求失败 {url}: {short_err(e)}") from e
        if r.status_code == 429 or 500 <= r.status_code < 600:
            raise DataFetchError(f"HTTP {r.status_code} {url}")
        return r

    return _run_with_retry(_once, f"GET {url}")


def http_get_json(url: str, *, headers: Optional[Dict[str, str]] = None,
                  timeout: Optional[Any] = None, **kwargs) -> Any:
    """GET + json 解析。非 JSON（如错误页）会走到重试，耗尽后抛 DataFetchError。"""
    r = http_get(url, headers=headers, timeout=timeout, **kwargs)
    try:
        return r.json()
    except Exception as e:
        head = (r.text or "")[:80].replace("\n", " ")
        raise DataFetchError(f"非 JSON 响应 {url}: {e}; 前 80 字节={head!r}") from e


def _run_with_retry(fn: Callable[[], Any], label: str,
                    max_retries: Optional[int] = None,
                    sleep: bool = True,
                    fail_fast: Optional[bool] = None) -> Any:
    """重试执行器：确定性失败立刻放弃，其余指数退避。

    max_retries 逐次覆盖全局值（批处理里外层已兜底时不要再套一层）；
    sleep=False 用于调用方自己已做间隔的场合，避免双重退避。
    """
    do_fail_fast = HTTP_CONFIG.fail_fast_on_missing_page if fail_fast is None else fail_fast
    total = HTTP_CONFIG.max_retries if max_retries is None else max(1, int(max_retries))
    last: Optional[BaseException] = None
    for attempt in range(total):
        try:
            return fn()
        except BaseException as e:  # noqa: BLE001 —— 需要捕获后再分类重抛
            if isinstance(e, (KeyboardInterrupt, SystemExit)):
                raise
            if do_fail_fast and is_deterministic_error(e):
                logger.warning(f"{label} 确定性失败，跳过重试: {short_err(e)}")
                if isinstance(e, FundNoNavPageError):
                    raise
                raise FundNoNavPageError(str(e)) from e
            last = e
            if attempt + 1 >= total:
                break
            delay = _backoff_delay(attempt)
            logger.info(f"{label} 第 {attempt + 1} 次失败，{delay:.1f}s 后重试: {short_err(e)}")
            if sleep:
                time.sleep(delay)
    raise DataFetchError(f"{label} 连续失败: {short_err(last) if last else '未知'}")


def ak_call(fn_name: str, *, validator: Optional[Callable[[Any], Any]] = None,
            max_retries: Optional[int] = None, sleep: bool = True,
            fail_fast: Optional[bool] = None, **kwargs):
    """调用 akshare 接口 `fn_name`（延迟 import，离线环境不会硬依赖）。

    ⚠️ `validator` 用来表达"返回空表也算失败"这类业务判定：raise DataFetchError
    即触发重试。调用方不要在外层再套自己的重试循环 —— 两层会把 3 次放大成 9 次。
    ⚠️ 本层不吞异常，"失败返回空 DataFrame"由调用方显式决定。
    """
    import akshare as ak
    fn = getattr(ak, fn_name, None)
    if fn is None:
        raise DataFetchError(f"akshare 无此接口: {fn_name}")

    def _once():
        try:
            res = fn(**kwargs)
        except TypeError as e:
            # 部分版本参数名是 fund= 而非 symbol=
            if "symbol" in kwargs and "unexpected keyword" in str(e):
                alt = dict(kwargs)
                alt["fund"] = alt.pop("symbol")
                res = fn(**alt)
            else:
                raise
        if validator is not None:
            res = validator(res)
        return res

    return _run_with_retry(_once, f"ak.{fn_name}({_fmt_kwargs(kwargs)})",
                           max_retries=max_retries, sleep=sleep,
                           fail_fast=fail_fast)


def _fmt_kwargs(kwargs: Dict[str, Any], limit: int = 120) -> str:
    s = ", ".join(f"{k}={v!r}" for k, v in kwargs.items())
    return s if len(s) <= limit else s[:limit] + "…"


@dataclass
class _CacheEntry:
    value: Any
    expires: float


_CACHE_LOCK = threading.Lock()
_CACHE: Dict[str, _CacheEntry] = {}


def cached_call(key: str, producer: Callable[[], Any],
                ttl: Optional[int] = None) -> Any:
    """带 TTL 的进程内缓存，用于全市场名单/快照这类短期不变的整表接口。

    ⚠️ 只缓存成功结果：producer 抛异常时不写缓存，否则一次抖动会把空结果钉死一天。
    """
    ttl = HTTP_CONFIG.cache_ttl_seconds if ttl is None else ttl
    now = time.time()
    if ttl > 0:
        with _CACHE_LOCK:
            hit = _CACHE.get(key)
            if hit is not None and hit.expires > now:
                logger.debug(f"[net.cache] 命中 {key}（剩余 {hit.expires - now:.0f}s）")
                return hit.value
    value = producer()
    if ttl > 0:
        with _CACHE_LOCK:
            _CACHE[key] = _CacheEntry(value=value, expires=now + ttl)
    return value


def cache_clear() -> None:
    """清空进程内取数缓存（测试用 / 排查"改了源却看不到新数据"时用）。"""
    with _CACHE_LOCK:
        _CACHE.clear()


def cache_info() -> Dict[str, float]:
    """当前缓存键与剩余秒数（排查用）。"""
    now = time.time()
    with _CACHE_LOCK:
        return {k: round(v.expires - now, 1) for k, v in _CACHE.items()}
