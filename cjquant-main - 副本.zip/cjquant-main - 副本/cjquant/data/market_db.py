# -*- coding: utf-8 -*-
"""统一基金数据仓（market.db）：单一 SQLite 库管理系统。

表（主外键：子表 fund_code → fund.fund_code，PRAGMA foreign_keys=ON 强制）：
    fund               全市场主档（含已清盘）—— 回测标的池权威来源
    fund_nav           日频净值（standard / money_market / synthetic，nav_type 区分）
    fund_fee           费率规则 + 申赎状态快照
    fund_redeem_tier   赎回费阶梯（持有期 → 档）
    fund_scale         规模与份额历史（季报口径）
    fund_manager       经理任职区间（H2）
    fund_manager_announce  人事公告（H2 的 PIT 锚点）
    fund_holder        持有人结构（H6）
    fund_holdings      持仓明细（D5）
    fund_industry      行业配置（D5）
    subscribe_status_daily  申赎状态每日快照（H4，只攒历史、绝不回填）
    sync_task_log      数据任务执行台账

⚠️ 代码口径统一 6 位数字为主键（查询 API 同时接受 XXXXXX / XXXXXX.OF）。
设计文档与三阶段迁移方案见 docs/统一数据仓设计.md。
"""
import logging
import os
import sqlite3
import threading
from datetime import datetime
from typing import Dict, Iterable, List, Optional, Sequence

import pandas as pd

from . import net

logger = logging.getLogger(__name__)

DEFAULT_MARKET_DB = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "store", "market.db")

SCHEMA = """
PRAGMA foreign_keys = ON;

-- ═══════════════════ 1. 基金主档（生命周期，权威来源） ═══════════════════
-- 全市场"历史上存在过 + 当前存续"的每一只基金一行。
-- 回测拉标的池 = 本表按 status/setup/liquidation/nav 覆盖过滤 —— 幸存者偏差
-- 治理从这里开始（清盘基金保留在池里，回测按清盘日强制赎回，见 engine F-3）。
CREATE TABLE IF NOT EXISTS fund (
    fund_code        TEXT PRIMARY KEY,   -- 6 位数字（统一口径，无 .OF 后缀）
    fund_name        TEXT,
    fund_type        TEXT,               -- 数据源原值，如「混合型-偏股」
    share_class      TEXT,               -- A/C/E/…（名称尾字母派生，NULL=无法识别）
    family_key       TEXT,               -- 名称剥份额字母后的族键（A/C 优选用）
    company          TEXT,               -- 基金管理人
    manager          TEXT,               -- 现任经理快照（历史在 fund_manager）
    benchmark        TEXT,               -- 业绩比较基准
    tracking_target  TEXT,               -- 跟踪标的（指数型）
    setup_date       TEXT,               -- 成立日 YYYY-MM-DD
    liquidation_date TEXT,               -- 清盘日；NULL = 存续
    end_date         TEXT,               -- 源页面的终止日（与清盘日并存的原始字段）
    status           TEXT NOT NULL DEFAULT 'unknown',  -- active/liquidated/stale/unknown
    -- 冗余统计列（refresh_stats 维护，避免回测池查询全表扫 fund_nav）
    first_nav_date   TEXT,
    last_nav_date    TEXT,
    nav_rows         INTEGER NOT NULL DEFAULT 0,
    scale_yi         REAL,               -- 最近一期规模（亿）快照
    updated_at       TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_fund_status ON fund(status);
CREATE INDEX IF NOT EXISTS idx_fund_type   ON fund(fund_type);
CREATE INDEX IF NOT EXISTS idx_fund_setup  ON fund(setup_date);

-- ═══════════════════ 2. 日频净值 ═══════════════════
CREATE TABLE IF NOT EXISTS fund_nav (
    fund_code   TEXT NOT NULL REFERENCES fund(fund_code),
    nav_date    TEXT NOT NULL,           -- YYYY-MM-DD
    unit_nav    REAL,                    -- 单位净值
    acc_nav     REAL,                    -- 累计净值
    adj_nav     REAL,                    -- 复权净值（分红/拆分还原；ETL 派生）
    daily_return REAL,                  -- 日增长率 %（JZZZL）
    shares      REAL,                   -- 基金总份额。⚠️ 公开源只有季报口径的
                                         -- 份额（fund_scale.shares_yi），日频恒 NULL，
                                         -- 列保留给未来的日频份额源
    nav_type    TEXT NOT NULL DEFAULT 'standard',  -- standard/money_market/synthetic
    source      TEXT,                   -- em_web/em_mobile/ak_info/bulk_migration
    updated_at  TEXT NOT NULL,
    PRIMARY KEY (fund_code, nav_date)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS idx_nav_date ON fund_nav(nav_date);

-- ═══════════════════ 3. 费率规则 ═══════════════════
CREATE TABLE IF NOT EXISTS fund_fee (
    fund_code     TEXT PRIMARY KEY REFERENCES fund(fund_code),
    buy_rate_raw  REAL,                 -- 原申购费率 %
    buy_rate_disc REAL,                 -- 折后申购费率 %
    mgmt_rate     REAL,                 -- 管理费 %/年
    custody_rate  REAL,                 -- 托管费 %/年
    sales_service REAL,                 -- 销售服务费 %/年（C 类）
    subscribe_stat TEXT,                -- 最近抓取时的申购状态（历史在快照表）
    redeem_stat    TEXT,
    fee_note      TEXT,                 -- 浮动费率等文本（结构化源没有，如实存文本）
    source        TEXT,
    updated_at    TEXT NOT NULL
);

-- 赎回费阶梯：持有自然日落在 [min_days, max_days) 的费率。
-- 每只基金一组；无基金专属数据时 ETL 不填，回测端回退到
-- 《流动性风险管理规定》默认阶梯（fee.py）——不猜数据。
CREATE TABLE IF NOT EXISTS fund_redeem_tier (
    fund_code  TEXT NOT NULL REFERENCES fund(fund_code),
    min_days   INTEGER NOT NULL,        -- 区间下界（含）
    max_days   INTEGER,                 -- 区间上界（不含）；NULL=无上限
    fee_rate   REAL NOT NULL,           -- %
    updated_at TEXT NOT NULL,
    PRIMARY KEY (fund_code, min_days)
);

-- ═══════════════════ 4. 规模历史（季报口径） ═══════════════════
CREATE TABLE IF NOT EXISTS fund_scale (
    fund_code   TEXT NOT NULL REFERENCES fund(fund_code),
    report_date TEXT NOT NULL,          -- 报告期末 YYYY-MM-DD
    scale_yi    REAL,                   -- 期末净资产（亿元）
    shares_yi   REAL,                   -- 期末总份额（亿份）
    source      TEXT,
    updated_at  TEXT NOT NULL,
    PRIMARY KEY (fund_code, report_date)
);

-- ═══════════════════ 5. 基金经理（H2） ═══════════════════
CREATE TABLE IF NOT EXISTS fund_manager (
    fund_code    TEXT NOT NULL REFERENCES fund(fund_code),
    manager_name TEXT NOT NULL,
    start_date   TEXT NOT NULL,         -- 该经理此段任职起始日
    end_date     TEXT,                  -- NULL = 在任
    updated_at   TEXT NOT NULL,
    PRIMARY KEY (fund_code, manager_name, start_date)
);
-- 人事公告：任职期在决策日"可知"的 PIT 锚点（起始日之后第一条公告 <= asof）
CREATE TABLE IF NOT EXISTS fund_manager_announce (
    fund_code  TEXT NOT NULL REFERENCES fund(fund_code),
    ann_date   TEXT NOT NULL,
    title      TEXT,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (fund_code, ann_date, title)
);

-- ═══════════════════ 6. 持有人结构（H6） ═══════════════════
CREATE TABLE IF NOT EXISTS fund_holder (
    fund_code      TEXT NOT NULL REFERENCES fund(fund_code),
    report_date    TEXT NOT NULL,       -- 公告日（6-30 / 12-31 口径）
    inst_ratio     REAL,                -- 机构持有比例（小数）
    person_ratio   REAL,
    internal_ratio REAL,
    total_shares   REAL,                -- 总份额（亿份）
    avail_date     TEXT,                -- PIT 可用日
    updated_at     TEXT NOT NULL,
    PRIMARY KEY (fund_code, report_date)
);

-- ═══════════════════ 7. 持仓明细（D5，季报） ═══════════════════
CREATE TABLE IF NOT EXISTS fund_holdings (
    fund_code   TEXT NOT NULL REFERENCES fund(fund_code),
    report_date TEXT NOT NULL,
    stock_code  TEXT,
    stock_name  TEXT,
    weight      REAL,                   -- 占净值比例（小数）
    shares      REAL,                   -- 持股数（万股）
    market_val  REAL,                   -- 持仓市值（万元）
    report_kind TEXT,                   -- Q/H/Y
    avail_date  TEXT,                   -- PIT 可用日 = 报告期末 + Δ
    updated_at TEXT NOT NULL,
    PRIMARY KEY (fund_code, report_date, stock_code)
);
CREATE INDEX IF NOT EXISTS idx_hold_avail ON fund_holdings(fund_code, avail_date);

-- ═══════════════════ 8. 行业配置（D5） ═══════════════════
CREATE TABLE IF NOT EXISTS fund_industry (
    fund_code   TEXT NOT NULL REFERENCES fund(fund_code),
    report_date TEXT NOT NULL,
    industry    TEXT NOT NULL,
    weight      REAL,                   -- 占净值比例（小数）
    avail_date  TEXT,
    updated_at  TEXT NOT NULL,
    PRIMARY KEY (fund_code, report_date, industry)
);

-- ═══════════════════ 9. 申赎状态每日快照（H4） ═══════════════════
-- 东财只有当日状态 → 自己每天落一份攒历史。绝不回填（前视偏差）。
CREATE TABLE IF NOT EXISTS subscribe_status_daily (
    fund_code      TEXT NOT NULL REFERENCES fund(fund_code),
    stat_date      TEXT NOT NULL,       -- 快照日（取数日）
    subscribe_stat TEXT,
    redeem_stat    TEXT,
    next_open_date TEXT,                -- 非 NULL ⇒ 定开/持有期产品
    daily_limit    REAL,                -- 日累计限定金额（元）
    buy_rate_disc  REAL,                -- 折后申购费率 %
    nav_latest     REAL,                -- 当日最新净值（新鲜度校验用）
    updated_at     TEXT NOT NULL,
    PRIMARY KEY (fund_code, stat_date)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS idx_sub_date ON subscribe_status_daily(stat_date);

-- ═══════════════════ 10. 数据任务执行日志 ═══════════════════
-- 调度模块的运行台账：哪个任务、何时、动了几行、成败。
CREATE TABLE IF NOT EXISTS sync_task_log (
    task_name   TEXT NOT NULL,          -- market_db_maintain / nav_warmup / …
    started_at  TEXT NOT NULL,
    finished_at TEXT,
    status      TEXT,                   -- running / ok / fail
    n_rows      INTEGER,                -- 本次写入行数（多表合计）
    message     TEXT,
    PRIMARY KEY (task_name, started_at)
);

-- ═══════════════════ 元信息 ═══════════════════
CREATE TABLE IF NOT EXISTS market_meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);
"""


def _c6(code: str) -> str:
    """统一为 6 位数字代码（剥 .OF、左补零）。非数字原样返回。"""
    s = str(code or "").strip().upper()
    if "." in s:
        s = s.split(".")[0]
    return s.zfill(6) if s.isdigit() else s


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


_SHARE_TAIL = ("A", "B", "C", "E", "D")
_NAME_TAILS = ("人民币", "RMB", "类", "份额")


def _share_class_of(name: str) -> Optional[str]:
    s = str(name or "").strip()
    while s and s.endswith(_NAME_TAILS):
        s = s[: -len([t for t in _NAME_TAILS if s.endswith(t)][0])].strip()
    if s and s[-1].upper() in _SHARE_TAIL and not (
            len(s) > 1 and s[-2].isascii() and s[-2].isalpha()):
        return s[-1].upper()
    return None


def _family_key(name: str) -> Optional[str]:
    """名称剥尾部份额标识后的族键（A/C 优选、同基金族归并用）。"""
    s = str(name or "").strip()
    changed = True
    while changed and s:
        changed = False
        for tail in _NAME_TAILS:
            if s.endswith(tail) and len(s) > len(tail):
                s = s[: -len(tail)].strip()
                changed = True
        if s and s[-1].upper() in _SHARE_TAIL and len(s) > 1:
            if not (s[-2].isascii() and s[-2].isalpha()):
                s = s[:-1].strip()
                changed = True
    return s or None


class MarketDB:
    """统一数据仓。纯本地 SQLite + 可注入数据（网络只发生在导入器里）。"""

    STALE_DAYS = 45   # nav 停更超这么多天且无清盘日 → status='stale'

    def __init__(self, db_path: str = DEFAULT_MARKET_DB, create: bool = True):
        self.db_path = db_path
        if create:
            os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")
        if create:
            self.conn.executescript(SCHEMA)
            self.conn.commit()

    # ------------------------------------------------------------------
    # 基础
    # ------------------------------------------------------------------
    def close(self):
        try:
            self.conn.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def _ensure_fund_row(self, code: str, name=None, fund_type=None):
        """给子表数据兜底建主档行（FK 约束要求先有 fund 行）。"""
        c = _c6(code)
        if not c:
            return
        with self._lock:
            self.conn.execute(
                "INSERT OR IGNORE INTO fund (fund_code, fund_name, fund_type, updated_at) "
                "VALUES (?,?,?,?)", (c, name, fund_type, _now()))
            # stub 行已存在则不覆盖富信息
            if name or fund_type:
                self.conn.execute(
                    "UPDATE fund SET fund_name=COALESCE(NULLIF(fund_name,''),?), "
                    "fund_type=COALESCE(NULLIF(fund_type,''),?) WHERE fund_code=?",
                    (name, fund_type, c))

    def _ensure_fund_row_bulk(self, codes: Iterable[str]):
        """批量兜底建主档 stub 行（迁移导入用，一次 executemany）。"""
        cs = {_c6(c) for c in codes if _c6(c)}
        if not cs:
            return
        with self._lock:
            self.conn.executemany(
                "INSERT OR IGNORE INTO fund (fund_code, updated_at) VALUES (?,?)",
                [(c, _now()) for c in cs])
            self.conn.commit()

    # ------------------------------------------------------------------
    # 写入（幂等 upsert）
    # ------------------------------------------------------------------
    def upsert_funds(self, rows: Iterable[Dict]) -> int:
        """批量 upsert 主档。字段缺省保留原值（COALESCE 语义）。"""
        data = []
        for r in rows:
            c = _c6(r.get("fund_code") or r.get("code") or "")
            if not c:
                continue
            name = r.get("fund_name") or r.get("name")
            data.append((
                c, name, r.get("fund_type"), _share_class_of(name),
                _family_key(name), r.get("company"), r.get("manager"),
                r.get("benchmark"), r.get("tracking_target"),
                r.get("setup_date"), r.get("liquidation_date"), r.get("end_date"),
                r.get("scale_yi"), _now(),
            ))
        if not data:
            return 0
        sql = ("INSERT INTO fund (fund_code, fund_name, fund_type, share_class, "
               "family_key, company, manager, benchmark, tracking_target, "
               "setup_date, liquidation_date, end_date, scale_yi, updated_at) "
               "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
               "ON CONFLICT(fund_code) DO UPDATE SET "
               "fund_name=COALESCE(excluded.fund_name, fund.fund_name), "
               "fund_type=COALESCE(excluded.fund_type, fund.fund_type), "
               "share_class=COALESCE(excluded.share_class, fund.share_class), "
               "family_key=COALESCE(excluded.family_key, fund.family_key), "
               "company=COALESCE(excluded.company, fund.company), "
               "manager=COALESCE(excluded.manager, fund.manager), "
               "benchmark=COALESCE(excluded.benchmark, fund.benchmark), "
               "tracking_target=COALESCE(excluded.tracking_target, fund.tracking_target), "
               "setup_date=COALESCE(excluded.setup_date, fund.setup_date), "
               "liquidation_date=COALESCE(excluded.liquidation_date, fund.liquidation_date), "
               "end_date=COALESCE(excluded.end_date, fund.end_date), "
               "scale_yi=COALESCE(excluded.scale_yi, fund.scale_yi), "
               "updated_at=excluded.updated_at")
        with self._lock:
            self.conn.executemany(sql, data)
            self.conn.commit()
        return len(data)

    def upsert_nav(self, code: str, rows: Iterable[Dict],
                   nav_type: str = "standard", source: str = None) -> int:
        """写入单只基金的净值序列（幂等，按 code+date 覆盖）。"""
        c = _c6(code)
        if not c:
            return 0
        self._ensure_fund_row(c)
        data = []
        for r in rows:
            ds = str(r.get("nav_date") or r.get("date") or "")[:10]
            if len(ds) != 10:
                continue
            def _f(k):
                try:
                    v = r.get(k)
                    return None if v is None else float(v)
                except (TypeError, ValueError):
                    return None
            unit, acc, adj = _f("unit_nav"), _f("acc_nav"), _f("adj_nav")
            if unit is None and acc is None and adj is None:
                continue
            data.append((c, ds, unit, acc, adj, _f("daily_return"),
                         _f("shares"), nav_type, source or r.get("source") or "unknown",
                         _now()))
        if not data:
            return 0
        sql = ("INSERT INTO fund_nav (fund_code, nav_date, unit_nav, acc_nav, adj_nav, "
               "daily_return, shares, nav_type, source, updated_at) "
               "VALUES (?,?,?,?,?,?,?,?,?,?) "
               "ON CONFLICT(fund_code, nav_date) DO UPDATE SET "
               "unit_nav=excluded.unit_nav, acc_nav=excluded.acc_nav, "
               "adj_nav=excluded.adj_nav, daily_return=excluded.daily_return, "
               "shares=excluded.shares, nav_type=excluded.nav_type, "
               "source=excluded.source, updated_at=excluded.updated_at")
        with self._lock:
            self.conn.executemany(sql, data)
            self.conn.commit()
        return len(data)

    def upsert_fee(self, code: str, fee: Dict, source: str = None) -> None:
        c = _c6(code)
        if not c or not fee:
            return
        self._ensure_fund_row(c)

        def _f(k):
            try:
                v = fee.get(k)
                return None if v is None else float(v)
            except (TypeError, ValueError):
                return None
        with self._lock:
            self.conn.execute(
                "INSERT INTO fund_fee (fund_code, buy_rate_raw, buy_rate_disc, "
                "mgmt_rate, custody_rate, sales_service, subscribe_stat, redeem_stat, "
                "fee_note, source, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(fund_code) DO UPDATE SET "
                "buy_rate_raw=excluded.buy_rate_raw, buy_rate_disc=excluded.buy_rate_disc, "
                "mgmt_rate=excluded.mgmt_rate, custody_rate=excluded.custody_rate, "
                "sales_service=excluded.sales_service, "
                "subscribe_stat=excluded.subscribe_stat, redeem_stat=excluded.redeem_stat, "
                "fee_note=excluded.fee_note, source=excluded.source, "
                "updated_at=excluded.updated_at",
                (c, _f("buy_rate_raw"), _f("buy_rate_disc"), _f("mgmt_rate"),
                 _f("custody_rate"), _f("sales_service"),
                 fee.get("subscribe_stat"), fee.get("redeem_stat"),
                 fee.get("fee_note"), source or fee.get("source"), _now()))
            self.conn.commit()

    def upsert_redeem_tiers(self, code: str,
                            tiers: Sequence[Dict]) -> int:
        """tiers: [{min_days, max_days, fee_rate}]，按 min_days 覆盖。"""
        c = _c6(code)
        if not c or not tiers:
            return 0
        self._ensure_fund_row(c)
        data = [(c, int(t["min_days"]),
                 None if t.get("max_days") is None else int(t["max_days"]),
                 float(t["fee_rate"]), _now()) for t in tiers]
        with self._lock:
            self.conn.executemany(
                "INSERT INTO fund_redeem_tier (fund_code, min_days, max_days, fee_rate, "
                "updated_at) VALUES (?,?,?,?,?) "
                "ON CONFLICT(fund_code, min_days) DO UPDATE SET "
                "max_days=excluded.max_days, fee_rate=excluded.fee_rate, "
                "updated_at=excluded.updated_at", data)
            self.conn.commit()
        return len(data)

    def upsert_subscribe_snapshot(self, df: pd.DataFrame) -> int:
        """落一张全市场申赎快照（幂等，按 code+date 覆盖）。"""
        if df is None or df.empty:
            return 0
        data = []
        for _, r in df.iterrows():
            c = _c6(r.get("fund_code"))
            if not c or not r.get("stat_date"):
                continue
            self._ensure_fund_row(c, r.get("fund_name"))
            try:
                lim = None if r.get("daily_limit") is None else float(r["daily_limit"])
                br = None if r.get("buy_rate_disc") is None else float(r["buy_rate_disc"])
                nl = None if r.get("nav_latest") is None else float(r["nav_latest"])
            except (TypeError, ValueError):
                lim = br = nl = None
            data.append((c, str(r["stat_date"])[:10],
                         r.get("subscribe_stat"), r.get("redeem_stat"),
                         r.get("next_open_date"), lim, br, nl, _now()))
        if not data:
            return 0
        with self._lock:
            for row in data:      # 先确保 fund 行（executemany 无法逐行建 stub）
                self._ensure_fund_row(row[0])
            self.conn.executemany(
                "INSERT INTO subscribe_status_daily (fund_code, stat_date, subscribe_stat, "
                "redeem_stat, next_open_date, daily_limit, buy_rate_disc, nav_latest, "
                "updated_at) VALUES (?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(fund_code, stat_date) DO UPDATE SET "
                "subscribe_stat=excluded.subscribe_stat, redeem_stat=excluded.redeem_stat, "
                "next_open_date=excluded.next_open_date, daily_limit=excluded.daily_limit, "
                "buy_rate_disc=excluded.buy_rate_disc, nav_latest=excluded.nav_latest, "
                "updated_at=excluded.updated_at", data)
            self.conn.commit()
        return len(data)

    # ------------------------------------------------------------------
    # 统计刷新与状态推导
    # ------------------------------------------------------------------
    def refresh_stats(self) -> Dict[str, int]:
        """重算 fund 表的冗余统计列与 status。

        status 推导（优先级从高到低）：
          liquidated : liquidation_date 非空
          stale      : 有净值但 last_nav_date 距今 > STALE_DAYS 且未标清盘
                       （停更/疑似下架 —— 回测端按清盘强赎兜底处理）
          active     : 有净值且新鲜，或无净值但主档无清盘标记
          unknown    : 兜底
        """
        with self._lock:
            self.conn.execute(
                "UPDATE fund SET "
                "nav_rows=COALESCE((SELECT COUNT(*) FROM fund_nav n "
                "                   WHERE n.fund_code=fund.fund_code),0), "
                "first_nav_date=(SELECT MIN(n.nav_date) FROM fund_nav n "
                "                WHERE n.fund_code=fund.fund_code), "
                "last_nav_date=(SELECT MAX(n.nav_date) FROM fund_nav n "
                "               WHERE n.fund_code=fund.fund_code)")
            today = datetime.now().strftime("%Y-%m-%d")
            cutoff = pd.Timestamp(today) - pd.Timedelta(days=self.STALE_DAYS)
            self.conn.execute(
                "UPDATE fund SET status='liquidated' WHERE liquidation_date IS NOT NULL")
            self.conn.execute(
                "UPDATE fund SET status='stale' WHERE liquidation_date IS NULL "
                "AND last_nav_date IS NOT NULL AND last_nav_date < ?",
                (cutoff.strftime("%Y-%m-%d"),))
            self.conn.execute(
                "UPDATE fund SET status='active' WHERE status='unknown' "
                "AND liquidation_date IS NULL")
            self.conn.execute(
                "UPDATE fund SET scale_yi=("
                "  SELECT s.scale_yi FROM fund_scale s WHERE s.fund_code=fund.fund_code "
                "  ORDER BY s.report_date DESC LIMIT 1) "
                "WHERE scale_yi IS NULL OR scale_yi=0")
            self.conn.commit()
            counts = {r["status"]: r["n"] for r in self.conn.execute(
                "SELECT status, COUNT(*) AS n FROM fund GROUP BY status").fetchall()}
            counts["total"] = int(self.conn.execute(
                "SELECT COUNT(*) FROM fund").fetchone()[0])
            return counts

    # ------------------------------------------------------------------
    # 查询 API（读端；代码参数同时接受 XXXXXX / XXXXXX.OF）
    # ------------------------------------------------------------------
    def fund_of(self, code: str) -> Optional[Dict]:
        r = self.conn.execute("SELECT * FROM fund WHERE fund_code=?",
                              (_c6(code),)).fetchone()
        return dict(r) if r else None

    def nav_series(self, code: str, start: Optional[str] = None,
                   end: Optional[str] = None,
                   col: str = "adj_nav") -> pd.Series:
        """净值序列 → pd.Series（date index）。col ∈ adj_nav/unit_nav/acc_nav。"""
        q = f"SELECT nav_date, {col} FROM fund_nav WHERE fund_code=?"
        args: List = [_c6(code)]
        if start:
            q += " AND nav_date>=?"
            args.append(str(start)[:10])
        if end:
            q += " AND nav_date<=?"
            args.append(str(end)[:10])
        q += " ORDER BY nav_date"
        df = pd.DataFrame(self.conn.execute(q, args).fetchall(),
                          columns=["nav_date", col])
        if df.empty:
            return pd.Series(dtype=float)
        s = pd.Series(pd.to_numeric(df[col], errors="coerce").values,
                      index=pd.to_datetime(df["nav_date"]))
        return s.dropna()

    def nav_panel(self, codes: Sequence[str], start: Optional[str] = None,
                  end: Optional[str] = None,
                  col: str = "adj_nav") -> pd.DataFrame:
        """多只基金的净值面板（行=日期、列=代码，XXX.OF 命名对齐旧接口）。"""
        frames = {}
        for c in codes:
            s = self.nav_series(c, start, end, col=col)
            if len(s):
                frames[f"{_c6(c)}.OF"] = s
        if not frames:
            return pd.DataFrame()
        return pd.DataFrame(frames).sort_index()

    def nav_coverage(self, min_rows: int = 0) -> pd.DataFrame:
        """有净值覆盖的基金清单（主档统计列直查，不扫 fund_nav）。"""
        rows = self.conn.execute(
            "SELECT fund_code, fund_name, fund_type, status, nav_rows, "
            "first_nav_date, last_nav_date FROM fund WHERE nav_rows>=? "
            "ORDER BY nav_rows DESC", (int(min_rows),)).fetchall()
        return pd.DataFrame([dict(r) for r in rows])

    def backtest_universe(self, asof: Optional[str] = None,
                          min_rows: int = 760,
                          exclude_types: Sequence[str] = ("货币",),
                          include_stale: bool = False) -> List[str]:
        """回测标的池的**权威来源**（设计文档 §3.1）。

        PIT 三重过滤：
          1. setup_date <= asof（成立足够早）
          2. liquidation_date IS NULL 或 >= asof（清盘基金在清盘前可用，
             引擎的清盘强赎会按最后净值清算 —— 幸存者偏差治理的入口）
          3. 本地净值覆盖 nav_rows >= min_rows 且 first_nav_date 足够早
        返回 XXXXXX.OF 形式（与现有策略池口径一致）。
        """
        a = str(asof or datetime.now().strftime("%Y-%m-%d"))[:10]
        q = ("SELECT fund_code FROM fund WHERE nav_rows>=? "
             "AND (setup_date IS NULL OR setup_date<=?) "
             "AND (liquidation_date IS NULL OR liquidation_date>=?)")
        args: List = [int(min_rows), a, a]
        if not include_stale:
            q += " AND status!='stale'"
        rows = self.conn.execute(q, args).fetchall()
        codes = [r["fund_code"] for r in rows]
        if exclude_types:
            # 类型过滤走主档（一次查询拿类型，避免 SQL 里写一长串 NOT LIKE）
            types = {r["fund_code"]: (r["fund_type"] or "")
                     for r in self.conn.execute(
                         "SELECT fund_code, fund_type FROM fund").fetchall()}
            codes = [c for c in codes
                     if not any(k in types.get(c, "") for k in exclude_types)]
        return [f"{c}.OF" for c in sorted(codes)]

    def cash_vehicle_candidates(self, min_rows: int = 250) -> Dict[str, Dict]:
        """现金载体候选（货币基金）：{6位代码: {rows, name, scale, liquidation_date}}。

        主池（backtest_universe）刻意剔除货币型——它不是风险资产、没有风险因子
        可言。但闲置现金需要一个真实载体，所以这里单独给一份名单：
        未清盘、非后端份额、本地净值覆盖 >= min_rows，按规模降序。

        min_rows=0 时不设覆盖门槛（用于"先看看有哪些货基"的诊断场景）。
        """
        rows = self.conn.execute(
            "SELECT f.fund_code, f.fund_name, f.nav_rows, f.liquidation_date, "
            "       (SELECT s.scale_yi FROM fund_scale s WHERE s.fund_code=f.fund_code "
            "        AND s.scale_yi IS NOT NULL ORDER BY s.report_date DESC LIMIT 1) AS sc "
            "FROM fund f WHERE f.fund_type LIKE '%货币%' AND f.nav_rows>=? "
            "AND (f.fund_name IS NULL OR f.fund_name NOT LIKE '%后端%') "
            "AND f.liquidation_date IS NULL "
            "ORDER BY (sc IS NULL), sc DESC, f.fund_code",
            (int(min_rows),)).fetchall()
        out: Dict[str, Dict] = {}
        for r in rows:
            out[str(r["fund_code"]).zfill(6)] = {
                "rows": int(r["nav_rows"] or 0),
                "name": r["fund_name"],
                "scale": float(r["sc"]) if r["sc"] is not None else 0.0,
                "liquidation_date": r["liquidation_date"],
            }
        return out

    def best_cash_vehicle(self, lookback_days: int = 365,
                          vol_penalty: float = 3.0) -> Optional[Dict]:
        """现金载体择优：收益最高、且最稳的那**一只**货币基金。

        判据（都在真实净值上算，不用宣传口径的 7 日年化）：
          * 窗口：近 lookback_days 自然日（默认 1 年）——货基早年收益高（余额宝
            曾 4~6%），用全历史会选出"过去好"而非"现在好"的标的。
          * ann_return：窗口内复利年化
          * ann_vol：日收益标准差 × √252（货基理论上恒正、波动≈0）
          * 硬门槛：窗口内出现**亏损日**直接淘汰（货基不该有，出现说明
            数据折算有问题或该产品不是纯货基）
          * 排序：ann_return − vol_penalty × ann_vol 降序（λ=3：货基波动本应
            极小，给足权重，"稳"才不会被"高一点点收益"盖过去）

        返回 {"fund_code","fund_name","ann_return","ann_vol","days","score"}，
        无合格候选返回 None（调用方自行回退）。
        """
        cands = self.cash_vehicle_candidates(min_rows=60)
        if not cands:
            return None
        from datetime import timedelta
        since = (datetime.now() - timedelta(days=int(lookback_days))).strftime("%Y-%m-%d")
        best = None
        for code, info in cands.items():
            rows = self.conn.execute(
                "SELECT nav_date, adj_nav FROM fund_nav WHERE fund_code=? "
                "AND nav_date>=? AND adj_nav IS NOT NULL ORDER BY nav_date",
                (code, since)).fetchall()
            if len(rows) < 60:
                continue
            vals = [float(r["adj_nav"]) for r in rows if float(r["adj_nav"]) > 0]
            if len(vals) < 60:
                continue
            rets = [vals[i] / vals[i - 1] - 1.0 for i in range(1, len(vals))]
            if min(rets) < -1e-6:      # 出现亏损日 → 不是干净的货基，淘汰
                continue
            n = len(rets)
            ann_ret = (vals[-1] / vals[0]) ** (252.0 / n) - 1.0
            mean = sum(rets) / n
            var = sum((x - mean) ** 2 for x in rets) / max(1, n - 1)
            ann_vol = (var ** 0.5) * (252 ** 0.5)
            score = ann_ret - vol_penalty * ann_vol
            rec = {"fund_code": code, "fund_name": info.get("name"),
                   "ann_return": ann_ret, "ann_vol": ann_vol, "days": n,
                   "score": score}
            if best is None or score > best["score"]:
                best = rec
        return best

    def all_codes(self, include_liquidated: bool = True) -> List[str]:
        """全市场 6 位代码（默认含已清盘）——净值预热/名录登记的权威名单。

        含清盘是刻意的：清盘基金的**历史净值**同样要预热，否则历史回测
        的标的池会被"现在还活着"这个后视条件污染。
        """
        q = "SELECT fund_code FROM fund"
        if not include_liquidated:
            q += " WHERE liquidation_date IS NULL"
        q += " ORDER BY fund_code"
        return [r["fund_code"] for r in self.conn.execute(q).fetchall()]

    def scale_asof(self, code: str, asof) -> Optional[float]:
        """PIT 规模（亿）：取 report_date <= asof 的最近一期。"""
        a = str(asof)[:10]
        r = self.conn.execute(
            "SELECT scale_yi FROM fund_scale WHERE fund_code=? AND report_date<=? "
            "AND scale_yi IS NOT NULL ORDER BY report_date DESC LIMIT 1",
            (_c6(code), a)).fetchone()
        return float(r["scale_yi"]) if r and r["scale_yi"] is not None else None

    def fee_of(self, code: str) -> Dict:
        r = self.conn.execute("SELECT * FROM fund_fee WHERE fund_code=?",
                              (_c6(code),)).fetchone()
        return dict(r) if r else {}

    def redeem_tiers_of(self, code: str) -> List[Dict]:
        rows = self.conn.execute(
            "SELECT min_days, max_days, fee_rate FROM fund_redeem_tier "
            "WHERE fund_code=? ORDER BY min_days", (_c6(code),)).fetchall()
        return [dict(r) for r in rows]

    def manager_tenure_days(self, code: str, asof) -> Optional[int]:
        """H2：现任经理团队的可考察任期（自然日）。PIT 逻辑与旧
        fund_reports.manager_tenure_days 一致：
          1. 取 end_date IS NULL 的经理名集合（start<=asof 的段）
          2. 回看这些名字最早出现的起始日
          3. 该起始日之后的第一条人事公告日 <= asof 才算"可知"
        """
        a = str(asof)[:10]
        c = _c6(code)
        cur = self.conn.execute(
            "SELECT manager_name, start_date FROM fund_manager "
            "WHERE fund_code=? AND start_date<=? "
            "AND (end_date IS NULL OR end_date='' OR end_date>=?)", (c, a, a)
        ).fetchall()
        if not cur:
            return None
        names = {r["manager_name"].strip() for r in cur if r["manager_name"]}
        if not names:
            return None
        all_rows = self.conn.execute(
            "SELECT manager_name, start_date FROM fund_manager "
            "WHERE fund_code=? AND start_date<=? ORDER BY start_date", (c, a)).fetchall()
        earliest = None
        for r in all_rows:
            if r["manager_name"] and r["manager_name"].strip() in names:
                if earliest is None or r["start_date"] < earliest:
                    earliest = r["start_date"]
        if earliest is None:
            return None
        # PIT：起始日之后第一条人事公告 <= asof 才可知；无公告数据保守 +1 天
        anns = [r[0] for r in self.conn.execute(
            "SELECT ann_date FROM fund_manager_announce WHERE fund_code=? "
            "ORDER BY ann_date", (c,)).fetchall()]
        if anns:
            after = [d for d in anns if d >= earliest]
            avail = after[0] if after else None
        else:
            avail = None
        if avail is not None and avail > a:
            return None
        try:
            return int((pd.Timestamp(a) - pd.Timestamp(earliest)).days)
        except Exception:
            return None

    def inst_ratio_asof(self, code: str, asof) -> Optional[float]:
        a = str(asof)[:10]
        r = self.conn.execute(
            "SELECT inst_ratio FROM fund_holder WHERE fund_code=? "
            "AND avail_date IS NOT NULL AND avail_date<=? "
            "ORDER BY report_date DESC LIMIT 1", (_c6(code), a)).fetchone()
        return float(r["inst_ratio"]) if r and r["inst_ratio"] is not None else None

    def subscribe_status_asof(self, code: str, asof,
                              max_lag_days: int = 10) -> Optional[Dict]:
        """H4：<= asof 的最近一条快照，新鲜度门槛 10 天（不拿旧状态冒充）。"""
        a = str(asof)[:10]
        r = self.conn.execute(
            "SELECT subscribe_stat, redeem_stat, next_open_date, daily_limit, stat_date "
            "FROM subscribe_status_daily WHERE fund_code=? AND stat_date<=? "
            "ORDER BY stat_date DESC LIMIT 1", (_c6(code), a)).fetchone()
        if r is None:
            return None
        if (pd.Timestamp(a) - pd.Timestamp(r["stat_date"])).days > int(max_lag_days):
            return None
        return dict(r)

    def holdings_asof(self, code: str, asof) -> pd.DataFrame:
        a = str(asof)[:10]
        rows = self.conn.execute(
            "SELECT * FROM fund_holdings WHERE fund_code=? AND avail_date<=? "
            "ORDER BY report_date DESC", (_c6(code), a)).fetchall()
        if not rows:
            return pd.DataFrame()
        latest = rows[0]["report_date"]
        return pd.DataFrame([dict(r) for r in rows if r["report_date"] == latest])

    # ------------------------------------------------------------------
    # 任务日志
    # ------------------------------------------------------------------
    def log_task_start(self, task_name: str) -> str:
        ts = _now()
        with self._lock:
            self.conn.execute(
                "INSERT OR REPLACE INTO sync_task_log "
                "(task_name, started_at, status) VALUES (?,?, 'running')",
                (task_name, ts))
            self.conn.commit()
        return ts

    def log_task_finish(self, task_name: str, started_at: str,
                        status: str = "ok", n_rows: int = 0,
                        message: str = "") -> None:
        with self._lock:
            self.conn.execute(
                "UPDATE sync_task_log SET finished_at=?, status=?, n_rows=?, message=? "
                "WHERE task_name=? AND started_at=?",
                (_now(), status, int(n_rows), message[:500], task_name, started_at))
            self.conn.commit()

    def stats(self) -> Dict[str, int]:
        def one(sql):
            try:
                return int(self.conn.execute(sql).fetchone()[0])
            except Exception:
                return 0
        return {
            "funds": one("SELECT COUNT(*) FROM fund"),
            "funds_with_nav": one("SELECT COUNT(*) FROM fund WHERE nav_rows>0"),
            "nav_rows": one("SELECT COUNT(*) FROM fund_nav"),
            "funds_with_fee": one("SELECT COUNT(*) FROM fund_fee"),
            "redeem_tier_rows": one("SELECT COUNT(*) FROM fund_redeem_tier"),
            "scale_rows": one("SELECT COUNT(*) FROM fund_scale"),
            "manager_rows": one("SELECT COUNT(*) FROM fund_manager"),
            "announce_rows": one("SELECT COUNT(*) FROM fund_manager_announce"),
            "holder_rows": one("SELECT COUNT(*) FROM fund_holder"),
            "holding_rows": one("SELECT COUNT(*) FROM fund_holdings"),
            "industry_rows": one("SELECT COUNT(*) FROM fund_industry"),
            "snapshot_rows": one("SELECT COUNT(*) FROM subscribe_status_daily"),
            "task_log_rows": one("SELECT COUNT(*) FROM sync_task_log"),
        }


# ----------------------------------------------------------------------
# 导入器：全市场名录（含清盘）—— fund 表的权威填充源
# ----------------------------------------------------------------------
def fetch_full_market_list() -> List[Dict]:
    """全市场基金名录（ak.fund_name_em()，1 个请求 ≈ 27,878 只）。

    天天基金的搜索名录**包含已下柜/清盘基金**（页面保留），配合
    master 的清盘日富化后即可做幸存者偏差治理（见 backtest_universe）。
    失败返回 []（调用方保持库内已有数据不动）。
    """
    # 与 providers/public.list_all_funds、fund_master.fetch_fund_list 共用同一份
    # 进程内缓存（一次请求 ≈2.7 万行，改造前一晚/一次调度里会被抓三遍）。
    # 这里仍保持"失败返回 []"的原语义（调用方据此保持库内数据不动）。
    try:
        df = net.cached_call(
            "ak.fund_name_em()",
            lambda: net.ak_call("fund_name_em"),
        )
    except Exception as e:
        logger.warning(f"全市场名录抓取失败（保持库内已有数据）: {net.short_err(e)}")
        return []
    if df is None or df.empty:
        return []
    out = []
    for _, r in df.iterrows():
        code = str(r.get("基金代码") or "").strip()
        if not code or not code.isdigit():
            continue
        out.append({
            "fund_code": code.zfill(6),
            "fund_name": str(r.get("基金简称") or "").strip() or None,
            "fund_type": str(r.get("基金类型") or "").strip() or None,
        })
    return out


def default_market_db(create: bool = False) -> Optional[MarketDB]:
    try:
        if not create and not os.path.exists(DEFAULT_MARKET_DB):
            return None
        return MarketDB(DEFAULT_MARKET_DB, create=create)
    except Exception:
        return None
