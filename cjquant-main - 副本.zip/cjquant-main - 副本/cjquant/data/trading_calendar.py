# -*- coding: utf-8 -*-
"""权威交易日历（P0-3 修复）。

🔴 问题（2026-09-26 评审）：回测的交易日历此前是**所有基金净值日期的并集**
    （`OTCBacktestEngine.__init__`: `all_dates = market_data.index.unique()`）。
    但货币基金按日计收益、**周末和节假日也出净值**（实测 market.db 里 2025 年以来
    91 个周日 + 91 个周六来自 62 只货基），这些非交易日被并进了 `trading_dates`。
    实测 2025-01-01~2026-09-24 的 511 个 bar 里有 **82 个周日、0 个周六**
    （形态提示某条加载路径存在 ±1 日偏移），真实交易日约 421~429 个。

    后果（每一条都在实际生效）：
      1. 年化因子用 `252/511` → 年化被系统性低估约 0.8pp；
      2. 伪 bar 稀释日波动约 9% → Sharpe 被高估约 9%；
      3. `T+1 确认 / T+3 到账` 是按 `trading_dates` 下标 `+n` 推算的，
         伪 bar 让实际结算天数变短 → 现金周转速度被高估；
      4. 部分基金日期偏移 1 日，统一 ffill 后产生人工的跨基金领先/滞后，
         动量类因子（D3）可能吃到"伪未来信息"。

解法：**交易日历必须是显式权威日历**，不能用净值并集推导。

优先级：
  1. 本地指数缓存 `.cache/cjquant/funnel/idx_sh000300.csv`（沪深300 日线 = A 股交易日历）
  2. market.db 的 `trading_calendar` 表（若已建）
  3. 兜底：周一~周五（会漏掉法定节假日，但至少不含周末）

并集规则：权威日历 ∪ "工作日且当日 ≥50% 的标的都有净值"的日期（防止权威日历
缺失导致真实交易日被误删）；**任何周末日期一律剔除**。
"""
from __future__ import annotations

import os
from typing import Iterable, Optional

import pandas as pd

# 沪深300 日线 = A 股/场外公募的通用交易日历
_INDEX_CACHE = ("funnel", "idx_sh000300.csv", "sh000300")


def _project_root() -> str:
    d = os.path.dirname(os.path.abspath(__file__))
    while True:
        if os.path.exists(os.path.join(d, "run_gui.py")) or \
           os.path.exists(os.path.join(d, "pyproject.toml")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        d = parent


def _from_index_cache(root: str) -> Optional[pd.DatetimeIndex]:
    p = os.path.join(root, ".cache", "cjquant", _INDEX_CACHE[0], _INDEX_CACHE[1])
    if not os.path.exists(p):
        return None
    try:
        df = pd.read_csv(p, encoding="utf-8-sig")
        col = "date" if "date" in df.columns else df.columns[0]
        idx = pd.to_datetime(df[col], errors="coerce").dropna()
        # 指数缓存里偶见的非法日期（如 1900-01-01）不该进日历
        idx = idx[idx >= pd.Timestamp("1990-01-01")]
        return pd.DatetimeIndex(sorted(set(idx)))
    except Exception:
        return None


def _from_market_db(root: str) -> Optional[pd.DatetimeIndex]:
    try:
        import sqlite3
        p = os.path.join(root, "cjquant", "data", "store", "market.db")
        if not os.path.exists(p):
            return None
        con = sqlite3.connect(p)
        try:
            rows = con.execute("SELECT day FROM trading_calendar").fetchall()
        except Exception:
            return None
        finally:
            con.close()
        if not rows:
            return None
        return pd.DatetimeIndex(sorted({pd.Timestamp(r[0]) for r in rows}))
    except Exception:
        return None


def trading_days(start=None, end=None, root: Optional[str] = None,
                 extra_dates: Optional[Iterable] = None) -> pd.DatetimeIndex:
    """返回 [start, end] 内的权威交易日（升序、去重、不含周末）。

    extra_dates: 调用方可额外并入的日期（例如"当日 ≥50% 标的都有净值"的日期），
                 内部只保留其中的工作日部分。
    """
    root = root or _project_root()
    idx = _from_index_cache(root)
    if idx is None or len(idx) == 0:
        idx = _from_market_db(root)
    keep: pd.DatetimeIndex
    if idx is not None and len(idx):
        keep = pd.DatetimeIndex(idx)
    else:
        # 兜底：工作日（漏法定节假日，但至少不含周末 —— 比净值并集好得多）
        s = pd.Timestamp(start) if start is not None else pd.Timestamp("1990-12-19")
        e = pd.Timestamp(end) if end is not None else pd.Timestamp.today()
        keep = pd.DatetimeIndex(pd.bdate_range(s, e))

    if extra_dates is not None and len(list(extra_dates)):
        ex = pd.DatetimeIndex(pd.to_datetime(pd.Index(list(extra_dates))).dropna().unique())
        keep = keep.union(ex)

    keep = pd.DatetimeIndex(sorted(set(keep)))
    # 铁律：周末一律剔除（公募/股市都不在周末确认份额）
    keep = keep[keep.weekday < 5]
    if start is not None:
        keep = keep[keep >= pd.Timestamp(start)]
    if end is not None:
        keep = keep[keep <= pd.Timestamp(end)]
    return keep


def filter_panel_dates(dfs, start=None, end=None, min_coverage: float = 0.5,
                       root: Optional[str] = None) -> pd.DatetimeIndex:
    """根据一组基金净值 DataFrame 生成"应当保留"的日期索引。

    dfs: [{date_index -> adj_nav}, ...]（Series 或 DataFrame 均可）。
    规则：权威日历 ∪ （工作日 且 当日有净值的标的占比 ≥ min_coverage）。
    """
    all_dates = None
    counts = {}
    for s in dfs:
        try:
            idx = pd.DatetimeIndex(pd.to_datetime(pd.Index(s.index)).dropna().unique())
        except Exception:
            continue
        counts[idx] = None
        all_dates = idx if all_dates is None else all_dates.union(idx)
    extra = []
    if all_dates is not None and len(all_dates):
        n = max(1, len(dfs))
        ser = pd.Series(0, index=all_dates, dtype=float)
        for s in dfs:
            try:
                idx = pd.DatetimeIndex(pd.to_datetime(pd.Index(s.index)).dropna().unique())
            except Exception:
                continue
            ser.loc[idx] = ser.loc[idx] + 1.0
        cov = ser / float(n)
        cand = cov[cov >= float(min_coverage)].index
        cand = cand[cand.weekday < 5]
        extra = list(cand)
    return trading_days(start=start, end=end, root=root, extra_dates=extra)
