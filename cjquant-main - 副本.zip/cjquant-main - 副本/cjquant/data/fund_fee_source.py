# -*- coding: utf-8 -*-
"""赎回费阶梯抓取（P1-2）：`ak.fund_fee_em(symbol, indicator="赎回费率")`。

为什么必须补这个字段
--------------------
`market.db.fund_redeem_tier` 表建了但**恒为 0 行**，于是回测一直用
`OTCFeeModel` 的全局默认阶梯 `(7,1.5%) / (30,0.75%) / (180,0.5%) / (∞,0)`。
那是《流动性风险管理规定》的**监管上限**，不是各基金的真实费率。实测
000390（华商优势行业混合A）的真实阶梯是：

    小于7天 1.50% | 7~30天 0.75% | 30~365天 0.50% | 365~730天 0.25% | ≥730天 0%

对比可见：180~365 天这段真实仍是 0.5%（**低估**），365 天以后真实 0.25%
而非 0（**高估**）。两个方向的偏差都直接影响"多久调一次仓最优"的结论，
也直接决定 `min_hold_days` 该设多少。

口径纪律
--------
* 返回的 `适用期限` 是**持有自然日**区间，与 `OTCFeeModel.get_sell_fee_rate`
  的 `holding_natural_days` 同口径（不是交易日）。
* 费率是**百分比字符串**（"1.50%"），入库统一转成小数 0.015。
* 天天基金展示的是**该渠道**费率；基金合同可能有别。这里如实记 `channel='em'`。
* 无历史版本：抓的是**当前**费率。历史回测要用它必须自己攒快照
  （见 `field_snapshot` 设计）；在此之前回测只用"当前费率"会带前视偏差，
  因此入库时同步写 `source='fund_fee_em'` 供上层判断是否可用于历史日期。
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional

# "大于等于7天，小于30天" / "小于7天" / "大于等于730天" / "7天以下"
_NUM = r"(\d+(?:\.\d+)?)"


def parse_term(text: str) -> Optional[tuple]:
    """`适用期限` 文本 → (min_days, max_days)；解析不了返回 None。

    实测东财的写法（这些**都出现过**）：
        "小于7天"                → (0, 7)
        "大于等于7天，小于30天"   → (7, 30)
        "大于等于30天，小于365天" → (30, 365)
        "大于等于730天"          → (730, None)
        "7天以下"                → (0, 7)     ← "以下"要和"小于"同样处理
    """
    if text is None:
        return None
    s = str(text).strip()
    nums = re.findall(_NUM, s)
    has_lt = ("小于" in s) or ("<" in s) or ("以下" in s) or ("以内" in s)
    has_ge = ("大于" in s) or (">" in s) or ("以上" in s)
    try:
        if len(nums) >= 2:
            return int(float(nums[0])), int(float(nums[1]))
        if len(nums) == 1:
            v = int(float(nums[0]))
            # 既有下界又有上界时按区间处理；只有"小于" → 从 0 起算
            if has_lt and not has_ge:
                return 0, v
            return v, None
    except (TypeError, ValueError):
        return None
    return None


def parse_rate(text) -> Optional[float]:
    """'1.50%' → 0.015；'0.75%' → 0.0075；'0' → 0.0。

    ⚠️ 不能靠 `v > 1.0` 猜量纲：东财赎回费率一栏里 0.75% 会写成 "0.75%"，
       去掉百分号后是 0.75，按 ">1 才除 100" 的规则会被当成 75% ——
       实测把 0.75% 读成了 0.75（75 倍误差），足以让"持有期优化"结论完全反向。
       正确判据：**原始文本里有没有百分号**。
    """
    if text is None:
        return None
    raw = str(text).strip()
    if raw in ("", "-", "—", "nan", "None"):
        return None
    is_pct = ("%" in raw) or ("％" in raw)
    s = raw.replace("%", "").replace("％", "").strip()
    try:
        v = float(s)
    except (TypeError, ValueError):
        return None
    return v / 100.0 if is_pct else v


def parse_redeem_table(df) -> List[Dict]:
    """`fund_fee_em(indicator='赎回费率')` 的返回 → [{min_days,max_days,fee_rate}]。"""
    out: List[Dict] = []
    if df is None or getattr(df, "empty", True):
        return out
    cols = {str(c).strip(): c for c in df.columns}
    col_term = next((cols[k] for k in cols if "期限" in k or "持有" in k), None)
    col_rate = next((cols[k] for k in cols if "费率" in k), None)
    if col_term is None or col_rate is None:
        return out
    for _, r in df.iterrows():
        term = parse_term(r.get(col_term))
        rate = parse_rate(r.get(col_rate))
        if term is None or rate is None:
            continue
        lo, hi = term
        out.append({"min_days": int(lo), "max_days": None if hi is None else int(hi),
                    "fee_rate": float(rate)})
    # 按 min_days 去重（同起点保留费率较高者，保守口径）
    dedup: Dict[int, Dict] = {}
    for t in out:
        k = int(t["min_days"])
        if k not in dedup or t["fee_rate"] > dedup[k]["fee_rate"]:
            dedup[k] = t
    return [dedup[k] for k in sorted(dedup)]


def fetch_redeem_tiers(code: str, max_retries: int = 2) -> List[Dict]:
    """抓一只基金的赎回费阶梯。失败抛异常（由调用方决定重试/降级）。"""
    from cjquant.data import net
    c = str(code).split(".")[0].zfill(6)
    df = net.ak_call("fund_fee_em", symbol=c, indicator="赎回费率",
                     max_retries=max_retries, sleep=True)
    return parse_redeem_table(df)


def fetch_buy_rate(code: str, max_retries: int = 2) -> Optional[float]:
    """折后申购费率（天天基金渠道）。失败返回 None。"""
    from cjquant.data import net
    c = str(code).split(".")[0].zfill(6)
    try:
        df = net.ak_call("fund_fee_em", symbol=c, indicator="申购费率（前端）",
                         max_retries=max_retries, sleep=True)
    except Exception:
        return None
    if df is None or getattr(df, "empty", True):
        return None
    cols = {str(x).strip(): x for x in df.columns}
    col = next((cols[k] for k in cols if "优惠" in k), None)
    if col is None:
        return None
    try:
        vals = [parse_rate(v) for v in df[col].tolist()]
        vals = [v for v in vals if v is not None]
        return max(vals) if vals else None
    except Exception:
        return None
