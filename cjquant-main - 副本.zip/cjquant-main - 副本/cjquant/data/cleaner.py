"""公募净值清洗：异常值 / 缺失值 / PIT（生产级）。

规范来源：用户策略文档 §2.1-2.5
- 复权在 Provider 侧完成，这里只做清洗 + PIT，不重算复权
- 所有函数幂等、可日志追溯，禁止静默丢数
"""
import logging
import pandas as pd
from typing import Dict, Optional, Tuple
from .schema import FundDataSchema

logger = logging.getLogger(__name__)


class FundDataCleaner:
    """单基金 + 宽表两级清洗。"""

    def __init__(
        self,
        outlier_threshold: float = 0.15,
        max_consecutive_nan: int = 5,
    ):
        self.outlier_threshold = outlier_threshold
        self.max_consecutive_nan = max_consecutive_nan

    def clean_single(
        self,
        df: pd.DataFrame,
        dividend_dates: Optional[pd.DatetimeIndex] = None,
    ) -> Tuple[pd.DataFrame, Dict]:
        """清洗单只基金长表。返回 (cleaned, report)。"""
        report = {"n_in": len(df), "n_outlier": 0, "n_zero": 0, "n_dup": 0}
        if df.empty:
            return df, report

        df = df.copy()
        df.index = pd.to_datetime(df.index)
        df = df.sort_index()

        # 0/负净值：直接剔除（spec §2.2）
        zero_mask = df[FundDataSchema.UNIT_NAV] <= 0
        report["n_zero"] = int(zero_mask.sum())
        if report["n_zero"]:
            logger.warning(f"剔除 {report['n_zero']} 条 <=0 净值记录")
        df = df[~zero_mask]

        # 重复日期：保留最后一条
        n_before = len(df)
        df = df[~df.index.duplicated(keep="last")]
        report["n_dup"] = n_before - len(df)

        # 跳变检测：|ret|>阈值 且 非分红日 -> NaN + 线性插值
        rets = df[FundDataSchema.ADJ_NAV].pct_change()
        outlier = rets.abs() > self.outlier_threshold
        if dividend_dates is not None and len(dividend_dates):
            try:
                div_idx = pd.to_datetime(dividend_dates)
                outlier.loc[outlier.index.isin(div_idx)] = False
            except Exception:
                pass
        report["n_outlier"] = int(outlier.sum())
        if report["n_outlier"]:
            logger.warning(f"检测到 {report['n_outlier']} 个跳变点，已插值修复")
            for col in (FundDataSchema.UNIT_NAV, FundDataSchema.ACC_NAV, FundDataSchema.ADJ_NAV):
                if col in df.columns:
                    df.loc[outlier, col] = float("nan")
            df[[FundDataSchema.UNIT_NAV, FundDataSchema.ACC_NAV, FundDataSchema.ADJ_NAV]] = df[
                [FundDataSchema.UNIT_NAV, FundDataSchema.ACC_NAV, FundDataSchema.ADJ_NAV]
            ].interpolate(method="linear", limit_direction="both")

        # 连续缺失超过阈值：只告警，不丢（由上层宇宙过滤决定），保证可追溯
        nan_runs = df[FundDataSchema.ADJ_NAV].isna().astype(int).groupby(
            df[FundDataSchema.ADJ_NAV].notna().cumsum()
        ).sum()
        if not nan_runs.empty and nan_runs.max() > self.max_consecutive_nan:
            logger.warning(f"连续缺失 {int(nan_runs.max())} 天超阈值，需人工核查")

        df = df.dropna(subset=[FundDataSchema.UNIT_NAV, FundDataSchema.ACC_NAV, FundDataSchema.ADJ_NAV])
        report["n_out"] = len(df)
        return df, report

    @staticmethod
    def apply_pit(panel: pd.DataFrame, lag: int = 1) -> pd.DataFrame:
        """PIT 防前视：策略 T 日只能见 T-lag 已公布净值。默认 shift(1)。

        场外净值当晚20-22点公布，日内信号必须基于昨日收盘后数据。
        """
        if panel.empty or lag <= 0:
            return panel
        return panel.shift(lag)

    @staticmethod
    def ffill_panel(panel: pd.DataFrame) -> pd.DataFrame:
        """宽表节假日/停牌前向填充（日频低频策略合理，高频禁用）。"""
        return panel.ffill()
