# -*- coding: utf-8 -*-
"""基金基础库（二期）：本地 SQLite 事实库，替掉「用 NAV 首末值代理成立日/清盘日」。

设计要点
--------
1. **只存核查过的事实**，不推测、不构造。取不到就留 None，由上层降级并标记来源。
2. **规模无历史源**：akshare 无单只基金历史规模（已实测 `fund_open_fund_info_em`
   的「规模变动」返回空表、`fund_scale_change_em` 只有全市场汇总）。因此只存
   「最新规模 + 观测日」，`scale_asof()` 在观测日晚于 asof 时返回 None，
   避免拿未来值当历史值（前视）。宁可少筛，不能给错数。
3. **PIT 无前视**：所有 asof 查询只看 <= asof 的事实。
4. **向后兼容**：本模块纯新增，不改动任何现有判定逻辑；只有在调用方显式传入
   ``master`` 时，DynamicUniverse 才会改用基础库（见 universe.py）。
"""
import logging
import os
import re
import sqlite3
import threading
from datetime import datetime, date, timedelta
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

from . import net
from .exceptions import DataFetchError

logger = logging.getLogger(__name__)

DEFAULT_DB_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "store", "fund_master.db"
)

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS fund_master (
    fund_code          TEXT PRIMARY KEY,
    fund_name          TEXT,
    fund_type          TEXT,
    setup_date         TEXT,
    end_date           TEXT,
    liquidation_date   TEXT,
    company            TEXT,
    manager            TEXT,
    scale_yi           REAL,
    scale_observed_at  TEXT,
    setup_source       TEXT,
    first_seen_at      TEXT,
    basic_fetched_at   TEXT,
    updated_at         TEXT
);
CREATE INDEX IF NOT EXISTS idx_fm_setup  ON fund_master(setup_date);
CREATE INDEX IF NOT EXISTS idx_fm_fetch ON fund_master(basic_fetched_at);

CREATE TABLE IF NOT EXISTS snapshot_daily (
    fund_code        TEXT,
    stat_date        TEXT,
    unit_nav         REAL,
    acc_nav          REAL,
    purchase_status  TEXT,
    redeem_status    TEXT,
    PRIMARY KEY (fund_code, stat_date)
);
CREATE INDEX IF NOT EXISTS idx_snap_date ON snapshot_daily(stat_date);

CREATE TABLE IF NOT EXISTS fund_scale (
    fund_code    TEXT,
    report_date  TEXT,
    scale_yi     REAL,
    shares_yi    REAL,
    change_rate  TEXT,
    source       TEXT,
    PRIMARY KEY (fund_code, report_date)
);
CREATE INDEX IF NOT EXISTS idx_scale_date ON fund_scale(report_date);

CREATE TABLE IF NOT EXISTS etl_error (
    fund_code  TEXT,
    stage      TEXT,
    message    TEXT,
    ts         TEXT
);

CREATE TABLE IF NOT EXISTS meta (
    key        TEXT PRIMARY KEY,
    value      TEXT
);
"""


def _norm_code(code: str) -> str:
    """统一为 6 位 + .OF。"""
    s = str(code).strip().upper()
    if "." in s:
        s = s.split(".")[0]
    try:
        s = s.zfill(6)
    except Exception:
        pass
    return s + ".OF" if s else ""


def _to_date(v) -> Optional[date]:
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    try:
        return pd.to_datetime(str(v)).date()
    except Exception:
        return None


def parse_scale_yi(raw) -> Optional[float]:
    """'39.38亿' / '39.38亿元' / '1,234.5万元' -> 亿元(float)。解析不出返回 None。"""
    if raw is None:
        return None
    s = str(raw).strip().replace(",", "")
    if not s or s.lower() == "nan":
        return None
    unit = 1.0
    if "万亿" in s:
        unit = 10000.0
    elif "万元" in s:
        unit = 1e-4
    m = re.search(r"([-+]?\d*\.?\d+)", s)
    if not m:
        return None
    try:
        return float(m.group(1)) * unit
    except ValueError:
        return None


try:  # pandas 仅用于日期解析
    import pandas as pd
except Exception:  # pragma: no cover
    pd = None  # type: ignore


class FundMasterDB:
    """基金基础事实库（纯本地 IO，无网络调用；网络在 fetchers 里，便于测试替换）。"""

    def __init__(self, db_path: str = DEFAULT_DB_PATH, create: bool = True):
        self.db_path = db_path
        if db_path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        if create:
            self._ensure_schema()

    # ---------- 生命周期 ----------
    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def close(self):
        try:
            self.conn.close()
        except Exception:
            pass

    def _ensure_schema(self):
        with self._lock:
            self.conn.executescript(SCHEMA_SQL)
            self.conn.commit()

    # ---------- 写入 ----------
    def upsert_list(self, records: Sequence[Dict]) -> int:
        """批量写入名单（一批一次请求的结果）。返回写入行数。

        records 每行需含 fund_code；可选 fund_name/fund_type。不覆盖已有更细的事实。
        """
        now = datetime.now().isoformat(timespec="seconds")
        rows = []
        for r in records:
            code = _norm_code(r.get("fund_code") or r.get("基金代码"))
            if not code:
                continue
            name = r.get("fund_name") or r.get("基金简称")
            ftype = r.get("fund_type") or r.get("基金类型")
            rows.append((code, name, ftype, now, name, ftype, code))
        if not rows:
            return 0
        sql = """
        INSERT INTO fund_master (fund_code, fund_name, fund_type, first_seen_at, updated_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(fund_code) DO UPDATE SET
            fund_name  = COALESCE(excluded.fund_name, fund_master.fund_name),
            fund_type  = COALESCE(excluded.fund_type, fund_master.fund_type),
            updated_at = excluded.updated_at
        """
        with self._lock:
            self.conn.executemany(sql, [(r[0], r[1], r[2], r[3], r[3]) for r in rows])
            self.conn.commit()
        return len(rows)

    def upsert_basic(self, code: str, info: Dict) -> bool:
        """写入/更新单只基金的基础事实（来自 fund_individual_basic_info_xq）。"""
        c = _norm_code(code)
        setup = _to_date(info.get("setup_date") or info.get("成立时间"))
        end = _to_date(info.get("end_date") or info.get("到期日"))
        scale = info.get("scale_yi")
        if scale is None:
            scale = parse_scale_yi(info.get("最新规模"))
        observed = _to_date(info.get("scale_observed_at")) or datetime.now().date()
        now = datetime.now().isoformat(timespec="seconds")
        sql = """
        INSERT INTO fund_master (
            fund_code, fund_name, fund_type, setup_date, end_date, company, manager,
            scale_yi, scale_observed_at, setup_source, first_seen_at, basic_fetched_at, updated_at
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(fund_code) DO UPDATE SET
            fund_name        = COALESCE(excluded.fund_name, fund_master.fund_name),
            fund_type        = COALESCE(excluded.fund_type, fund_master.fund_type),
            setup_date       = COALESCE(excluded.setup_date, fund_master.setup_date),
            end_date         = COALESCE(excluded.end_date, fund_master.end_date),
            company          = COALESCE(excluded.company, fund_master.company),
            manager          = COALESCE(excluded.manager, fund_master.manager),
            scale_yi         = COALESCE(excluded.scale_yi, fund_master.scale_yi),
            scale_observed_at   = COALESCE(excluded.scale_observed_at, fund_master.scale_observed_at),
            setup_source     = COALESCE(excluded.setup_source, fund_master.setup_source),
            basic_fetched_at = excluded.basic_fetched_at,
            updated_at       = excluded.updated_at
        """
        params = (
            c,
            info.get("fund_name") or info.get("基金名称"),
            info.get("fund_type") or info.get("基金类型"),
            setup.isoformat() if setup else None,
            end.isoformat() if end else None,
            info.get("company") or info.get("基金公司"),
            info.get("manager") or info.get("基金经理"),
            scale,
            observed.isoformat(),
            info.get("setup_source") or ("basic_info" if setup else None),
            datetime.now().date().isoformat(),
            now,
            now,
        )
        with self._lock:
            self.conn.execute(sql, params)
            self.conn.commit()
        return True

    def set_liquidation_date(self, code: str, liq: Optional[date]) -> None:
        c = _norm_code(code)
        with self._lock:
            self.conn.execute(
                "UPDATE fund_master SET liquidation_date=?, updated_at=? WHERE fund_code=?",
                (liq.isoformat() if liq else None,
                 datetime.now().isoformat(timespec="seconds"), c),
            )
            self.conn.commit()

    def set_nav_proxy_facts(self, code: str, first_nav: date, last_nav: date,
                            gap_days: int = 60, today: Optional[date] = None,
                            n_rows: Optional[int] = None, min_rows: int = 30) -> bool:
        """净值首末日兜底：真题缺失时才写，且来源标 nav_proxy（不冒充权威事实）。

        末值距今超过 gap_days -> 判定已停更/清盘，落 liquidation_date。

        n_rows/min_rows：序列行数太少的必须拒绝。实测有些基金只能取到 1 行净值，
        若照写会把「成立日 = 清盘日 = 那唯一一天」写进库（008464 就踩过），
        这种「没有足够证据」的情况应保持 None，而不是编一个日期。
        """
        c = _norm_code(code)
        if n_rows is not None and int(n_rows) < int(min_rows):
            logger.info(f"[FundMaster] {c} 净值仅 {n_rows} 行（<{min_rows}），不足以推断成立/清盘，跳过")
            return False
        self.conn.execute("INSERT OR IGNORE INTO fund_master (fund_code) VALUES (?)", (c,))
        r = self.get_fund(c)
        now = today or datetime.now().date()
        sets, params = [], []
        if first_nav and not (r or {}).get("setup_date"):
            sets += ["setup_date=?", "setup_source=?"]
            params += [first_nav.isoformat(), "nav_proxy"]
        if last_nav and (now - last_nav).days > int(gap_days) and not (r or {}).get("liquidation_date"):
            sets.append("liquidation_date=?")
            params.append(last_nav.isoformat())
        if not sets:
            return False
        params += [datetime.now().isoformat(timespec="seconds"), c]
        with self._lock:
            self.conn.execute(
                "UPDATE fund_master SET " + ", ".join(sets) + ", updated_at=? WHERE fund_code=?",
                params,
            )
            self.conn.commit()
        return True

    def upsert_snapshot(self, rows: Sequence[Dict]) -> int:
        """写入每日快照（幂等，按 code+date 覆盖）。"""
        sql = """
        INSERT INTO snapshot_daily (fund_code, stat_date, unit_nav, acc_nav, purchase_status, redeem_status)
        VALUES (?,?,?,?,?,?)
        ON CONFLICT(fund_code, stat_date) DO UPDATE SET
            unit_nav=excluded.unit_nav, acc_nav=excluded.acc_nav,
            purchase_status=excluded.purchase_status, redeem_status=excluded.redeem_status
        """
        data = []
        for r in rows:
            code = _norm_code(r.get("fund_code") or r.get("基金代码"))
            d = _to_date(r.get("stat_date"))
            if not code or not d:
                continue

            def _f(*names):
                for n in names:
                    if n in r and r[n] is not None and str(r[n]) != "":
                        try:
                            return float(r[n])
                        except (TypeError, ValueError):
                            return None
                return None

            data.append((
                code, d.isoformat(),
                _f("unit_nav", "单位净值"),
                _f("acc_nav", "累计净值"),
                r.get("purchase_status") or r.get("申购状态"),
                r.get("redeem_status") or r.get("赎回状态"),
            ))
        if not data:
            return 0
        with self._lock:
            self.conn.executemany(sql, data)
            self.conn.commit()
        return len(data)

    def upsert_scale_history(self, code: str, rows: Sequence[Dict]) -> int:
        """写入规模历史（季报/半年报/年报），幂等按 code+report_date 覆盖。"""
        c = _norm_code(code)
        data = []
        for r in rows:
            raw_date = str(r.get("report_date") or r.get("日期") or "").strip()
            # 写入侧也把住关：非 YYYY-MM-DD 一律丢弃（如东财表尾的「说明：...」行）
            if not re.match(r"^\d{4}-\d{2}-\d{2}$", raw_date):
                continue
            d = _to_date(raw_date)
            if not d:
                continue
            scale = r.get("scale_yi")
            if scale is None:
                scale = r.get("期末净资产（亿元）")
            try:
                scale = None if scale in (None, "", "---", "nan") else float(str(scale).replace(",", ""))
            except (TypeError, ValueError):
                scale = None
            # 规模值缺失的行（东财早期季报常给 '---'）不入库：
            # 存成 NULL 会让 scale_asof 误退回到「最新规模」，不如如实当它没这条事实
            if scale is None:
                continue
            shares = r.get("shares_yi")
            if shares is None:
                shares = r.get("期末总份额（亿份）")
            try:
                shares = None if shares in (None, "", "---", "nan") else float(str(shares).replace(",", ""))
            except (TypeError, ValueError):
                shares = None
            data.append((c, d.isoformat(), scale, shares,
                         r.get("change_rate") or r.get("净资产变动率") or None,
                         r.get("source") or "em_gmbd"))
        if not data:
            return 0
        sql = """
        INSERT INTO fund_scale (fund_code, report_date, scale_yi, shares_yi, change_rate, source)
        VALUES (?,?,?,?,?,?)
        ON CONFLICT(fund_code, report_date) DO UPDATE SET
            scale_yi=excluded.scale_yi, shares_yi=excluded.shares_yi,
            change_rate=excluded.change_rate, source=excluded.source
        """
        with self._lock:
            self.conn.executemany(sql, data)
            self.conn.commit()
        return len(data)

    def scale_history(self, code: str) -> List[Dict]:
        c = _norm_code(code)
        cur = self.conn.execute(
            "SELECT * FROM fund_scale WHERE fund_code=? ORDER BY report_date", (c,))
        return [dict(r) for r in cur.fetchall()]

    def codes_without_scale_history(self, limit: int = 0) -> List[str]:
        """名单里有、但还没有规模历史的代码（回填调度用）。"""
        q = ("SELECT fund_code FROM fund_master WHERE fund_code NOT IN "
             "(SELECT DISTINCT fund_code FROM fund_scale) ORDER BY fund_code")
        if limit and limit > 0:
            q += " LIMIT %d" % int(limit)
        cur = self.conn.execute(q)
        return [r["fund_code"] for r in cur.fetchall()]

    def record_error(self, code: str, stage: str, message: str) -> None:
        with self._lock:
            self.conn.execute(
                "INSERT INTO etl_error (fund_code, stage, message, ts) VALUES (?,?,?,?)",
                (code, stage, str(message)[:300], datetime.now().isoformat(timespec="seconds")),
            )
            self.conn.commit()

    def prune_snapshots(self, keep_days: int = 30) -> int:
        """删掉超出保留窗口的旧快照，控制库体积。

        每日快照约 2.4 万行，不清理一年会涨到 GB 级。默认留 30 天。
        """
        cutoff = (datetime.now().date() - timedelta(days=int(keep_days))).isoformat()
        with self._lock:
            cur = self.conn.execute("DELETE FROM snapshot_daily WHERE stat_date < ?", (cutoff,))
            deleted = max(cur.rowcount or 0, 0)
            self.conn.commit()
            if deleted:
                self.conn.execute("VACUUM")  # 否则文件只会涨不会缩
        return deleted

    def failure_count(self, code: str, stage: str) -> int:
        with self._lock:
            cur = self.conn.execute(
                "SELECT COUNT(*) FROM etl_error WHERE fund_code=? AND stage=?",
                (_norm_code(code), stage))
            return int(cur.fetchone()[0])

    def set_meta(self, key: str, value) -> None:
        with self._lock:
            self.conn.execute(
                "INSERT INTO meta(key,value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, str(value)),
            )
            self.conn.commit()

    def get_meta(self, key: str) -> Optional[str]:
        cur = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,))
        row = cur.fetchone()
        return row["value"] if row else None

    # ---------- 查询 ----------
    def get_fund(self, code: str) -> Optional[Dict]:
        c = _norm_code(code)
        cur = self.conn.execute("SELECT * FROM fund_master WHERE fund_code=?", (c,))
        row = cur.fetchone()
        return dict(row) if row else None

    def facts_for(self, codes: Sequence[str]) -> Dict[str, Dict]:
        """批量取多只基金的事实（一次查询，避免选池时 N 次往返）。"""
        keys = [_norm_code(c) for c in codes]
        keys = [k for k in keys if k]
        if not keys:
            return {}
        out: Dict[str, Dict] = {}
        # SQLite 变量上限约 999，分批查
        for i in range(0, len(keys), 900):
            chunk = keys[i:i + 900]
            marks = ",".join("?" * len(chunk))
            for r in self.conn.execute(
                    f"SELECT * FROM fund_master WHERE fund_code IN ({marks})", chunk):
                d = dict(r)
                out[d["fund_code"]] = d
        return out

    def setup_date(self, code: str) -> Optional[date]:
        r = self.get_fund(code)
        return _to_date(r.get("setup_date")) if r else None

    def liquidation_date(self, code: str) -> Optional[date]:
        r = self.get_fund(code)
        return _to_date(r.get("liquidation_date")) if r else None

    def scale_asof(self, code: str, asof: date) -> Optional[float]:
        """PIT 规模（亿元）。

        优先查规模历史表（季报，report_date <= asof 的最新一期）—— 这是真 PIT；
        没有历史才退回「最新规模+观测日」，且观测日晚于 asof 时返回 None，拒绝前视。
        """
        c = _norm_code(code)
        a = _to_date(asof)
        if a is None:
            return None
        cur = self.conn.execute(
            "SELECT scale_yi FROM fund_scale WHERE fund_code=? AND report_date<=? "
            "ORDER BY report_date DESC LIMIT 1", (c, a.isoformat()))
        row = cur.fetchone()
        if row and row["scale_yi"] is not None:
            try:
                return float(row["scale_yi"])
            except (TypeError, ValueError):
                return None
        r = self.get_fund(c)
        if not r or r.get("scale_yi") is None:
            return None
        obs = _to_date(r.get("scale_observed_at"))
        if obs is None or obs > a:
            return None
        try:
            return float(r["scale_yi"])
        except (TypeError, ValueError):
            return None

    def type_asof(self, code: str, asof: date = None) -> Optional[str]:
        r = self.get_fund(code)
        return r.get("fund_type") if r else None

    def status_asof(self, code: str, asof: date) -> Optional[str]:
        """取 <= asof 的最近一条快照的申购状态。没有则 None。"""
        c = _norm_code(code)
        a = _to_date(asof)
        cur = self.conn.execute(
            "SELECT purchase_status FROM snapshot_daily "
            "WHERE fund_code=? AND stat_date<=? ORDER BY stat_date DESC LIMIT 1",
            (c, a.isoformat() if a else ""),
        )
        row = cur.fetchone()
        return row["purchase_status"] if row else None

    def candidate_codes(self, min_scale_yi: Optional[float] = 2.0,
                        min_age_days: int = 365,
                        exclude_types: Sequence[str] = ("货币",),
                        exclude_name_contains: Sequence[str] = ("(后端)",),
                        liquidated: bool = False,
                        require_facts: bool = False,
                        limit: int = 0) -> List[str]:
        """筛出「值得预热净值」的合格候选（供热池按价值优先抓取）。

        只用库里已有的事实判断，不联网。
        require_facts=False（默认）：缺事实的（如无规模）不因此被排除，
            避免因数据不全把好标的挡在门外 —— 适合"全量覆盖"；
        require_facts=True：必须同时有 setup_date 与 scale_yi 才入选，
            适合"优先预热我们确知合格的那批"，避免优先级队列被未知标的稀释。
        """
        today = datetime.now().date()
        cutoff_setup = (today - timedelta(days=int(min_age_days))).isoformat()
        q = "SELECT fund_code, fund_name, fund_type, setup_date, scale_yi, liquidation_date " \
            "FROM fund_master WHERE 1=1"
        args: List = []
        for t in exclude_types:
            q += " AND COALESCE(fund_type, '') NOT LIKE ?"
            args.append("%" + str(t) + "%")
        for n in exclude_name_contains:
            q += " AND COALESCE(fund_name, '') NOT LIKE ?"
            args.append("%" + str(n) + "%")
        out: List[str] = []
        for r in self.conn.execute(q, args):
            setup = r["setup_date"]
            if require_facts and not setup:
                continue
            if setup and str(setup) > cutoff_setup:
                continue                                     # 成立太短，历史不够
            if require_facts and r["scale_yi"] is None:
                continue
            if liquidated is False and r["liquidation_date"]:
                continue                                     # 已清盘
            if min_scale_yi is not None and r["scale_yi"] is not None:
                try:
                    if float(r["scale_yi"]) < float(min_scale_yi):
                        continue
                except (TypeError, ValueError):
                    pass
            out.append(r["fund_code"])
            if limit and len(out) >= int(limit):
                break
        return out

    def all_codes(self) -> List[str]:
        cur = self.conn.execute("SELECT fund_code FROM fund_master ORDER BY fund_code")
        return [r["fund_code"] for r in cur.fetchall()]

    def filter_codes(self, fund_type_contains: str = None, code_prefix: str = None,
                     limit: int = 0) -> List[str]:
        """按类型/代码前缀筛候选池。基础库有全量名单时，比每次回测都拉一次接口划算。"""
        q = "SELECT fund_code FROM fund_master WHERE 1=1"
        params = []
        if fund_type_contains:
            q += " AND COALESCE(fund_type, '') LIKE ?"
            params.append("%" + str(fund_type_contains) + "%")
        if code_prefix:
            q += " AND fund_code LIKE ?"
            params.append(str(code_prefix) + "%")
        q += " ORDER BY fund_code"
        if limit and limit > 0:
            q += " LIMIT ?"
            params.append(int(limit))
        cur = self.conn.execute(q, params)
        return [r["fund_code"] for r in cur.fetchall()]

    def codes_without_latest_snapshot(self, limit: int = 0, skip_failed_after: int = 3) -> List[str]:
        """名单里有、最近一次快照里没有的基金（后端份额/货币型/非开放式居多）。

        注意：这**不是**清盘证据。它只是「需要单独补事实」的候选，
        因为每日快照接口只覆盖开放式净值基金，覆盖不到这些代码。

        skip_failed_after：排除 NAV 兜底已累计失败达标的代码，否则无独立净值页的
        后端份额代码会永远排在最前面，把每夜 REPAIR_BATCH 名额占满、进度卡死
        （与 pending_codes 的 enrich 闸门同理）。
        """
        q = """
        SELECT fund_code FROM fund_master
        WHERE fund_code NOT IN (
            SELECT DISTINCT fund_code FROM snapshot_daily
            WHERE stat_date = (SELECT MAX(stat_date) FROM snapshot_daily)
        )
        """
        if skip_failed_after and skip_failed_after > 0:
            q += (" AND fund_code NOT IN (SELECT fund_code FROM etl_error "
                  "WHERE stage='repair_nav' GROUP BY fund_code HAVING COUNT(*) >= %d)"
                  % int(skip_failed_after))
        q += " ORDER BY fund_code"
        if limit and limit > 0:
            q += " LIMIT %d" % int(limit)
        cur = self.conn.execute(q)
        return [r["fund_code"] for r in cur.fetchall()]

    def pending_codes(self, limit: int = 0, skip_failed_after: int = 3) -> List[str]:
        """尚未拉过基础信息的代码，按 code 排序。

        skip_failed_after：排除已放弃（累计 enrich 失败达标）的代码，
        否则前几只永远拉不到的「(后端)」份额代码会把每夜的增量名额全占掉、卡死进度。
        """
        q = "SELECT fund_code FROM fund_master WHERE basic_fetched_at IS NULL"
        if skip_failed_after and skip_failed_after > 0:
            q += (" AND fund_code NOT IN (SELECT fund_code FROM etl_error "
                  "WHERE stage='enrich' GROUP BY fund_code HAVING COUNT(*) >= %d)"
                  % int(skip_failed_after))
        q += " ORDER BY fund_code"
        if limit and limit > 0:
            q += " LIMIT %d" % int(limit)
        cur = self.conn.execute(q)
        return [r["fund_code"] for r in cur.fetchall()]

    def stale_codes(self, max_age_days: int = 30, limit: int = 0) -> List[str]:
        """基础信息已过期，需要重拉的代码。"""
        cutoff = (datetime.now() - timedelta(days=int(max_age_days))).isoformat(timespec="seconds")
        q = ("SELECT fund_code FROM fund_master "
             "WHERE basic_fetched_at IS NULL OR basic_fetched_at < ? ORDER BY basic_fetched_at")
        params: Tuple = (cutoff,)
        if limit and limit > 0:
            q += " LIMIT ?"
            params = (cutoff, int(limit))
        cur = self.conn.execute(q, params)
        return [r["fund_code"] for r in cur.fetchall()]

    def stats(self) -> Dict[str, int]:
        def cnt(sql, args=()):
            return int(self.conn.execute(sql, args).fetchone()[0])

        return {
            "total": cnt("SELECT COUNT(*) FROM fund_master"),
            "enriched": cnt("SELECT COUNT(*) FROM fund_master WHERE basic_fetched_at IS NOT NULL"),
            "with_setup": cnt("SELECT COUNT(*) FROM fund_master WHERE setup_date IS NOT NULL"),
            "with_scale": cnt("SELECT COUNT(*) FROM fund_master WHERE scale_yi IS NOT NULL"),
            "liquidated": cnt("SELECT COUNT(*) FROM fund_master WHERE liquidation_date IS NOT NULL"),
            "snapshot_rows": cnt("SELECT COUNT(*) FROM snapshot_daily"),
            "errors": cnt("SELECT COUNT(*) FROM etl_error"),
        }


# -------------------- 网络抓取（懒加载 akshare，便于离线单测） --------------------

# -------------------- 进程内共享句柄 --------------------

_MASTER_SINGLETON = None


def default_master(db_path: str = DEFAULT_DB_PATH):
    """取进程内共享的基础库句柄。库不存在/打不开 -> 返回 None，调用方自动降级为旧逻辑。

    回测与调度都用它，避免每次调用都重开一次 sqlite。
    """
    global _MASTER_SINGLETON
    if _MASTER_SINGLETON is not None:
        return _MASTER_SINGLETON
    try:
        if db_path != ":memory:" and not os.path.exists(db_path):
            logger.info("[FundMaster] 基础库文件不存在，本次不启用基础库（降级旧逻辑）")
            return None
        _MASTER_SINGLETON = FundMasterDB(db_path=db_path)
        return _MASTER_SINGLETON
    except Exception as e:
        logger.warning(f"[FundMaster] 基础库打开失败，降级旧逻辑: {e}")
        return None


def fetch_fund_list() -> List[Dict]:
    """全量基金名单（一次请求）。返回 [{fund_code, fund_name, fund_type}...]。

    ⚠️ 这是全市场名单的**第三处**实现（另两处在 providers/public.list_all_funds
    与 market_db.fetch_full_market_list）。三份原来是各抓各的，一次调度里可能
    产生三个约 2.7 万行的请求。现在统一走 net.cached_call 的进程内缓存，
    只保留各自不同的**解析口径**（这里返回 dict 列表，public 返回 DataFrame）。
    """
    df = net.cached_call(
        "ak.fund_name_em()",
        lambda: net.ak_call("fund_name_em"),
    )
    out = []
    for _, r in df.iterrows():
        out.append({
            "fund_code": str(r.get("基金代码", "")).strip(),
            "fund_name": r.get("基金简称"),
            "fund_type": r.get("基金类型"),
        })
    return out


def fetch_basic_info(code: str) -> Dict:
    """单只基金基础信息（成立时间/规模/类型/公司/经理）。失败抛异常由上层处理。

    雪球接口对部分基金返回不了 data（KeyError: 'data'）—— 统一层会把它归为
    可重试失败退避重试；确实拿不到的由上层 FundMasterUpdater.repair_by_nav 兜底。
    """
    df = net.ak_call("fund_individual_basic_info_xq",
                     symbol=str(code).split(".")[0].zfill(6))
    kv = {}
    try:
        kv = dict(zip(df["item"].astype(str), df["value"].astype(str)))
    except Exception:
        for _, r in df.iterrows():
            kv[str(r.get("item"))] = r.get("value")
    return {
        "fund_name": kv.get("基金名称") or kv.get("基金简称"),
        "fund_type": kv.get("基金类型"),
        "setup_date": kv.get("成立时间"),
        "scale_yi": parse_scale_yi(kv.get("最新规模")),
        "company": kv.get("基金公司"),
        "manager": kv.get("基金经理"),
    }


def fetch_snapshot_rows() -> List[Dict]:
    """每日快照：动态日期列名 -> 标准行结构。

    与 providers/public.get_daily_snapshot 同源（``fund_open_fund_daily_em``），
    也统一走进程内缓存。两者只解析口径不同：这里摊平成 {code, stat_date, nav...} 行，
    public 保留原始宽表。
    """
    df = net.cached_call(
        "ak.fund_open_fund_daily_em()",
        lambda: net.ak_call("fund_open_fund_daily_em"),
    )
    rows = []
    date_cols = {}
    for c in df.columns:
        m = re.match(r"^(\d{4}-\d{2}-\d{2})-(单位净值|累计净值)$", str(c))
        if m:
            date_cols.setdefault(m.group(1), {})[m.group(2)] = c
    for _, r in df.iterrows():
        code = str(r.get("基金代码", "")).strip()
        for d, cols in date_cols.items():
            rows.append({
                "fund_code": code,
                "stat_date": d,
                "unit_nav": r.get(cols.get("单位净值")),
                "acc_nav": r.get(cols.get("累计净值")),
                "purchase_status": r.get("申购状态"),
                "redeem_status": r.get("赎回状态"),
            })
    return rows


def _short_err(e: Exception, limit: int = 200) -> str:
    """把异常压成一行短消息。akshare 的 JS 解析异常会把整页 HTML 塞进 message，
    直接打日志会刷屏（如 000002.OF 后端份额的 3924 字节错误页）。"""
    s = str(e).replace("\n", " ").replace("\r", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return s if len(s) <= limit else s[:limit] + "…"


# pingzhongdata 快速探针（ technique 借自外部 funddata 项目的 AkshareSource，
# 代码已搬入本仓，不跨目录引用）：天天基金 pingzhongdata/{code}.js 无数据时
# 返回 404 HTML 错误页。先用一次轻 GET 判定，避免走 akshare + mini_racer
# 三次慢重试还把整页 HTML 塞进异常信息。
_PZ_URL = "https://fund.eastmoney.com/pingzhongdata/{code}.js"
_PZ_HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/122.0 Safari/537.36"),
    "Referer": "https://fundf10.eastmoney.com/",
}


def has_nav_page(code: str, timeout: float = 15.0) -> bool:
    """该代码是否有独立净值页。False = 后端份额/已下架到无页面的品种。"""
    raw = str(code).split(".")[0].zfill(6)
    try:
        r = net.http_get(_PZ_URL.format(code=raw), headers=_PZ_HEADERS,
                         timeout=timeout)
        head = (r.text or "")[:200].lower()
        if r.status_code != 200 or "<!doctype" in head or "<html" in head:
            return False
        return "networthtrend" in (r.text or "").lower()
    except Exception:
        # 探针本身失败不下结论，交给正常抓取路径重试
        return True


def fetch_nav_range(code: str):
    """取该基金净值序列的 (首日期, 末日期, 行数)（一次请求拿全史）。

    雪球 basic_info 对部分基金返回不了 data（KeyError: 'data'），需兜底。
    实测三类情况都遇到过，按顺序回退：
      1. 单位净值走势 —— 绝大多数开放式基金（含已清盘，如 2020 年退市的分级基金）
      2. 累计净值走势 —— 少数有累计净值但无单位净值序列的份额
      3. 累计收益率走势 —— 货币基金（它们压根没有 Data_netWorthTrend）
    注意一：名单里大量 "(后端)" 份额代码本身没有独立净值页，三种都取不到，属正常，
          按「反复失败后放弃」处理，不写成清盘。
    注意二：行数要一起返回。实测有基金只能取到 1 行，若照此推断成立日/清盘日
          会写出「成立日=清盘日=唯一那天」的假事实，上层必须用 min_rows 拦掉。
    """
    raw = str(code).split(".")[0].zfill(6)
    if not has_nav_page(raw):
        raise ValueError(f"{raw} 无独立净值页（pingzhongdata 返回 HTML/404，多为后端份额代码），跳过净值兜底")
    last_err = None
    for indicator, date_col in (("单位净值走势", "净值日期"),
                                ("累计净值走势", "净值日期"),
                                ("累计收益率走势", "日期")):
        try:
            # max_retries=1：这里是"三种 indicator 依次回退"的最后一跳，
            # 每个 indicator 自己再退避重试会把整个兜底路径拖慢好几倍。
            df = net.ak_call("fund_open_fund_info_em", symbol=raw,
                             indicator=indicator, max_retries=1)
            if df is None or df.empty or date_col not in df.columns:
                last_err = ValueError(f"{indicator} 返回空或缺列 {date_col}")
                continue
            dates = pd.to_datetime(df[date_col])
            return dates.min().date(), dates.max().date(), int(len(df))
        except Exception as e:  # noqa: PERF203
            last_err = e
            continue
    raise ValueError(f"净值序列三种 indicator 均取不到: {_short_err(last_err) if last_err else '未知'}")


def fetch_scale_history(code: str) -> List[Dict]:
    """单只基金规模历史（季报/半年报/年报），来源：东方财富 F10「规模变动」。

    实测：akshare 没有任何可用接口（`fund_open_fund_info_em` 的「规模变动」返回空表，
    `fund_scale_change_em()` 只有全市场汇总）。但东财 F10 的底层数据源是公开的：

        https://fundf10.eastmoney.com/FundArchivesDatas.aspx?type=gmbd&code=000001

    返回 JS 包裹的 HTML 表：日期 / 期间申购(亿份) / 期间赎回(亿份) /
    期末总份额(亿份) / **期末净资产(亿元)** / 净资产变动率，长期基金可取到近百期。
    取不到或解析不出有效行时抛异常，由上层记录降级。
    """
    from io import StringIO

    raw = str(code).split(".")[0].zfill(6)
    url = "https://fundf10.eastmoney.com/FundArchivesDatas.aspx?type=gmbd&mode=0&code=%s" % raw
    headers = {
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/122.0 Safari/537.36"),
        "Referer": "https://fundf10.eastmoney.com/gmbd_%s.html" % raw,
    }
    # 走统一访问层（共享连接池 + 统一超时 + 退避重试）。改造前这里是一次裸
    # requests.get + raise_for_status()：偶发 502 会把整只基金的规模历史判死，
    # 而 scale_asof 取不到它并不会报错，只是让 PIT 规模过滤**静默少筛**。
    r = net.http_get(url, headers=headers, timeout=20)
    if r.status_code != 200:
        raise DataFetchError(f"规模变动请求失败 HTTP {r.status_code} {raw}")
    r.encoding = "utf-8"
    txt = r.text
    i, j = txt.find("<table"), txt.rfind("</table>")
    if i < 0 or j <= i:
        raise ValueError("返回体里没有规模变动表格")
    dfs = pd.read_html(StringIO(txt[i:j + 8]))
    if not dfs:
        raise ValueError("表格解析为空")
    df = dfs[0]

    def _col(*names):
        for n in names:
            for c in df.columns:
                if str(c).strip().endswith(n) or n in str(c):
                    return c
        return None

    c_date = _col("日期")
    c_scale = _col("期末净资产")
    c_shares = _col("期末总份额")
    c_chg = _col("净资产变动率")
    if c_date is None or c_scale is None:
        raise ValueError(f"表结构不符预期: {list(df.columns)}")

    rows = []
    for _, rr in df.iterrows():
        d = str(rr.get(c_date, "")).strip()
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", d):
            # 部分基金表尾带一行「说明：...」文字，必须丢弃
            continue
        rows.append({
            "report_date": d,
            "scale_yi": rr.get(c_scale),
            "shares_yi": rr.get(c_shares) if c_shares is not None else None,
            "change_rate": rr.get(c_chg) if c_chg is not None else None,
            "source": "em_gmbd",
        })
    if not rows:
        raise ValueError("解析出 0 行有效日期数据")
    return rows


class FundMasterUpdater:
    """编排层：把网络源灌进 FundMasterDB。抓取函数可注入，便于离线测试。"""

    def __init__(self, db: FundMasterDB,
                 list_fetcher: Callable[[], List[Dict]] = None,
                 basic_fetcher: Callable[[str], Dict] = None,
                 snapshot_fetcher: Callable[[], List[Dict]] = None,
                 nav_range_fetcher: Callable[[str], Tuple[date, date]] = None,
                 scale_history_fetcher: Callable[[str], List[Dict]] = None,
                 liquidate_gap_days: int = 60,
                 min_nav_rows: int = 30,
                 sleep: float = 0.0):
        self.db = db
        self._list = list_fetcher or fetch_fund_list
        self._basic = basic_fetcher or fetch_basic_info
        self._snap = snapshot_fetcher or fetch_snapshot_rows
        self._nav_range = nav_range_fetcher or fetch_nav_range
        self._scale_hist = scale_history_fetcher or fetch_scale_history
        self.liquidate_gap_days = int(liquidate_gap_days)
        self.min_nav_rows = int(min_nav_rows)
        self.sleep = sleep

    def sync_list(self) -> int:
        try:
            recs = self._list()
        except Exception as e:
            logger.error(f"[FundMaster] 名单拉取失败: {e}")
            raise
        n = self.db.upsert_list(recs)
        self.db.set_meta("last_list_sync", datetime.now().isoformat(timespec="seconds"))
        logger.info(f"[FundMaster] 名单同步 {n} 只")
        return n

    def enrich(self, codes: Iterable[str], max_fail_ratio: float = 0.5,
               skip_after_failures: int = 3) -> Dict[str, int]:
        """按给定代码逐个补基础信息。单只失败跳过并记录，不中断整体。

        skip_after_failures：同一只累计失败到 N 次就放弃。
        名单里有一批「(后端)」份额代码没有独立净值页，不加这个闸门会被每晚无限重试。
        """
        codes = list(codes)
        ok, fail, failed_codes, given_up = 0, 0, [], 0
        for c in codes:
            if self.db.failure_count(c, "enrich") >= skip_after_failures:
                given_up += 1
                continue
            try:
                info = self._basic(c)
                self.db.upsert_basic(c, info)
                ok += 1
            except Exception as e:
                fail += 1
                failed_codes.append(_norm_code(c))
                self.db.record_error(c, "enrich", str(e))
                logger.warning(f"[FundMaster] {c} 基础信息失败: {_short_err(e)}")
            if self.sleep:
                import time
                time.sleep(self.sleep)
        if codes and fail / len(codes) > max_fail_ratio:
            logger.error(f"[FundMaster] enrich 失败率过高 {fail}/{len(codes)}，请检查数据源")
        self.db.set_meta("last_enrich", datetime.now().isoformat(timespec="seconds"))
        return {"ok": ok, "fail": fail, "failed_codes": failed_codes, "given_up": given_up}

    def sync_scale_history(self, codes: Iterable[str],
                           skip_after_failures: int = 3) -> Dict[str, int]:
        """批量落规模历史（季报）。有了它 scale_asof 才是真 PIT。"""
        ok = fail = rows = given_up = 0
        for raw in codes:
            c = _norm_code(raw)
            if self.db.failure_count(c, "scale_hist") >= skip_after_failures:
                given_up += 1
                continue
            try:
                hist = self._scale_hist(c)
                rows += self.db.upsert_scale_history(c, hist)
                ok += 1
            except Exception as e:
                fail += 1
                self.db.record_error(c, "scale_hist", str(e))
                logger.warning(f"[FundMaster] {c} 规模历史失败: {_short_err(e)}")
            if self.sleep:
                import time
                time.sleep(self.sleep)
        logger.info(f"[FundMaster] 规模历史 ok={ok} fail={fail} rows={rows} given_up={given_up}")
        return {"ok": ok, "fail": fail, "rows": rows, "given_up": given_up}

    def repair_by_nav(self, codes: Iterable[str], only_missing: bool = True,
                      skip_after_failures: int = 3) -> Dict[str, int]:
        """用净值首末日补齐拉不到基础信息的基金。

        only_missing=True 时跳过已有 setup_date 的基金，避免拿代理值覆盖真值。
        skip_after_failures：同一只连续失败到 N 次就放弃，避免「没有独立净值页的
        (后端)份额代码」被每天无效重试。
        """
        ok = fail = skipped = given_up = 0
        for raw in codes:
            c = _norm_code(raw)
            row = self.db.get_fund(c)
            if only_missing and row and row.get("setup_date"):
                skipped += 1
                continue
            if self.db.failure_count(c, "repair_nav") >= skip_after_failures:
                given_up += 1
                continue
            try:
                got = self._nav_range(c)
                # 兼容只返回 (first, last) 的旧式 fetcher / 注入替身
                if isinstance(got, tuple) and len(got) >= 3:
                    first, last, n_rows = got[0], got[1], got[2]
                else:
                    first, last, n_rows = got[0], got[1], None
                wrote = self.db.set_nav_proxy_facts(c, first, last, self.liquidate_gap_days,
                                                    n_rows=n_rows, min_rows=self.min_nav_rows)
                if wrote:
                    ok += 1
                else:
                    skipped += 1
            except Exception as e:
                fail += 1
                self.db.record_error(c, "repair_nav", str(e))
                logger.warning(f"[FundMaster] {c} NAV 兜底失败: {_short_err(e)}")
            if self.sleep:
                import time
                time.sleep(self.sleep)
        logger.info(f"[FundMaster] NAV 兜底 ok={ok} fail={fail} skipped={skipped} given_up={given_up}")
        return {"ok": ok, "fail": fail, "skipped": skipped, "given_up": given_up}

    def ensure_funds(self, codes: Iterable[str], max_age_days: int = 30) -> Dict[str, int]:
        """确保这些代码的基础信息已存在且不过期；只对缺失/过期的抓取。

        雪球接口失败(KeyError: 'data')的代码，自动转 NAV 兜底，不留空。
        """
        codes = [_norm_code(c) for c in codes]
        target = []
        now = datetime.now()
        for c in codes:
            r = self.db.get_fund(c)
            if r is None:
                target.append(c)
                continue
            fetched = r.get("basic_fetched_at")
            if fetched:
                try:
                    if (now - datetime.fromisoformat(fetched)).days < max_age_days:
                        continue
                except ValueError:
                    pass
            target.append(c)
        if not target:
            return {"ok": 0, "fail": 0, "skipped": len(codes), "repaired": 0}
        res = self.enrich(target)
        # 雪球拉不到的（多为已终止/退市）转 NAV 首末日兜底，不留空
        repaired = {"ok": 0, "fail": 0, "skipped": 0}
        if res.get("failed_codes"):
            repaired = self.repair_by_nav(res["failed_codes"])
        res["skipped"] = len(codes) - len(target)
        res["repaired"] = repaired.get("ok", 0)
        return res

    def update_snapshot(self) -> int:
        rows = self._snap()
        n = self.db.upsert_snapshot(rows)
        self.db.set_meta("last_snapshot", datetime.now().isoformat(timespec="seconds"))
        logger.info(f"[FundMaster] 快照落库 {n} 行")
        return n
