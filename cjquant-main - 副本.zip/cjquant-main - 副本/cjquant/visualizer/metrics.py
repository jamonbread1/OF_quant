import pandas as pd
import numpy as np


def downside_deviation(returns: pd.Series, rf: float = 0.02,
                       periods_per_year: int = 252) -> float:
    """年化下行偏差（Downside Deviation），Sortino 的正确分母。

    ⚠️ 旧实现是 `returns[returns < 0].std()` —— 那是"负收益子集的离散度"，
    不是下行偏差。反例：每天恒定亏 -1%，旧算法 std(常量)=0 → Sortino=0，
    而真实的 DS 高达 15.87%。正确定义（说明书 §3.1）：

        DS = sqrt( (periods/n) * Σ min(r_t - MAR, 0)^2 )

    分母是**全样本 n**（不是只数下行日），阈值 MAR = rf/periods（不是 0）。
    """
    r = pd.to_numeric(returns, errors="coerce").dropna()
    if len(r) == 0:
        return float("nan")
    mar = float(rf) / periods_per_year
    shortfall = np.minimum(r.values - mar, 0.0)
    ds_period = float(np.sqrt(np.mean(shortfall ** 2)))   # 全样本 n 作分母
    return ds_period * np.sqrt(periods_per_year)


def equal_weight_benchmark(panel_px: dict, n_days: int,
                           min_coverage: float = 0.5) -> dict:
    """同池等权买入持有基准（🔴 P0-2 修复，单独抽出来以便回归测试）。

    旧实现 `px / px.iloc[0]` 用**第一行**当基准价：只要某一只在该行没有净值
    （回测日历首日常常只有货币型现金载体有值），整列变 NaN，再被
    `mean(skipna=True)` 静默丢弃 —— 实测 281 只只剩 1 只货币基金参与，
    "同池等权"退化成"一只货基"（年化 1.25% / 回撤 0.00）。
    正确口径：**每只按自己的首个有效净值归一化**再等权。

    返回 {annualized, max_drawdown, n_funds_used, coverage_warning}
    """
    if not panel_px or not n_days:
        return {}
    px = pd.DataFrame(panel_px).sort_index()
    px = px.loc[:, px.notna().any()]
    if px.empty or px.shape[1] == 0:
        return {}
    norm = px.apply(lambda s: s / s.dropna().iloc[0] if s.dropna().size else s)
    ew = norm.mean(axis=1).dropna()
    used = int(norm.notna().any().sum())
    if len(ew) < 2:
        return {}
    ann = float(ew.iloc[-1] ** (252.0 / float(n_days)) - 1.0)
    mdd = float((ew / ew.cummax() - 1.0).min())
    return {
        "annualized": round(ann, 6),
        "max_drawdown": round(mdd, 6),
        "n_funds_used": used,
        "coverage_warning": bool(used < max(2, int(min_coverage * px.shape[1]))),
    }


class QualityMetrics:
    @staticmethod
    def calculate(daily_stats: pd.DataFrame, rf=0.02) -> dict:
        """
        输入 engine.export_results_csv 产生的 DataFrame
        """
        nav = daily_stats['total_assets']
        returns = daily_stats['daily_return']

        total_return = nav.iloc[-1] / nav.iloc[0] - 1
        annual_return = (1 + total_return) ** (252 / len(nav)) - 1
        annual_vol = returns.std() * np.sqrt(252)

        sharpe = (annual_return - rf) / annual_vol if annual_vol != 0 else 0

        # F-7 修复：Sortino 分母用下行偏差（全样本 + MAR=rf/252），不再用负收益子集的 std
        downside_vol = downside_deviation(returns, rf=rf)
        sortino = (annual_return - rf) / downside_vol if downside_vol and downside_vol > 0 else 0

        cum_max = nav.cummax()
        drawdown = (nav - cum_max) / cum_max
        max_drawdown = drawdown.min()

        calmar = annual_return / abs(max_drawdown) if max_drawdown != 0 else 0

        # F-8 修复：冻结资金也是"没在持仓里的钱"，漏掉会低估真实现金拖累
        cash_cols = [c for c in ("available_cash", "frozen_cash", "transit_cash")
                     if c in daily_stats.columns]
        avg_cash_ratio = (daily_stats[cash_cols].sum(axis=1)).mean() / daily_stats['total_assets'].mean()

        return {
            "累计收益": f"{total_return:.2%}",
            "年化收益": f"{annual_return:.2%}",
            "年化波动": f"{annual_vol:.2%}",
            "最大回撤": f"{max_drawdown:.2%}",
            "夏普比率": f"{sharpe:.2f}",
            "索提诺比率": f"{sortino:.2f}",
            "卡玛比率": f"{calmar:.2f}",
            "平均现金占比": f"{avg_cash_ratio:.2%}",
            "运行天数": len(nav)
        }
