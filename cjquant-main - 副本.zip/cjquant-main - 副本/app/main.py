import os
import sys
import json
import math
import time
import threading
import asyncio
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from cjquant.optimizer.traditional import RiskParityOptimizer, MeanVarianceOptimizer
from cjquant.optimizer.machine_learning import HRPOptimizer
from cjquant.data.providers.public import PublicFundProvider
from cjquant.data.exceptions import FundNoNavPageError
from cjquant.data.fund_master import default_master
from cjquant.data.pipeline import DataPipeline
from cjquant.execution import export_plan

# -------------------- 统一取数入口 --------------------
# 【2026-09-26】三个接口原先各建各的 provider/pipeline：
#   refresh_navs       每次 new DataPipeline（有 .cache，但没有跨请求复用）
#   get_real_returns   new PublicFundProvider —— **绕过 DataPipeline**，
#                      因此读不到 market.db / nav_bulk.db，研究页只能在
#                      .cache 里那几只基金上算，与其余页面看到的世界不一致
#   provider_auto_list new PublicFundProvider()（无 cache_dir）—— 正是
#                      refresh_navs 文档里点名批评的"裸 provider"，每次真联网
# 统一到这里后：共用一条读取链（market.db → nav_bulk → .cache → 联网），
# 也共用统一访问层的连接池与进程内缓存。
_PIPELINE_LOCK = threading.Lock()
_PIPELINE = None


def get_pipeline() -> DataPipeline:
    """进程内共享的 DataPipeline（懒加载 + 线程安全）。

    为什么不每次新建：DataPipeline 持有 market.db / nav_bulk 的连接，
    每次 new 都会重连一遍；统一层的进程内缓存也依赖**同一个实例**才生效。
    """
    global _PIPELINE
    with _PIPELINE_LOCK:
        if _PIPELINE is None:
            _PIPELINE = DataPipeline(
                cache_dir=os.path.join(os.path.dirname(BASE_DIR), ".cache", "cjquant"),
                adjust=True,
            )
        return _PIPELINE


app = FastAPI(title="CJQuant OTC Strategy & Portfolio Terminal")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STRATEGIES_DIR = os.path.join(BASE_DIR, "strategies")
LOGS_DIR = os.path.join(BASE_DIR, "logs")
# 每日决策记录（由调度任务落盘的 JSON），供前端「决策」页签读取
DECISIONS_DIR = os.path.join(BASE_DIR, "decisions")
# 下单文件（O32 / 微信）的产出目录。
# ⚠️ 必须与 `sync_exported_orders_to_portfolio()` 的扫描目录**保持同一个值**：
#    一边产出、另一边扫描，目录不一致就会出现"出了单但流水永远收不回来"。
#    以前两者都指项目根目录，导致下单文件散落在根目录、与源码混在一起；
#    现在统一收到 app/orders/ 下（OTCExecutor.execute 会自建目录）。
ORDER_OUTPUT_DIR = os.path.join(BASE_DIR, "orders")
# 回测运行记录（每次 /api/analytics/backtest 成功后落盘），供前端「历史回测」查看。
# 起因：回测结果原来只在响应里返回、不落任何盘（run_backtest 零写文件），
# 跑完一刷新就查不到了，连"我最近一次回测是什么结果"都答不上来。
BACKTESTS_DIR = os.path.join(BASE_DIR, "backtests")
TASKS_JSON = os.path.join(BASE_DIR, "tasks.json")
PORTFOLIO_JSON = os.path.join(BASE_DIR, "portfolio.json")

# Ensure directories exist
os.makedirs(STRATEGIES_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

def robust_corr(rets: pd.DataFrame) -> pd.DataFrame:
    """零方差列免疫的相关矩阵。

    `DataFrame.corr()` 走 `np.corrcoef`，内部 `c /= stddev[:, None]`；
    只要有一列收益率恒为 0（**货币基金**净值钉在 1.0、或净值停更被清洗成常数），
    就是 0/0 → 整行整列 NaN，并往日志刷
        RuntimeWarning: invalid value encountered in divide
    退化列与其他列的相关系数定义为 0（无信息）、对角线为 1。
    """
    if rets is None or rets.empty or rets.shape[1] < 2:
        return pd.DataFrame()
    r = rets.replace([np.inf, -np.inf], np.nan)
    cols = list(r.columns)
    std = r.std()
    degenerate = [c for c in cols
                  if not np.isfinite(float(std.get(c, np.nan)))
                  or float(std.get(c, 0.0)) <= 0.0]
    valid = [c for c in cols if c not in set(degenerate)]
    out = pd.DataFrame(0.0, index=cols, columns=cols)
    if len(valid) >= 2:
        with np.errstate(invalid="ignore", divide="ignore"):
            out.loc[valid, valid] = r[valid].corr().values
    for c in cols:
        out.loc[c, c] = 1.0
    return out.replace([np.inf, -np.inf], 0.0).fillna(0.0).clip(-1.0, 1.0)


# ----------------- JSON 安全 -----------------
def sanitize_json(obj: Any) -> Any:
    """把 NaN / ±Inf 递归换成 None。

    ⚠️ 为什么必须有：Starlette 的 JSONResponse 用 `allow_nan=False` 序列化，
    响应里只要有一个 float('nan')，整个接口直接抛 ValueError → HTTP 500。
    实测：漏斗决策记录的 diagnostics.per_pool.*.avg_corr 就是 NaN
    （子池不足 2 只时 pool_avg_corr 返回 nan），于是 /api/decisions 整页打不开。

    Python 的 json.load 能读回裸 NaN 字面量，但浏览器的 JSON.parse 不行，
    所以这个文件对前端而言已经是非法 JSON —— 必须在服务端这一层兜住。
    """
    if isinstance(obj, dict):
        return {k: sanitize_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [sanitize_json(v) for v in obj]
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, (np.floating,)):
        v = float(obj)
        return v if math.isfinite(v) else None
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, (pd.Timestamp, datetime)):
        return str(obj)
    return obj


# Helper to load tasks
def load_tasks() -> List[Dict[str, Any]]:
    if not os.path.exists(TASKS_JSON):
        return []
    try:
        with open(TASKS_JSON, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

# Helper to save tasks
def save_tasks(tasks: List[Dict[str, Any]]):
    with open(TASKS_JSON, "w", encoding="utf-8") as f:
        json.dump(tasks, f, indent=2, ensure_ascii=False)

def _default_portfolio() -> Dict[str, Any]:
    return {"account_id": "55002038", "initial_cash": 0.0, "cash": 0.0,
            "positions": [], "total_value": 0.0, "pnl": 0.0, "transactions": []}


def _num(v, default: float = 0.0) -> float:
    """把任意入参安全转成有限 float；脏值（None/''/NaN/非数字）一律归零。"""
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    return f if math.isfinite(f) else default


def _normalize_portfolio(p: Any) -> Dict[str, Any]:
    """把读进来的 portfolio.json 强制整理成合法结构。

    ⚠️ 为什么必须做：「我的账户」页本身就是让用户在表格里直接改份额/现值的，
    portfolio.json 也完全可能被手改或第三方写坏。实测三种脏数据都能让
    /api/portfolio 直接 500，整个账户页打不开：
        positions 条目缺 current_nav          → KeyError
        positions 被写成字符串 "oops"          → TypeError: string indices
        整个 JSON 被写成数组 [1,2,3]           → TypeError: list indices
    这里按"能修就修、修不了就丢弃该条目"处理，保证接口永远返回可用结构。
    """
    if not isinstance(p, dict):
        return _default_portfolio()
    out = dict(_default_portfolio())
    out.update({k: v for k, v in p.items() if k in out})
    if not isinstance(out.get("positions"), list):
        out["positions"] = []
    if not isinstance(out.get("transactions"), list):
        out["transactions"] = []
    cleaned = []
    for pos in out["positions"]:
        if not isinstance(pos, dict):
            continue
        code = str(pos.get("fund_code") or "").strip()
        if not code:
            continue
        shares = _num(pos.get("shares"), 0.0)
        nav = _num(pos.get("current_nav"), 0.0)
        # 份额/净值为负是明显的脏数据（会让市值算出负的总资产），归零而不是照抄
        if shares < 0 or nav < 0:
            shares, nav = max(0.0, shares), max(0.0, nav)
        cleaned.append({
            "fund_code": code,
            "fund_name": str(pos.get("fund_name") or ""),
            "shares": round(shares, 4),
            "cost_nav": round(_num(pos.get("cost_nav"), 0.0), 4),
            "current_nav": round(nav, 4),
            "market_value": round(shares * nav, 2),
        })
    out["positions"] = cleaned
    out["cash"] = round(_num(out.get("cash"), 0.0), 2)
    out["initial_cash"] = round(_num(out.get("initial_cash"), 0.0), 2)
    return out


# Helper to load portfolio
def load_portfolio() -> Dict[str, Any]:
    if not os.path.exists(PORTFOLIO_JSON):
        return _default_portfolio()
    try:
        with open(PORTFOLIO_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return _default_portfolio()
    return _normalize_portfolio(data)

# Helper to save portfolio
def save_portfolio(p: Dict[str, Any]):
    with open(PORTFOLIO_JSON, "w", encoding="utf-8") as f:
        json.dump(p, f, indent=2, ensure_ascii=False)

# Active processes tracker: {task_name: Process}
active_processes: Dict[str, asyncio.subprocess.Process] = {}

# ----------------- BACKGROUND SCHEDULER -----------------
def _child_env() -> Dict[str, str]:
    """子进程环境变量：Windows 下子进程 stdout/stderr 默认走 GBK，
    父进程按 UTF-8 解码会产生乱码并丢字，故强制子进程以 UTF-8 输出。"""
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def _decode_subprocess_line(raw: bytes) -> str:
    """子进程输出解码：优先 UTF-8（已注入 PYTHONIOENCODING），失败回退 GBK。
    绝不静默丢字（历史实现用 errors='ignore'，把中文吞掉了）。"""
    for enc in ("utf-8", "gbk"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


async def run_task_process(task_name: str, script_name: str):
    """Executes the strategy script as a subprocess and streams output to logs"""
    log_file_path = os.path.join(LOGS_DIR, f"{task_name}.log")
    script_path = os.path.join(STRATEGIES_DIR, script_name)

    # 同一任务不允许并发跑两遍：手动「运行」+ 定时触发可能撞在一起，
    # 两个子进程同时写同一个日志文件、同时改 tasks.json，结果不可预期。
    if task_name in active_processes:
        print(f"[Scheduler] 任务 '{task_name}' 已在运行中，跳过本次触发")
        return

    # 1. Update task status to running
    tasks = load_tasks()
    for t in tasks:
        if t["name"] == task_name:
            t["status"] = "running"
            t["last_run"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            break
    save_tasks(tasks)

    print(f"[Scheduler] Starting task '{task_name}' -> subprocess '{script_name}'")
    try:
        # Create log file
        with open(log_file_path, "w", encoding="utf-8") as log_f:
            log_f.write(f"=== TASK START: {task_name} at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===\n")
            log_f.flush()

            # Launch process using python interpreter (pointing to root to preserve imports)
            proc = await asyncio.create_subprocess_exec(
                sys.executable, script_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=os.path.dirname(BASE_DIR),  # Run in cjquant root to allow modular imports
                env=_child_env(),
            )
            active_processes[task_name] = proc
            
            # Helper to stream output
            async def stream_output(stream, is_stderr=False):
                prefix = "[ERR] " if is_stderr else ""
                while True:
                    line = await stream.readline()
                    if not line:
                        break
                    decoded_line = _decode_subprocess_line(line)
                    log_f.write(f"{prefix}{decoded_line}")
                    log_f.flush()

            # Await both stdout and stderr streaming
            await asyncio.gather(
                stream_output(proc.stdout),
                stream_output(proc.stderr)
            )

            # Wait for exit
            exit_code = await proc.wait()
            log_f.write(f"\n=== TASK FINISHED: Exit code {exit_code} at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===\n")

        # 2. Update task status after completion
        tasks = load_tasks()
        for t in tasks:
            if t["name"] == task_name:
                t["status"] = "idle" if exit_code == 0 else "error"
                # Schedule next run if enabled
                if t["enabled"] and t["schedule_type"] == "interval":
                    next_time = datetime.now() + timedelta(seconds=t["schedule_value"])
                    t["next_run"] = next_time.strftime("%Y-%m-%d %H:%M:%S")
                break
        save_tasks(tasks)
        print(f"[Scheduler] Finished task '{task_name}' with code {exit_code}")
    except Exception as e:
        # Log scheduler exceptions
        with open(log_file_path, "a", encoding="utf-8") as log_f:
            log_f.write(f"\n[Scheduler Error] Failed to run task: {str(e)}\n")
        tasks = load_tasks()
        for t in tasks:
            if t["name"] == task_name:
                t["status"] = "error"
                break
        save_tasks(tasks)
        print(f"[Scheduler Exception] Task '{task_name}' failed: {e}")
    finally:
        active_processes.pop(task_name, None)

async def scheduler_loop():
    """Periodic loop to trigger enabled scheduler tasks"""
    print("[Scheduler] Starting scheduler background loop...")
    while True:
        try:
            tasks = load_tasks()
            now = datetime.now()
            modified = False
            
            for task in tasks:
                if not task["enabled"]:
                    continue
                
                # If status is running, skip
                if task["status"] == "running":
                    continue
                
                should_run = False
                # If next_run is not defined or is past, run it
                if not task["next_run"]:
                    should_run = True
                else:
                    try:
                        next_run_dt = datetime.strptime(task["next_run"], "%Y-%m-%d %H:%M:%S")
                        if now >= next_run_dt:
                            should_run = True
                    except Exception:
                        should_run = True
                
                if should_run:
                    # Trigger async
                    asyncio.create_task(run_task_process(task["name"], task["strategy_file"]))
                    # Update next run time
                    next_time = now + timedelta(seconds=task["schedule_value"])
                    task["next_run"] = next_time.strftime("%Y-%m-%d %H:%M:%S")
                    modified = True
            
            if modified:
                save_tasks(tasks)
                
        except Exception as e:
            print(f"[Scheduler Loop Error] {e}")
            
        await asyncio.sleep(5)

def _reset_stale_running() -> int:
    """启动时把残留的 status="running" 复位为 idle。

    ⚠️ 为什么必须有这一步：scheduler_loop 会 `continue` 跳过 running 的任务。
    若上次进程被杀（关窗口 / 崩溃 / 强停），tasks.json 里的 running 就永远留在盘上，
    重启后没有任何子进程在跑，但该任务再也不会被调度 —— 表现为"我明明启用了，
    它却再也不跑了"，且界面上看不出异常（状态一直是运行中）。
    实测 tasks.json 里就卡着两个这样的任务。
    """
    tasks = load_tasks()
    n = 0
    for t in tasks:
        if t.get("status") == "running":
            t["status"] = "idle"
            n += 1
    if n:
        save_tasks(tasks)
        print(f"[Startup] 复位 {n} 个残留 running 状态的任务（上次进程非正常退出）")
    return n


@app.on_event("startup")
async def startup_event():
    # 子进程不会跨进程存活：先清掉上次异常退出留下的 running 状态，否则任务被永久跳过
    try:
        _reset_stale_running()
    except Exception as e:
        print(f"[Startup] 复位任务状态失败: {e}")
    # 策略自注册优先于调度循环，保证 SCHEDULE 定义的任务存在
    try:
        _sync_strategy_tasks()
    except Exception as e:
        print(f"[Startup] 策略任务同步失败: {e}")
    # Start background scheduler
    asyncio.create_task(scheduler_loop())

# ----------------- CLOSED LOOP PORTFOLIO SYNC -----------------
def sync_exported_orders_to_portfolio():
    """
    Scans the execution directory for O32 and WeChat exported orders (e.g. *_o32.csv, *_wechat.csv),
    records them in the transaction log as exported trades,
    and moves/renames the files to prevent double processing.
    Does NOT automatically execute simulated fills to modify cash or holdings.
    """
    import glob
    # 与产出目录同一个常量（见 ORDER_OUTPUT_DIR 的注释：两处必须一致）
    root_dir = ORDER_OUTPUT_DIR
    if not os.path.isdir(root_dir):
        return
    o32_files = glob.glob(os.path.join(root_dir, "*_o32.csv"))
    wechat_files = glob.glob(os.path.join(root_dir, "*_wechat.csv"))
    
    portfolio = load_portfolio()
    if "transactions" not in portfolio:
        portfolio["transactions"] = []
        
    updated = False
    
    # Process O32 files
    for file_path in o32_files:
        if ".processed_" in file_path:
            continue
        try:
            print(f"[Portfolio Sync] Found O32 exported order file: {file_path}. Recording transactions...")
            df = pd.read_csv(file_path, encoding="gbk", dtype={"证券代码": str})
            for _, row in df.iterrows():
                raw_code = row["证券代码"]
                fund_code = f"{raw_code.zfill(6)}.OF"
                direction = row["业务类别"]
                order_value = float(row["委托金额"])
                order_shares = float(row["委托数量"])
                
                portfolio["transactions"].insert(0, {
                    "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "fund_code": fund_code,
                    "type": direction,
                    "amount": order_value if direction == "申购" else round(order_shares * 1.0, 2),
                    "shares": round(order_shares, 2),
                    "fee": 0.0,
                    "status": "已导出"
                })
            updated = True
            
            # Rename the file to prevent double-processing
            processed_path = file_path + f".processed_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            os.rename(file_path, processed_path)
            print(f"[Portfolio Sync] Processed and renamed O32 file: {processed_path}")
        except Exception as e:
            print(f"[Portfolio Sync Error] Failed to process O32 file {file_path}: {e}")
            
    # Process WeChat files
    for file_path in wechat_files:
        if ".processed_" in file_path:
            continue
        try:
            print(f"[Portfolio Sync] Found WeChat exported order file: {file_path}. Recording transactions...")
            df = pd.read_csv(file_path, encoding="utf-8-sig", dtype={"基金代码": str})
            for _, row in df.iterrows():
                raw_code = row["基金代码"]
                fund_code = f"{raw_code.zfill(6)}.OF"
                direction = row["交易类型"]
                amount = float(row["发生金额"])
                shares = float(row["发生份额"])
                
                portfolio["transactions"].insert(0, {
                    "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "fund_code": fund_code,
                    "type": direction,
                    "amount": amount,
                    "shares": round(shares, 2),
                    "fee": 0.0,
                    "status": "已导出"
                })
            updated = True
            
            # Rename the file to prevent double-processing
            processed_path = file_path + f".processed_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            os.rename(file_path, processed_path)
            print(f"[Portfolio Sync] Processed and renamed WeChat file: {processed_path}")
        except Exception as e:
            print(f"[Portfolio Sync Error] Failed to process WeChat file {file_path}: {e}")
            
    if updated:
        save_portfolio(portfolio)

# ----------------- PYDANTIC SCHEMAS -----------------
class TaskCreate(BaseModel):
    name: str
    strategy_file: str
    schedule_value: int

class StrategyCreate(BaseModel):
    name: str
    code: str

class StrategyUpdate(BaseModel):
    code: str

class OptimizeRequest(BaseModel):
    funds: List[str]
    method: str  # "RiskParity", "MeanVariance", "HRP"

class CorrelationRequest(BaseModel):
    funds: List[str]

class PerformanceRequest(BaseModel):
    funds: List[str]

class LookThroughRequest(BaseModel):
    weights: Dict[str, float]

class PositionItem(BaseModel):
    fund_code: str
    fund_name: str
    shares: float
    cost_nav: float
    current_nav: float

class PortfolioUpdateRequest(BaseModel):
    initial_cash: float
    cash: float
    pnl_override: Optional[float] = None
    positions: List[PositionItem]

class BacktestRequest(BaseModel):
    funds: Optional[List[str]] = None
    start_date: str
    end_date: str
    initial_cash: float
    rebalance_freq: str  # "once", "monthly", "monthly_rp" 或 "xxx.py"
    # 三期双轨制：steady=稳健线（默认）/ aggressive=进攻线（三期工程 §6）。
    # 策略模块是动态加载的，PROFILE 在 import 时读环境变量 —— 所以这里
    # 必须在加载前 set，加载后改环境变量不影响已加载的模块。
    profile: Optional[str] = None

# ----------------- API ENDPOINTS -----------------

# 1. Strategy Files Endpoint
def _iter_strategy_files() -> list:
    """递归列出策略文件（相对 app/strategies 的 posix 路径）。

    策略库分层后（app/strategies/<组名>/*.py）不能再只看第一层。
    跳过 __pycache__ 等目录，排除组描述文件 group.json。
    """
    out = []
    for dp, dns, fns in os.walk(STRATEGIES_DIR):
        dns[:] = sorted(d for d in dns if not d.startswith("__") and not d.startswith("."))
        for fn in sorted(fns):
            if not fn.endswith(".py"):
                continue
            # ⚠️ 跳过 `_` 开头的私有模块（如 data_ops/_common.py）：
            # 它们是库不是策略入口，扫进来后 _parse_strategy_meta 解析不到
            # SCHEDULE/handle_bar，前端会显示成"xxx.py (未识别)"，
            # 用户会以为策略文件放错了目录。
            if fn.startswith("_"):
                continue
            rel = os.path.relpath(os.path.join(dp, fn), STRATEGIES_DIR).replace("\\", "/")
            out.append(rel)
    return sorted(out)


def _group_of(rel_path: str) -> str:
    """相对路径 -> 组目录名。根目录下的文件返回空串。"""
    parts = rel_path.split("/")
    return parts[0] if len(parts) > 1 else ""


def _load_group_meta(group: str) -> Dict[str, Any]:
    """读组目录下的 group.json（显示名/说明）。缺失时用目录名兜底。"""
    if not group:
        return {"dir": "", "name": "未分组", "desc": ""}
    meta: Dict[str, Any] = {"dir": group, "name": group, "desc": ""}
    try:
        with open(os.path.join(STRATEGIES_DIR, group, "group.json"), encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            meta["name"] = d.get("name") or group
            meta["desc"] = d.get("desc") or ""
            if d.get("order") is not None:
                meta["order"] = d.get("order")
    except Exception:
        pass
    return meta


@app.get("/api/strategies")
def list_strategies():
    """List strategy files inside app/strategies (含分组子目录)"""
    return {"strategies": _iter_strategy_files()}


@app.get("/api/strategy_groups")
def list_strategy_groups():
    """策略组清单（供回测/调度/决策中心按组筛选）。

    数据来源：app/strategies/<组>/group.json + 组内 .py 文件。
    组 = 一个可独立运行/回测的策略集合（如"多因子动量轮动"含回测插件与日报任务）。
    """
    groups: Dict[str, Dict[str, Any]] = {}
    for rel in _iter_strategy_files():
        g = _group_of(rel)
        key = g or ""
        if key not in groups:
            groups[key] = _load_group_meta(g)
            groups[key]["files"] = []
        try:
            with open(os.path.join(STRATEGIES_DIR, rel), encoding="utf-8") as f:
                meta = _parse_strategy_meta(f.read())
        except Exception:
            meta = {"kind": "unknown"}
        groups[key]["files"].append({
            "name": rel,
            "file": rel.split("/")[-1],
            "kind": meta.get("kind", "unknown"),
            "schedule": meta.get("schedule"),
            "defines_universe": meta.get("defines_universe", False),
            "candidates": meta.get("candidates", []),
        })
    ordered = sorted(groups.values(), key=lambda x: (x.get("order", 99), x["dir"]))
    return {"groups": ordered, "total": len(ordered)}


@app.get("/api/strategies_with_meta")
def list_strategies_with_meta():
    """带 kind/universe/schedule/group 的列表，供回测/调度下拉按类型过滤并按组分组。"""
    out = []
    try:
        files = _iter_strategy_files()
    except Exception:
        return {"strategies": out}
    for fn in files:
        try:
            with open(os.path.join(STRATEGIES_DIR, fn), "r", encoding="utf-8") as f:
                meta = _parse_strategy_meta(f.read())
            meta["name"] = fn
            meta["group"] = _group_of(fn)
            meta["group_name"] = _load_group_meta(meta["group"])["name"]
            out.append(meta)
        except Exception:
            out.append({"name": fn, "kind": "unknown", "group": _group_of(fn)})
    return {"strategies": out}

@app.get("/api/strategies/{name:path}/meta")
def get_strategy_meta(name: str):
    """返回策略是否自带候选池。defines_universe=True 时回测标的由策略决定，前端须锁定输入。"""
    path = os.path.join(STRATEGIES_DIR, name)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Strategy not found")
    with open(path, "r", encoding="utf-8") as f:
        code = f.read()
    meta = _parse_strategy_meta(code)
    meta["name"] = name
    return meta

# 注意：本路由必须注册在 /api/strategies/{name:path} 之前。
# {name:path} 会匹配斜杠，若它在前，请求 ".../xxx.py/meta" 会被它先截获、把 name 解析成
# "xxx.py/meta" 然后 404 —— 这正是本接口长期不可达、前端「自动锁定标的框」从未生效的原因。
@app.get("/api/strategies/{name:path}")
def get_strategy_content(name: str):
    """Retrieve python strategy contents"""
    path = os.path.join(STRATEGIES_DIR, name)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Strategy not found")
    with open(path, "r", encoding="utf-8") as f:
        return {"name": name, "code": f.read()}

@app.put("/api/strategies/{name:path}")
def update_strategy_content(name: str, payload: StrategyUpdate):
    """Overwrite python strategy content"""
    path = os.path.join(STRATEGIES_DIR, name)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Strategy not found")
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(payload.code)
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def _parse_strategy_meta(code: str) -> Dict[str, Any]:
    """AST 静态解析策略元信息（不执行代码，供前端决定标的池/类型归属）。"""
    import ast
    meta: Dict[str, Any] = {
        "defines_universe": False, "candidates": [], "top_n": None,
        "has_handle_bar": False, "has_task_entry": False, "kind": "unknown",
        "schedule": None, "universe_filter": None,
        "dynamic_universe": False, "universe_limit": None,
    }
    try:
        tree = ast.parse(code)
    except Exception:
        return meta
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name) and t.id in ("CANDIDATES", "UNIVERSE"):
                    try:
                        vals = ast.literal_eval(node.value)
                        if isinstance(vals, (list, tuple)):
                            meta["candidates"] = [str(x) for x in vals]
                            meta["defines_universe"] = len(meta["candidates"]) > 0
                    except Exception:
                        pass
                if isinstance(t, ast.Name) and t.id == "TOP_N":
                    try:
                        meta["top_n"] = int(ast.literal_eval(node.value))
                    except Exception:
                        pass
                if isinstance(t, ast.Name) and t.id in ("SCHEDULE", "TASK_SCHEDULE"):
                    try:
                        sched = ast.literal_eval(node.value)
                        if isinstance(sched, dict):
                            meta["schedule"] = sched
                    except Exception:
                        pass
                if isinstance(t, ast.Name) and t.id == "UNIVERSE_FILTER":
                    try:
                        uf = ast.literal_eval(node.value)
                        if isinstance(uf, dict):
                            meta["universe_filter"] = uf
                            meta["defines_universe"] = True
                    except Exception:
                        pass
                if isinstance(t, ast.Name) and t.id == "UNIVERSE_SIZE":
                    try:
                        meta["universe_limit"] = int(ast.literal_eval(node.value))
                    except Exception:
                        pass
        if isinstance(node, ast.FunctionDef) and node.name == "handle_bar":
            meta["has_handle_bar"] = True
        if isinstance(node, ast.FunctionDef) and node.name == "get_universe":
            meta["defines_universe"] = True
            meta["dynamic_universe"] = True
        if isinstance(node, ast.FunctionDef) and node.name in ("run_strategy", "run_monitor", "run", "main"):
            meta["has_task_entry"] = True
    # kind 判定：回测插件必须有 handle_bar；调度任务必须有入口函数
    if meta["has_handle_bar"] and meta["has_task_entry"]:
        meta["kind"] = "both"
    elif meta["has_handle_bar"]:
        meta["kind"] = "backtest"
    elif meta["has_task_entry"]:
        meta["kind"] = "task"
    return meta

@app.post("/api/strategies/create")
def create_strategy(payload: StrategyCreate):
    """Create new empty python strategy"""
    if not payload.name.endswith(".py"):
        filename = payload.name + ".py"
    else:
        filename = payload.name
        
    path = os.path.join(STRATEGIES_DIR, filename)
    if os.path.exists(path):
        raise HTTPException(status_code=400, detail="Strategy file already exists")
    try:
        # 支持 "策略组/新策略.py"：父目录（策略组）不存在时自动创建
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(payload.code)
        return {"status": "success", "filename": filename}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# 2. Tasks Scheduler Endpoint
@app.get("/api/tasks")
def list_tasks():
    return load_tasks()

def _sync_strategy_tasks() -> Dict[str, Any]:
    """策略自注册：扫描 SCHEDULE/TASK_SCHEDULE，自动写入 tasks.json。

    约定（任选其一）：
      SCHEDULE = {"name": "每日多因子", "interval": 86400}
      SCHEDULE = {"name": "...", "schedule_value": 86400, "enabled": True}
    已存在同名任务则只补 strategy_file/interval，不覆盖 enabled/status。
    无 SCHEDULE 的 task 类文件不自动注册（保持手动创建入口）。
    """
    try:
        files = _iter_strategy_files()
    except Exception as e:
        return {"synced": 0, "error": str(e)}
    tasks = load_tasks()
    by_name = {t.get("name"): t for t in tasks}
    synced = 0
    for fn in files:
        try:
            with open(os.path.join(STRATEGIES_DIR, fn), "r", encoding="utf-8") as f:
                meta = _parse_strategy_meta(f.read())
        except Exception:
            continue
        sched = meta.get("schedule")
        if not isinstance(sched, dict):
            continue
        tname = sched.get("name") or fn.replace(".py", "")
        interval = sched.get("interval", sched.get("schedule_value", 86400))
        try:
            interval = int(interval)
        except Exception:
            interval = 86400
        if interval < 5:
            interval = 5
        if tname in by_name:
            # 补齐文件指向与间隔，不动开关与状态
            by_name[tname]["strategy_file"] = fn
            by_name[tname]["schedule_value"] = interval
            by_name[tname].setdefault("schedule_type", "interval")
        else:
            tasks.append({
                "name": tname,
                "strategy_file": fn,
                "schedule_type": "interval",
                "schedule_value": interval,
                "enabled": bool(sched.get("enabled", False)),
                "status": "idle",
                "last_run": None,
                "next_run": None,
                "auto_registered": True,
            })
            by_name[tname] = tasks[-1]
        synced += 1

    # 清理「策略文件已不在磁盘上」的僵尸条目。
    # ⚠️ 自注册只增不删，所以归档/删除一个策略之后，tasks.json 里会留下指向
    #    不存在文件的条目：调度器每轮都去加载它并报错，用户在前端只看到一条
    #    永远失败的记录，却不知道根因是"策略已经没了"。
    #    判据用「文件是否真实存在」，而不是 _iter_strategy_files() 的结果 ——
    #    后者只扫归它管的范围，拿它当白名单会误删手动创建的任务。
    alive, ghosts = [], []
    for t in tasks:
        sf = str(t.get("strategy_file") or "")
        if not sf or os.path.exists(os.path.join(STRATEGIES_DIR, sf)):
            alive.append(t)
        else:
            ghosts.append(t.get("name"))
    if ghosts:
        print(f"[Startup] 清理 {len(ghosts)} 个僵尸任务（策略文件已不存在）: {ghosts}")
        tasks = alive

    save_tasks(tasks)
    return {"synced": synced, "total": len(tasks), "removed": ghosts}

@app.post("/api/tasks/sync")
def sync_strategy_tasks():
    """手动触发策略自注册同步（前端调度页加载时也会调）。"""
    return _sync_strategy_tasks()

@app.post("/api/tasks")
def create_task(task: TaskCreate):
    tasks = load_tasks()
    # Check if duplicate name
    if any(t["name"] == task.name for t in tasks):
        raise HTTPException(status_code=400, detail="Task name already exists")
        
    new_task = {
        "name": task.name,
        "strategy_file": task.strategy_file,
        "schedule_type": "interval",
        "schedule_value": task.schedule_value,
        "enabled": False,
        "status": "idle",
        "last_run": None,
        "next_run": None
    }
    tasks.append(new_task)
    save_tasks(tasks)
    return new_task

@app.delete("/api/tasks/{name}")
def delete_task(name: str):
    tasks = load_tasks()
    filtered = [t for t in tasks if t["name"] != name]
    if len(filtered) == len(tasks):
        raise HTTPException(status_code=404, detail="Task not found")
    save_tasks(filtered)
    return {"status": "success"}

def provider_auto_list(uf: Dict[str, Any]) -> List[str]:
    """UNIVERSE_FILTER -> 自动化候选池（当前时点名单 + 每bar适格过滤保证时序正确）。

    uf 例：{"fund_type_contains": "混合", "limit": 30}
    注意：list_all_funds 是当前存续+历史全量中的当前可查名单，已清盘老基金可能缺失
    （幸存者偏差残留，需自建基金库解决）；未来基金在早期bar会被 MIN_HISTORY/适格过滤自动排除。
    """
    # 优先查基础库（全量名单已在本地，省一次网络请求）；库不可用才回退原接口
    try:
        m = default_master()
        if m is not None:
            hit = m.filter_codes(fund_type_contains=uf.get("fund_type_contains"),
                                 code_prefix=uf.get("code_prefix"),
                                 limit=int(uf.get("limit", 30)))
            if hit:
                return hit
    except Exception as e:
        print(f"基础库候选池查询失败，回退接口: {e}")

    # 【2026-09-26】这里原是 `PublicFundProvider()` —— **没有任何 cache_dir**，
    # 正是 refresh_navs 文档里点名批评的写法：每次调用都真联网，
    # 且拿不到 FundMasterUpdater 已经写好的本地名单优化路径。
    # 本地（基础库）都查不到才联网；且给 provider 配上 cache_dir，
    # 避免同一个进程里重复拉全市场名单（现在统一访问层也有进程内缓存兜底）。
    prov = PublicFundProvider(
        cache_dir=os.path.join(os.path.dirname(BASE_DIR), ".cache", "cjquant"))
    df = prov.list_all_funds()
    if df is None or df.empty:
        return []
    if uf.get("fund_type_contains"):
        key = str(uf["fund_type_contains"])
        col = "fund_type" if "fund_type" in df.columns else "基金类型"
        if col in df.columns:
            df = df[df[col].astype(str).str.contains(key, na=False)]
    if uf.get("code_prefix"):
        df = df[df["fund_code"].astype(str).str.startswith(str(uf["code_prefix"]))]
    df = df.sort_values("fund_code")
    limit = int(uf.get("limit", 30))
    return df["fund_code"].head(limit).tolist()

@app.post("/api/tasks/{name}/toggle")
def toggle_task(name: str):
    tasks = load_tasks()
    found = False
    for t in tasks:
        if t["name"] == name:
            t["enabled"] = not t["enabled"]
            if t["enabled"]:
                # Schedule next run immediately or offset
                t["next_run"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            else:
                t["next_run"] = None
                t["status"] = "idle"
            found = True
            break
    if not found:
        raise HTTPException(status_code=404, detail="Task not found")
    save_tasks(tasks)
    return {"status": "success", "enabled": t["enabled"]}

@app.post("/api/tasks/{name}/run")
async def run_task_immediately(name: str, background_tasks: BackgroundTasks):
    tasks = load_tasks()
    task_file = None
    for t in tasks:
        if t["name"] == name:
            task_file = t["strategy_file"]
            break
            
    if not task_file:
        raise HTTPException(status_code=404, detail="Task not found")

    # 已在跑就直接拒绝，避免重复下单文件 / 重复决策记录
    if name in active_processes:
        raise HTTPException(status_code=409, detail="该任务正在运行中，请稍后再试")

    # Trigger background process execution
    background_tasks.add_task(run_task_process, name, task_file)
    return {"status": "triggered"}

@app.get("/api/tasks/{name}/logs")
def get_task_logs(name: str):
    log_file = os.path.join(LOGS_DIR, f"{name}.log")
    if not os.path.exists(log_file):
        return {"logs": "--- 尚无运行日志 ---"}
    try:
        with open(log_file, "r", encoding="utf-8") as f:
            # Read last 300 lines
            lines = f.readlines()
            last_lines = lines[-300:]
            return {"logs": "".join(last_lines)}
    except Exception as e:
        return {"logs": f"读取日志出错: {str(e)}"}

# 3. Portfolio & Account holdings
@app.get("/api/decisions")
def list_decisions(limit: int = 30, group: str = None):
    """每日推送的决策记录（新→旧）。

    数据来源：调度任务每次跑完落盘的 app/decisions/decision_*.json。
    含 asof、策略组、候选池、可用池、完整打分排名、TopN、下单金额与产出文件。
    group: 可选，按策略组（目录名）过滤，供「决策中心」切换查看哪个策略组的决策。
    """
    items = []
    try:
        if os.path.isdir(DECISIONS_DIR):
            files = sorted([f for f in os.listdir(DECISIONS_DIR) if f.endswith(".json")],
                           reverse=True)
            for fn in files:
                try:
                    with open(os.path.join(DECISIONS_DIR, fn), encoding="utf-8") as f:
                        d = json.load(f)
                except Exception:
                    continue
                if group and str(d.get("group") or "") != group:
                    continue
                d["id"] = fn
                items.append(sanitize_json(d))
                if len(items) >= max(1, int(limit)):
                    break
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"决策记录读取失败: {e}")
    return {"decisions": items, "total": len(items), "group": group or ""}


class DecisionConfirmRequest(BaseModel):
    id: str          # 决策记录文件名（decision_*.json）
    confirm: bool    # 前端复选框的勾选状态，服务端强制校验


@app.post("/api/decisions/confirm")
def confirm_decision(req: DecisionConfirmRequest):
    """人工确认后，把「待确认」的调仓计划真正落成下单文件（申购 + 赎回）。

    调度任务产出的是 status=pending_confirm 的计划，**不会**自己出单；
    这里的 `confirm` 必须显式为 true —— 它就是前端那个复选框的服务端闸门，
    只调接口不勾选一律拒绝。出单用的是**确认时计划里存的内容**（份额/金额
    以用户看到的为准），不按当下持仓重算。
    """
    if not req.confirm:
        raise HTTPException(status_code=400,
                            detail="未勾选确认：请先勾选「我已核对并确认以下调仓」")
    # 只取文件名，防路径穿越
    fn = os.path.basename(str(req.id).strip())
    if not fn.endswith(".json"):
        fn += ".json"
    path = os.path.join(DECISIONS_DIR, fn)
    if not os.path.isfile(path):
        raise HTTPException(status_code=404, detail=f"决策记录不存在: {fn}")
    try:
        with open(path, encoding="utf-8") as f:
            rec = json.load(f)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"决策记录读取失败: {e}")
    if rec.get("status") != "pending_confirm":
        raise HTTPException(status_code=400,
                            detail=f"该记录状态为 {rec.get('status')}，不能确认出单")
    if not (rec.get("orders") or rec.get("orders_sell")):
        raise HTTPException(status_code=400, detail="该记录没有调仓计划（无申购也无赎回）")

    # 账户标识与调度任务同一套规则（account_id 非 0 才覆盖默认值）
    # ⚠️ 按策略分流：出单文件不能都叫同一个前缀，否则 O32 侧无法区分是哪套策略的单，
    #    对账时两套持仓会串在一起。
    #    注：多因子策略（mf_rotation）已于 2026-09-19 归档弃用（见 archive/README.md）。
    #    这里**保留**分流而不是删掉 —— 决策目录里还留着它此前产生的记录，
    #    保留下来的话那些历史记录仍能正确出单，且文件名前缀与存量对账口径一致。
    strat = str(rec.get("strategy") or "")
    is_funnel = ("funnel" in strat) or (str(rec.get("group") or "") == "fof_funnel")
    pid, unit = ("FOF_FUNNEL" if is_funnel else "FOF_MF"), "MF_01"
    file_prefix = "funnel_rotation" if is_funnel else "multifactor_topn"
    try:
        with open(os.path.join(BASE_DIR, "portfolio.json"), encoding="utf-8") as f:
            pf = json.load(f)
        if pf.get("account_id") and str(pf["account_id"]) != "0":
            pid = str(pf["account_id"])
    except Exception:
        pass

    try:
        out = export_plan(rec, portfolio_id=pid, asset_unit=unit,
                          output_dir=ORDER_OUTPUT_DIR,
                          file_prefix=file_prefix, channels=["o32"])
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"下单文件生成失败: {e}")

    rec["status"] = "ok"
    rec["confirmed"] = True
    rec["confirmed_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rec["files"] = {str(k): str(v) for k, v in (out or {}).items()}
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(rec, f, ensure_ascii=False, indent=2)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"决策记录回写失败: {e}")
    print(f"[决策确认] {fn} 已由人工确认出单："
          f"赎回 {len(rec.get('orders_sell') or [])} 只 / 申购 {len(rec.get('orders') or [])} 只 -> {rec['files']}")
    return {"status": "success", "record": rec}


def _portfolio_pnl(p: Dict[str, Any], total_val: float) -> float:
    """总盈亏：有初始资金就用总资产口径；没有就用持仓浮动盈亏兜底。

    ⚠️ 为什么不能直接 `total_value - initial_cash`：
        初始资金默认是 0（用户没填），于是总盈亏 == 总资产 ——
        截图上就是「总资产 4,000.09 / 总盈亏 +4,000.09」，
        看起来像"资金算法算错了"，其实只是拿 0 当基准。
        初始资金缺失时改用 Σ份额×(最新净值 − 成本净值)，这个指标永远有意义。
    """
    override = p.get("pnl_override")
    if override is not None:
        return round(_num(override, 0.0), 2)
    init_cash = _num(p.get("initial_cash"), 0.0)
    if init_cash > 0:
        return round(total_val - init_cash, 2)
    unrealized = 0.0
    for pos in (p.get("positions") or []):
        if not isinstance(pos, dict):
            continue
        sh = _num(pos.get("shares"), 0.0)
        cur, cost = _num(pos.get("current_nav"), 0.0), _num(pos.get("cost_nav"), 0.0)
        if sh > 0 and cost > 0:
            unrealized += sh * (cur - cost)
    return round(unrealized, 2)


@app.get("/api/portfolio")
def get_portfolio():
    # Sync first in case of recent exports
    sync_exported_orders_to_portfolio()
    
    portfolio = load_portfolio()

    # Recalculate totals dynamically
    # 【2026-09-26】原为 `pos["shares"] * pos["current_nav"]`：只要 portfolio.json
    # 里有一条脏数据（缺 shares / current_nav 或值为 None），这个被前端高频轮询的
    # 接口就直接 500，整个面板白屏。改成与 refresh_navs 一致的容错取值：
    # 读不出来就按 0 计并跳过，不让一条坏记录拖垮整页。
    total_val = _num(portfolio.get("cash"), 0.0)
    for pos in portfolio.get("positions", []):
        if not isinstance(pos, dict):
            continue
        pos["market_value"] = round(_num(pos.get("shares"), 0.0)
                                    * _num(pos.get("current_nav"), 0.0), 2)
        total_val += pos["market_value"]
        
    portfolio["total_value"] = round(total_val, 2)
    portfolio["pnl"] = _portfolio_pnl(portfolio, total_val)

    save_portfolio(portfolio)
    return portfolio

@app.post("/api/portfolio/update")
def update_portfolio(req: PortfolioUpdateRequest):
    portfolio = load_portfolio()
    portfolio["initial_cash"] = round(req.initial_cash, 2)
    portfolio["cash"] = round(req.cash, 2)
    portfolio["pnl_override"] = round(req.pnl_override, 2) if req.pnl_override is not None else None
    
    new_positions = []
    total_val = req.cash
    for pos in req.positions:
        mv = round(pos.shares * pos.current_nav, 2)
        total_val += mv
        new_positions.append({
            "fund_code": pos.fund_code,
            "fund_name": pos.fund_name,
            "shares": round(pos.shares, 4),
            "cost_nav": round(pos.cost_nav, 4),
            "current_nav": round(pos.current_nav, 4),
            "market_value": mv
        })
        
    portfolio["positions"] = new_positions
    portfolio["total_value"] = round(total_val, 2)
    portfolio["pnl"] = _portfolio_pnl(portfolio, total_val)

    save_portfolio(portfolio)
    return portfolio

@app.post("/api/portfolio/refresh_navs")
def refresh_navs():
    """刷新持仓最新净值。

    ⚠️ 走 DataPipeline（bulk 库 → 本地缓存 → 联网），不要裸 new PublicFundProvider()：
    裸 provider 没有 cache_dir，每只标的每次都真联网，持仓一多点这个接口就会卡住，
    而且读不到已经预热好的 nav_bulk.db（明明本地有数据还要联网）。
    """
    portfolio = load_portfolio()
    # 统一取数入口：跨请求复用同一条读取链，避免每次重连 + 重复联网
    pipe = get_pipeline()

    total_val = portfolio.get("cash", 0.0)
    failed = []

    for pos in portfolio.get("positions", []):
        code = str(pos.get("fund_code") or "").strip()
        if not code:
            continue
        try:
            df = pipe.get_public_fund(code, clean=True)
            if df is not None and not df.empty:
                # 场内净值展示用 unit_nav（用户看到的就是这个），收益计算才用 adj_nav
                col = "unit_nav" if "unit_nav" in df.columns else "adj_nav"
                latest = float(df[col].dropna().iloc[-1])
                if latest > 0:
                    pos["current_nav"] = round(latest, 4)
                    # ⚠️ 记录净值日期：场外基金净值是 T+1 发布的，用户看到"还是昨天的
                    # 净值"时，需要知道这是数据源的真实截止日，而不是程序没刷新。
                    # 没有这个字段，用户无法区分"没刷新"和"最新净值本就到昨天为止"。
                    nav_date = df.index[-1]
                    pos["nav_date"] = (nav_date.strftime("%Y-%m-%d")
                                       if hasattr(nav_date, "strftime")
                                       else str(nav_date)[:10])
                else:
                    failed.append(code)
            else:
                failed.append(code)
        except Exception as e:
            print(f"Error fetching NAV for fund {code}: {e}")
            failed.append(code)

        pos["market_value"] = round(float(pos.get("shares") or 0.0)
                                    * float(pos.get("current_nav") or 0.0), 2)
        total_val += pos["market_value"]

    portfolio["total_value"] = round(total_val, 2)
    portfolio["nav_updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    portfolio["pnl"] = _portfolio_pnl(portfolio, total_val)

    portfolio["nav_refresh_failed"] = failed
    save_portfolio(portfolio)
    return portfolio

def get_real_returns(funds: List[str], days: int = 252):
    """
    Fetches real historical returns.

    返回 (df, source, info)：
      df     列 = 实际参与计算的基金代码
      source "real"      请求的标的全部拿到真数据
             "partial"   部分标的无净值（已剔除，只用可用标的算）
             "simulated" 可用标的不足 2 只，退回随机数（调用方必须回显前端警示）
      info   {"used": [...], "excluded": [{"fund", "reason"}, ...]}

    历史行为是「只要 1 只失败就整池降级为随机数」—— 曾因投研页默认池里写死了
    000002.OF（华夏成长混合(后端)，数据源无独立净值页）导致 3 只标的全部变成
    模拟数据。现在改为部分可用就用可用的，并回报被剔除的标的与原因。
    """
    # 【2026-09-26】这里原先 `new PublicFundProvider(...).fetch()` —— **绕过了
    # DataPipeline**，于是读不到 market.db / nav_bulk.db 里那几百只已预热的基金，
    # 研究页的世界被限制在 .cache 那几只里，与持仓页/回测页看到的不一致。
    # 现在统一走 get_pipeline()；clean=False 是为了保持原语义（旧的裸 provider
    # 不做离群点清洗，直接算收益率）。
    pipe = get_pipeline()   # 走完整读取链（market.db → bulk → .cache → 联网）
    returns_dict = {}
    excluded = []

    end_date = datetime.now().strftime("%Y-%m-%d")
    start_date = (datetime.now() - timedelta(days=int(days * 1.5))).strftime("%Y-%m-%d")

    for code in funds:
        clean_code = code.split(".")[0]
        try:
            df = pipe.get_public_fund(clean_code, start_date=start_date,
                                      end_date=end_date, clean=False)
            if not df.empty and len(df) > 5:
                df_sorted = df.sort_index()
                rets = df_sorted['adj_nav'].pct_change().dropna()
                if len(rets) >= 10:
                    returns_dict[code] = rets
                    continue
            excluded.append({"fund": code,
                             "reason": "净值样本不足（<10 个交易日），不足以计算收益矩阵"})
        except FundNoNavPageError as e:
            excluded.append({"fund": code, "reason": str(e)})
            print(f"[Research Data Fetch] {code} 无独立净值页，已从计算中排除: {e}")
        except Exception as e:
            excluded.append({"fund": code, "reason": f"{type(e).__name__}: {e}"})
            print(f"[Research Data Fetch] Error fetching NAV for {code}: {e}")

    if len(returns_dict) >= 2:
        df_all = pd.DataFrame(returns_dict).dropna()
        if len(df_all) >= 10:
            used = list(df_all.columns)
            src = "real" if len(used) == len(funds) else "partial"
            return df_all.tail(days), src, {"used": used, "excluded": excluded}

    print(f"[Research Data Fetch] Fallback triggered. Simulating returns for funds: {funds}")
    np.random.seed(42)
    raw_ret = np.random.normal(0.0002, 0.012, size=(days, len(funds)))
    cov_matrix = np.eye(len(funds)) * 0.7 + 0.3
    correlated_ret = raw_ret @ np.linalg.cholesky(cov_matrix).T
    return (pd.DataFrame(correlated_ret, columns=funds),
            "simulated",
            {"used": list(funds), "excluded": excluded})


# 研究页默认标的池：以下代码均已联网核验东财有独立净值页（可取到净值）。
# 严禁放入「(后端)」份额（如 000002.OF 华夏成长混合(后端)）—— 它们没有独立净值页，
# 会把整个研究计算拖进随机数兜底。有本地净数据库时优先用库里已确认的标的。
DEFAULT_RESEARCH_FUNDS = ["000001.OF", "000003.OF", "110022.OF", "161725.OF", "000216.OF"]


def pick_default_research_funds(limit: int = 5) -> Dict[str, Any]:
    """挑一组「真的能取到净值」的默认标的：先查本地净数据库，库空才用静态核验名单。"""
    limit = max(2, int(limit))
    try:
        from cjquant.data.nav_bulk import NavBulkStore
        store = NavBulkStore(create=False)
        try:
            rows = list(store.conn.execute(
                "SELECT fund_code, rows FROM bulk_progress "
                "WHERE status = 'ok' AND COALESCE(rows, 0) >= 250 "
                "ORDER BY rows DESC LIMIT ?", (limit,)))
        finally:
            store.close()
        codes = [r["fund_code"] for r in rows]
        if len(codes) >= 2:
            return {"funds": codes, "source": "nav_bulk"}
    except Exception as e:
        print(f"默认研究标的池：本地净数据库不可用（{e}），回退核验名单")
    return {"funds": DEFAULT_RESEARCH_FUNDS[:limit], "source": "verified_list"}


@app.get("/api/analytics/default_funds")
def analytics_default_funds(limit: int = 5):
    """研究页默认标的池（保证每只都有净值可取）。"""
    return pick_default_research_funds(limit)


# 4. Analytics endpoints (Calls cjquant library)
@app.post("/api/analytics/optimize")
def run_optimization(req: OptimizeRequest):
    """Calculates risk allocation using the real cjquant optimizers and real data"""
    if len(req.funds) < 2:
        raise HTTPException(status_code=400, detail="Please select at least 2 funds for optimization")
        
    try:
        df_returns, _src, _info = get_real_returns(req.funds)
        
        if req.method == "RiskParity":
            opt = RiskParityOptimizer(df_returns)
            weights = opt.optimize()
        elif req.method == "MeanVariance":
            opt = MeanVarianceOptimizer(df_returns)
            weights = opt.optimize()
        elif req.method == "HRP":
            opt = HRPOptimizer(df_returns)
            weights = opt.optimize()
        else:
            raise HTTPException(status_code=400, detail="Invalid optimization method")
            
        # 权重必须与「实际参与计算的标的」对齐（被剔除的标的不能拿到权重占位）
        used = list(df_returns.columns)
        results = []
        for fund, w in zip(used, weights):
            results.append({"fund": fund, "weight": round(float(w), 6)})
            
        return {"weights": results, "method": req.method, "data_source": _src,
                "used_funds": used, "excluded": _info.get("excluded", [])}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Optimization failed: {str(e)}")

@app.post("/api/analytics/correlation")
def run_correlation(req: CorrelationRequest):
    if len(req.funds) < 2:
        raise HTTPException(status_code=400, detail="请选择至少 2 个基金进行相关性分析")
    try:
        df_returns, _src, _info = get_real_returns(req.funds)
        corr_matrix = robust_corr(df_returns).round(4)
        
        # 只输出参与了相关性计算的标的（被剔除的标的不能给 0 占位，那会被误读成"零相关"）
        used = list(df_returns.columns)
        results = []
        for fund in used:
            row = {"fund": fund}
            for other_fund in used:
                val = corr_matrix.loc[fund, other_fund] if (fund in corr_matrix.index and other_fund in corr_matrix.columns) else 0.0
                row[other_fund] = float(val)
            results.append(row)
            
        return {"correlation": results, "data_source": _src,
                "used_funds": used, "excluded": _info.get("excluded", [])}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"相关性计算失败: {str(e)}")

@app.post("/api/analytics/performance")
def run_performance(req: PerformanceRequest):
    if not req.funds:
        raise HTTPException(status_code=400, detail="请提供基金列表进行性能对比")
    try:
        df_returns, _src, _info = get_real_returns(req.funds)
        
        # 只统计有真实净值的标的：被剔除的标的不再输出 0 值行（那等于报"零收益零波动"）
        results = []
        for fund in list(df_returns.columns):

            rets = df_returns[fund]
            
            total_ret = (1.0 + rets).prod() - 1.0
            n_days = len(rets)
            ann_ret = (1.0 + total_ret) ** (252.0 / n_days) - 1.0 if n_days > 0 else 0.0
            
            vol = rets.std() * np.sqrt(252.0) if len(rets) > 1 else 0.0
            
            cum_nav = (1.0 + rets).cumprod()
            cum_max = cum_nav.cummax()
            drawdowns = (cum_nav - cum_max) / cum_max
            max_dd = float(drawdowns.min()) if not drawdowns.empty else 0.0
            
            rf = 0.02
            sharpe = (ann_ret - rf) / vol if vol > 0 else 0.0
            
            results.append({
                "fund": fund,
                "ann_return": round(float(ann_ret), 4),
                "volatility": round(float(vol), 4),
                "sharpe": round(float(sharpe), 4),
                "max_drawdown": round(float(max_dd), 4)
            })
            
        return {"performance": results, "data_source": _src,
                "used_funds": list(df_returns.columns),
                "excluded": _info.get("excluded", [])}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"业绩指标计算失败: {str(e)}")

@app.post("/api/analytics/look_through")
def run_look_through(req: LookThroughRequest):
    """真实季报穿透：行业来自天天基金行业配置（市值归一），风格为行业启发式（透明近似）。"""
    if not req.weights:
        raise HTTPException(status_code=400, detail="Portfolio weights must not be empty")
    try:
        from cjquant.look_through.holdings import RealHoldingsProvider
        prov = RealHoldingsProvider()
        wsum = sum(req.weights.values())
        if wsum <= 0:
            raise HTTPException(status_code=400, detail="权重和必须>0")
        norm = {k: float(v) / wsum for k, v in req.weights.items()}
        ind_tot: Dict[str, float] = {}
        sty_tot: Dict[str, float] = {}
        detail = {}
        sources = {}
        for code, w in norm.items():
            try:
                exp = prov.get_fund_exposure(code)
            except Exception as e:
                print(f"穿透拉取失败 {code}: {e}")
                exp = {"source": "empty", "industry": {}, "style": {}, "top_holdings": [], "quarter": ""}
            sources[code] = exp.get("source", "empty")
            detail[code] = {
                "quarter": exp.get("quarter", ""),
                "industry_date": exp.get("industry_date", ""),
                "source": exp.get("source", "empty"),
                "top_holdings": exp.get("top_holdings", [])[:10],
            }
            for k, v in (exp.get("industry") or {}).items():
                ind_tot[k] = ind_tot.get(k, 0) + float(v) * w
            for k, v in (exp.get("style") or {}).items():
                sty_tot[k] = sty_tot.get(k, 0) + float(v) * w
        real_n = sum(1 for s in sources.values() if s == "real")
        data_source = "real" if real_n == len(norm) else ("mixed" if real_n > 0 else "fallback")
        return {
            "industry": {k: round(v, 4) for k, v in sorted(ind_tot.items(), key=lambda x: -x[1])},
            "style": {k: round(v, 4) for k, v in sorted(sty_tot.items(), key=lambda x: -x[1])},
            "detail": detail,
            "data_source": data_source,
            "note": "行业=最新季报行业配置市值归一；风格=行业启发式（成长/价值/均衡/稳健），精确风格需Wind/申万二期。",
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Look-through failed: {str(e)}")


class BacktestContext:
    def __init__(self, engine):
        self._engine = engine
        self._reinvest_weights = None
        self.funds = list(self._engine.market_data['fund_code'].unique())
        # 基金基础库（基金库二期）：回测编排层在创建 context 后注入，
        # 策略插件用它查真实成立日/清盘日/规模 PIT。为 None 时插件必须降级为旧逻辑。
        self.master = None

    @property
    def current_date(self) -> datetime:
        return self._engine.current_date

    @property
    def current_date_idx(self) -> int:
        return self._engine.current_date_idx

    @property
    def cash(self) -> float:
        return self._engine.cash_account.available_cash

    @property
    def total_assets(self) -> float:
        """组合总资产 = 持仓市值 + 可用 + 冻结 + 在途。

        ⚠️ 为什么策略必须用这个而不是 `cash`：
            场外是 T+1 确认 / T+3 到账，下单后钱先进 frozen_cash、赎回后钱进
            transit_queue。这段窗口里 `available_cash` 接近 0，
            若用「市值 + available_cash」记权益曲线，日收益会出现 −100% / +∞ 的
            假跳变 → 已实现波动率被算到 30%+ → §7.4 波动率目标把杠杆压到下限
            0.30，组合长期只有三成仓位（实测：回测 L_t 从 1.00 掉到 0.30）。
        """
        mv = 0.0
        for code, pos in self._engine.positions.items():
            sh = float(getattr(pos, "total_shares", 0.0) or 0.0)
            if sh > 0:
                nav = self._engine._get_nav(code, self._engine.current_date)
                if nav:
                    mv += sh * float(nav)
        ca = self._engine.cash_account
        try:
            transit = float(sum(ca.transit_queue.values()))
        except Exception:
            transit = 0.0
        return mv + float(ca.available_cash) + float(getattr(ca, "frozen_cash", 0.0)) + transit

    @property
    def positions(self) -> Dict[str, float]:
        return {code: pos.total_shares for code, pos in self._engine.positions.items() if pos.total_shares > 0}

    def buy(self, fund_code: str, value: float):
        self._engine.submit_order(fund_code, 'BUY', value=value)

    # ---------- 费用感知的持有/卖出决策所需的持仓视图 ----------
    # 场外赎回费是**逐笔按 FIFO 批次**的持有自然日计费的，所以必须暴露批次，
    # 而不是只给一个"平均持有天数"。见 cjquant/backtest/hold_policy.py。
    def position_lots(self, fund_code: str):
        """返回 [(shares, confirm_date), ...]，供 hold_policy 做工批次加权赎费率。"""
        pos = self._engine.positions.get(fund_code)
        if pos is None:
            return []
        out = []
        for lot in getattr(pos, "lots", []) or []:
            sh = float(getattr(lot, "shares", 0.0) or 0.0)
            if sh > 0:
                out.append((sh, getattr(lot, "confirm_date", None)))
        return out

    def position_cost_nav(self, fund_code: str) -> Optional[float]:
        """按批次份额加权的买入单位成本；无持仓返回 None。"""
        pos = self._engine.positions.get(fund_code)
        if pos is None:
            return None
        total = 0.0
        cost = 0.0
        for lot in getattr(pos, "lots", []) or []:
            sh = float(getattr(lot, "shares", 0.0) or 0.0)
            if sh > 0:
                total += sh
                cost += sh * float(getattr(lot, "unit_cost", 0.0) or 0.0)
        return (cost / total) if total > 0 else None

    def position_loss_pct(self, fund_code: str) -> Optional[float]:
        """当前浮亏（小数，负数=亏损）：按最新可用净值与加权成本算；缺数据返回 None。"""
        cost = self.position_cost_nav(fund_code)
        if cost is None or cost <= 0:
            return None
        nav = self._engine._get_nav(fund_code, self._engine.current_date)
        if nav is None:
            return None
        return (nav / cost) - 1.0

    def sell_fee_rate_now(self, fund_code: str) -> float:
        """按当前 FIFO 批次算"赎回全部份额"的加权平均费率（费率的唯一来源在 fee 模型）。"""
        from cjquant.backtest.hold_policy import blended_redeem_fee_rate
        lots = self.position_lots(fund_code)
        if not lots:
            return 0.0
        asof = self._engine.current_date
        asof_d = asof.date() if hasattr(asof, "date") else asof
        return blended_redeem_fee_rate(lots, asof_d, self._engine.fee_model,
                                       fund_code=fund_code)

    def sell(self, fund_code: str, shares: float):
        self._engine.submit_order(fund_code, 'SELL', shares=shares)

    def get_nav(self, fund_code: str, date: datetime) -> Optional[float]:
        return self._engine._get_nav(fund_code, date)

    def get_history_navs(self, fund_code: str, count: int) -> pd.Series:
        mdata = self._engine.market_data
        subset = mdata[(mdata.index <= self.current_date) & (mdata['fund_code'] == fund_code)].sort_index()
        return subset['adj_nav'].tail(count)

    def get_history_navs_pit(self, fund_code: str, count: int) -> pd.Series:
        """PIT安全版：排除当前交易日（当日净值晚间才公布，策略只能见昨日及以前）。"""
        mdata = self._engine.market_data
        subset = mdata[(mdata.index < self.current_date) & (mdata['fund_code'] == fund_code)].sort_index()
        return subset['adj_nav'].tail(count)

    def rebalance(self, target_weights: Dict[str, float]):
        # Sell existing positions
        any_sold = False
        for code, pos in self._engine.positions.items():
            shares = pos.total_available_shares
            if shares > 0.001:
                self.sell(code, shares)
                any_sold = True
        
        transit_value = sum(self._engine.cash_account.transit_queue.values())
        if any_sold or transit_value > 0 or len(self._engine.pending_orders) > 0:
            self._reinvest_weights = target_weights
        else:
            # Buy immediately
            total_cash = self.cash
            if total_cash > 100.0:
                for code, w in target_weights.items():
                    if w > 0:
                        self.buy(code, total_cash * w)

    def rotate(self, target_weights: Dict[str, float]):
        """差集轮动（生产级）：持有不动，只卖跌出、只买新进。

        target_weights: 目标权重（只需含 TopN，等权或加权均可，内部归一）。
        仍在目标中的持仓不操作，节省赎回费 + 避免 T+3 空仓。
        新进买入复用 _reinvest 机制：若有在途/pending 则延迟到资金到账后按可用现金比例买入。
        """
        target_set = {c for c, w in target_weights.items() if w and w > 0}
        if not target_set:
            return
        held = {c for c, pos in self._engine.positions.items() if pos.total_shares > 0.001}
        to_sell = held - target_set
        to_buy = target_set - held
        for code in to_sell:
            pos = self._engine.positions.get(code)
            if pos is None:
                continue
            shares = pos.total_available_shares
            if shares > 0.001:
                try:
                    self.sell(code, shares)
                except Exception:
                    continue
        if not to_buy:
            return
        # 新进权重在 to_buy 子集内归一，交由主循环延迟买入
        sub = {c: float(target_weights[c]) for c in to_buy}
        s = sum(sub.values())
        if s <= 0:
            return
        sub = {k: v / s for k, v in sub.items()}
        transit_value = sum(self._engine.cash_account.transit_queue.values())
        has_pending = len(self._engine.pending_orders) > 0
        # 若有卖出（pending 含刚提交的 sell）或在途，延迟买入；否则立即按可用现金买入
        if has_pending or transit_value > 0:
            # 合并已有延迟买入（避免覆盖）
            if isinstance(self._reinvest_weights, dict):
                merged = dict(self._reinvest_weights)
                merged.update(sub)
                self._reinvest_weights = merged
            else:
                self._reinvest_weights = sub
        else:
            total_cash = self.cash
            if total_cash > 100.0:
                for code, w in sub.items():
                    self.buy(code, total_cash * w)


def _dump_backtest_record(payload: Dict[str, Any]) -> Optional[str]:
    """把一次回测的输入 + 结果落盘，供前端「历史回测」回看。

    失败只告警，**绝不影响回测响应**（同决策记录的取舍）。
    用 临时文件 + os.replace 落盘，避免半截 JSON。
    """
    try:
        os.makedirs(BACKTESTS_DIR, exist_ok=True)
        name = "bt_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json"
        payload["id"] = name
        path = os.path.join(BACKTESTS_DIR, name)
        tmp_path = path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False)
        os.replace(tmp_path, path)
        return name
    except Exception as e:
        print(f"[Backtest] 回测记录落盘失败（不影响本次结果）: {e}")
        return None


def _backtest_record_path(record_id: str) -> Optional[str]:
    """把记录 id 映射为磁盘路径；只允许 bt_*.json，防目录穿越。"""
    safe = os.path.basename(str(record_id or ""))
    if not safe.startswith("bt_") or not safe.endswith(".json"):
        return None
    p = os.path.join(BACKTESTS_DIR, safe)
    return p if os.path.exists(p) else None


@app.get("/api/backtests")
def list_backtests(limit: int = 20):
    """历史回测列表（新→旧）。

    默认**不返回** daily_stats / trades（明细可能上万行），
    需要明细时再用 GET /api/backtests/{id} 拉完整记录。
    """
    items = []
    try:
        if os.path.isdir(BACKTESTS_DIR):
            files = sorted([f for f in os.listdir(BACKTESTS_DIR)
                            if f.startswith("bt_") and f.endswith(".json")], reverse=True)
            for fn in files[:max(1, int(limit))]:
                try:
                    with open(os.path.join(BACKTESTS_DIR, fn), encoding="utf-8") as f:
                        d = json.load(f)
                except Exception:
                    continue          # 坏文件跳过，不炸列表
                d.pop("daily_stats", None)
                d.pop("trades", None)
                d["id"] = fn
                items.append(sanitize_json(d))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"回测记录读取失败: {e}")
    return {"backtests": items, "total": len(items)}


@app.get("/api/backtests/{record_id}")
def get_backtest_record(record_id: str):
    """取某次回测的完整记录（含每日明细与成交），用于前端复现整张结果页。"""
    path = _backtest_record_path(record_id)
    if not path:
        raise HTTPException(status_code=404, detail="回测记录不存在")
    try:
        with open(path, encoding="utf-8") as f:
            return sanitize_json(json.load(f))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"回测记录解析失败: {e}")


@app.get("/api/backtests/{record_id}/export")
def export_backtest_record(record_id: str):
    """回测数据**全量导出**（zip 包，供离线做全量归因）。

    包内：
      summary.json          输入参数 / 汇总指标 / 可信度标注 / 归因摘要
      daily_stats.csv       每日资产：现金三项 / 市值 / 总资产 / 外部现金流 /
                            当日收益 / 累计收益 / 水下深度 / 持仓占比
      trades.csv            全部成交：提交/确认/到账三日期 + 净值/份额/金额/费
      monthly_returns.csv   月度收益表（归因的天然粒度：一调仓一档）
      holdings_daily.csv    逐日逐标的市值矩阵（归因核心：谁在涨谁在跌）
      positions_final.csv   期末持仓快照

    为什么是 zip of CSV 而不是一个 Excel：CSV 无行数限制、可 diff、可被
    pandas/Excel/R 直接读；归因经常要 join 外部数据（指数、风格因子），
    CSV 比 xlsx 友好得多。
    """
    import io
    import zipfile
    import pandas as _pd

    path = _backtest_record_path(record_id)
    if not path:
        raise HTTPException(status_code=404, detail="回测记录不存在")
    try:
        with open(path, encoding="utf-8") as f:
            rec = json.load(f)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"回测记录解析失败: {e}")

    ds = rec.get("daily_stats") or []
    tr = rec.get("trades") or []
    hd = rec.get("holdings_daily") or []

    ds_df = _pd.DataFrame(ds)
    if not ds_df.empty and "total_assets" in ds_df.columns:
        ta = ds_df["total_assets"].astype(float)
        ds_df["daily_return"] = ta.pct_change().fillna(0.0).round(8)
        ds_df["cum_return"] = (ta / ta.iloc[0] - 1.0).round(8)
        ds_df["underwater"] = (ta / ta.cummax() - 1.0).round(8)
        inv_cols = [c for c in ("available_cash", "frozen_cash", "transit_cash")
                    if c in ds_df.columns]
        if inv_cols and "total_assets" in ds_df.columns:
            tot = ds_df[inv_cols].sum(axis=1) + ds_df.get("market_value", 0.0)
            ds_df["invested_ratio"] = (1.0 - (ds_df[inv_cols].sum(axis=1)
                                              / tot.replace(0.0, np.nan))).round(6)
            ds_df["invested_ratio"] = ds_df["invested_ratio"].fillna(0.0)
    if not ds_df.empty:
        # 必须先转 DatetimeIndex 再 resample；strftime 要放最后（否则月度收益表挂掉）
        ds_df["date"] = _pd.to_datetime(ds_df["date"])
        ds_df = ds_df.set_index("date")

    tr_df = _pd.DataFrame(tr)
    if not tr_df.empty and "date" in tr_df.columns:
        tr_df = tr_df.rename(columns={"date": "submit_date"})

    # 月度收益（复利链接；归因按月对齐调仓节奏）
    monthly = []
    if not ds_df.empty:
        m = ds_df["total_assets"].resample("ME").last()
        m0 = m.shift(1)
        first_val = float(ds_df["total_assets"].iloc[0])
        mr = (m / m0 - 1.0)
        if len(m):
            mr.iloc[0] = m.iloc[0] / first_val - 1.0
        monthly = [{"month": str(idx)[:7], "monthly_return": round(float(v), 8)}
                   for idx, v in mr.items() if v == v]   # v==v 过滤 NaN

    # 归因摘要（F-8 的"成本类"三项 + 换手；IR/超额需外部基准序列，见 README）
    attribution = {}
    if not ds_df.empty and not tr_df.empty:
        years = max(1e-9, len(ds_df) / 252.0)
        avg_assets = float(ds_df["total_assets"].mean())
        fee_total = float(tr_df.get("fee", 0).sum())
        turnover_gross = float(tr_df.get("volume", 0).sum())
        attribution = {
            "n_trades": int(len(tr_df)),
            "n_trading_days": int(len(ds_df)),
            "avg_total_assets": round(avg_assets, 2),
            "fee_total": round(fee_total, 2),
            "fee_ratio_of_avg_assets": round(fee_total / avg_assets, 6) if avg_assets else None,
            "fee_drag_annualized": round((fee_total / avg_assets) / years, 6)
                                   if avg_assets else None,
            "gross_turnover": round(turnover_gross, 2),
            "annual_turnover_ratio": round(turnover_gross / 2.0 / avg_assets / years, 4)
                                     if avg_assets else None,
            "fee_before_vs_after_note": ("费前/费后差的严格口径需要引擎同时记录免 "
                                         "费净值曲线；此处 fee_drag_annualized 为 "
                                         "费用/平均资产/年数的近似拖累。"),
        }
        if "invested_ratio" in ds_df.columns:
            attribution["avg_invested_ratio"] = round(float(ds_df["invested_ratio"].mean()), 6)

    summary_doc = {
        "request": rec.get("request"),
        "summary": rec.get("summary"),
        "caveats": rec.get("caveats"),
        "attribution": attribution,
        "universe_note": rec.get("request", {}).get("universe_note"),
    }

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("summary.json", json.dumps(summary_doc, ensure_ascii=False,
                                               indent=2, default=str))
        if not ds_df.empty:
            zf.writestr("daily_stats.csv", ds_df.to_csv(encoding="utf-8-sig"))
        if not tr_df.empty:
            zf.writestr("trades.csv", tr_df.to_csv(index=False, encoding="utf-8-sig"))
        if monthly:
            zf.writestr("monthly_returns.csv",
                        _pd.DataFrame(monthly).to_csv(index=False, encoding="utf-8-sig"))
        if hd:
            zf.writestr("holdings_daily.csv",
                        _pd.DataFrame(hd).to_csv(index=False, encoding="utf-8-sig"))
        # 期末持仓快照（从 holdings_daily 最后一行取）
        if hd:
            last = dict(hd[-1])
            last.pop("date", None)
            pos_final = [{"fund_code": c, "market_value": v}
                         for c, v in sorted(last.items(), key=lambda kv: -kv[1])]
            zf.writestr("positions_final.csv",
                        _pd.DataFrame(pos_final).to_csv(index=False, encoding="utf-8-sig"))
    buf.seek(0)

    # 同步落盘一份到 app/exports/：桌面壳（pywebview/WebView2）对 blob 下载的
    # 处理不可控（可能静默吞掉、或落到用户找不到的目录）。落一份到项目里，
    # 前端把绝对路径告诉用户 —— 文件一定在那里。
    zip_bytes = buf.getvalue()
    saved_path = None
    try:
        exports_dir = os.path.join(BASE_DIR, "exports")
        os.makedirs(exports_dir, exist_ok=True)
        safe_id = os.path.basename(str(record_id or "")).replace(".json", "") or "unknown"
        saved_path = os.path.join(exports_dir, f"backtest_{safe_id}.zip")
        with open(saved_path, "wb") as f:
            f.write(zip_bytes)
    except Exception as e:
        print(f"[Export] zip 落盘失败（不影响浏览器下载）: {e}")

    from fastapi.responses import Response as _Resp
    safe_id = os.path.basename(str(record_id or "")).replace(".json", "") or "unknown"
    fname = f"backtest_{safe_id}.zip"
    headers = {"Content-Disposition": f'attachment; filename="{fname}"'}
    if saved_path:
        headers["X-Export-Path"] = saved_path
    return _Resp(content=zip_bytes, media_type="application/zip", headers=headers)


# 5. FOF Backtest Endpoint
# 回测是 CPU 密集型同步请求（漏斗 278 只 × 逐月 RBSA，单次 1~3 分钟）。
# FastAPI 把 sync handler 丢进线程池，默认并发 40 —— 连点两次「运行回测」
# 或误刷新后再点，就会有两个 278 只的回测同时跑，互相抢 CPU 导致双双超时/卡死。
# 用一把锁串行化，第二个请求明确拒绝而不是一起变慢。
_BACKTEST_LOCK = threading.Lock()


@app.post("/api/analytics/backtest")
def run_backtest(req: BacktestRequest):
    if req.initial_cash <= 0:
        raise HTTPException(status_code=400, detail="初始资金必须大于 0")

    if not _BACKTEST_LOCK.acquire(blocking=False):
        raise HTTPException(status_code=409,
                            detail="已有一个回测正在运行，请等它结束（多标的策略通常需 1~3 分钟）再提交新的回测")
    try:
        return _run_backtest_locked(req)
    finally:
        _BACKTEST_LOCK.release()


def _run_backtest_locked(req: BacktestRequest):
        
    if req.start_date and req.end_date and str(req.start_date) > str(req.end_date):
        raise HTTPException(status_code=400,
                            detail=f"开始日期 {req.start_date} 晚于结束日期 {req.end_date}")

    try:
        from cjquant.backtest.engine import OTCBacktestEngine
        from cjquant.backtest.slippage import ZeroSlippage
        import importlib.util
        import uuid

        _t_start = time.time()

        # 0. 先判定是否为自定义策略（决定标的池归属）
        # 内置 once/monthly/monthly_rp -> 标的由用户填写
        # 自定义 xxx.py 且定义 CANDIDATES/UNIVERSE/get_universe -> 标的由策略决定，忽略用户输入
        is_user_strategy = False
        strategy_file = req.rebalance_freq
        init_func = None
        handle_bar_func = None
        strategy_module = None

        if strategy_file.endswith(".py") or os.path.exists(os.path.join(STRATEGIES_DIR, strategy_file)):
            is_user_strategy = True
            strategy_path = os.path.join(STRATEGIES_DIR, strategy_file)
            if not os.path.exists(strategy_path):
                strategy_path = strategy_file
                if not os.path.exists(strategy_path):
                    raise HTTPException(status_code=400, detail=f"策略文件未找到: {strategy_file}")
            try:
                # 三期双轨制：profile 在策略模块 import 时被读取，必须先设
                if req.profile:
                    os.environ["CJQ_FUNNEL_PROFILE"] = str(req.profile)
                spec = importlib.util.spec_from_file_location(f"user_strategy_{uuid.uuid4().hex}", strategy_path)
                strategy_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(strategy_module)
                # 用完即清：防止下一次未传 profile 的回测继承上一次的选择
                if req.profile:
                    os.environ.pop("CJQ_FUNNEL_PROFILE", None)
                init_func = getattr(strategy_module, "init", None)
                handle_bar_func = getattr(strategy_module, "handle_bar", None)
                if not handle_bar_func:
                    raise HTTPException(status_code=400, detail="策略文件必须定义 handle_bar(context) 函数")
            except Exception as se:
                raise HTTPException(status_code=400, detail=f"导入或执行策略文件失败: {str(se)}")

        # 0.1 解析有效标的池（策略优先，自动化池次之，用户最后）
        # 优先级：get_universe(start,end) > CANDIDATES/UNIVERSE > UNIVERSE_FILTER(自动) > req.funds
        # 2020回测含2026基金是安全的：策略每bar按 PIT 历史<180剔除 + DynamicUniverse 适格过滤，
        # 未来基金在早期bar自动排除，不产生持仓；仅多一次拉数开销（有缓存）。
        effective_funds = list(req.funds or [])
        universe_source = "user"
        universe_note = ""
        if is_user_strategy and strategy_module is not None:
            resolved = None
            if callable(getattr(strategy_module, "get_universe", None)):
                try:
                    try:
                        got = strategy_module.get_universe(req.start_date, req.end_date)
                    except TypeError:
                        got = strategy_module.get_universe()
                    if isinstance(got, (list, tuple)) and len(got) > 0:
                        resolved = [str(x) for x in got]
                        universe_note = f"动态池 get_universe() -> {len(resolved)} 只"
                    else:
                        universe_note = "动态池 get_universe() 返回空，回退 CANDIDATES"
                except Exception as ue:
                    print(f"策略 get_universe() 调用失败，回退下一级: {ue}")
                    universe_note = f"动态池 get_universe() 失败({ue})，回退 CANDIDATES"
            if resolved is None:
                strat_cands = getattr(strategy_module, "CANDIDATES", None) or getattr(strategy_module, "UNIVERSE", None)
                if isinstance(strat_cands, (list, tuple)) and len(strat_cands) > 0:
                    resolved = [str(x) for x in strat_cands]
                    if not universe_note:
                        universe_note = f"CANDIDATES 静态池 -> {len(resolved)} 只"
            if resolved is None:
                uf = getattr(strategy_module, "UNIVERSE_FILTER", None)
                if isinstance(uf, dict):
                    try:
                        flist = provider_auto_list(uf)
                        if flist:
                            resolved = flist
                            universe_note = f"auto_filter={uf} -> {len(flist)} 只"
                    except Exception as ue:
                        print(f"UNIVERSE_FILTER 解析失败: {ue}")
            if resolved:
                effective_funds = resolved
                universe_source = "strategy"
        if not effective_funds:
            raise HTTPException(status_code=400, detail="标的池为空：自定义策略未定义 CANDIDATES 且用户未填写基金标的")
        
        # 1. Fetch public fund historical NAV data from EM (akshare)
        # 生产级：真复权 + 缓存 + 跳变清洗（与 DataPipeline 一致）
        # 预热期：策略算因子需要历史，但若数据窗口就等于回测窗口，
        # 第一根 bar 的历史为 0，MIN_HISTORY(180) 之类的门槛永远过不去 ——
        # 表现为「整个回测区间全部输出『候选不足，跳过』、一笔不成交」。
        # 这里把数据往前多取 WARMUP_DAYS 天，交易窗口仍从 req.start_date 开始。
        warmup_days = 0
        if is_user_strategy and strategy_module is not None:
            try:
                warmup_days = int(getattr(strategy_module, "WARMUP_DAYS", 400))
            except Exception:
                warmup_days = 400
            warmup_days = max(0, min(warmup_days, 3650))
        data_start = req.start_date
        if warmup_days > 0:
            try:
                data_start = (datetime.strptime(req.start_date, "%Y-%m-%d")
                              - timedelta(days=warmup_days)).strftime("%Y-%m-%d")
            except Exception:
                data_start = req.start_date
            print(f"[Backtest] 预热 {warmup_days} 天：数据自 {data_start} 取，交易窗口自 {req.start_date} 起")

        # ⚠️ 两点：
        #  1) 用绝对路径：相对 "./.cache/cjquant" 会随进程 CWD 漂移，
        #     从别处启动（桌面壳 / 其他目录起 uvicorn）就会另建一个空缓存目录，
        #     表现为"明明之前拉过，又全部重新联网"。
        #  2) 走 DataPipeline（bulk 库 → 缓存 → 联网）：nav_bulk.db 里已预热的标的
        #     直接本地命中。否则选了漏斗策略（278 只）会逐只真联网，几分钟出不来回测。
        from cjquant.data.pipeline import DataPipeline
        from cjquant.data.cleaner import FundDataCleaner
        _pipe = DataPipeline(cache_dir=os.path.join(os.path.dirname(BASE_DIR), ".cache", "cjquant"),
                             adjust=True)
        _cleaner = FundDataCleaner(outlier_threshold=0.15)
        dfs = []
        for code in effective_funds:
            try:
                df = _pipe.get_public_fund(code, start_date=data_start,
                                           end_date=req.end_date, clean=False)
                if df is None or df.empty:
                    continue
                try:
                    df, _rep = _cleaner.clean_single(df)
                except Exception as ce:
                    print(f"清洗跳过 {code}: {ce}")
                if not df.empty:
                    df['fund_code'] = code
                    dfs.append(df)
            except Exception as e:
                print(f"Error fetching data for {code} during backtest: {e}")
                
        if not dfs:
            raise HTTPException(status_code=400, detail="未获取到所选基金在指定日期区间内的任何历史净值数据。")

        # ---- 货币基金：合成现金收益曲线 ----
        # 东财对货币基金**不提供「单位净值走势」**（只给每万份收益 / 7日年化），
        # akshare 的 fund_money_fund_info_em 当前也是坏的（字段数不匹配），
        # 所以货币基金的历史净值序列在本数据源下拿不到。
        # 但"闲置现金放进货币基金生息"必须能回测 —— 否则占着大量现金只能按
        # 0 收益计，整条结论会系统性偏悲观。
        # 对现金而言合成误差可忽略：货币基金日收益≈0.005%、年化波动近乎为 0。
        # 实盘时用真实货币基金代码下单，收益按真实净值结算，无需合成。
        try:
            _mm_all = default_master().facts_for(effective_funds) or {}
        except Exception:
            _mm_all = {}
        _mm_codes = [c for c in effective_funds
                     if "货币" in str((_mm_all.get(c) or {}).get("fund_type") or "")
                     and c not in {str(d["fund_code"].iloc[0]) for d in dfs if len(d)}]
        if _mm_codes:
            _annual = float(os.environ.get("CJQ_CASH_ANNUAL", "0.018") or 0.018)
            _idx = pd.concat(dfs).index.unique().sort_values()
            _daily = (1.0 + _annual) ** (1.0 / 252.0) - 1.0
            _curve = np.cumprod(np.full(len(_idx), 1.0 + _daily))
            _synth = []
            for _c in _mm_codes:
                _synth.append(pd.DataFrame({
                    "fund_code": _c,
                    "unit_nav": 1.0,
                    "acc_nav": _curve,
                    "adj_nav": _curve,
                    "adj_method": "synthetic_cash",
                }, index=_idx))
            dfs.extend(_synth)
            print(f"[Backtest] 货币基金 {len(_mm_codes)} 只用**合成现金曲线**"
                  f"（年化 {_annual:.2%}）—— 数据源不提供货币基金单位净值走势：{_mm_codes}")

        market_data = pd.concat(dfs)
        
        # 2. Initialize Backtest Engine
        # 费率允许策略覆盖：BUY_FEE_RATE / SELL_TIERS，否则用默认（申购0.15%，赎回7天1.5%/30天0.75%/180天0.5%）
        engine = OTCBacktestEngine(
            market_data=market_data,
            initial_cash=req.initial_cash,
            t_plus_confirm=1,
            t_plus_settle=3,
            slippage_model=ZeroSlippage(),
            # 预热数据只用于策略取历史，下单与业绩统计仍严格从 req.start_date 开始
            trade_start=(req.start_date if warmup_days > 0 else None),
        )
        if is_user_strategy and strategy_module is not None:
            try:
                bfr = getattr(strategy_module, "BUY_FEE_RATE", None)
                if bfr is not None:
                    engine.fee_model.buy_fee_rate = float(bfr)
                st = getattr(strategy_module, "SELL_TIERS", None)
                if isinstance(st, (list, tuple)) and st:
                    engine.fee_model.set_sell_tiers([(int(d), float(r)) for d, r in st])
            except Exception as fe:
                print(f"策略费率覆盖失败，用默认: {fe}")

        # 货币基金免申赎费：全平台 0 申购费 + 0 赎回费（含快速赎回 T+0）。
        # 赎回阶梯里的"<7 天 1.5%"来自《流动性风险管理规定》第 9 条，
        # **只约束非货币基金**。不区分的话，策略把闲置现金放进货币基金生息，
        # 回测里会被套上 1.5% 的假成本 —— 结论会完全反过来。
        try:
            from cjquant.data.fund_master import default_master as _dm
            _mm = _dm()
            if _mm is not None:
                _facts = _mm.facts_for(effective_funds) or {}
                _mm_codes = [c for c, f in _facts.items()
                             if "货币" in str((f or {}).get("fund_type") or "")]
                if _mm_codes:
                    engine.fee_model.add_fee_free(_mm_codes)
                    print(f"[Backtest] 货币基金（现金载体）{len(_mm_codes)} 只已设为免申赎费")
        except Exception as fe:
            print(f"货币基金免费率登记失败（按普通费率）: {fe}")


        # 3. 策略模块已在步骤0加载，此处不再重复 import
        # 4. Simulate Rebalance Strategy Loop
        context = BacktestContext(engine)
        # 基金库二期：把基础库注入策略上下文（库不可用时为 None，插件自动降级）
        try:
            context.master = default_master()
        except Exception as me:
            print(f"基础库注入失败，按旧逻辑跑: {me}")
            context.master = None
        
        if is_user_strategy and init_func:
            try:
                init_func(context)
            except Exception as ie:
                raise HTTPException(status_code=500, detail=f"策略初始化失败 (init): {str(ie)}")
                
        last_month = None
        reinvest_weights = None
        
        while engine.current_date_idx < len(engine.trading_dates):
            current_date = engine.current_date
            
            # Reinvest if a previous monthly rebalance liquidation has settled (for both built-in & user strategy rebalance)
            active_reinvest_weights = context._reinvest_weights if is_user_strategy else reinvest_weights
            
            if active_reinvest_weights is not None:
                transit_value = sum(engine.cash_account.transit_queue.values())
                # If transit cash is fully settled and no pending transactions remain
                if transit_value == 0 and len(engine.pending_orders) == 0:
                    portfolio_value = engine.cash_account.available_cash
                    if portfolio_value > 100.0:
                        if isinstance(active_reinvest_weights, dict):
                            items = [(c, w) for c, w in active_reinvest_weights.items() if w > 0]
                            w_sum = sum(w for _, w in items)
                            if w_sum > 0:
                                allocated = 0.0
                                for i, (code, w) in enumerate(items):
                                    if i == len(items) - 1:
                                        buy_value = portfolio_value - allocated
                                    else:
                                        buy_value = round(portfolio_value * (w / w_sum), 6)
                                        allocated += buy_value
                                    if buy_value > 0.01:
                                        engine.submit_order(code, 'BUY', value=buy_value)
                        else:
                            # list format from built-in rebalance
                            w_sum = sum(active_reinvest_weights)
                            weights_norm = [w / w_sum for w in active_reinvest_weights]
                            allocated = 0.0
                            for i, (code, w) in enumerate(zip(effective_funds, weights_norm)):
                                if i == len(effective_funds) - 1:
                                    buy_value = portfolio_value - allocated
                                else:
                                    buy_value = round(portfolio_value * w, 6)
                                    allocated += buy_value
                                if buy_value > 0.01:
                                    engine.submit_order(code, 'BUY', value=buy_value)
                                
                        if is_user_strategy:
                            context._reinvest_weights = None
                        else:
                            reinvest_weights = None  # Reinvestment complete
            
            if is_user_strategy:
                try:
                    handle_bar_func(context)
                except Exception as hbe:
                    raise HTTPException(status_code=500, detail=f"策略运行报错 (handle_bar) 日期 {current_date.strftime('%Y-%m-%d')}: {str(hbe)}")
            else:
                is_first_step = (engine.current_date_idx == 0)
                is_new_month = (last_month is not None and current_date.month != last_month)
                
                if is_first_step:
                    # Initial buy-in: normalize weights to prevent float sum > 1.0
                    weights = [1.0 / len(effective_funds)] * len(effective_funds)
                    w_sum = sum(weights)
                    weights = [w / w_sum for w in weights]
                    portfolio_value = engine.cash_account.available_cash
                    allocated = 0.0
                    for i, (code, w) in enumerate(zip(effective_funds, weights)):
                        if i == len(effective_funds) - 1:
                            buy_value = portfolio_value - allocated  # remainder
                        else:
                            buy_value = round(portfolio_value * w, 6)
                            allocated += buy_value
                        if buy_value > 0.01:
                            engine.submit_order(code, 'BUY', value=buy_value)
                
                elif is_new_month and (req.rebalance_freq in ["monthly", "monthly_rp"]):
                    # Calculate new target weights
                    if req.rebalance_freq == "monthly_rp":
                        try:
                            if engine.current_date_idx >= 10:
                                sub_returns = {}
                                for code in effective_funds:
                                    fund_df = market_data[market_data['fund_code'] == code]
                                    fund_df_sub = fund_df[fund_df.index < current_date]
                                    if not fund_df_sub.empty:
                                        sub_returns[code] = fund_df_sub['adj_nav'].pct_change().dropna()
                                df_sub_rets = pd.DataFrame(sub_returns).dropna()
                                if len(df_sub_rets) > 5:
                                    from cjquant.optimizer.traditional import RiskParityOptimizer
                                    opt = RiskParityOptimizer(df_sub_rets)
                                    weights = opt.optimize().tolist()
                                else:
                                    weights = [1.0 / len(effective_funds)] * len(effective_funds)
                            else:
                                weights = [1.0 / len(effective_funds)] * len(effective_funds)
                        except Exception:
                            weights = [1.0 / len(effective_funds)] * len(effective_funds)
                    else:
                        weights = [1.0 / len(effective_funds)] * len(effective_funds)
                    
                    # Sell all current positions
                    any_sold = False
                    for code, pos in engine.positions.items():
                        shares = pos.total_available_shares
                        if shares > 0.001:
                            engine.submit_order(code, 'SELL', shares=shares)
                            any_sold = True
                            
                    if any_sold:
                        reinvest_weights = weights
                    else:
                        # If cash-only, buy immediately
                        portfolio_value = engine.cash_account.available_cash
                        # Normalize and last-bucket remainder
                        w_sum = sum(weights)
                        weights_norm = [w / w_sum for w in weights]
                        allocated = 0.0
                        for i, (code, w) in enumerate(zip(effective_funds, weights_norm)):
                            if i == len(effective_funds) - 1:
                                buy_value = portfolio_value - allocated
                            else:
                                buy_value = round(portfolio_value * w, 6)
                                allocated += buy_value
                            if buy_value > 0.01:
                                engine.submit_order(code, 'BUY', value=buy_value)
            
            last_month = current_date.month
            engine.step()
            
        # 5. Formulate response payload
        trades = []
        for t in engine.trade_history:
            trades.append({
                "trade_id": t.trade_id,
                "order_id": t.order_id,
                "fund_code": t.fund_code,
                "direction": "买入" if t.direction == "BUY" else "卖出",
                "submit_date": t.submit_date.strftime("%Y-%m-%d"),
                "confirm_date": t.confirm_date.strftime("%Y-%m-%d"),
                "settle_date": t.settle_date.strftime("%Y-%m-%d"),
                "nav": round(float(t.confirm_nav), 4),
                "shares": round(float(t.filled_shares), 4),
                "volume": round(float(t.gross_amount), 2),
                "fee": round(float(t.fee), 2),
                "net_volume": round(float(t.net_amount), 2)
            })
            
        daily_stats = []
        for s in engine.daily_stats:
            ret = (s['total_assets'] / req.initial_cash) - 1.0
            daily_stats.append({
                "date": s['date'].strftime("%Y-%m-%d"),
                "available_cash": round(float(s['available_cash']), 2),
                "frozen_cash": round(float(s['frozen_cash']), 2),
                "transit_cash": round(float(s['transit_cash']), 2),
                "market_value": round(float(s['market_value']), 2),
                "total_assets": round(float(s['total_assets']), 2),
                # F-4：外部净现金流（回测恒 0；上线接定投后供 TWR）
                "cash_flow": round(float(s.get('cash_flow', 0.0)), 2),
                "return": round(float(ret), 6)
            })

        # 全量归因：逐日持仓市值分布（日期 × 标的市值）。只给总资产曲线的话，
        # "回撤是谁带来的"永远答不出来 —— 归因必须有逐标的的敞口序列。
        holdings_daily = []
        for row in engine.holdings_daily:
            hr = {"date": row["date"].strftime("%Y-%m-%d")}
            for code, mv in row.items():
                if code != "date":
                    hr[code] = round(float(mv), 2)
            holdings_daily.append(hr)

        if len(engine.daily_stats) > 1:
            total_ret = (engine.daily_stats[-1]['total_assets'] / req.initial_cash) - 1.0
            n_days = len(engine.daily_stats)
            ann_ret = (1.0 + total_ret) ** (252.0 / n_days) - 1.0 if n_days > 0 else 0.0
            
            assets_series = pd.Series([s['total_assets'] for s in engine.daily_stats])
            cum_max = assets_series.cummax()
            drawdowns = (assets_series - cum_max) / cum_max
            max_dd = float(drawdowns.min())
            
            daily_rets = assets_series.pct_change().dropna()
            std_dev = daily_rets.std()
            sharpe = (float(daily_rets.mean() * 252 - 0.02) / (float(std_dev * np.sqrt(252)))) if std_dev > 0 else 0.0
        else:
            total_ret = 0.0
            ann_ret = 0.0
            max_dd = 0.0
            sharpe = 0.0
            
        summary = {
            "total_return": round(total_ret, 6),
            "annualized_return": round(ann_ret, 6),
            "max_drawdown": round(max_dd, 6),
            "sharpe_ratio": round(sharpe, 4),
            "initial_cash": req.initial_cash,
            "final_assets": round(float(engine.daily_stats[-1]['total_assets']), 2) if engine.daily_stats else req.initial_cash
        }

        # L-5（三期工程 §6.4）：基准对比三选二，随结果一起落盘与展示。
        #   ① 同池等权买入持有（事前可实现的 β 基准）
        #   ② 同池最强单只（**事后 winner，含前视**——只用于量化"分散成本"，
        #      不是策略可达承诺，三期工程 §8 第 3 条）
        # 均用与组合相同的年化天数口径，保证可比。
        benchmarks = {}
        try:
            if len(engine.daily_stats) > 1 and dfs:
                _bt_start = pd.Timestamp(req.start_date)
                panel_px = {}
                for d_ in dfs:
                    c_ = str(d_["fund_code"].iloc[0])
                    s_ = d_.set_index(d_.index)["adj_nav"].dropna()
                    s_ = s_[s_.index >= _bt_start]
                    if len(s_) >= 60:
                        panel_px[c_] = s_
                if panel_px:
                    _n_days_bt = len(engine.daily_stats)
                    px = pd.DataFrame(panel_px).sort_index()
                    norm = px / px.iloc[0]
                    ew = norm.mean(axis=1)
                    ew_ann = float(ew.iloc[-1] ** (252.0 / _n_days_bt) - 1.0)
                    ew_mdd = float((ew / ew.cummax() - 1.0).min())
                    per_ann = {c: float((s.iloc[-1] / s.iloc[0]) ** (252.0 / len(s)) - 1.0)
                               for c, s in panel_px.items()}
                    best = max(per_ann, key=per_ann.get)
                    benchmarks = {
                        "equal_weight_buyhold": {
                            "annualized": round(ew_ann, 6), "max_drawdown": round(ew_mdd, 6)},
                        "best_single_buyhold": {
                            "code": best, "annualized": round(per_ann[best], 6),
                            "note": "事后 winner，含前视；仅量化分散成本，非可达承诺"},
                        "n_funds_computed": len(panel_px),
                    }
        except Exception as be:
            print(f"[Backtest] 基准对比计算失败（不影响主结果）: {be}")
        summary["benchmarks"] = benchmarks

        # B-2/B-1（评审 2026-09-19）：结果可信度标注，跟结果一起走（响应 + 落盘 + 前端）。
        # 样本是"本地已预热且凑满净值窗口"的便利样本，不是全市场 —— 存续久、数据
        # 质量好的基金天然更容易进池；且未做清盘敏感性校正。任何结论**不能外推**
        # 到全市场，与全市场口径的数字并列比较前必须先扩池（见 README §数据仓）。
        caveat = {
            "survivorship_bias": True,
            "sample_note": ("标的池为本地已预热的便利样本（非全市场随机抽样），"
                            "结果含幸存者偏差、未校正；不能外推到全市场。"),
        }
        
        payload = {
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "request": {
                "strategy_file": strategy_file,
                "start_date": req.start_date,
                "end_date": req.end_date,
                "initial_cash": req.initial_cash,
                "funds": list(effective_funds),
                "universe_source": universe_source,
                "universe_note": universe_note,
                "profile": str(req.profile or "steady"),
            },
            "summary": summary,
            "daily_stats": daily_stats,
            "holdings_daily": holdings_daily,
            "trades": trades,
            "caveats": caveat,
        }
        # 落盘后前端「历史回测」才能回看（_dump_backtest_record 曾定义了却没人调用，
        # 导致整轮回测跑完不留痕、刷新即失）。失败只告警，不影响本次响应。
        record_id = _dump_backtest_record(payload)
        print(f"[Backtest] 完成 strategy={strategy_file} "
              f"{req.start_date}~{req.end_date} 标的 {len(effective_funds)} 只 "
              f"成交 {len(trades)} 笔 耗时 {time.time() - _t_start:.1f}s")

        return {
            "status": "success",
            "summary": summary,
            "daily_stats": daily_stats,
            "holdings_daily": holdings_daily,
            "trades": trades,
            "universe": effective_funds,
            "universe_source": universe_source,
            "universe_note": universe_note,
            "caveats": caveat,
            "record_id": record_id,
            "elapsed_seconds": round(time.time() - _t_start, 1),
        }
    except HTTPException:
        # ⚠️ 必须原样透传：内部所有"用户填错了"的校验都是 400（日期反了、
        # 标的池为空、策略文件不存在、区间内无净值…）。若被下面那个兜底
        # except 捕获并改写成 500，用户看到的是"服务端异常"，
        # 分不清是自己输入错了还是系统坏了，前端也无法针对性提示。
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Backtest simulation execution failed: {str(e)}")

# 6. Serve HTML & Static Files
@app.get("/")
def get_dashboard():
    index_path = os.path.join(BASE_DIR, "static", "index.html")
    if not os.path.exists(index_path):
        return HTMLResponse("<h2>Frontend static files not found. Please compile them.</h2>")
    return FileResponse(index_path)

# Mount remaining static resources
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
