document.addEventListener("DOMContentLoaded", () => {
    // Current state variables
    let currentSelectedTaskForLogs = null;
    let logPollingInterval = null;
    let portfolioPollingInterval = null;
    let activeTab = "tab-portfolio";
    // 默认池仅是占位：真实默认值由 /api/analytics/default_funds 下发（保证每只都有净值可取）。
    // 历史这里写死了 "000002.OF"，而它是华夏成长混合(后端)份额，数据源没有独立净值页，
    // 必然失败并把整个研究计算拖进随机数兜底 —— 不要再写死未经核验的代码。
    let researchFundPool = [];
    let researchPoolLoaded = false;

    async function loadDefaultResearchFunds() {
        if (researchPoolLoaded && researchFundPool.length) return;
        try {
            const res = await fetch("/api/analytics/default_funds?limit=5");
            const data = await res.json();
            if (Array.isArray(data.funds) && data.funds.length >= 2) {
                researchFundPool = data.funds.slice();
            }
        } catch (e) {
            console.warn("默认标的池加载失败", e);
        }
        if (!researchFundPool.length) {
            // 后端不可用时的兜底：全部为已核验可取净值的代码
            researchFundPool = ["000001.OF", "000003.OF", "110022.OF"];
        }
        researchPoolLoaded = true;
        renderResearchFundPool();
    }

    // Initialize clock
    function updateClock() {
        const timeBox = document.getElementById("system-time");
        if (timeBox) {
            const now = new Date();
            timeBox.textContent = now.toLocaleTimeString("zh-CN", { hour12: false });
        }
    }
    setInterval(updateClock, 1000);
    updateClock();

    // Tab Navigation switching
    const menuItems = document.querySelectorAll(".menu-item");
    menuItems.forEach(item => {
        item.addEventListener("click", () => {
            // Remove active from all buttons & contents
            document.querySelectorAll(".menu-item").forEach(i => i.classList.remove("active"));
            document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
            
            // Add active to current
            item.classList.add("active");
            const tabId = item.getAttribute("data-tab");
            document.getElementById(tabId).classList.add("active");
            
            activeTab = tabId;
            
            // Update breadcrumb title
            const labelText = item.querySelector(".label").textContent;
            document.getElementById("current-view-title").textContent = labelText;
            
            // Handle view changes (e.g. stop polling or trigger fetches)
            onTabChanged(tabId);
        });
    });

    function onTabChanged(tabId) {
        // Clear background log pollers if we leave scheduler
        if (tabId !== "tab-scheduler") {
            clearInterval(logPollingInterval);
            logPollingInterval = null;
        }
        
        // Stop portfolio poller if we leave portfolio
        if (tabId !== "tab-portfolio") {
            clearInterval(portfolioPollingInterval);
            portfolioPollingInterval = null;
        }
        
        // Trigger page-specific loaders
        if (tabId === "tab-portfolio") {
            fetchPortfolio();
            // Start tick poller (every 5 seconds) for simulated ticks
            portfolioPollingInterval = setInterval(fetchPortfolio, 5000);
        } else if (tabId === "tab-scheduler") {
            // 策略自注册优先：先 sync 再拉列表，保证 SCHEDULE 定义的任务自动出现
            fetch("/api/tasks/sync", {method: "POST"}).catch(() => {}).finally(() => fetchTasks());
            loadStrategyOptions();
        } else if (tabId === "tab-research") {
            fetchStrategyFiles();
        } else if (tabId === "tab-decisions") {
            fetchDecisions();
        } else if (tabId === "tab-analytics") {
            renderResearchFundPool();
        }
    }

    // ----------------- TAB: DECISIONS (决策推送记录) -----------------
    let decisionCache = [];
    // 默认聚焦五层漏斗（主策略）；若该组没有记录，fetchDecisions 会自动回退"全部"
    let decisionGroupFilter = "fof_funnel";
    let groupNameMap = null;           // {目录名: 显示名}
    let currentDecisionForConfirm = null;   // 当前正在明细里展示、可被勾选确认的决策 id
    let currentDetailRecord = null;         // 当前明细记录（"只看入选"开关切换时重渲染用）

    async function ensureGroupNameMap() {
        if (groupNameMap) return groupNameMap;
        groupNameMap = {};
        try {
            const r = await fetch("/api/strategy_groups");
            const d = await r.json();
            (d.groups || []).forEach(g => { groupNameMap[g.dir] = g.name; });
        } catch (e) { /* 拉不到就用目录名兜底 */ }
        return groupNameMap;
    }

    function renderDecisionGroupFilter(groups) {
        const box = document.getElementById("decision-group-filter");
        if (!box) return;
        box.innerHTML = "";
        const mk = (label, val) => {
            const b = document.createElement("button");
            b.className = "btn btn-secondary btn-sm";
            b.textContent = label;
            if (decisionGroupFilter === val) {
                b.style.borderColor = "var(--color-orange)";
                b.style.color = "var(--color-orange)";
            }
            b.addEventListener("click", () => { decisionGroupFilter = val; fetchDecisions(); });
            box.appendChild(b);
        };
        // 主策略（五层漏斗）排最前，其余按出现顺序，"全部"放最后 —— 视线动线从主到次
        const funnel = groups.filter(g => g.value === "fof_funnel");
        const others = groups.filter(g => g.value !== "fof_funnel" && g.value !== "");
        funnel.forEach(g => mk(g.label, g.value));
        others.forEach(g => mk(g.label, g.value));
        mk("全部", "");
    }

    function detailPickedOnly() {
        const cb = document.getElementById("decision-detail-picked-only");
        return !cb || cb.checked;      // 默认只看入选（100 行打分里通常只有 ~20 只入选）
    }

    const money = (v) => (Number(v) || 0).toLocaleString("zh-CN", { maximumFractionDigits: 2 });
    const pct = (v) => `${(Number(v) || 0).toFixed(2)}%`;

    function renderDecisionAdvice(d) {
        const box = document.getElementById("decision-advice");
        if (!box) return;
        const a = d.advice;
        if (!a) { box.style.display = "none"; box.innerHTML = ""; return; }  // 老记录没有该段
        box.style.display = "block";

        const pos = (a.target_positions || []).map(p => {
            const members = (p.members || []).slice(0, 8).map(m =>
                `<div style="margin-left: 12px; font-size: 11px; color: var(--text-muted);">
                    <span class="font-mono">${m.fund_code}</span>
                    ${m.name ? `· ${m.name}` : ""}
                    ${m.type ? `（${m.type}）` : ""}
                    <span style="float: right;">${(Number(m.weight) * 100).toFixed(2)}%</span>
                </div>`).join("");
            return `<div style="margin-bottom: 4px;">
                <div><b>${p.class_label || p.class}</b>
                    <span style="float: right;">目标 ${(Number(p.weight) * 100).toFixed(2)}%</span></div>
                ${members}
            </div>`;
        }).join("");

        const buys = (a.buys || []).length
            ? (a.buys || []).map(b => `<div style="margin-bottom: 3px;">
                    • <span class="font-mono">${b.fund_code}</span>
                      ${b.name ? `· ${b.name}` : ""}
                      <span style="float: right;">${money(b.amount)} 元（${pct(b.weight_pct)}）</span>
                    <div style="margin-left: 12px; font-size: 11px; color: var(--text-muted);">${b.limit_note || ""}</div>
                </div>`).join("")
            : '<div style="color: var(--text-muted);">（无）</div>';

        const sells = (a.sells || []).length
            ? (a.sells || []).map(s => `<div style="margin-bottom: 3px;">
                    • <span class="font-mono">${s.fund_code}</span>
                      ${s.name ? `· ${s.name}` : ""}
                      <span style="float: right;">${Number(s.shares).toFixed(2)} 份
                      ${s.est_amount !== null && s.est_amount !== undefined ? `（约 ${money(s.est_amount)} 元）` : ""}</span>
                    <div style="margin-left: 12px; font-size: 11px; color: var(--text-muted);">${s.settle_note || ""}</div>
                </div>`).join("")
            : '<div style="color: var(--text-muted);">（无）</div>';

        const reasons = (a.reasons || []).map(r =>
            `<div style="margin-bottom: 2px;">• ${r}</div>`).join("");

        box.innerHTML = `
            <div style="font-size: 14px; font-weight: 600; margin-bottom: 6px;">${a.headline || "组合建议"}</div>
            <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 10px;">
                当前状态：${a.status_text || "-"}　|　日期：${a.asof || "-"}
                ${a.buy_total ? `　|　申购合计 ${money(a.buy_total)} 元` : ""}
                ${a.sell_est_total ? `　|　回收约 ${money(a.sell_est_total)} 元` : ""}
                ${a.total_assets ? `　|　总资产 ${money(a.total_assets)} 元` : ""}
            </div>
            <div style="font-size: 12px; font-weight: 600; margin: 8px 0 4px;">目标仓位</div>
            ${pos || '<div style="color: var(--text-muted);">（无）</div>'}
            <div style="font-size: 12px; font-weight: 600; margin: 10px 0 4px;">建议买入（限购感知）</div>
            ${buys}
            <div style="font-size: 12px; font-weight: 600; margin: 10px 0 4px;">建议卖出（份额冻结、资金 T+${a.settle_days || 4} 到账）</div>
            ${sells}
            <div style="font-size: 12px; font-weight: 600; margin: 10px 0 4px;">决策理由</div>
            ${reasons || '<div style="color: var(--text-muted);">（无）</div>'}
            ${d.status === "pending_confirm"
                ? '<div style="margin-top: 10px; font-size: 11px; color: var(--color-orange, #ff9500);">需在下方勾选「我已核对并确认」并点「执行确认」后，才会生成下单文件并落到账户。</div>'
                : ""}
        `;
    }

    function renderDecisionDetail(d) {
        currentDetailRecord = d;
        renderDecisionAdvice(d);
        const title = document.getElementById("decision-detail-title");
        const tbody = document.getElementById("decision-detail-list");
        const picked = new Set(d.picks || []);
        const scores = d.scores || [];
        const sells = d.orders_sell || [];
        const buys = d.orders || [];
        currentDecisionForConfirm = null;

        // 人工确认闸门：只有「待确认」状态才出勾选框，确认过/无调仓的不出
        const bar = document.getElementById("decision-confirm-bar");
        const chk = document.getElementById("decision-confirm-check");
        const btn = document.getElementById("btn-confirm-decision");
        const cmsg = document.getElementById("decision-confirm-msg");
        if (bar) bar.style.display = (d.status === "pending_confirm") ? "flex" : "none";
        if (chk) chk.checked = false;
        if (btn) btn.disabled = true;
        if (cmsg) cmsg.textContent = "";

        const buyAmt = buys.reduce((s, b) => s + (Number(b.amount) || 0), 0);
        const sellTxt = sells.length ? `，赎回 ${sells.length} 只` : "";
        const buyTxt = buys.length
            ? `，申购 ${buys.length} 只 ${buyAmt.toLocaleString("zh-CN", { maximumFractionDigits: 0 })} 元`
            : "";
        title.textContent = `决策明细 · ${d.run_at || "-"} · asof ${d.asof || "-"} · ` +
            `入选 ${(d.picks || []).length}/${scores.length} 只` +
            `${sellTxt}${buyTxt}`;
        if (!scores.length) {
            tbody.innerHTML = '<tr><td colspan="5" class="loading">该次决策没有打分记录</td></tr>';
            return;
        }
        const onlyPicked = detailPickedOnly();
        // 申购/赎回涉及的标的即使权重为 0 也保留显示（用户核对出单时要用）
        const tradeCodes = new Set([...buys.map(b => b.fund_code),
                                    ...sells.map(s => s.fund_code)]);
        tbody.innerHTML = "";
        let shown = 0;
        scores.forEach(s => {
            const isIn = picked.has(s.fund_code);
            if (onlyPicked && !isIn && !tradeCodes.has(s.fund_code)) return;
            shown += 1;
            const tr = document.createElement("tr");
            if (isIn) tr.style.backgroundColor = "rgba(255, 149, 0, 0.08)";
            const rank = (s.rank === null || s.rank === undefined) ? "-" : s.rank;
            const sc = (s.total_score === null || s.total_score === undefined ||
                        Number.isNaN(s.total_score)) ? "-" : Number(s.total_score).toFixed(6);
            // 漏斗记录带子池/档位；多因子记录没有这两列，显示 "-" 即可
            const pool = s.pool || "";
            const tier = s.tier || "";
            const extra = (pool || tier)
                ? `${pool}${pool && tier ? " · " : ""}${tier}`
                : '<span style="color: var(--text-muted);">-</span>';
            tr.innerHTML = `
                <td class="font-mono">${rank}</td>
                <td class="font-mono">${s.fund_code || "-"}</td>
                <td class="font-mono">${sc}</td>
                <td class="font-mono">${extra}</td>
                <td>${isIn ? '<span style="color: var(--color-red);">✔ 已入选</span>'
                           : '<span style="color: var(--text-muted);">未入选</span>'}</td>
            `;
            tbody.appendChild(tr);
        });
        if (onlyPicked && shown < scores.length) {
            const tr = document.createElement("tr");
            tr.innerHTML = `<td colspan="5" class="loading" style="font-size: 11px;">` +
                `已折叠 ${scores.length - shown} 只未入选标的（取消勾选「只看入选」查看全部）</td>`;
            tbody.appendChild(tr);
        }
        if (d.status === "pending_confirm") currentDecisionForConfirm = d.id;
        if (btn) btn.disabled = (d.status !== "pending_confirm");
    }

    async function fetchDecisions() {
        const tbody = document.getElementById("decisions-list");
        const summary = document.getElementById("decisions-summary");
        try {
            const gmap = await ensureGroupNameMap();
            const q = decisionGroupFilter
                ? `/api/decisions?limit=60&group=${encodeURIComponent(decisionGroupFilter)}`
                : "/api/decisions?limit=60";
            const res = await fetch(q);
            if (!res.ok) throw new Error("加载决策记录失败");
            const data = await res.json();
            decisionCache = data.decisions || [];

            // 默认五层漏斗：该组没有记录时自动回退"全部"，避免打开就是空表
            if (decisionGroupFilter === "fof_funnel" && !decisionCache.length) {
                decisionGroupFilter = "";
                return fetchDecisions();
            }

            // 组筛选按钮：只列出"确实有决策记录"的组
            const seen = new Map();
            decisionCache.forEach(d => {
                const g = d.group || "";
                if (!seen.has(g)) seen.set(g, gmap[g] || (g || "未分组"));
            });
            renderDecisionGroupFilter([...seen.entries()].map(([value, label]) => ({ value, label })));

            if (!decisionCache.length) {
                summary.textContent = decisionGroupFilter ? "该策略组暂无记录" : "暂无记录";
                tbody.innerHTML = '<tr><td colspan="8" class="loading">' +
                    '暂无决策记录：调度任务跑过一次后就会出现（可在「策略调度」页点运行）</td></tr>';
                document.getElementById("decision-detail-list").innerHTML =
                    '<tr><td colspan="5" class="loading">暂无选中记录</td></tr>';
                return;
            }

            const latest = decisionCache[0];
            // 摘要只给"一眼要看的"：次数 + 最近一次的要点。入选名单点行看，
            // 不在顶栏平铺（20+ 个代码会把头部撑爆）。
            const latestAmt = (latest.orders || []).reduce(
                (s, o) => s + (Number(o.amount) || 0), 0);
            summary.textContent =
                `共 ${decisionCache.length} 次 · 最近 ${latest.run_at || "-"} ` +
                `${gmap[latest.group] || latest.group || ""} 入选 ${(latest.picks || []).length} 只` +
                (latestAmt ? ` 申购 ${latestAmt.toLocaleString("zh-CN", { maximumFractionDigits: 0 })} 元` : "");

            tbody.innerHTML = "";
            decisionCache.forEach((d, idx) => {
                const tr = document.createElement("tr");
                tr.style.cursor = "pointer";
                const picksArr = d.picks || [];
                // 只露前 2 只 + 数量：完整列表点行看明细，悬浮看全部
                const picks = picksArr.length > 2
                    ? picksArr.slice(0, 2).join(", ") + ` 等 ${picksArr.length} 只`
                    : (picksArr.join(", ") || "-");
                const picksTitle = picksArr.join(", ") || "-";
                const amt = (d.orders || []).reduce((s, o) => s + (Number(o.amount) || 0), 0);
                const sellN = (d.orders_sell || []).length;
                const statusHtml =
                    d.status === "pending_confirm"
                        ? '<span style="color: var(--color-orange); font-weight: 600;">⏸ 待确认</span>'
                        : (d.status === "ok"
                            ? '<span style="color: var(--color-red);">已出单</span>'
                            : (d.status === "no_change"
                                ? '<span style="color: var(--text-muted);">无调仓</span>'
                                : '<span style="color: var(--color-orange);">无入选</span>'));
                // 产出文件只显示文件名（完整路径挂悬浮）—— 全路径 80+ 字符，
                // 是历史表里最挤的一列，而且用户根本不需要看路径
                const fileLinks = Object.entries(d.files || {});
                const filesShort = fileLinks.length
                    ? fileLinks.map(([k, v]) => {
                        const base = String(v).split(/[\\/]/).pop();
                        return `<span title="${String(v)}">${base}</span>`;
                      }).join("<br>")
                    : "-";
                const gLabel = gmap[d.group] || (d.group || "未分组");
                tr.innerHTML = `
                    <td class="font-mono">${d.run_at || "-"}</td>
                    <td>${gLabel}</td>
                    <td class="font-mono">${d.asof || "-"}</td>
                    <td class="font-mono">${(d.candidates || []).length} / ${(d.eligible || []).length}</td>
                    <td class="font-mono" title="${picksTitle}">${picks}</td>
                    <td class="font-mono" style="text-align: right;">${amt ? amt.toLocaleString("zh-CN", { maximumFractionDigits: 2 }) : "-"}${sellN ? `<div style="font-size:10px;color:var(--color-orange);">赎回 ${sellN} 只</div>` : ""}</td>
                    <td>${statusHtml}</td>
                    <td class="font-mono" style="font-size: 10px; color: var(--text-muted); max-width: 150px; overflow: hidden; text-overflow: ellipsis;">${filesShort}</td>
                `;
                tr.addEventListener("click", () => {
                    document.querySelectorAll("#decisions-list tr").forEach(x => x.style.outline = "none");
                    tr.style.outline = "1px solid var(--color-orange)";
                    renderDecisionDetail(d);
                });
                tbody.appendChild(tr);
                if (idx === 0) renderDecisionDetail(d);
            });
        } catch (e) {
            tbody.innerHTML = `<tr><td colspan="8" class="loading">加载失败: ${e.message}</td></tr>`;
        }
    }

    const btnRefreshDecisions = document.getElementById("btn-refresh-decisions");
    if (btnRefreshDecisions) btnRefreshDecisions.addEventListener("click", fetchDecisions);

    // 「只看入选」开关：切换时用当前明细记录重渲染（不重新拉接口）
    const chkPickedOnly = document.getElementById("decision-detail-picked-only");
    if (chkPickedOnly) chkPickedOnly.addEventListener("change", () => {
        if (currentDetailRecord) renderDecisionDetail(currentDetailRecord);
    });

    // ----------------- 人工确认闸门（申购/赎回出单前必须勾选） -----------------
    const chkConfirm = document.getElementById("decision-confirm-check");
    const btnConfirmDecision = document.getElementById("btn-confirm-decision");
    if (chkConfirm && btnConfirmDecision) {
        chkConfirm.addEventListener("change", () => {
            // 只有勾上了才允许点「确认出单」；切换决策时 renderDecisionDetail 会重置
            btnConfirmDecision.disabled = !chkConfirm.checked
                || currentDecisionForConfirm === null;
            const msg = document.getElementById("decision-confirm-msg");
            if (msg && chkConfirm.checked) msg.textContent = "";
        });
    }
    if (btnConfirmDecision) {
        btnConfirmDecision.addEventListener("click", async () => {
            const msg = document.getElementById("decision-confirm-msg");
            if (!chkConfirm.checked) {
                msg.textContent = "请先勾选「我已核对并确认以下调仓」";
                return;
            }
            if (!currentDecisionForConfirm) return;
            btnConfirmDecision.disabled = true;
            try {
                const res = await fetch("/api/decisions/confirm", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ id: currentDecisionForConfirm, confirm: true })
                });
                const data = await res.json();
                if (!res.ok) throw new Error(data.detail || "确认失败");
                const files = Object.values((data.record || {}).files || {}).join(", ") || "-";
                msg.textContent = `已出单：${files}。下单文件在下次刷新账户时记入流水。`;
                chkConfirm.checked = false;
                fetchDecisions();          // 刷新列表状态（待确认 -> 已出单）
            } catch (e) {
                msg.textContent = e.message;
                btnConfirmDecision.disabled = false;
            }
        });
    }

    // ----------------- TAB: PORTFOLIO -----------------
    async function fetchPortfolio(force = false) {
        try {
            const res = await fetch("/api/portfolio");
            if (!res.ok) throw new Error("加载持仓失败");
            const data = await res.json();
            
            // Check if user is currently editing cash or table inputs
            const isEditing = document.activeElement && (
                document.activeElement.classList.contains("table-input") ||
                document.activeElement.id === "edit-initial-cash" ||
                document.activeElement.id === "edit-cash" ||
                document.activeElement.id === "edit-pnl-override"
            );
            
            // Update summary displays (always safe to overwrite)
            document.getElementById("portfolio-total").textContent = data.total_value.toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            document.getElementById("portfolio-cash").textContent = data.cash.toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            
            // Render PnL with colors
            const pnlBox = document.getElementById("portfolio-pnl");
            pnlBox.textContent = (data.pnl >= 0 ? "+" : "") + data.pnl.toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            if (data.pnl >= 0) {
                pnlBox.style.color = "var(--color-red)";
                pnlBox.className = "number text-up";
            } else {
                pnlBox.style.color = "var(--color-green)";
                pnlBox.className = "number text-down";
            }
            // 说明总盈亏的口径：初始资金为 0 时不能拿"总资产−0"当盈亏（那等于总资产，
            // 看起来就像资金算法错了）。此时后端改用持仓浮动盈亏兜底，这里同步说明。
            const pnlHint = document.getElementById("portfolio-pnl-hint");
            if (pnlHint) {
                if (data.pnl_override !== null && data.pnl_override !== undefined) {
                    pnlHint.textContent = "人工调整值";
                } else if (Number(data.initial_cash) > 0) {
                    pnlHint.textContent = "总资产 − 初始资金";
                } else {
                    pnlHint.textContent = "持仓浮动盈亏（初始资金为 0，未含已实现）";
                }
            }
            
            // Only update input box values and positions table if not editing, or if forced
            if (!isEditing || force) {
                const initCashInput = document.getElementById("edit-initial-cash");
                if (document.activeElement !== initCashInput || force) {
                    initCashInput.value = data.initial_cash;
                }
                const cashInput = document.getElementById("edit-cash");
                if (document.activeElement !== cashInput || force) {
                    cashInput.value = data.cash;
                }
                const pnlOverrideInput = document.getElementById("edit-pnl-override");
                if (document.activeElement !== pnlOverrideInput || force) {
                    pnlOverrideInput.value = data.pnl_override !== null ? data.pnl_override : "";
                }
                
                // Render positions rows
                const posList = document.getElementById("positions-list");
                posList.innerHTML = "";
                
                if (data.positions.length === 0) {
                    posList.innerHTML = `<tr><td colspan="9" class="loading">目前无任何场外基金持仓</td></tr>`;
                } else {
                    data.positions.forEach(pos => {
                        const pnl = pos.cost_nav > 0 ? ((pos.current_nav - pos.cost_nav) / pos.cost_nav) * 100 : 0.0;
                        const pnlClass = pnl >= 0 ? "badge-red" : "badge-green";
                        const pnlText = (pnl >= 0 ? "+" : "") + pnl.toFixed(2) + "%";
                        // 净值日期：场外基金净值 T+1 发布，这里让用户看到该净值的真实截止日，
                        // 避免误以为"还是昨天的净值"是程序没刷新
                        const navDate = pos.nav_date || '<span style="color: var(--text-muted);">—</span>';

                        const tr = document.createElement("tr");
                        tr.innerHTML = `
                            <td><input type="text" class="table-input pos-code" value="${pos.fund_code}"></td>
                            <td><input type="text" class="table-input pos-name" value="${pos.fund_name}"></td>
                            <td><input type="number" class="table-input pos-shares" value="${pos.shares}" step="0.01"></td>
                            <td><input type="number" class="table-input pos-cost-nav" value="${pos.cost_nav}" step="0.0001"></td>
                            <td><input type="number" class="table-input pos-current-nav" value="${pos.current_nav}" step="0.0001"></td>
                            <td class="font-mono" style="font-size: 11px; color: var(--text-muted);">${navDate}</td>
                            <td><span class="cell-text font-mono" style="color: var(--color-blue); font-weight: 500;">${pos.market_value.toLocaleString("zh-CN", { minimumFractionDigits: 2 })}</span></td>
                            <td><span class="badge ${pnlClass}">${pnlText}</span></td>
                            <td style="text-align: center;"><button class="btn-delete-pos" style="color: var(--color-red); border: none; background: transparent; cursor: pointer; padding: 6px 10px; font-weight: 600;">删除</button></td>
                        `;

                        tr.querySelector(".btn-delete-pos").addEventListener("click", () => {
                            tr.remove();
                            if (posList.children.length === 0) {
                                posList.innerHTML = `<tr><td colspan="9" class="loading">目前无任何场外基金持仓</td></tr>`;
                            }
                        });

                        posList.appendChild(tr);
                    });
                }
            }
            
            // Render Transactions
            const txList = document.getElementById("transactions-list");
            txList.innerHTML = "";
            
            if (data.transactions.length === 0) {
                txList.innerHTML = `<tr><td colspan="7" class="loading">暂无历史交易流水</td></tr>`;
            } else {
                data.transactions.forEach(tx => {
                    const typeClass = tx.type === "申购" ? "badge-blue" : "badge-orange";
                    
                    const tr = document.createElement("tr");
                    tr.innerHTML = `
                        <td style="color: var(--text-muted); font-size: 12px; height: 30px;"><span class="cell-text">${tx.time}</span></td>
                        <td style="font-family: var(--font-mono);"><span class="cell-text">${tx.fund_code}</span></td>
                        <td><span class="cell-text"><span class="badge ${typeClass}">${tx.type}</span></span></td>
                        <td style="font-weight: 500;"><span class="cell-text">${tx.amount.toLocaleString("zh-CN", { minimumFractionDigits: 2 })}</span></td>
                        <td><span class="cell-text">${tx.shares.toLocaleString("zh-CN")}</span></td>
                        <td><span class="cell-text">${tx.fee.toFixed(2)}</span></td>
                        <td><span class="cell-text"><span class="badge badge-green">${tx.status}</span></span></td>
                    `;
                    txList.appendChild(tr);
                });
            }
        } catch (err) {
            console.error("加载组合数据错误: ", err);
        }
    }

    async function savePortfolioData() {
        const initialCash = parseFloat(document.getElementById("edit-initial-cash").value) || 0.0;
        const cash = parseFloat(document.getElementById("edit-cash").value) || 0.0;
        const pnlOverrideVal = document.getElementById("edit-pnl-override").value;
        const pnlOverride = pnlOverrideVal.trim() === "" ? null : parseFloat(pnlOverrideVal);
        
        // Collect positions
        const positionRows = document.querySelectorAll("#positions-list tr");
        const positions = [];
        
        positionRows.forEach(row => {
            if (row.querySelector(".loading") || row.cells.length < 8) {
                return;
            }
            
            const code = row.querySelector(".pos-code").value.trim();
            const name = row.querySelector(".pos-name").value.trim();
            const shares = parseFloat(row.querySelector(".pos-shares").value) || 0.0;
            const costNav = parseFloat(row.querySelector(".pos-cost-nav").value) || 0.0;
            const currentNav = parseFloat(row.querySelector(".pos-current-nav").value) || 0.0;
            
            if (code !== "") {
                positions.push({
                    fund_code: code,
                    fund_name: name,
                    shares: shares,
                    cost_nav: costNav,
                    current_nav: currentNav
                });
            }
        });
        
        try {
            const res = await fetch("/api/portfolio/update", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    initial_cash: initialCash,
                    cash: cash,
                    pnl_override: pnlOverride,
                    positions: positions
                })
            });
            
            if (!res.ok) throw new Error("保存资产信息失败");
            
            alert("保存资产持仓信息成功！");
            fetchPortfolio(true); // force reload to redraw the calculated values
        } catch (err) {
            alert(err.message);
        }
    }

    async function refreshNavs() {
        const btn = document.getElementById("btn-refresh-navs");
        btn.disabled = true;
        btn.textContent = "更新中...";
        
        try {
            const res = await fetch("/api/portfolio/refresh_navs", { method: "POST" });
            if (!res.ok) throw new Error("刷新净值失败");
            
            alert("实时净值更新成功！");
            await fetchPortfolio(true); // force reload to draw new net assets
        } catch (err) {
            alert(err.message);
        } finally {
            btn.disabled = false;
            btn.textContent = "更新净值";
        }
    }

    function addPositionRow() {
        const posList = document.getElementById("positions-list");
        const emptyRow = posList.querySelector("td.loading");
        if (emptyRow) {
            posList.innerHTML = "";
        }
        
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td><input type="text" class="table-input pos-code" value="" placeholder="如: 000001.OF"></td>
            <td><input type="text" class="table-input pos-name" value="" placeholder="如: 华夏成长混合"></td>
            <td><input type="number" class="table-input pos-shares" value="0.00" step="0.01"></td>
            <td><input type="number" class="table-input pos-cost-nav" value="1.0000" step="0.0001"></td>
            <td><input type="number" class="table-input pos-current-nav" value="1.0000" step="0.0001"></td>
            <td><span class="cell-text font-mono" style="color: var(--text-muted); font-style: italic;">保存后计算</span></td>
            <td><span class="badge badge-blue">0.00%</span></td>
            <td style="text-align: center;"><button class="btn-delete-pos" style="color: var(--color-red); border: none; background: transparent; cursor: pointer; padding: 6px 10px; font-weight: 600;">删除</button></td>
        `;
        
        tr.querySelector(".btn-delete-pos").addEventListener("click", () => {
            tr.remove();
            if (posList.children.length === 0) {
                posList.innerHTML = `<tr><td colspan="8" class="loading">目前无任何场外基金持仓</td></tr>`;
            }
        });
        
        posList.appendChild(tr);
        tr.querySelector(".pos-code").focus();
    }

    // Register button event listeners
    document.getElementById("btn-refresh-portfolio").addEventListener("click", () => fetchPortfolio(true));
    document.getElementById("btn-save-cash-info").addEventListener("click", savePortfolioData);
    document.getElementById("btn-save-positions").addEventListener("click", savePortfolioData);
    document.getElementById("btn-refresh-navs").addEventListener("click", refreshNavs);
    document.getElementById("btn-add-position").addEventListener("click", addPositionRow);


    // ----------------- TAB: SCHEDULER -----------------
    async function loadStrategyOptions() {
        try {
            // 按 kind 分流：回测只显示 handle_bar 插件，调度只显示任务入口，避免选错
            let files = [];
            let metaByName = {};
            try {
                const r2 = await fetch("/api/strategies_with_meta");
                const d2 = await r2.json();
                (d2.strategies || []).forEach(m => { files.push(m.name); metaByName[m.name] = m; });
            } catch (e) {
                const res = await fetch("/api/strategies");
                const data = await res.json();
                files = data.strategies || [];
            }
            
            // 按「策略组」分组渲染：optgroup 标签取 group.json 的中文名
            const byGroup = new Map();
            const groupOrder = [];
            files.forEach(file => {
                const m = metaByName[file] || {};
                const gname = m.group_name || m.group || "未分组";
                if (!byGroup.has(gname)) { byGroup.set(gname, []); groupOrder.push(gname); }
                byGroup.get(gname).push(file);
            });
            function appendGrouped(select, accept) {
                groupOrder.forEach(gname => {
                    const items = byGroup.get(gname).filter(accept);
                    if (!items.length) return;
                    const og = document.createElement("optgroup");
                    og.label = gname;
                    items.forEach(file => {
                        const k = (metaByName[file] || {}).kind || "unknown";
                        const opt = document.createElement("option");
                        opt.value = file;
                        opt.textContent = (k === "unknown")
                            ? `${file.split("/").pop()} (未识别)`
                            : file.split("/").pop();
                        og.appendChild(opt);
                    });
                    select.appendChild(og);
                });
            }
            const acceptTask = f => ["task", "both", "unknown"].includes((metaByName[f] || {}).kind || "unknown");
            const acceptBacktest = f => ["backtest", "both", "unknown"].includes((metaByName[f] || {}).kind || "unknown");

            // 1. Populate task-strategy select（仅 task/both/unknown）
            const select = document.getElementById("task-strategy");
            if (select) {
                select.innerHTML = '<option value="">请选择策略文件...</option>';
                appendGrouped(select, acceptTask);
                const hint = document.createElement("div");
                hint.style.cssText = "font-size:11px;color:var(--text-muted);margin-top:4px;";
                hint.textContent = "任务一般由策略 SCHEDULE 自注册，手动创建仅用于临时调试。";
                select.parentElement.appendChild(hint);
            }

            // 2. Populate backtest-rebalance-freq select（仅 backtest/both/unknown）
            const btSelect = document.getElementById("backtest-rebalance-freq");
            if (btSelect) {
                btSelect.innerHTML = `
                    <option value="once">once (仅期初买入并持有)</option>
                    <option value="monthly">monthly (按月等权再平衡)</option>
                    <option value="monthly_rp">monthly_rp (按月风险平价再平衡)</option>
                `;
                appendGrouped(btSelect, acceptBacktest);
                // 策略自带池时锁定标的输入：避免用户手填与 CANDIDATES 打架
                btSelect.onchange = async () => {
                    const v = btSelect.value;
                    const fundsInput = document.getElementById("backtest-funds");
                    const hint = document.getElementById("backtest-funds-hint");
                    if (!v || !v.endsWith(".py")) {
                        if (fundsInput) { fundsInput.disabled = false; fundsInput.required = true; }
                        if (hint) hint.textContent = "内置策略用此池；自定义策略（xxx.py）若自带 CANDIDATES 则忽略此输入。";
                        return;
                    }
                    try {
                        const r = await fetch(`/api/strategies/${encodeURIComponent(v)}/meta`);
                        if (!r.ok) throw new Error();
                        const meta = await r.json();
                        if (meta.defines_universe) {
                            const dyn = !!meta.dynamic_universe;
                            const limitTxt = meta.universe_limit ? `，单次上限 ${meta.universe_limit} 只` : "";
                            if (fundsInput) {
                                fundsInput.disabled = true;
                                fundsInput.required = false;
                                if (dyn) {
                                    fundsInput.value = "";
                                    fundsInput.placeholder = "由策略动态生成，无需填写";
                                } else {
                                    fundsInput.value = meta.candidates.join(",");
                                }
                            }
                            if (hint) {
                                hint.textContent = dyn
                                    ? `候选池由策略 ${v} 动态生成（按本地可用净值 + 基金基础库事实实时建池${limitTxt}，Top${meta.top_n || "?"}），已锁定，回测将忽略手填。`
                                    : `候选池由策略 ${v} 定义（${meta.candidates.length}只，Top${meta.top_n || "?"}），已锁定，回测将忽略手填。`;
                            }
                        } else {
                            if (fundsInput) { fundsInput.disabled = false; fundsInput.required = true; }
                            if (hint) hint.textContent = `策略 ${v} 未定义 CANDIDATES，请手填候选池。`;
                        }
                    } catch (e) {
                        if (fundsInput) { fundsInput.disabled = false; fundsInput.required = true; }
                    }
                };
            }
        } catch (err) {
            console.error("加载下拉策略文件失败: ", err);
        }
    }

    async function fetchTasks() {
        try {
            const res = await fetch("/api/tasks");
            const data = await res.json();
            const tasksList = document.getElementById("tasks-list");
            tasksList.innerHTML = "";
            
            if (data.length === 0) {
                tasksList.innerHTML = `<tr><td colspan="8" class="loading">目前无任何调度任务，请在左侧新建</td></tr>`;
                return;
            }

            // 主策略置顶 + 角色徽标：决策策略是用户关心的，数据管线是它的前置供给，
            // 混排时用户要在一堆每日任务里找主策略（实测反馈：太拥挤）
            const roleOf = (t) => {
                const f = String(t.strategy_file || "");
                if (f.startsWith("fof_funnel")) return "main";
                if (f.startsWith("data_ops")) return "data";
                return "other";
            };
            const roleBadge = {
                main: '<span class="badge badge-orange" style="margin-left:6px;">主策略</span>',
                data: '<span class="badge badge-blue" style="margin-left:6px;">数据管线</span>',
                other: "",
            };
            const roleOrder = { main: 0, data: 1, other: 2 };
            data.sort((a, b) => roleOrder[roleOf(a)] - roleOrder[roleOf(b)]);

            data.forEach(task => {
                const tr = document.createElement("tr");
                const role = roleOf(task);
                
                // 调度周期人性化：2592000秒 这种原始值没人看得懂
                const iv = Number(task.schedule_value) || 0;
                const intervalTxt = iv >= 86400
                    ? (iv % 86400 === 0 ? `${iv / 86400} 天` : `${(iv / 86400).toFixed(1)} 天`)
                    : (iv >= 3600
                        ? (iv % 3600 === 0 ? `${iv / 3600} 小时` : `${(iv / 3600).toFixed(1)} 小时`)
                        : (iv >= 60
                            ? (iv % 60 === 0 ? `${iv / 60} 分钟` : `${(iv / 60).toFixed(1)} 分钟`)
                            : `${iv} 秒`));
                
                // Enabled state toggle switch
                const checked = task.enabled ? "checked" : "";
                const switchHtml = `
                    <label class="switch">
                        <input type="checkbox" class="toggle-task-btn" data-name="${task.name}" ${checked}>
                        <span class="slider"></span>
                    </label>
                `;
                
                // Status mapping
                let statusBadge = "";
                if (task.status === "running") {
                    statusBadge = '<span class="badge badge-green"><span class="dot live" style="display:inline-block; margin-right:4px;"></span>执行中</span>';
                } else if (task.status === "idle") {
                    statusBadge = '<span class="badge badge-blue">空闲</span>';
                } else {
                    statusBadge = '<span class="badge badge-red">异常</span>';
                }
                
                tr.innerHTML = `
                    <td style="font-weight:600; color:var(--text-primary);">${task.name}${roleBadge[role]}</td>
                    <td style="font-family: var(--font-mono); font-size:12px;">${task.strategy_file}</td>
                    <td title="${iv} 秒">${intervalTxt}</td>
                    <td>${switchHtml}</td>
                    <td>${statusBadge}</td>
                    <td style="font-size:11px; color:var(--text-muted);">${task.last_run || "-"}</td>
                    <td style="font-size:11px; color:var(--text-muted);">${task.next_run || "-"}</td>
                    <td>
                        <div style="display:flex; gap:6px;">
                            <button class="btn btn-secondary btn-sm btn-logs" data-name="${task.name}">日志</button>
                            <button class="btn btn-primary btn-sm btn-run" data-name="${task.name}">立即运行</button>
                            <button class="btn btn-secondary btn-sm btn-del" style="color:var(--color-red); border-color:rgba(239,68,68,0.2);" data-name="${task.name}">删除</button>
                        </div>
                    </td>
                `;
                tasksList.appendChild(tr);
            });
            
            // Attach button action handlers
            document.querySelectorAll(".toggle-task-btn").forEach(sw => {
                sw.addEventListener("change", async (e) => {
                    const name = e.target.getAttribute("data-name");
                    await toggleTask(name);
                });
            });
            
            document.querySelectorAll(".btn-logs").forEach(btn => {
                btn.addEventListener("click", () => {
                    const name = btn.getAttribute("data-name");
                    selectTaskForLogs(name);
                });
            });
            
            document.querySelectorAll(".btn-run").forEach(btn => {
                btn.addEventListener("click", async () => {
                    const name = btn.getAttribute("data-name");
                    btn.disabled = true;
                    await runTaskImmediately(name);
                    btn.disabled = false;
                });
            });
            
            document.querySelectorAll(".btn-del").forEach(btn => {
                btn.addEventListener("click", async () => {
                    const name = btn.getAttribute("data-name");
                    if (confirm(`确认删除策略任务 '${name}' 吗?`)) {
                        await deleteTask(name);
                    }
                });
            });
        } catch (err) {
            console.error("加载任务列表失败: ", err);
        }
    }

    async function toggleTask(name) {
        try {
            const res = await fetch(`/api/tasks/${name}/toggle`, { method: "POST" });
            if (!res.ok) throw new Error("切换状态失败");
            fetchTasks();
        } catch (err) {
            alert(err.message);
        }
    }

    async function runTaskImmediately(name) {
        try {
            const res = await fetch(`/api/tasks/${name}/run`, { method: "POST" });
            if (!res.ok) throw new Error("手动触发失败");
            alert(`已成功发送策略运行信号，正在触发 '${name}'...`);
            fetchTasks();
            selectTaskForLogs(name);
        } catch (err) {
            alert(err.message);
        }
    }

    async function deleteTask(name) {
        try {
            const res = await fetch(`/api/tasks/${name}`, { method: "DELETE" });
            if (!res.ok) throw new Error("删除失败");
            fetchTasks();
            if (currentSelectedTaskForLogs === name) {
                currentSelectedTaskForLogs = null;
                document.getElementById("log-header-title").textContent = "任务运行控制台日志";
                document.getElementById("log-console-box").textContent = "--- 选中任务已被删除 ---";
                document.getElementById("btn-refresh-logs").disabled = true;
                clearInterval(logPollingInterval);
            }
        } catch (err) {
            alert(err.message);
        }
    }

    // Task Create submit handler
    document.getElementById("form-create-task").addEventListener("submit", async (e) => {
        e.preventDefault();
        const name = document.getElementById("task-name").value.trim();
        const strategy_file = document.getElementById("task-strategy").value;
        const schedule_value = parseInt(document.getElementById("task-interval").value);
        
        if (!name || !strategy_file || !schedule_value) return;
        
        try {
            const res = await fetch("/api/tasks", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name, strategy_file, schedule_value })
            });
            if (!res.ok) {
                const errData = await res.json();
                throw new Error(errData.detail || "创建任务失败");
            }
            
            // Success reset form
            document.getElementById("task-name").value = "";
            document.getElementById("task-strategy").value = "";
            document.getElementById("task-interval").value = "300";
            
            fetchTasks();
        } catch (err) {
            alert(err.message);
        }
    });

    // Logging viewing & polling
    function selectTaskForLogs(name) {
        currentSelectedTaskForLogs = name;
        document.getElementById("log-header-title").textContent = `任务控制台日志: ${name} (实时刷新中)`;
        document.getElementById("btn-refresh-logs").disabled = false;
        
        // Fetch logs immediately
        fetchLogs(name);
        
        // Setup live polling (every 2 seconds)
        clearInterval(logPollingInterval);
        logPollingInterval = setInterval(() => {
            fetchLogs(name);
            // Also refresh task list status to check if finished
            fetchTasks();
        }, 2000);
    }

    async function fetchLogs(name) {
        try {
            const res = await fetch(`/api/tasks/${name}/logs`);
            const data = await res.json();
            const logBox = document.getElementById("log-console-box");
            
            // Preserve scroll height if user is looking at top, else scroll to bottom
            const isScrolledToBottom = logBox.scrollHeight - logBox.clientHeight <= logBox.scrollTop + 40;
            logBox.textContent = data.logs;
            
            if (isScrolledToBottom) {
                logBox.scrollTop = logBox.scrollHeight;
            }
        } catch (err) {
            document.getElementById("log-console-box").textContent = "拉取日志数据出错: " + err.message;
        }
    }

    document.getElementById("btn-refresh-logs").addEventListener("click", () => {
        if (currentSelectedTaskForLogs) {
            fetchLogs(currentSelectedTaskForLogs);
        }
    });


    // ----------------- TAB: MODEL RESEARCH -----------------
    let currentSelectedFile = null;

    async function fetchStrategyFiles() {
        try {
            const res = await fetch("/api/strategies");
            const data = await res.json();
            const list = document.getElementById("strategy-file-list");
            list.innerHTML = "";
            
            data.strategies.forEach(file => {
                const li = document.createElement("li");
                li.innerHTML = `<span class="fn">${file}</span>`;
                li.setAttribute("data-filename", file);
                
                if (currentSelectedFile === file) {
                    li.classList.add("active");
                }
                
                li.addEventListener("click", () => {
                    selectStrategyFile(file);
                });
                
                list.appendChild(li);
            });
            // Update strategy dropdown options
            await loadStrategyOptions();
        } catch (err) {
            console.error("无法加载文件列表: ", err);
        }
    }

    async function selectStrategyFile(filename) {
        currentSelectedFile = filename;
        document.querySelectorAll("#strategy-file-list li").forEach(li => {
            if (li.getAttribute("data-filename") === filename) {
                li.classList.add("active");
            } else {
                li.classList.remove("active");
            }
        });
        
        try {
            const res = await fetch(`/api/strategies/${encodeURIComponent(filename)}`);
            if (!res.ok) throw new Error("加载文件失败");
            const data = await res.json();
            
            document.getElementById("code-editor").value = data.code;
            document.getElementById("editor-filename").textContent = filename;
            document.getElementById("btn-save-strategy").disabled = false;
        } catch (err) {
            alert(err.message);
        }
    }

    // Save changes
    document.getElementById("btn-save-strategy").addEventListener("click", async () => {
        if (!currentSelectedFile) return;
        const code = document.getElementById("code-editor").value;
        const btn = document.getElementById("btn-save-strategy");
        
        btn.textContent = "正在保存...";
        btn.disabled = true;
        
        try {
            const res = await fetch(`/api/strategies/${encodeURIComponent(currentSelectedFile)}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ code })
            });
            if (!res.ok) throw new Error("保存代码失败");
            
            // Brief success state representation
            btn.textContent = "保存成功";
            setTimeout(() => {
                btn.textContent = "保存修改";
                btn.disabled = false;
            }, 1500);
        } catch (err) {
            alert(err.message);
            btn.textContent = "保存修改";
            btn.disabled = false;
        }
    });

    // Create new strategy file
    document.getElementById("btn-new-strategy").addEventListener("click", async () => {
        const name = prompt("请输入策略文件名 (包含 .py 后缀):", "new_strategy.py");
        if (!name) return;
        
        const starterTemplate = `import os
import sys
from datetime import datetime

# 引入 cjquant 并执行场外交易或分析
print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 新策略开始运行...")
print("核心量化计算完毕。")
`;

        try {
            const res = await fetch("/api/strategies/create", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name: name, code: starterTemplate })
            });
            if (!res.ok) {
                const errData = await res.json();
                throw new Error(errData.detail || "创建文件失败");
            }
            
            const data = await res.json();
            alert(`策略文件 '${data.filename}' 创建成功!`);
            
            await fetchStrategyFiles();
            // Automatically select new file
            selectStrategyFile(data.filename);
        } catch (err) {
            alert(err.message);
        }
    });


    // ----------------- TAB: ANALYTICS TOOLS -----------------

    // ----------------- 研究工具共用：被剔除标的的显式提示 -----------------
    // 数据源没有净值页 / 样本不足的标的会被后端剔除，必须在界面上说清楚，
    // 否则用户会以为这次结果覆盖了标的池里的每一只。
    function excludedNoticeHtml(excluded, dataSource) {
        const list = excluded || [];
        if (!list.length) return "";
        const items = list.map(x =>
            `<li><span class="font-mono">${x.fund}</span> — ${x.reason || "无可用净值"}</li>`).join("");
        const sim = dataSource === "simulated"
            ? `<div style="margin-top:6px;font-weight:600;color:var(--color-orange);">本次可用标的不足 2 只，结果已降级为随机模拟数据，不可用于任何决策。</div>`
            : "";
        return `<div style="margin-top:8px;padding:8px 10px;border:1px solid var(--color-orange);border-radius:4px;background:rgba(255,149,0,0.08);">
            <div style="color:var(--color-orange);font-weight:600;font-size:11px;margin-bottom:4px;">⚠ 以下标的已从本次计算中剔除（共 ${list.length} 只）</div>
            <ul style="margin:0;padding-left:16px;font-size:11px;color:var(--text-secondary);line-height:1.7;">${items}</ul>
            ${sim}
        </div>`;
    }

    function setExcludedNotice(resultsDiv, key, data) {
        if (!resultsDiv) return;
        const id = `${key}-excluded-notice`;
        let node = document.getElementById(id);
        if (!node) {
            node = document.createElement("div");
            node.id = id;
            resultsDiv.insertAdjacentElement("afterend", node);
        }
        node.innerHTML = excludedNoticeHtml(data && data.excluded, data && data.data_source);
    }

    function renderResearchFundPool() {
        // 1. Render chips
        const chipsContainer = document.getElementById("research-fund-chips");
        if (chipsContainer) {
            chipsContainer.innerHTML = "";
            researchFundPool.forEach(code => {
                const chip = document.createElement("div");
                chip.className = "chip";
                chip.innerHTML = `<span>${code}</span><span class="chip-remove" data-code="${code}">&times;</span>`;
                chip.querySelector(".chip-remove").addEventListener("click", () => {
                    removeResearchFund(code);
                });
                chipsContainer.appendChild(chip);
            });
        }

        // 2. Render FOF Optimizer checkboxes
        const optContainer = document.getElementById("opt-funds-container");
        if (optContainer) {
            optContainer.innerHTML = "";
            if (researchFundPool.length === 0) {
                optContainer.innerHTML = `<span style="font-size: 11px; color: var(--text-muted); padding: 4px;">标的池为空，请先添加</span>`;
            } else {
                researchFundPool.forEach(code => {
                    const label = document.createElement("label");
                    label.className = "checkbox-item";
                    label.innerHTML = `<input type="checkbox" name="opt-funds" value="${code}" checked> ${code}`;
                    optContainer.appendChild(label);
                });
            }
        }

        // 3. Render Look-Through Weights inputs
        const ltContainer = document.getElementById("look-through-weights-container");
        if (ltContainer) {
            ltContainer.innerHTML = "";
            if (researchFundPool.length === 0) {
                ltContainer.innerHTML = `<span style="font-size: 11px; color: var(--text-muted); padding: 4px;">标的池为空，请先添加</span>`;
            } else {
                const N = researchFundPool.length;
                const equalWeight = Math.floor((1.0 / N) * 100) / 100;
                const remainder = (1.0 - equalWeight * N).toFixed(2);
                
                researchFundPool.forEach((code, idx) => {
                    const val = idx === N - 1 ? (equalWeight + parseFloat(remainder)).toFixed(2) : equalWeight.toFixed(2);
                    const div = document.createElement("div");
                    div.className = "input-row";
                    div.innerHTML = `
                        <label for="lt-w-${code}">${code} 权重:</label>
                        <input type="number" class="lt-weight-input" data-code="${code}" id="lt-w-${code}" value="${val}" min="0" max="1" step="0.01" style="background-color: var(--bg-input); border: 1px solid var(--border-color); color: var(--text-primary); padding: 4px 6px; font-family: var(--font-mono); font-size: 11px;">
                    `;
                    ltContainer.appendChild(div);
                });
            }
        }
    }

    function addResearchFund(code) {
        code = code.trim().toUpperCase();
        if (code === "") return;
        // Basic format check or auto-append .OF if user typed just digits
        if (/^\d{6}$/.test(code)) {
            code = code + ".OF";
        }
        if (!researchFundPool.includes(code)) {
            researchFundPool.push(code);
            renderResearchFundPool();
        }
    }

    function removeResearchFund(code) {
        researchFundPool = researchFundPool.filter(c => c !== code);
        renderResearchFundPool();
    }

    // Register active fund pool events
    const inputFund = document.getElementById("input-research-fund");
    const btnAddFund = document.getElementById("btn-add-research-fund");
    
    if (btnAddFund && inputFund) {
        btnAddFund.addEventListener("click", () => {
            addResearchFund(inputFund.value);
            inputFund.value = "";
            inputFund.focus();
        });
        inputFund.addEventListener("keydown", (e) => {
            if (e.key === "Enter") {
                e.preventDefault();
                addResearchFund(inputFund.value);
                inputFund.value = "";
            }
        });
    }

    // Optimizer Form
    document.getElementById("form-optimize").addEventListener("submit", async (e) => {
        e.preventDefault();
        
        // Collect checked funds
        const checkboxes = document.querySelectorAll("input[name='opt-funds']:checked");
        const funds = Array.from(checkboxes).map(cb => cb.value);
        const method = document.getElementById("opt-method").value;
        
        if (funds.length < 2) {
            alert("请选择至少两个基金标的进行优化!");
            return;
        }
        
        try {
            const res = await fetch("/api/analytics/optimize", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ funds, method })
            });
            
            if (!res.ok) {
                const err = await res.json();
                throw new Error(err.detail || "计算优化权重失败");
            }
            
            const data = await res.json();
            
            // Draw result table
            const resultsDiv = document.getElementById("optimization-results");
            const tbody = document.getElementById("opt-results-body");
            tbody.innerHTML = "";
            if (data.data_source === "simulated") {
                tbody.innerHTML = `<tr><td colspan="2" style="color:var(--color-orange);font-weight:600;">⚠ 部分净值拉取失败，本次为模拟数据，仅供链路调试，不可实盘。</td></tr>`;
            }
            
            data.weights.forEach(item => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td style="font-family: var(--font-mono);">${item.fund}</td>
                    <td style="font-weight: 600; color: var(--color-blue);">${(item.weight * 100).toFixed(2)}%</td>
                `;
                tbody.appendChild(tr);
            });
            
            resultsDiv.classList.remove("hidden");
            setExcludedNotice(resultsDiv, "opt", data);
        } catch (err) {
            alert(err.message);
        }
    });

    // Look-Through Form
    document.getElementById("form-look-through").addEventListener("submit", async (e) => {
        e.preventDefault();
        
        const inputs = document.querySelectorAll(".lt-weight-input");
        const weights = {};
        let sum = 0.0;
        
        inputs.forEach(input => {
            const code = input.getAttribute("data-code");
            const val = parseFloat(input.value) || 0.0;
            weights[code] = val;
            sum += val;
        });
        
        if (Math.abs(sum - 1.0) > 0.0001) {
            alert(`配置权重加总不等于 100% (当前为: ${(sum*100).toFixed(1)}%)，请重新分配！`);
            return;
        }
        
        try {
            const res = await fetch("/api/analytics/look_through", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ weights })
            });
            
            if (!res.ok) {
                const err = await res.json();
                throw new Error(err.detail || "穿透分析失败");
            }
            
            const data = await res.json();
            const resultsDiv = document.getElementById("look-through-results");
            // 数据来源水印：real=全真季报，mixed=部分回退债基，fallback=全回退
            let srcNote = document.getElementById("lt-source-note");
            if (!srcNote) {
                srcNote = document.createElement("div");
                srcNote.id = "lt-source-note";
                srcNote.style.cssText = "font-size:11px;margin-bottom:8px;";
                resultsDiv.prepend(srcNote);
            }
            const src = data.data_source || "unknown";
            srcNote.textContent = src === "real"
                ? `真实季报穿透（${Object.keys(data.detail || {}).length}只全命中）${data.note || ""}`
                : `⚠ data_source=${src}：${data.note || "部分基金无股票持仓，按债券/货币回退，不代表个股暴露。"}`;
            srcNote.style.color = src === "real" ? "var(--text-muted)" : "var(--color-orange)";
            
            // Draw Industry Bars
            const indContainer = document.getElementById("lt-industry-bars");
            indContainer.innerHTML = "";
            Object.entries(data.industry).sort((a,b) => b[1] - a[1]).forEach(([ind, exp]) => {
                const pct = (exp * 100).toFixed(2) + "%";
                const row = document.createElement("div");
                row.className = "bar-row";
                row.innerHTML = `
                    <div class="bar-label"><span>${ind}</span><span>${pct}</span></div>
                    <div class="bar-bg"><div class="bar-fill" style="width: 0%;"></div></div>
                `;
                indContainer.appendChild(row);
                // Trigger animation
                setTimeout(() => {
                    row.querySelector(".bar-fill").style.width = pct;
                }, 50);
            });
            
            // Draw Style Bars
            const styleContainer = document.getElementById("lt-style-bars");
            styleContainer.innerHTML = "";
            Object.entries(data.style).sort((a,b) => b[1] - a[1]).forEach(([style, exp]) => {
                const pct = (exp * 100).toFixed(2) + "%";
                const row = document.createElement("div");
                row.className = "bar-row";
                row.innerHTML = `
                    <div class="bar-label"><span>${style}风格</span><span>${pct}</span></div>
                    <div class="bar-bg"><div class="bar-fill" style="background-color: var(--color-orange); width: 0%;"></div></div>
                `;
                styleContainer.appendChild(row);
                // Trigger animation
                setTimeout(() => {
                    row.querySelector(".bar-fill").style.width = pct;
                }, 50);
            });
            
            resultsDiv.classList.remove("hidden");
        } catch (err) {
            alert(err.message);
        }
    });

    // Correlation matrix rendering
    const btnRunCorrelation = document.getElementById("btn-run-correlation");
    if (btnRunCorrelation) {
        btnRunCorrelation.addEventListener("click", async () => {
            if (researchFundPool.length < 2) {
                alert("请在标的池中添加至少两个基金进行相关性分析！");
                return;
            }
            btnRunCorrelation.disabled = true;
            btnRunCorrelation.textContent = "计算中...";
            
            try {
                const res = await fetch("/api/analytics/correlation", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ funds: researchFundPool })
                });
                
                if (!res.ok) {
                    const err = await res.json();
                    throw new Error(err.detail || "计算相关性失败");
                }
                
                const data = await res.json();
                // 热力图必须用「实际参与计算的标的」，被剔除的标的不能留在行列标签里
                const usedFunds = (data.used_funds && data.used_funds.length >= 2)
                    ? data.used_funds : researchFundPool;
                renderCorrelationHeatmap(data.correlation, usedFunds, data.data_source);
                setExcludedNotice(document.getElementById("correlation-results"), "corr", data);
            } catch (err) {
                alert(err.message);
            } finally {
                btnRunCorrelation.disabled = false;
                btnRunCorrelation.textContent = "运行相关性计算";
            }
        });
    }

    function renderCorrelationHeatmap(corrList, funds, dataSource) {
        const thead = document.getElementById("corr-thead");
        const tbody = document.getElementById("corr-tbody");
        const resultsDiv = document.getElementById("correlation-results");
        
        if (!thead || !tbody || !resultsDiv) return;
        
        thead.innerHTML = "";
        tbody.innerHTML = "";
        if (dataSource === "simulated") {
            thead.innerHTML = `<tr><th colspan="${funds.length + 1}" style="color:var(--color-orange);font-size:11px;">⚠ 模拟数据（拉取失败降级），仅调试用</th></tr>`;
        }
        
        // 1. Build Header Row
        const trHead = document.createElement("tr");
        trHead.innerHTML = `<th class="corr-header-cell" style="text-align: left;">基金代码</th>`;
        funds.forEach(code => {
            const th = document.createElement("th");
            th.className = "corr-header-cell";
            th.textContent = code;
            trHead.appendChild(th);
        });
        thead.appendChild(trHead);
        
        // 2. Build Body Rows
        corrList.forEach(row => {
            const tr = document.createElement("tr");
            tr.innerHTML = `<td class="corr-cell" style="text-align: left; font-weight: 600; background-color: var(--bg-dark);">${row.fund}</td>`;
            
            funds.forEach(otherFund => {
                const val = row[otherFund] !== undefined ? row[otherFund] : 0.0;
                const td = document.createElement("td");
                td.className = "corr-cell";
                td.style.backgroundColor = getCorrColor(val);
                td.textContent = val.toFixed(3);
                td.title = `${row.fund} vs ${otherFund}: ${val.toFixed(4)}`;
                tr.appendChild(td);
            });
            tbody.appendChild(tr);
        });
        
        resultsDiv.classList.remove("hidden");
    }

    function getCorrColor(val) {
        if (val > 0) {
            return `rgba(15, 117, 196, ${val * 0.7})`; // Blue with max 70% opacity
        } else if (val < 0) {
            return `rgba(255, 59, 48, ${Math.abs(val) * 0.7})`; // Red with max 70% opacity
        } else {
            return "transparent";
        }
    }

    // Performance comparison rendering
    const btnRunPerformance = document.getElementById("btn-run-performance");
    if (btnRunPerformance) {
        btnRunPerformance.addEventListener("click", async () => {
            if (researchFundPool.length === 0) {
                alert("请先在标的池中添加基金标的！");
                return;
            }
            btnRunPerformance.disabled = true;
            btnRunPerformance.textContent = "计算中...";
            
            try {
                const res = await fetch("/api/analytics/performance", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ funds: researchFundPool })
                });
                
                if (!res.ok) {
                    const err = await res.json();
                    throw new Error(err.detail || "加载业绩对比失败");
                }
                
                const data = await res.json();
                renderPerformanceComparison(data.performance, data.data_source);
                setExcludedNotice(document.getElementById("performance-results"), "perf", data);
            } catch (err) {
                alert(err.message);
            } finally {
                btnRunPerformance.disabled = false;
                btnRunPerformance.textContent = "运行业绩指标对比";
            }
        });
    }

    function renderPerformanceComparison(perfList, dataSource) {
        const tbody = document.getElementById("perf-tbody");
        const resultsDiv = document.getElementById("performance-results");
        
        if (!tbody || !resultsDiv) return;
        
        tbody.innerHTML = "";
        if (dataSource === "simulated") {
            tbody.innerHTML = `<tr><td colspan="5" style="color:var(--color-orange);font-weight:600;">⚠ 模拟数据（拉取失败降级），仅调试用</td></tr>`;
        }
        
        perfList.forEach(item => {
            const tr = document.createElement("tr");
            tr.style.borderBottom = "1px solid var(--border-color)";
            
            const annRetClass = item.ann_return >= 0 ? "text-up" : "text-down";
            const annRetText = (item.ann_return >= 0 ? "+" : "") + (item.ann_return * 100).toFixed(2) + "%";
            const volText = (item.volatility * 100).toFixed(2) + "%";
            const sharpeClass = item.sharpe >= 1.0 ? "text-up" : (item.sharpe >= 0.0 ? "text-flat" : "text-down");
            const sharpeText = item.sharpe.toFixed(2);
            const maxDDText = (item.max_drawdown * 100).toFixed(2) + "%";
            
            tr.innerHTML = `
                <td style="padding: 8px; font-family: var(--font-mono); font-weight: 600;">${item.fund}</td>
                <td style="padding: 8px; text-align: right; font-weight: 600;" class="${annRetClass}">${annRetText}</td>
                <td style="padding: 8px; text-align: right; font-family: var(--font-mono);">${volText}</td>
                <td style="padding: 8px; text-align: right; font-weight: 600;" class="${sharpeClass}">${sharpeText}</td>
                <td style="padding: 8px; text-align: right; font-family: var(--font-mono); color: var(--color-green);">${maxDDText}</td>
            `;
            tbody.appendChild(tr);
        });
        
        resultsDiv.classList.remove("hidden");
    }

    // ----------------- TAB: FOF BACKTESTING -----------------
    
    // SVG Chart Plotter
    function drawBacktestChart(dailyStats) {
        const svg = document.getElementById("backtest-svg");
        if (!svg) return;
        
        // Clear previous elements
        svg.innerHTML = "";
        
        if (!dailyStats || dailyStats.length === 0) {
            svg.innerHTML = `<text x="50%" y="50%" fill="var(--text-muted)" font-size="12" text-anchor="middle" id="svg-placeholder-text">暂无数据，请运行回测</text>`;
            return;
        }
        
        // SVG Dimensions
        const svgWidth = 800;
        const svgHeight = 320;
        svg.setAttribute("viewBox", `0 0 ${svgWidth} ${svgHeight}`);
        
        const margin = { top: 25, right: 30, bottom: 40, left: 60 };
        const chartWidth = svgWidth - margin.left - margin.right;
        const chartHeight = svgHeight - margin.top - margin.bottom;
        
        // Find min and max returns
        const returns = dailyStats.map(s => s.return);
        let minRet = Math.min(...returns);
        let maxRet = Math.max(...returns);
        
        // Add small padding to min/max
        const retRange = maxRet - minRet;
        if (retRange === 0) {
            minRet -= 0.05;
            maxRet += 0.05;
        } else {
            minRet -= retRange * 0.1;
            maxRet += retRange * 0.1;
        }
        
        // Ensure we see 0.0 line if possible
        if (minRet > 0) minRet = 0;
        if (maxRet < 0) maxRet = 0;
        
        // Scales
        const getX = (index) => margin.left + (index / (dailyStats.length - 1)) * chartWidth;
        const getY = (val) => margin.top + chartHeight - ((val - minRet) / (maxRet - minRet)) * chartHeight;
        
        // Draw background grid lines (horizontal)
        const yTicks = 6;
        for (let i = 0; i <= yTicks; i++) {
            const val = minRet + (i / yTicks) * (maxRet - minRet);
            const y = getY(val);
            
            // Grid line
            const gridLine = document.createElementNS("http://www.w3.org/2000/svg", "line");
            gridLine.setAttribute("x1", margin.left);
            gridLine.setAttribute("y1", y);
            gridLine.setAttribute("x2", margin.left + chartWidth);
            gridLine.setAttribute("y2", y);
            gridLine.setAttribute("stroke", val === 0 ? "rgba(0,0,0,0.3)" : "var(--border-color)");
            gridLine.setAttribute("stroke-width", val === 0 ? "1" : "0.5");
            if (val !== 0) {
                gridLine.setAttribute("stroke-dasharray", "2,2");
            }
            svg.appendChild(gridLine);
            
            // Y label
            const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
            text.setAttribute("x", margin.left - 8);
            text.setAttribute("y", y + 4);
            text.setAttribute("fill", val >= 0 ? "var(--color-red)" : "var(--color-green)");
            if (val === 0) text.setAttribute("fill", "var(--text-muted)");
            text.setAttribute("font-size", "10");
            text.setAttribute("font-family", "var(--font-mono)");
            text.setAttribute("text-anchor", "end");
            text.textContent = (val >= 0 ? "+" : "") + (val * 100).toFixed(2) + "%";
            svg.appendChild(text);
        }
        
        // Draw vertical grid lines & X labels
        const xTicksCount = Math.min(5, dailyStats.length);
        for (let i = 0; i < xTicksCount; i++) {
            const index = Math.floor((i / (xTicksCount - 1)) * (dailyStats.length - 1));
            const s = dailyStats[index];
            const x = getX(index);
            
            // Vertical grid line
            const gridLine = document.createElementNS("http://www.w3.org/2000/svg", "line");
            gridLine.setAttribute("x1", x);
            gridLine.setAttribute("y1", margin.top);
            gridLine.setAttribute("x2", x);
            gridLine.setAttribute("y2", margin.top + chartHeight);
            gridLine.setAttribute("stroke", "var(--border-color)");
            gridLine.setAttribute("stroke-width", "0.5");
            gridLine.setAttribute("stroke-dasharray", "2,2");
            svg.appendChild(gridLine);
            
            // X label
            const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
            text.setAttribute("x", x);
            text.setAttribute("y", margin.top + chartHeight + 16);
            text.setAttribute("fill", "var(--text-muted)");
            text.setAttribute("font-size", "10");
            text.setAttribute("font-family", "var(--font-mono)");
            text.setAttribute("text-anchor", "middle");
            text.textContent = s.date;
            svg.appendChild(text);
        }
        
        // Draw performance curve line path
        let pathD = "";
        dailyStats.forEach((s, idx) => {
            const x = getX(idx);
            const y = getY(s.return);
            if (idx === 0) {
                pathD += `M ${x} ${y}`;
            } else {
                pathD += ` L ${x} ${y}`;
            }
        });
        
        const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
        path.setAttribute("d", pathD);
        path.setAttribute("fill", "none");
        path.setAttribute("stroke", "var(--color-red)"); // Portfolio line is QMT Red
        path.setAttribute("stroke-width", "2");
        svg.appendChild(path);
        
        // Draw interactive vertical crosshair, circle and tooltip group
        const crosshair = document.createElementNS("http://www.w3.org/2000/svg", "line");
        crosshair.setAttribute("x1", 0);
        crosshair.setAttribute("y1", margin.top);
        crosshair.setAttribute("x2", 0);
        crosshair.setAttribute("y2", margin.top + chartHeight);
        crosshair.setAttribute("stroke", "rgba(0, 0, 0, 0.4)");
        crosshair.setAttribute("stroke-width", "1");
        crosshair.setAttribute("stroke-dasharray", "3,3");
        crosshair.style.display = "none";
        svg.appendChild(crosshair);
        
        const trackerDot = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        trackerDot.setAttribute("r", "4");
        trackerDot.setAttribute("fill", "var(--bg-panel)");
        trackerDot.setAttribute("stroke", "var(--color-red)");
        trackerDot.setAttribute("stroke-width", "2");
        trackerDot.style.display = "none";
        svg.appendChild(trackerDot);
        
        // Tooltip elements
        const tooltipGroup = document.createElementNS("http://www.w3.org/2000/svg", "g");
        tooltipGroup.style.display = "none";
        
        const tooltipRect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        tooltipRect.setAttribute("fill", "rgba(255, 255, 255, 0.95)");
        tooltipRect.setAttribute("stroke", "var(--border-color)");
        tooltipRect.setAttribute("stroke-width", "1");
        tooltipRect.setAttribute("width", "150");
        tooltipRect.setAttribute("height", "55");
        tooltipGroup.appendChild(tooltipRect);
        
        const tooltipTextDate = document.createElementNS("http://www.w3.org/2000/svg", "text");
        tooltipTextDate.setAttribute("x", "8");
        tooltipTextDate.setAttribute("y", "16");
        tooltipTextDate.setAttribute("fill", "var(--text-muted)");
        tooltipTextDate.setAttribute("font-size", "10");
        tooltipGroup.appendChild(tooltipTextDate);
        
        const tooltipTextRet = document.createElementNS("http://www.w3.org/2000/svg", "text");
        tooltipTextRet.setAttribute("x", "8");
        tooltipTextRet.setAttribute("y", "32");
        tooltipTextRet.setAttribute("fill", "var(--text-primary)");
        tooltipTextRet.setAttribute("font-size", "11");
        tooltipTextRet.setAttribute("font-weight", "600");
        tooltipGroup.appendChild(tooltipTextRet);
        
        const tooltipTextAssets = document.createElementNS("http://www.w3.org/2000/svg", "text");
        tooltipTextAssets.setAttribute("x", "8");
        tooltipTextAssets.setAttribute("y", "46");
        tooltipTextAssets.setAttribute("fill", "var(--color-blue)");
        tooltipTextAssets.setAttribute("font-size", "10");
        tooltipTextAssets.setAttribute("font-family", "var(--font-mono)");
        tooltipGroup.appendChild(tooltipTextAssets);
        
        svg.appendChild(tooltipGroup);
        
        // Invisible overlay for tracking mouse
        const overlay = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        overlay.setAttribute("x", margin.left);
        overlay.setAttribute("y", margin.top);
        overlay.setAttribute("width", chartWidth);
        overlay.setAttribute("height", chartHeight);
        overlay.setAttribute("fill", "transparent");
        overlay.style.cursor = "crosshair";
        svg.appendChild(overlay);
        
        overlay.addEventListener("mousemove", (e) => {
            const rect = svg.getBoundingClientRect();
            const mouseX = ((e.clientX - rect.left) / rect.width) * svgWidth;
            
            const relativeX = mouseX - margin.left;
            const percent = Math.min(Math.max(relativeX / chartWidth, 0), 1);
            const index = Math.round(percent * (dailyStats.length - 1));
            const dataPoint = dailyStats[index];
            if (!dataPoint) return;
            
            const ptX = getX(index);
            const ptY = getY(dataPoint.return);
            
            // Update crosshair
            crosshair.setAttribute("x1", ptX);
            crosshair.setAttribute("x2", ptX);
            crosshair.style.display = "block";
            
            // Update dot
            trackerDot.setAttribute("cx", ptX);
            trackerDot.setAttribute("cy", ptY);
            trackerDot.style.display = "block";
            
            // Update Tooltip
            tooltipTextDate.textContent = `日期: ${dataPoint.date}`;
            
            const retVal = dataPoint.return;
            tooltipTextRet.textContent = `收益: ${(retVal * 100).toFixed(2)}%`;
            tooltipTextRet.setAttribute("fill", retVal >= 0 ? "var(--color-red)" : "var(--color-green)");
            
            tooltipTextAssets.textContent = `资产: ${dataPoint.total_assets.toLocaleString("zh-CN", { minimumFractionDigits: 2 })}`;
            
            // Tooltip position
            let tooltipX = ptX + 15;
            let tooltipY = ptY - 20;
            
            if (tooltipX + 150 > margin.left + chartWidth) {
                tooltipX = ptX - 165;
            }
            if (tooltipY + 55 > margin.top + chartHeight) {
                tooltipY = margin.top + chartHeight - 55;
            }
            if (tooltipY < margin.top) {
                tooltipY = margin.top;
            }
            
            tooltipGroup.setAttribute("transform", `translate(${tooltipX}, ${tooltipY})`);
            tooltipGroup.style.display = "block";
        });
        
        overlay.addEventListener("mouseleave", () => {
            crosshair.style.display = "none";
            trackerDot.style.display = "none";
            tooltipGroup.style.display = "none";
        });
    }

    // Submit backtest request
    document.getElementById("form-backtest").addEventListener("submit", async (e) => {
        e.preventDefault();
        
        const btn = document.getElementById("btn-run-backtest");
        
        const fundsRaw = document.getElementById("backtest-funds").value;
        const funds = fundsRaw.split(",").map(f => f.trim()).filter(f => f !== "");
        const initialCash = parseFloat(document.getElementById("backtest-initial-cash").value) || 0;
        const startDate = document.getElementById("backtest-start-date").value;
        const endDate = document.getElementById("backtest-end-date").value;
        const rebalanceFreq = document.getElementById("backtest-rebalance-freq").value;
        const fundsDisabled = document.getElementById("backtest-funds").disabled;
        
        if (funds.length === 0 && !fundsDisabled) {
            alert("请选择至少一个基金标的！");
            return;
        }

        btn.disabled = true;
        btn.textContent = "回测运行中... 0s";

        // ⚠️ 漏斗策略回测一次要 1~2 分钟（278 只 × 每月 RBSA 回归），
        //    期间后端没有任何中间响应。没有这个计时器，按钮一直停在"回测运行中..."，
        //    用户会以为程序崩了（实测就是这个观感：等 2 分钟无任何变化）。
        const btHint = document.getElementById("backtest-funds-hint");
        const btT0 = Date.now();
        let btTimer = setInterval(() => {
            const sec = Math.floor((Date.now() - btT0) / 1000);
            btn.textContent = `回测运行中... ${sec}s`;
            if (btHint) {
                btHint.textContent = sec < 15
                    ? "正在取数与预热，请稍候…"
                    : `已运行 ${sec} 秒。多标的策略（如五层漏斗 278 只）需逐月做风格回归，`
                      + `通常 1~3 分钟，请勿关闭窗口。`;
            }
        }, 1000);
        const stopBtTimer = () => { if (btTimer) { clearInterval(btTimer); btTimer = null; } };
        
        try {
            const res = await fetch("/api/analytics/backtest", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    funds: funds,
                    start_date: startDate,
                    end_date: endDate,
                    initial_cash: initialCash,
                    rebalance_freq: rebalanceFreq
                })
            });
            
            if (!res.ok) {
                const errData = await res.json();
                throw new Error(errData.detail || "后端计算回测失败");
            }
            
            const data = await res.json();
            // 0. 回显实际标的池归属（策略自带 vs 手填）
            const hint = document.getElementById("backtest-funds-hint");
            if (hint && data.universe) {
                const n = data.universe.length;
                const note = data.universe_note ? `（${data.universe_note}）` : "";
                const head = data.universe.slice(0, 8).join(", ");
                hint.textContent = data.universe_source === "strategy"
                    ? `本次回测标的由策略定义：共 ${n} 只${note}。${n > 8 ? `前 8 只：${head} …` : `全部：${head}`}`
                    : `本次回测标的由用户定义（${n} 只）。`;
            }
            
            // 1. Render Summary Stats
            const summary = data.summary;
            
            const trSpan = document.getElementById("bt-stat-total-return");
            trSpan.textContent = (summary.total_return >= 0 ? "+" : "") + (summary.total_return * 100).toFixed(2) + "%";
            trSpan.className = "value font-mono " + (summary.total_return >= 0 ? "text-up" : "text-down");
            
            const arSpan = document.getElementById("bt-stat-annualized-return");
            arSpan.textContent = (summary.annualized_return >= 0 ? "+" : "") + (summary.annualized_return * 100).toFixed(2) + "%";
            arSpan.className = "value font-mono " + (summary.annualized_return >= 0 ? "text-up" : "text-down");
            
            const mdSpan = document.getElementById("bt-stat-max-drawdown");
            mdSpan.textContent = (summary.max_drawdown * 100).toFixed(2) + "%";
            mdSpan.className = "value font-mono text-down"; // Drawdown is always negative/loss
            
            const srSpan = document.getElementById("bt-stat-sharpe-ratio");
            srSpan.textContent = summary.sharpe_ratio.toFixed(2);
            srSpan.className = "value font-mono " + (summary.sharpe_ratio >= 1.0 ? "text-up" : "text-flat");
            
            document.getElementById("bt-stat-final-assets").textContent = summary.final_assets.toLocaleString("zh-CN", { minimumFractionDigits: 2 });
            
            // 2. Render SVG chart
            drawBacktestChart(data.daily_stats);
            
            // 3. Render Daily Ledger Table
            const dailyList = document.getElementById("backtest-daily-list");
            dailyList.innerHTML = "";
            
            if (data.daily_stats.length === 0) {
                dailyList.innerHTML = `<tr><td colspan="7" class="loading">暂无回测明细数据</td></tr>`;
            } else {
                data.daily_stats.forEach(s => {
                    const tr = document.createElement("tr");
                    const retClass = s.return >= 0 ? "text-up" : "text-down";
                    const retText = (s.return >= 0 ? "+" : "") + (s.return * 100).toFixed(2) + "%";
                    
                    tr.innerHTML = `
                        <td style="color: var(--text-muted); font-size: 12px; height: 30px;"><span class="cell-text">${s.date}</span></td>
                        <td style="font-family: var(--font-mono);"><span class="cell-text">${s.available_cash.toLocaleString("zh-CN", { minimumFractionDigits: 2 })}</span></td>
                        <td style="font-family: var(--font-mono);"><span class="cell-text">${(s.frozen_cash || 0.0).toLocaleString("zh-CN", { minimumFractionDigits: 2 })}</span></td>
                        <td style="font-family: var(--font-mono);"><span class="cell-text">${s.transit_cash.toLocaleString("zh-CN", { minimumFractionDigits: 2 })}</span></td>
                        <td style="font-family: var(--font-mono);"><span class="cell-text">${s.market_value.toLocaleString("zh-CN", { minimumFractionDigits: 2 })}</span></td>
                        <td style="font-family: var(--font-mono); font-weight: 500;"><span class="cell-text text-blue">${s.total_assets.toLocaleString("zh-CN", { minimumFractionDigits: 2 })}</span></td>
                        <td><span class="cell-text ${retClass}" style="font-weight: 600;">${retText}</span></td>
                    `;
                    dailyList.appendChild(tr);
                });
            }
            
            // 4. Render Trade History Table
            const tradeList = document.getElementById("backtest-trade-list");
            tradeList.innerHTML = "";
            
            if (data.trades.length === 0) {
                tradeList.innerHTML = `<tr><td colspan="11" class="loading">无任何交易订单确认历史</td></tr>`;
            } else {
                data.trades.forEach(t => {
                    const tr = document.createElement("tr");
                    const dirClass = t.direction === "买入" ? "badge-red" : "badge-orange";
                    
                    tr.innerHTML = `
                        <td style="color: var(--text-muted);"><span class="cell-text">${t.trade_id}</span></td>
                        <td style="color: var(--text-muted);"><span class="cell-text">${t.order_id}</span></td>
                        <td style="font-family: var(--font-mono);"><span class="cell-text">${t.fund_code}</span></td>
                        <td><span class="cell-text"><span class="badge ${dirClass}">${t.direction}</span></span></td>
                        <td style="font-size: 11px;"><span class="cell-text">${t.submit_date}</span></td>
                        <td style="font-size: 11px;"><span class="cell-text">${t.confirm_date}</span></td>
                        <td style="font-size: 11px;"><span class="cell-text">${t.settle_date}</span></td>
                        <td style="font-family: var(--font-mono);"><span class="cell-text">${t.nav.toFixed(4)}</span></td>
                        <td style="font-family: var(--font-mono);"><span class="cell-text">${t.shares.toLocaleString("zh-CN", { minimumFractionDigits: 2 })}</span></td>
                        <td style="font-weight: 500;"><span class="cell-text">${t.volume.toLocaleString("zh-CN", { minimumFractionDigits: 2 })}</span></td>
                        <td><span class="cell-text">${t.fee.toFixed(2)}</span></td>
                    `;
                    tradeList.appendChild(tr);
                });
            }

            // 5. 全量数据导出按钮（回测成功后出现；zip 内含每日资产/逐日持仓市值矩阵/
            //    全部成交/月度收益/归因摘要，供离线做全量归因）
            // ⚠️ 不用 window.location.href：那是导航式下载，接口 404/500 时浏览器
            //    静默失败（顶多跳个错误页），用户只会觉得"按了没反应、找不到 zip"。
            //    fetch+blob 能捕获状态码并给出明确提示（最常见原因：后端没重启，
            //    旧进程里没有这个新接口）。
            const expBtn = document.getElementById("btn-export-backtest");
            if (expBtn && data.record_id) {
                expBtn.style.display = "inline-block";
                expBtn.onclick = async () => {
                    const orig = expBtn.textContent;
                    expBtn.disabled = true;
                    expBtn.textContent = "打包中…";
                    try {
                        const r = await fetch(`/api/backtests/${encodeURIComponent(data.record_id)}/export`);
                        if (r.status === 404) {
                            throw new Error("导出接口不存在（404）——后端服务是旧进程，请关闭并重新运行 run_gui.py 后再试。");
                        }
                        if (!r.ok) {
                            const t = await r.text().catch(() => "");
                            throw new Error(`导出失败 HTTP ${r.status}：${t.slice(0, 200)}`);
                        }
                        const blob = await r.blob();
                        const fname = `backtest_${String(data.record_id).replace(".json", "")}.zip`;
                        // 服务端同时把 zip 落了一份到 app/exports/（绝对路径在响应头里）
                        // —— 桌面壳的浏览器下载目录不好找，项目内的副本一定在。
                        const savedPath = r.headers.get("X-Export-Path");
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement("a");
                        a.href = url;
                        a.download = fname;
                        document.body.appendChild(a);
                        a.click();
                        a.remove();
                        setTimeout(() => URL.revokeObjectURL(url), 3000);
                        expBtn.textContent = `✓ 已导出 ${fname}`;
                        setTimeout(() => { expBtn.textContent = orig; }, 4000);
                        alert(savedPath
                            ? `导出完成！\n\n已保存到项目目录（一定存在）：\n${savedPath}\n\n浏览器副本 ${fname} 可能也在你的下载文件夹。`
                            : `导出完成：${fname}（请查看浏览器下载文件夹）`);
                    } catch (err) {
                        alert(err.message);
                        expBtn.textContent = orig;
                    } finally {
                        expBtn.disabled = false;
                    }
                };
            }

        } catch (err) {
            alert(err.message);
            if (btHint) {
                btHint.textContent = `回测失败（已运行 ${Math.floor((Date.now() - btT0) / 1000)} 秒）：${err.message}`;
            }
        } finally {
            stopBtTimer();
            btn.disabled = false;
            btn.textContent = "运行回测模拟";
        }
    });

    // ----------------- APP INITIAL LOADING -----------------
    // Start on portfolio tab
    onTabChanged("tab-portfolio");
});

