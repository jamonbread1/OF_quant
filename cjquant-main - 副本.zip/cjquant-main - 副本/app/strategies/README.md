# 策略编写规范（Strategy Spec）· 生产版 v2

> 适用范围：`cjquant-main` 全框架。后续所有策略必须按此规范编写，才能完整对接回测 / 调度 / 下单 / 投研 / 记账闭环。
> 核心实现对照：`app/main.py`（API+调度+回测编排）、`cjquant/`（量化内核）、`app/static/app.js`（前端调用）。
> 生产新增：真复权 + 清洗 + PIT + 动态池（Phase1）、因子引擎（Phase2）、差集轮动（Phase3）。

**现货清单**：当前上线的策略是**五层漏斗 FOF 选基** —— 回测插件
`fof_funnel/funnel_rotation.py`，调度任务 `fof_funnel/funnel_rotation_task.py`，
核心算法在 `cjquant/funnel/`（不写在策略文件里，保证回测与上线同口径）。
数据运维任务在 `data_ops/`。
早先的 `mf_rotation/multifactor_topn*.py` 已于 2026-09-19 归档到 `archive/`，
不再参与调度与回测（见 `archive/README.md`）。
* 调度任务必须定义 `run_strategy/run_monitor/run/main` 之一 + 可选 `SCHEDULE={"name","interval"}` 自注册
* `kind=both` 允许双栖，但新策略禁止（回测与实盘分离）
* `GET /strategies_with_meta` 供下拉按 kind 过滤；`GET /strategies/{name}/meta` 供回测锁定标的

---

## 1. 两种策略类型（必须先选对）

| 类型 | 运行位置 | 触发方式 | 基类/接口 | 用途 |
|------|----------|----------|-----------|------|
| **A. 回测插件** | `POST /api/analytics/backtest` 内 `importlib` 动态加载 | 回测页“调仓策略”下拉选中后，引擎逐交易日调用 | 必须定义 `handle_bar(context)`，可选 `init(context)` | 历史仿真：首日建仓、按月/季/年再平衡、风险平价等 |
| **B. 调度脚本** | `asyncio.create_subprocess_exec(sys.executable, strategies/xxx.py)` 独立子进程，`cwd=项目根` | 策略调度页创建任务 → 定时（interval 秒）或手动运行，日志写 `app/logs/{任务名}.log` | 必须 `if __name__=="__main__": run_xxx()`，靠 `print` 输出日志 | 生产/准生产：定时算权重、`OTCExecutor` 落盘 O32/微信单、合规监控 |

目录规则：

* 策略文件一律放 `app/strategies/*.py`，UTF-8。文件名即注册名，前端两个下拉（任务页 `task-strategy`、回测页 `backtest-rebalance-freq`）都来自 `GET /api/strategies` 即 `os.listdir(STRATEGIES_DIR)` 过滤 `.py`（`app/main.py:334`）。
* 推荐纯 ASCII 文件名。中文名可用（后端用 `{name:path}` + 前端 `encodeURIComponent`），但 O32/日志排错成本高，新策略禁止中文名。
* `STRATEGIES_DIR` 为空是合法状态：回测内置 `once/monthly/monthly_rp` 照常可用；新建任务前需先在“模型研究”页创建文件。
* 调度脚本必须可独立执行：文件头加：
  ```python
  import os, sys
  sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
  ```

---

## 2. 类型 A：回测插件规范

### 2.1 生命周期

```
POST /api/analytics/backtest {funds, start_date, end_date, initial_cash, rebalance_freq}
  → 后端 akshare 拉数 → OTCBacktestEngine(T+1确认/T+3到账)
  → if rebalance_freq=="once|monthly|monthly_rp": 内置逻辑
    else: importlib 加载 strategies/{rebalance_freq}，要求 handle_bar 存在
  → init(context) 一次 → while trading_dates: handle_bar(context); engine.step()
  → 返回 {summary, daily_stats, trades}
```

* `rebalance_freq` 传文件名（如 `my_strategy.py`）即选中该插件；传 `once/monthly/monthly_rp` 则走内置（`app/main.py:859-887`）。文件不存在 → 400。
* `handle_bar` 每个交易日按时间顺序调一次，无返回值，异常会直接 500 并带日期（`app/main.py:936-940`），务必内部 `try/except` 做降级。
* 状态寄存在 `context` 属性上（如 `context.last_month`），不要用全局变量。

### 2.2 `BacktestContext` 全 API（`app/main.py:755-810`）

```python
context.funds: List[str]              # 本次回测标的，如 ["000001.OF"]
context.current_date: datetime        # 当前交易日
context.current_date_idx: int         # 下标，首日==0
context.cash: float                   # 可用现金（不含冻结/在途）
context.positions: Dict[str,float]    # {code: 总份额(含冻结)}，只含份额>0
context.buy(fund_code, value: float)  # 按金额申购 → engine.submit_order(BUY)
context.sell(fund_code, shares: float)# 按份额赎回 → engine.submit_order(SELL)
context.get_nav(code, date) -> float|None   # 查复权净值（ffill 缓存）
context.get_history_navs(code, count) -> Series  # 截止当日的近N个adj_nav
context.rebalance(target_weights: Dict[str,float])  # 见2.3
```

### 2.3 `rebalance` 语义（必须理解，否则资金对不上）

* 先按 `total_available_shares` 全卖（`app/main.py:791-798`）。若有卖出/在途/pending，则把 `target_weights` 存为 `_reinvest_weights` 暂不买；主循环（`app/main.py:898-934`）等 `transit==0 and pending==0` 时再按权重全仓买入，按 `w/sum(w)` 归一、最后一只接余数（浮点尾差处理）。
* 若无持仓无在途，则立即按 `cash` 全买。`cash<=100` 不动作。
* 这是为了还原 `T+1确认/T+3到账`：卖出资金在途时不可复投。自定义插件不要自己实现等待，直接调 `rebalance` 即可。

### 2.4 模板

```python
import pandas as pd
from cjquant.optimizer.traditional import RiskParityOptimizer

def init(context):
    context.last_month = None
    print(f"Init with {context.funds}")

def handle_bar(context):
    d = context.current_date
    first = (context.current_date_idx == 0)
    new_month = (context.last_month is not None and d.month != context.last_month)
    context.last_month = d.month
    if first:
        context.rebalance({f: 1.0/len(context.funds) for f in context.funds})
    elif new_month:
        try:
            hist = {}
            for f in context.funds:
                navs = context.get_history_navs(f, count=60)
                if len(navs) > 5:
                    hist[f] = navs.pct_change().dropna()
            df = pd.DataFrame(hist).dropna()
            w = RiskParityOptimizer(df).optimize().to_dict() if len(df) > 10 else \
                {f: 1.0/len(context.funds) for f in context.funds}
        except Exception as e:
            print(f"optimizer fallback: {e}")
            w = {f: 1.0/len(context.funds) for f in context.funds}
        context.rebalance(w)
```

参考已删内置：等权月再平衡见旧 `backtest_demo.py`；季度风险平价+静态回退见旧 `桥水全天候.py`；年检+5%阈值见旧 `永久投资组合.py`。

### 2.5 禁止事项 + 生产铁律

* 禁止 `import app.main`（循环依赖）；只用 `context` + `cjquant.*`。
* 禁止文件 IO 写盘、网络长阻塞；回测是同步 HTTP，超时即 500。
* `buy/sell` 金额/份额 `>0.01` 才会被执行（后端过滤），小数直接丢单。
* `sell` 超可用份额会抛 `InsufficientPositionError`，先查 `context.positions`。
* **必须用 `get_history_navs_pit`（不含当日），禁止 `get_history_navs` 直接做信号**，否则前视。
* **TopN 必须用 `context.rotate`，禁止 `context.rebalance`**（后者全卖全买，多付费 + T+3 空仓）。`rotate` 语义见 `app/main.py:806-863`。
* 新基金历史 `<180` 点必须排除出候选（漏斗侧由 `funnel_rotation.UNIVERSE_MIN_ROWS`
  与 `get_universe()` 的净值可得性门槛负责；`CANDIDATES` 只是取不到数时的兜底）。

---

## 3. 类型 B：调度脚本规范

### 3.1 生命周期

```
前端 新建任务 {name, strategy_file, schedule_value} → tasks.json
  → toggle enabled → scheduler_loop 每5s 扫 next_run (app/main.py:146-189)
  → run_task_process: 状态running → 子进程 stdout/stderr 实时追加入 logs/{name}.log
  → exit 0→idle，否则error；interval 任务自动算下次 next_run
```

* `tasks.json` schema：`{name, strategy_file, schedule_type:"interval", schedule_value:秒, enabled, status, last_run, next_run}`。`schedule_value>=5`。
* 脚本单次跑完必须退出，禁止死循环/`while True`。定时靠调度器重复拉起。
* 日志只看后 300 行（`GET /api/tasks/{name}/logs`），关键结果 `print` 中文即可，异常也要 `print`。
* `cwd` 是项目根（`app/main.py:95`），`output_dir="./"` 即根目录，不要写绝对路径。

### 3.2 下单闭环（调度脚本唯一允许的“交易出口”）

```python
from cjquant.execution import OTCExecutor
ex = OTCExecutor(portfolio_id="FOF001", asset_unit="FOF001_01",
                 output_dir="./", strip_suffix=True)
ex.buy("000001.OF", amount=100000.0)   # 申购按金额
ex.sell("000002.OF", shares=50000.0)   # 赎回按份额
ex.execute(channels=["o32","wechat"], file_prefix="rp_rebalance")
# 落盘 ./rp_rebalance_o32.csv(gbk) + ./rp_rebalance_wechat.csv(utf8-sig)
```

* O32 列：证券代码/业务类别(申购/赎回)/委托金额/委托数量/组合编号/资产单元/交易日期(`%Y%m%d`)，代码默认去 `.OF`（`cjquant/execution/o32.py:43-48`）。微信列：基金代码/交易类型/发生金额/发生份额/交易渠道/申请时间。
* 不要直写 `portfolio.json`。下次 `GET /api/portfolio` 时 `sync_exported_orders_to_portfolio (app/main.py:197-280)` 会自动把 `*_o32.csv/*_wechat.csv` 记为 `transactions(已导出)` 并重命名 `.processed_时间戳` 防重。只记流水，不改 cash/持仓；持仓盈亏在前端手工或 `refresh_navs` 更新。
* `execute` 前 `output_dir` 不存在会自动建；无订单时返回 `{}` 并打印警告。

### 3.3 模板

```python
import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
import pandas as pd
from datetime import datetime
from cjquant.optimizer.traditional import RiskParityOptimizer
from cjquant.execution import OTCExecutor

def run_strategy():
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] start")
    funds = ["000001.OF","000002.OF"]
    # ... 拉数/算权重（见第4章）...
    ex = OTCExecutor(portfolio_id="FOF001", asset_unit="FOF001_01", output_dir="./")
    ex.buy(funds[0], 100000.0)
    print(ex.execute(channels=["o32","wechat"], file_prefix="my_task"))

if __name__ == "__main__":
    run_strategy()
```

---

## 4. `cjquant` 全功能速查（两类策略共用）

### data — 数据（生产：真复权+缓存+清洗+PIT+动态池）

```python
from cjquant.data.pipeline import DataPipeline
p = DataPipeline(cache_dir="./.cache/cjquant", adjust=True)  # 上线必传 cache
df = p.get_public_fund("000001", start_date="2023-01-01", end_date="2023-12-31")
# -> adj_nav 已按 a(t)=a(t-1)*[u*s+d]/u(t-1) 真复权，adj_method 列标记口径
panel = p.create_universe_panel(public_codes=[...],
    start_date=..., freq="B", resample_method="ffill",
    pit_lag=1,  # 策略信号必须 1，防前视；仅展示可 0
)
eligible = p.eligible_funds_at("2023-07-01", panel, status_map=..., scale_map=...)
# 新基金<180天、清盘(末值距asof>60天)、封闭期、规模<2亿 自动排除
```

### backtest — 引擎（调度脚本想自做仿真时用；回测插件禁止直调）

```python
from cjquant.backtest.engine import OTCBacktestEngine
from cjquant.backtest.fee import OTCFeeModel
from cjquant.backtest.slippage import SquareRootSlippage, ZeroSlippage, CustomLambdaSlippage
fee = OTCFeeModel(buy_fee_rate=0.0015)
fee.set_sell_tiers([(7,0.015),(30,0.0075),(365,0.005),(float('inf'),0.0)])  # 按持有自然日
eng = OTCBacktestEngine(market_data=long_df, initial_cash=1e7,
    t_plus_confirm=1, t_plus_settle=3, slippage_model=SquareRootSlippage(0.05,1e8))
eng.fee_model = fee
eng.submit_order('000001.OF','BUY',value=5e6)  # BUY按value，SELL按shares
while eng.current_date_idx < len(eng.trading_dates):
    # ... 策略 ...
    eng.step()
eng.export_trades_csv('trades.csv'); eng.export_results_csv('results.csv')
# market_data 须为长表：index=date, 含 fund_code+adj_nav；NAV缺口已ffill；BUY冻结cash，SELL冻结shares+在途
```

### optimizer — 权重

```python
from cjquant.optimizer.traditional import RiskParityOptimizer, MeanVarianceOptimizer
from cjquant.optimizer.machine_learning import HRPOptimizer
from cjquant.optimizer.black_litterman import BlackLittermanOptimizer
from cjquant.optimizer.utils import calculate_shrunk_covariance
RiskParityOptimizer(rets_df).optimize()              # -> Series，和=1
MeanVarianceOptimizer(rets_df, risk_free_rate=0.02).optimize()
HRPOptimizer(rets_df).optimize()                     # fillna(0)内部处理
BlackLittermanOptimizer(rets_df, pi=eq_ret, tau=0.05).optimize(Q,P,Omega=None)
# 输入 rets_df 须为宽表日收益；样本不足时协方差已 LedoitWolf 收缩
```

### look_through — 穿透

```python
from cjquant.look_through.engine import LookThroughAnalyzer
# RBSA：黑盒净值反推
a = LookThroughAnalyzer(method='RBSA', factor_returns=factor_rets_df)
r = a.run(fund_rets_series, window=60)   # -> .exposures{因子:权}, .r_squared
# HBA：持仓加权（ holdings 须含 fund_code,stock_code,weight,industry,style ）
a2 = LookThroughAnalyzer(method='HBA', holdings_df=holdings_df)
r2 = a2.run({"000001.OF":0.4}, category="industry")  # category="industry|style"
```

### execution — 导出

```python
from cjquant.execution import O32OrderExporter, OTCExecutor
O32OrderExporter(portfolio_id, asset_unit, strip_suffix=True).export(
    engine.pending_orders, "o32.csv", format="csv", encoding="gbk")
```

### visualizer — 报告（`results.csv` 须含 total_assets/daily_return）

```python
from cjquant.visualizer.reporter import CJQuantReporter
CJQuantReporter('results.csv','trades.csv').generate_html('report.html')
```

---

## 5. 联调 Checklist（上线版）

1. 回测插件：`init/handle_bar` 签名对、`context.rotate` 权重和>0、用 `get_history_navs_pit`、历史不足跳过、有首日建仓分支。`pytest tests/test_phase3.py` 通过。
2. 调度脚本：本地 `python app/strategies/xxx.py` 能一次跑通、根目录生成 `*_o32.csv/*_wechat.csv`、前端任务日志可见、`GET /api/portfolio` 后 transactions 出现且文件被 `.processed_` 改名。
3. 数据：`pytest tests/test_phase1.py`（复权连续/跳变/PIT/动态池）+ `test_phase2.py`（因子/评分）全绿；回测链路已切真复权+清洗（`app/main.py` backtest）。
4. 基金代码：回测/优化用 `XXXXXX.OF`；O32 去后缀靠 `strip_suffix`，`sync` 靠 `zfill(6)+.OF` 还原。
5. 金额精度：买入分配做末位余数处理，避免 `available - allocated` 漂移触发 `lock_cash`。
6. 上线运维：`.cache/cjquant` 保留（加速+可复现）；`app/logs/*.log` 只看后300行，大任务拆小步打印；`tasks.json interval>=5`；`panel start` 须早于策略起始 180 天以上，否则新基金过滤失效。
7. 调试：回测 500 看 `traceback` 的日期+函数；调度看 `app/logs/{任务}.log`；持仓页 `更新净值` 调 `POST /api/portfolio/refresh_navs` 拉 akshare。

### cjquant.factors — 通用因子引擎（Phase2）

```python
from cjquant.factors import compute_factors_at, FactorScorer
f = compute_factors_at(panel_pit, asof, rf=0.02)  # 9因子：mom_20/60/250_skip20/质量/sharpe/sortino/calmar/max_dd/recovery
scored = FactorScorer().score(f)  # 横截面Z + clip(±3) + 默认权 15/20/10/5/20/10/10/5/5
top = FactorScorer().top_n(scored, 3)
```

⚠️ 这是**通用因子引擎**，供独立研究与快速原型使用。
**当前上线的五层漏斗不用它** —— 漏斗有自己的六维因子体系
（`cjquant/funnel/factors.py` 的 D1~D6，含 MAD 去极值、中性化与两级打分）。
两套不要混用，否则回测与上线口径会对不上。

新策略的推荐做法：复制 `fof_funnel/funnel_rotation.py`（回测）+
`fof_funnel/funnel_rotation_task.py`（调度），把核心算法放进 `cjquant/<策略名>/`，
只让策略文件做"读数据 / 调算法 / 落订单"三件事。
不要复制已归档的 `mf_rotation`。
