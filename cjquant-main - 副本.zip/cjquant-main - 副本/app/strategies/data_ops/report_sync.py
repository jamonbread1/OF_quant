# -*- coding: utf-8 -*-
"""定期报告同步（数据运维）：补 D5/D6 需要的持仓 / 行业配置 / 费率。

按预算分批填充 `fund_reports.db`，断点续跑（report_progress 已 ok 的跳过）。

⚠️ 费率/申赎状态有 7 天过期重抓：申购状态每天都在变，不能抓一次用一辈子。
"""
import os
import sys
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))


def _project_root(start: str) -> str:
    d = os.path.abspath(start)
    while True:
        if os.path.exists(os.path.join(d, "run_gui.py")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            return os.path.abspath(os.path.join(start, "..", ".."))
        d = parent


ROOT = _project_root(_HERE)
STRATEGIES_DIR = os.path.join(ROOT, "app", "strategies")
sys.path.append(ROOT)
sys.path.append(_HERE)

from cjquant.data.fund_reports import default_store, sync_fund   # noqa: E402
from _common import scan_strategy_candidates, dynamic_universe  # noqa: E402

# 2026-09-18 启用：漏斗的 D5 持仓健康族（HHI/隐含换手/共识度）与 D6 费率
# 目前全部缺席（fund_reports.db 未建库），导致 6 维里 2 维没有数据。
# 每夜一批（BATCH 只 × YEARS 年），断点续跑，单只失败不阻断。
SCHEDULE = {"name": "定期报告同步", "interval": 86400, "enabled": True}
BATCH = int(os.environ.get("CJQ_REPORT_BATCH", "40") or 40)
YEARS = int(os.environ.get("CJQ_REPORT_YEARS", "3") or 3)


# ---------------- 候选扫描（实现已迁入 _common.py） ----------------
# 【2026-09-26】原先 _all_strategy_candidates / _dynamic_universe 各写一份，
# 与 fund_master_update._priority_codes 是第三份，三者的排除目录还不一致
# （有的把 data_ops 目录自己也扫进去）。现在统一到 _common 共用一份实现。


def _all_strategy_candidates() -> list:
    """扫所有策略组声明的 CANDIDATES / UNIVERSE（AST 静态解析，不 import，避免副作用）。

    ⚠️ 不能只 import fof_funnel：数据运维任务是**公共基础设施**，
    绑死某一个策略组会导致——新增策略组时这里不跟着改就永远同步不到，
    而删掉那个策略组时这个运维任务会直接 ImportError 挂掉。
    """
    return scan_strategy_candidates(STRATEGIES_DIR)


def _dynamic_universe(limit: int = 0) -> list:
    """尝试各策略组的动态 get_universe()（能拿到就用，拿不到不影响主流程）。"""
    return dynamic_universe(STRATEGIES_DIR)


def _sync_market_db(done_n: int):
    """本任务写 legacy 报告仓后，把费率/经理/公告/持有人/持仓/行业吸收进 market.db。

    报告库很小（单只几千行），全量幂等吸收成本可忽略；market.db 才是策略读源。
    """
    try:
        from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
        from cjquant.data.market_db_migrate import absorb_legacy
        mk = MarketDB(DEFAULT_MARKET_DB, create=True)
        started = mk.log_task_start("report_sync.sync")
        try:
            res = absorb_legacy(mk, parts=("reports",))
            print(f"[统一数据仓] 吸收报告数据：{res}")
            mk.log_task_finish("report_sync.sync", started, status="ok",
                               n_rows=done_n, message="reports absorbed")
        finally:
            mk.close()
    except Exception as e:
        print(f"[WARN] 统一数据仓吸收失败（legacy 数据已落盘，次日会补）: {e}")


def run_strategy():
    store = default_store(create=True)
    if store is None:
        print("[ERROR] 报告仓无法创建")
        return
    codes: list = []
    try:
        codes = _all_strategy_candidates()
    except Exception as e:
        print(f"[WARN] 扫描策略候选失败: {e}")
    try:
        codes += _dynamic_universe()
    except Exception as e:
        print(f"[WARN] 取动态标的池失败: {e}")
    # 去重保序
    seen, uniq = set(), []
    for c in codes:
        if c and c not in seen:
            seen.add(c)
            uniq.append(c)
    codes = uniq
    if not codes:
        print("[WARN] 无候选，退出")
        return

    years = [datetime.now().year - i for i in range(YEARS)]
    done = 0
    for code in codes[:BATCH]:
        try:
            sync_fund(store, code, years)
            done += 1
        except Exception as e:
            print(f"[WARN] {code} 同步失败: {e}")
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] 定期报告同步 {done}/{min(len(codes), BATCH)} 只，"
          f"库内 {store.stats()}")
    try:
        store.close()
    except Exception:
        pass
    # Phase C：写端切换 —— 立即把本次结果吸收进统一数据仓（权威读源）
    _sync_market_db(done)


if __name__ == "__main__":
    run_strategy()
