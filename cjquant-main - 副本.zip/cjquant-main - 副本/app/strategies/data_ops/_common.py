# -*- coding: utf-8 -*-
"""data_ops 运维任务的公共工具。

⚠️ 用 AST 静态解析而非 import：运维任务是公共基础设施，import 某个具体策略组
会导致新增组时不同步、删掉该组时运维任务直接 ImportError 挂掉。
"""
import ast
import os


def scan_strategy_candidates(strategies_dir: str,
                             exclude_dirs=("__pycache__", "data_ops")) -> list:
    """扫所有策略组里声明的 CANDIDATES / UNIVERSE，返回去重保序的代码列表。

    strategies_dir: app/strategies 目录
    exclude_dirs:   默认排除 __pycache__ 与 data_ops（运维脚本自身，不含策略）
    """
    codes: list = []
    if not os.path.isdir(strategies_dir):
        return codes
    for dp, dns, fns in os.walk(strategies_dir):
        dns[:] = [d for d in dns if d not in exclude_dirs]
        for fn in fns:
            if not fn.endswith(".py"):
                continue
            try:
                with open(os.path.join(dp, fn), encoding="utf-8") as f:
                    tree = ast.parse(f.read())
            except Exception:
                continue  # 语法错误的文件不该拖垮整个扫描
            for node in tree.body:
                if not isinstance(node, ast.Assign):
                    continue
                for t in node.targets:
                    if isinstance(t, ast.Name) and t.id in ("CANDIDATES", "UNIVERSE"):
                        try:
                            vals = ast.literal_eval(node.value)
                        except Exception:
                            continue  # 动态构造的（如函数调用）无法静态求值，跳过
                        if isinstance(vals, (list, tuple)):
                            codes += [str(x) for x in vals]
    # 去重保序
    seen, out = set(), []
    for c in codes:
        if c and c not in seen:
            seen.add(c)
            out.append(c)
    return out


def dynamic_universe(strategies_dir: str,
                     exclude_dirs=("__pycache__", "data_ops")) -> list:
    """运行时问各策略组"你现在的池子是什么"（拿不到就跳过）。

    与 scan_strategy_candidates 的区别：那份是静态读代码里的常量，
    这份是运行时调用 get_universe()。两者互补。
    """
    import importlib
    import sys

    codes: list = []
    if not os.path.isdir(strategies_dir):
        return codes
    for name in sorted(os.listdir(strategies_dir)):
        gdir = os.path.join(strategies_dir, name)
        if not os.path.isdir(gdir) or name in exclude_dirs:
            continue
        if gdir not in sys.path:
            sys.path.append(gdir)
        for fn in sorted(os.listdir(gdir)):
            if not fn.endswith(".py"):
                continue
            try:
                m = importlib.import_module(fn[:-3])
                gu = getattr(m, "get_universe", None)
                if callable(gu):
                    got = gu() or []
                    if got:
                        codes += [str(c) for c in got]
                        break
            except Exception:
                continue
    seen, out = set(), []
    for c in codes:
        if c and c not in seen:
            seen.add(c)
            out.append(c)
    return out
