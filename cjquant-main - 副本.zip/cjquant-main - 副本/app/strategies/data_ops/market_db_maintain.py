# -*- coding: utf-8 -*-
"""统一数据仓（market.db）每日维护任务。

职责（对应设计文档 §5 维护方案）：
  1. 联网拉全市场名录（含清盘基金）→ fund 主档（1 个请求，成本低）
  2. 从 legacy 三库**增量吸收**当前 Phase A 尚未切换写端的数据
     （master 富信息 / scale / nav_bulk / reports 各表）
  3. refresh_stats：重算 nav_rows、first/last_nav_date、status、scale 快照
  4. 数据质量自检 + 写入 sync_task_log（调度模块可查运行台账）

为什么每日跑而不是每次回测前跑：名录与净值是"慢变量"，日频足够；
而 sync_task_log 让"哪天没同步成功"变成可查询事实，而不是靠猜。
"""
import os
import sys
from datetime import datetime, timedelta
from typing import Optional

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
sys.path.insert(0, _ROOT)

# 每日 1 次（收盘后跑，此时当日净值已落地）
SCHEDULE = {"name": "统一数据仓维护", "interval": 86400, "enabled": True}

# 数据质量阈值（低于则 WARN，不阻断）
MIN_FUNDS = 20000
MIN_NAV_ROWS = 500000
# 【2026-09-26 新增】新鲜度闸门。
# 起因：nav_bulk_warmup 曾有一个 NameError，导致这个任务每晚静默失败、
# 净值停在 9/17 长达 9 天无人察觉 —— 用户是拿支付宝对账才发现"严重延后"。
# 上面两个阈值只查"量够不够"，查不出"数据是不是新的"，
# 而"数据过期但量还在"恰恰是最危险的形态：看起来一切正常，算出来的全是旧数。
# 规则：有净值的基金里，若末值落后于最新净值日超过 FRESH_STALE_DAYS 的
# 占比高于 FRESH_WARN_RATIO，就明确告一条警。
FRESH_STALE_DAYS = int(os.environ.get("CJQ_NAV_FRESH_STALE_DAYS", "5"))
FRESH_WARN_RATIO = float(os.environ.get("CJQ_NAV_FRESH_WARN_RATIO", "0.30"))


def _check_freshness(mk) -> Optional[str]:
    """返回告警文本；数据新鲜则 None。"""
    try:
        row = mk.conn.execute(
            "SELECT MAX(nav_date) FROM fund_nav WHERE nav_date <= ?",
            (datetime.now().strftime("%Y-%m-%d"),)).fetchone()
    except Exception:
        return None
    newest = (row[0] if row else None)
    if not newest:
        return "fund_nav 里取不到最新净值日，无法判断新鲜度"
    try:
        cutoff_dt = (datetime.strptime(str(newest)[:10], "%Y-%m-%d")
                     - timedelta(days=FRESH_STALE_DAYS))
    except Exception:
        return None
    cutoff = cutoff_dt.strftime("%Y-%m-%d")
    try:
        total = mk.conn.execute(
            "SELECT COUNT(*) FROM fund WHERE last_nav_date IS NOT NULL").fetchone()[0]
        stale = mk.conn.execute(
            "SELECT COUNT(*) FROM fund WHERE last_nav_date IS NOT NULL "
            "AND last_nav_date < ?", (cutoff,)).fetchone()[0]
    except Exception:
        return None
    if total <= 0:
        return None
    ratio = stale / total
    if ratio > FRESH_WARN_RATIO:
        return (f"净值新鲜度告警：最新净值日 {newest}，但 {stale}/{total} 只"
                f"（{ratio:.0%}）的末值早于 {cutoff}，"
                f"超过阈值 {FRESH_WARN_RATIO:.0%} —— "
                f"多半是预热/增量刷新任务失败了，去查 nav_bulk_warmup 日志")
    return None


def run_strategy():
    from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
    from cjquant.data.market_db_migrate import migrate_all

    t0 = datetime.now()
    print(f"[统一数据仓] {t0:%Y-%m-%d %H:%M:%S} 启动 → {DEFAULT_MARKET_DB}")
    mk = MarketDB(DEFAULT_MARKET_DB, create=True)
    started = mk.log_task_start("market_db_maintain")
    try:
        res = migrate_all(mk, with_network=True)
        st = mk.stats()
        print(f"[统一数据仓] 迁移：{res}")
        print(f"[统一数据仓] 库内：{st}")

        # 数据质量自检
        warns = []
        if st.get("funds", 0) < MIN_FUNDS:
            warns.append(f"fund 主档仅 {st.get('funds')} 只（< {MIN_FUNDS}）："
                         f"全市场名录拉取可能失败")
        if st.get("nav_rows", 0) < MIN_NAV_ROWS:
            warns.append(f"净值仅 {st.get('nav_rows')} 行（< {MIN_NAV_ROWS}）："
                         f"nav_bulk 预热/迁移可能中断")
        fresh = _check_freshness(mk)
        if fresh:
            warns.append(fresh)
        # 孤儿检查（FK 已强制，这里再加一道显式断言便于日志留痕）
        orphans = mk.conn.execute(
            "SELECT COUNT(*) FROM fund_nav n LEFT JOIN fund f "
            "ON n.fund_code=f.fund_code WHERE f.fund_code IS NULL").fetchone()[0]
        if orphans:
            warns.append(f"fund_nav 有 {orphans} 行孤儿记录（主档缺失）")

        if warns:
            for w in warns:
                print(f"[统一数据仓][WARN] {w}")
            status, msg = "ok", "完成但存在告警: " + "; ".join(warns)
        else:
            status, msg = "ok", "完成"
        mk.log_task_finish("market_db_maintain", started, status=status,
                           n_rows=st.get("nav_rows", 0), message=msg)
        print(f"[统一数据仓] 耗时 {(datetime.now() - t0).total_seconds():.1f}s → {msg}")
    except Exception as e:
        mk.log_task_finish("market_db_maintain", started, status="fail", message=str(e)[:400])
        print(f"[ERROR] 统一数据仓维护失败: {e}")
    finally:
        mk.close()


if __name__ == "__main__":
    run_strategy()
