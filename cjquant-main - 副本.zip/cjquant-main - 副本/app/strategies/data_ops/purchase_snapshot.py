# -*- coding: utf-8 -*-
"""申赎状态每日快照（H4 可交易性，修复方案 v1.0 §3.1e）。

东财的申购/赎回状态只有**当日**快照、没有历史，要支持回测里的 PIT 判断，
唯一诚实的办法是自己每天落一份、攒出时间序列。

数据源 `ak.fund_purchase_em()`：一次请求拿全市场 ≈27,565 只，每天 1 次即可。
⚠️ 不要用逐只抓 F10 页面的方式替代——2.7 万次请求必被封 IP 且要跑两小时。

⚠️ 建表后历史是空的：`subscribe_status_asof(code, asof)` 找不到 ≤ asof 且
   新鲜（≤10 天）的快照时如实记"未校验"，**绝不拿今天的状态回填历史**（前视）。
"""
import os
import sys
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
sys.path.insert(0, _ROOT)

from cjquant.data.fund_reports import default_store, fetch_purchase_snapshot  # noqa: E402

# 每天 1 次（收盘后跑一次即可；接口本身就是"全市场当日状态"）
SCHEDULE = {"name": "申赎状态每日快照", "interval": 86400, "enabled": True}


def run_strategy():
    t0 = datetime.now()
    # Phase C（写端切换）：market.db 为**主落点**；legacy 报告仓保留一份，
    # 供尚未切换读端的旧路径使用（Phase B 完成前不破坏任何现有行为）。
    market_n = 0
    df = None
    try:
        from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
        mk = MarketDB(DEFAULT_MARKET_DB, create=True)
        try:
            df = fetch_purchase_snapshot()
            market_n = mk.upsert_subscribe_snapshot(df)
        finally:
            mk.close()
    except Exception as e:
        print(f"[WARN] market.db 落库失败（legacy 仍会写）: {e}")

    store = default_store(create=True)
    if store is None:
        print("[ERROR] 报告仓无法创建，快照落库失败")
        return
    try:
        if df is None:
            df = fetch_purchase_snapshot()
        n = store.upsert_subscribe_snapshot(df)
        st = store.stats()
        print(f"[申赎快照] {datetime.now():%Y-%m-%d %H:%M:%S} "
              f"market.db {market_n} 只 / legacy {n} 只；"
              f"累计 {st.get('snapshot_funds', 0)} 只 / {st.get('snapshot_days', 0)} 个交易日")
    except Exception as e:
        print(f"[ERROR] 申赎快照失败: {e}")
    finally:
        store.close()
    print(f"[申赎快照] 完成，耗时 {(datetime.now() - t0).total_seconds():.1f}s")


if __name__ == "__main__":
    run_strategy()
