# -*- coding: utf-8 -*-
"""现金载体（货币基金）净值预热 —— 消除"合成现金曲线"假设。

背景（这条任务是数据仓重构的直接产物）：
    五层漏斗的 Pool_CASH / 释放仓位落到货币基金，需要货基**真实**净值序列。
    但东财对货基不提供"单位净值走势"，本地净值库天然没有它们 →
    `_pick_cash_vehicle()` 只能退化为"按规模挑代码占位 + 回测用合成曲线"。

    2026-09-19 打通了货基通道（PublicFundProvider 走东财移动端
    FundMNHisNetList，万份收益折算成复利净值），本任务把它落进 market.db：
    每夜补一批，攒够后现金载体自动用真实数据（无需改任何策略代码，
    因为 `_pick_cash_vehicle` 的判定依据就是"本地有没有净值"）。

选型：类型含「货币」、非后端份额、未清盘，按最新规模降序取前 N 只。
"""
import os
import sys
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))


def _project_root(start: str) -> str:
    d = os.path.abspath(start)
    while True:
        if os.path.exists(os.path.join(d, "run_gui.py")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            return os.path.abspath(os.path.join(start, "..", ".."))
        d = parent


ROOT = _project_root(_HERE)
sys.path.insert(0, ROOT)

# 每夜补多少只（货基通道每只 1 个请求，历史全量约 4000~5000 行）
BATCH = int(os.environ.get("CJQ_CASH_WARMUP_BATCH", "20"))
# 少于这么多行视为没拉到，不占位
MIN_ROWS = int(os.environ.get("CJQ_CASH_WARMUP_MIN_ROWS", "250"))
# 净值停更超过 N 天就重拉（货基每天都有收益，停更即异常）
STALE_DAYS = int(os.environ.get("CJQ_CASH_WARMUP_STALE_DAYS", "5"))

SCHEDULE = {"name": "现金载体货基预热", "interval": 86400, "enabled": True}


def _candidates(mk, limit: int) -> list:
    """market.db 里规模靠前的货基；已够新的排后面（优先补没拉过的）。"""
    rows = mk.conn.execute(
        "SELECT f.fund_code, f.fund_name, f.status, f.last_nav_date, f.nav_rows,"
        "       (SELECT s.scale_yi FROM fund_scale s WHERE s.fund_code=f.fund_code "
        "        AND s.scale_yi IS NOT NULL ORDER BY s.report_date DESC LIMIT 1) AS sc "
        "FROM fund f WHERE f.fund_type LIKE '%货币%' "
        "AND (f.fund_name IS NULL OR f.fund_name NOT LIKE '%后端%') "
        "AND f.liquidation_date IS NULL "
        "ORDER BY (sc IS NULL), sc DESC, f.fund_code").fetchall()
    out = []
    for r in rows:
        r = dict(r)
        fresh = False
        lnd = r.get("last_nav_date")
        if lnd and (datetime.now() - datetime.strptime(str(lnd)[:10], "%Y-%m-%d")).days <= STALE_DAYS:
            fresh = True
        out.append({"code": r["fund_code"], "name": r.get("fund_name"),
                    "scale": r.get("sc"), "rows": r.get("nav_rows") or 0,
                    "fresh": fresh})
    # 没拉过的排前面（fresh=False 优先），同档内按规模
    out.sort(key=lambda x: (x["fresh"], -(x["scale"] or 0.0), x["code"]))
    return out[:limit]


def run_strategy():
    t0 = datetime.now()
    from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
    from cjquant.data.providers.public import PublicFundProvider

    mk = MarketDB(DEFAULT_MARKET_DB, create=True)
    started = mk.log_task_start("cash_vehicle_warmup")
    ok_n = fail_n = 0
    try:
        cands = _candidates(mk, BATCH)
        if not cands:
            print("[现金载体] market.db 里没有可选货币基金，退出")
            mk.log_task_finish("cash_vehicle_warmup", started, status="ok",
                               message="no candidates")
            return
        prov = PublicFundProvider(cache_dir=None, adjust=True)
        for c in cands:
            if c["fresh"] and (c["rows"] or 0) >= MIN_ROWS:
                continue
            try:
                df = prov.fetch(f"{c['code']}.OF", use_cache=False)
                if df is None or df.empty:
                    fail_n += 1
                    continue
                rows = [{"nav_date": d.strftime("%Y-%m-%d"),
                         "unit_nav": float(v), "adj_nav": float(v)}
                        for d, v in df["adj_nav"].dropna().items()]
                n = mk.upsert_nav(c["code"], rows, nav_type="money_market",
                                  source="em_mobile_mmf")
                if n >= MIN_ROWS:
                    ok_n += 1
                    print(f"[现金载体] {c['code']} {c['name']} 落库 {n} 行")
                else:
                    fail_n += 1
            except Exception as e:
                fail_n += 1
                print(f"[WARN] {c['code']} 预热失败: {e}")
        res = mk.refresh_stats()
        print(f"[现金载体] 本批成功 {ok_n} 只 / 失败 {fail_n} 只；"
              f"库内有净值基金 {res.get('with_nav', len(res))} 类统计已刷新")
        mk.log_task_finish("cash_vehicle_warmup", started,
                           status="ok" if ok_n or fail_n == 0 else "warn",
                           n_rows=ok_n, message=f"ok={ok_n} fail={fail_n}")
    except Exception as e:
        mk.log_task_finish("cash_vehicle_warmup", started, status="fail",
                           message=str(e)[:300])
        print(f"[ERROR] 现金载体预热失败: {e}")
    finally:
        mk.close()
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] 完成，耗时 "
          f"{(datetime.now() - t0).total_seconds():.1f}s")


if __name__ == "__main__":
    run_strategy()
