# -*- coding: utf-8 -*-
"""全市场净值分批预热（data_ops 组），落到 `cjquant/data/store/nav_bulk.db`。

分批原因：全市场 2.7 万只 ≈ 0.3 亿行，单只抓取 ~0.55s，全量首轮 ≈ 4.3 小时，
必须分批以便不阻塞调度 / 按价值优先 / 断点续跑。

优先级：策略组 CANDIDATES → 货币基金（现金载体）→ 基础库合格候选 → 其余按 code。
配额：库体积达 CJQ_BULK_MAX_GB 后只做存量增量、不再扩新标的。
"""
import os
import sys
import time


def _project_root(start: str) -> str:
    d = os.path.abspath(start)
    while True:
        if os.path.exists(os.path.join(d, "run_gui.py")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            return os.path.abspath(os.path.join(start, "..", ".."))
        d = parent


ROOT = _project_root(os.path.dirname(os.path.abspath(__file__)))
STRATEGIES_DIR = os.path.join(ROOT, "app", "strategies")
GROUP = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(ROOT)
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from datetime import datetime  # noqa: E402
from cjquant.data.nav_bulk import NavBulkStore, NavBulkWarmup  # noqa: E402
from cjquant.data.fund_master import FundMasterDB  # noqa: E402
from cjquant.data.exceptions import FundNoNavPageError  # noqa: E402
from _common import scan_strategy_candidates  # noqa: E402

# 调度自注册
SCHEDULE = {"name": "全市场净值预热", "interval": 86400}

BULK_DB = os.path.join(ROOT, "cjquant", "data", "store", "nav_bulk.db")
MASTER_DB = os.path.join(ROOT, "cjquant", "data", "store", "fund_master.db")
# 每夜新增多少只（4000 × ~0.55s ≈ 37 分钟；调大请自行评估调度窗口）
BATCH = int(os.environ.get("CJQ_BULK_BATCH", "4000"))
# 存储配额（GB）：触达后只做增量、不再扩新标的
MAX_GB = float(os.environ.get("CJQ_BULK_MAX_GB", "40"))
SLEEP = float(os.environ.get("CJQ_BULK_SLEEP", "0.15"))
SKIP_AFTER = int(os.environ.get("CJQ_BULK_SKIP_AFTER", "3"))
# 增量刷新：已预热成功的基金，净值停更超过多少天就要重新拉最新（否则持仓页
# 的"最新净值"会一直停在首次预热那天，看起来像"更新净值还是昨天的"）。
# 每批最多刷新多少只（刷新优先于首轮预热，占用 BATCH 的额度）。
REFRESH_STALE_DAYS = int(os.environ.get("CJQ_BULK_REFRESH_STALE_DAYS", "3"))
REFRESH_LIMIT = int(os.environ.get("CJQ_BULK_REFRESH_LIMIT", "200"))


def _safe_phase(label: str, fn) -> object:
    """执行一个阶段，失败只记日志不中断整体流程。

    这是本次重构的核心：**阶段隔离**。批处理任务里，某一阶段的非预期异常
    不应该抹掉其他阶段已经拿到的成果（尤其是最后那个 market.db 同步）。
    """
    t = datetime.now()
    try:
        return fn()
    except Exception as e:
        print(f"[WARN] 阶段「{label}」失败（已跳过，不影响后续阶段）: {e}")
        return None
    finally:
        print(f"[阶段耗时] {label} {(datetime.now() - t).total_seconds():.1f}s")


def _strategy_candidates() -> list:
    """各策略组声明的 CANDIDATES/UNIVERSE。

    【2026-09-26 修复】原先这里调了一个**从不存在**的函数局部变量，
    且没有 try 兜底 —— NameError 直接冒泡到 run_strategy 的外层大 try，
    于是这个每天跑的任务每次都在这一行失败，从没真正预热过任何一只新基金。
    现在统一走 _common.scan_strategy_candidates（与 report_sync /
    fund_master_update 共用同一份 AST 扫描实现）。
    """
    try:
        return scan_strategy_candidates(STRATEGIES_DIR)
    except Exception as e:
        print(f"[WARN] 扫描策略候选失败（跳过，不影响后续阶段）: {e}")
        return []


def run_strategy():
    t0 = datetime.now()
    print(f"[{t0:%Y-%m-%d %H:%M:%S}] 全市场净值预热启动 db={BULK_DB}")
    store = NavBulkStore(db_path=BULK_DB)
    try:
        # 登记全量名单（幂等），顺序稳定便于断点续跑
        # Phase C：名单的权威来源是 market.db（含清盘基金的全市场主档）；
        # 取不到才回退 legacy 基础库，行为不变。
        master = None
        codes = None
        try:
            from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
            mk = MarketDB(DEFAULT_MARKET_DB, create=False)
            if mk is not None:
                try:
                    codes = mk.all_codes()
                finally:
                    mk.close()
        except Exception as e:
            print(f"[WARN] 读取统一数据仓名单失败: {e}")
        if codes is None:
            try:
                master = FundMasterDB(db_path=MASTER_DB)
                codes = master.all_codes()
            except Exception as e:
                print(f"[WARN] 读取基础库名单失败（继续按已有名单跑）: {e}")
        if codes:
            n_univ = store.set_universe(codes)
            print(f"全量名单登记 {n_univ} 只")

        # ---------- 阶段划分 ----------
        # 【2026-09-26 重构】原先 4 个阶段全在同一个大 try 里：任何一个非预期异常
        # （哪怕只是某只基金的数据格式异常）都会让后续**所有**阶段跳过，
        # 包括「写 market.db」这个收尾同步 —— 表现为"库里明明有新数据，
        # 策略却读不到"。现在每个阶段独立兜底，互不影响，且 market.db 同步恒执行。
        up = NavBulkWarmup(store, sleep=SLEEP, skip_after_failures=SKIP_AFTER, max_gb=MAX_GB)

        # ---------------- 阶段 0：增量刷新停更的基金 ----------------
        # 已 status=ok 的基金不再被 pending_codes 碰到，净值会停在首次预热那天。
        # 这里先把"停更超过 N 天"的基金重新拉一遍最新净值（upsert 幂等覆盖），
        # 保证持仓页 / 策略取到的都是新鲜数据。
        def _phase0_refresh():
            stale = store.stale_codes(stale_days=REFRESH_STALE_DAYS, limit=REFRESH_LIMIT)
            if not stale:
                print(f"[增量刷新] 无需刷新（没有停更 > {REFRESH_STALE_DAYS} 天的基金）")
                return
            print(f"[增量刷新] 有 {len(stale)} 只净值停更 > {REFRESH_STALE_DAYS} 天，开始刷新…")
            ok_r = fail_r = 0
            for c in stale:
                try:
                    up.store.upsert_nav(c, up.fetcher(c))
                    ok_r += 1
                except FundNoNavPageError as e:
                    # 确定性失败：这只基金本来就没有独立净值页。
                    # 【2026-09-26 修复】原先这里引用了未导入的 FundNoNavPageError
                    # -> NameError -> 冒泡到外层大 try -> **整个任务当天作废**。
                    fail_r += 1
                    print(f"[增量刷新] {c} 无独立净值页，跳过: {e}")
                except Exception as e:
                    fail_r += 1
                    # 失败兜底：库里旧净值保留不动（upsert 不会删行），
                    # 只是暂时不新鲜，不会退化成"没有这只基金"。
                    up.store.mark_fail(c, str(e), skip_after=SKIP_AFTER)
                if SLEEP:
                    time.sleep(SLEEP)
            print(f"[增量刷新] 完成：刷新 {ok_r} 只 / 失败 {fail_r} 只")

        # ---------------- 阶段 1：首轮预热（策略候选 + 合格候选优先） ----------------
        def _phase1_priority():
            priority = []
            # 货币基金**置顶**：它们是策略的现金载体（闲置现金的去处），
            # 数量少（几十只）、抓取快，但如果不显式预热，本地净值索引里一只都没有
            # —— 实测 977 只货币基金全都没落库，于是 Pool_CASH 永远为空，
            # 「闲置现金放进随买随取的货币基金生息」这条设计无法生效。
            if master is not None:
                try:
                    mm = master.filter_codes(fund_type_contains="货币", limit=60) or []
                    priority += list(mm)
                    print(f"现金载体（货币基金）优先预热 {len(mm)} 只")
                except Exception as e:
                    print(f"[WARN] 取货币基金名单失败: {e}")
            priority += _strategy_candidates()
            if master is not None:
                try:
                    # 优先预热「我们确知合格」的那批（有成立日+规模且达标），
                    # 避免优先级队列被还没富化过事实的未知标的稀释
                    good = master.candidate_codes(min_scale_yi=2.0, min_age_days=365,
                                                  require_facts=True)
                    priority += good
                    allgood = master.candidate_codes(min_scale_yi=2.0, min_age_days=365,
                                                     require_facts=False)
                    print(f"确知合格候选 {len(good)} 只；放宽口径(含未知事实) {len(allgood)} 只")
                except Exception as e:
                    print(f"[WARN] 合格候选筛选失败: {e}")
            seen, pri = set(), []
            for c in priority:
                if c and c not in seen:
                    seen.add(c)
                    pri.append(c)
            print(f"优先级队列 {len(pri)} 只（策略候选在前）")
            return pri

        def _phase2_warmup(pri):
            try:
                print(f"预热前: {store.stats()}")
            except Exception:
                pass
            res = up.run_batch(limit=BATCH, priority=pri)
            print(f"本批: 取 {res['picked']} 只 ok={res['ok']} fail={res['fail']} "
                  f"写入 {res['rows']} 行 耗时 {res['seconds']}s 库体积 {res['db_gb']}GB")
            st = res["stats"]
            print(f"预热后: 行数={st['nav_rows']} 已完成={st['funds_ok']} "
                  f"失败={st['funds_fail']} 已放弃={st['funds_skip']} 库={st['db_gb']}GB")
            try:
                remain = len(store.pending_codes(limit=0, skip_failed_after=SKIP_AFTER))
                eta = remain * (SLEEP + 0.4) / 60
                print(f"剩余待预热 {remain} 只，按本机速率预计还需 ≈ {eta:.0f} 分钟"
                      f"（{eta/60:.1f} 小时）")
            except Exception as e:
                print(f"[WARN] 统计剩余待预热失败: {e}")
            if store.over_quota(MAX_GB):
                print(f"[WARN] 已触达存储配额 {MAX_GB}GB，后续批次只做存量增量、不再扩充新标的")

        def _phase3_sync_market_db():
            # Phase C（写端切换）：本批净值同步落进统一数据仓 market.db。
            # 幂等 upsert，重复执行只覆盖；失败不影响 legacy 库（旧路径继续可用）。
            # 放在独立阶段 + 恒执行：即使上面某阶段挂了，本地已有的新净值
            # 也要能被同步过去，否则策略读到的还是昨天的数据。
            from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
            from cjquant.data.market_db_migrate import import_nav_bulk
            mk = MarketDB(DEFAULT_MARKET_DB, create=True)
            try:
                mv = import_nav_bulk(mk)
                mk.refresh_stats()
                # 增量模式下 nav_rows 只是"本次变动的行数"，不是库内总量 ——
                # 直接打印会让人以为"只同步了 2 行 = 同步坏了"。
                # 补上 incremental 标记与库内总量，两种模式一眼可分。
                kind = "增量" if mv.get("incremental") else "全量"
                print(f"[统一数据仓] 本批同步({kind}) 变动 {mv.get('nav_rows', 0)} 行"
                      f"（库内 {mk.stats().get('nav_rows')} 行）")
            finally:
                mk.close()

        # ---- 顺序执行：任一阶段失败只丢该阶段，不拖垮后续 ----
        pri = []
        for label, fn in (("增量刷新", _phase0_refresh),
                          ("优先级队列", _phase1_priority),
                          ("首轮预热", lambda: _phase2_warmup(pri))):
            r = _safe_phase(label, fn)
            if label == "优先级队列":
                pri = r if isinstance(r, list) else []
        # 收尾同步恒执行（不因上面任一阶段失败而跳过）
        _safe_phase("统一数据仓同步", _phase3_sync_market_db)
    except Exception as e:
        print(f"[ERROR] 预热流程异常: {e}")
    finally:
        try:
            store.close()
        except Exception:
            pass
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] 完成，耗时 "
          f"{(datetime.now() - t0).total_seconds():.1f}s")


if __name__ == "__main__":
    run_strategy()
