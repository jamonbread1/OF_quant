# -*- coding: utf-8 -*-
"""赎回费阶梯抓取（P1-2，`fund_redeem_tier` 历史上恒为 0 行）。

数据源 `ak.fund_fee_em(symbol, indicator="赎回费率")`：天天基金 F10 费率页，
**逐只**抓取（没有批量接口）。实测返回：

    适用期限               赎回费率
    小于7天                1.50%
    大于等于7天，小于30天   0.75%
    大于等于30天，小于365天 0.50%
    大于等于365天，小于730天 0.25%
    大于等于730天          0.00%

为什么值得抓：回测现在用的是监管上限阶梯（7/30/180 天），与真实费率
两个方向都偏（180~365 天真实仍是 0.5%；365 天后真实 0.25% 而非 0）。
没有它，`min_hold_days` 设多少、"多久调一次仓"都只能拍脑袋。

⚠️ 三条纪律
  1. **货币基金跳过**：它本身 0 申赎费，且 F10 页面给的不是赎回费阶梯
     （实测 000605 会抓到「1~1 天 1.00%」这种无意义的行）。
  2. **限速**：东财 F10 反爬敏感，默认 ~1.2s/只；用 `CJQ_FEE_BATCH`
     控制单轮只数（滚动几天跑完全池，别一晚打爆配额）。
  3. **无历史版本**：抓的是**当前**费率。要用于历史回测必须另攒快照
     （见 `field_snapshot` 设计）；在此之前回测里用它带前视偏差，
     可用 `CJQ_FEE_TIERS=0` 关掉。
"""
import os
import sys
import time
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
sys.path.insert(0, _ROOT)

from cjquant.data.fund_fee_source import fetch_redeem_tiers  # noqa: E402

# 周频足够（费率靠合同/公告变更，日频纯浪费配额）
SCHEDULE = {"name": "费率与赎回阶梯快照", "interval": 7 * 86400, "enabled": True}

BATCH = int(os.environ.get("CJQ_FEE_BATCH", "60") or 60)
SLEEP = float(os.environ.get("CJQ_FEE_SLEEP", "1.2") or 1.2)


def _targets(limit: int = 0):
    """待抓取名单：优先"本地有净值的研究池"（回测真正在用的那批）。

    拿不到就退回全市场 —— 2.7 万只 × 1.2s ≈ 9 小时，只能靠 CJQ_FEE_BATCH 滚动。
    """
    try:
        from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
        mk = MarketDB(DEFAULT_MARKET_DB, create=False)
        if mk is None:
            return []
        try:
            codes = list(mk.backtest_universe(min_rows=250) or [])
            if not codes:
                codes = [r[0] for r in mk.conn.execute(
                    "SELECT fund_code FROM fund WHERE nav_rows>0 ORDER BY nav_rows DESC").fetchall()]
            money = {str(r[0]).split(".")[0].zfill(6) for r in mk.conn.execute(
                "SELECT fund_code FROM fund WHERE fund_type LIKE '%货币%'").fetchall()}
            return [c for c in codes if str(c).split(".")[0].zfill(6) not in money]
        finally:
            mk.close()
    except Exception as e:
        print(f"[WARN] 取待抓名单失败: {e}")
        return []


def run_strategy():
    t0 = datetime.now()
    if os.environ.get("CJQ_FEE_TIERS", "1") in ("0", "false", "False"):
        print("[费率快照] CJQ_FEE_TIERS=0，已跳过")
        return
    codes = _targets()
    if not codes:
        print("[WARN] 没有待抓取标的，退出")
        return
    # 只抓「库里还没有」的（幂等 + 断点续跑）；CJQ_FEE_REFRESH=1 则强制重抓
    refresh = os.environ.get("CJQ_FEE_REFRESH", "0") not in ("0", "false", "False")
    if not refresh:
        try:
            from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
            mk = MarketDB(DEFAULT_MARKET_DB, create=False)
            try:
                done = {str(r[0]).zfill(6) for r in mk.conn.execute(
                    "SELECT DISTINCT fund_code FROM fund_redeem_tier").fetchall()}
            finally:
                mk.close()
            before = len(codes)
            codes = [c for c in codes if str(c).split(".")[0].zfill(6) not in done]
            print(f"[费率快照] 库内已有 {len(done)} 只，本轮待抓 {len(codes)} 只"
                  f"（原 {before} 只）")
        except Exception as e:
            print(f"[WARN] 读库内进度失败，按全量抓: {e}")

    if BATCH > 0:
        codes = codes[:BATCH]
    print(f"[费率快照] 本批 {len(codes)} 只，限速 {SLEEP}s/只，预计 "
          f"{len(codes) * SLEEP / 60:.1f} 分钟")

    try:
        from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
        mk = MarketDB(DEFAULT_MARKET_DB, create=False)
    except Exception as e:
        print(f"[ERROR] market.db 不可用: {e}")
        return
    if mk is None:
        print("[ERROR] market.db 不可用")
        return

    ok = fail = skip = 0
    try:
        for i, c in enumerate(codes, 1):
            c6 = str(c).split(".")[0].zfill(6)
            try:
                tiers = fetch_redeem_tiers(c6)
            except Exception as e:
                fail += 1
                print(f"  [{i}/{len(codes)}] {c6} 抓取失败: {str(e)[:80]}")
                time.sleep(SLEEP)
                continue
            if not tiers:
                skip += 1
                time.sleep(SLEEP)
                continue
            try:
                mk.upsert_redeem_tiers(c6, tiers)
            except Exception as e:
                fail += 1
                print(f"  [{i}/{len(codes)}] {c6} 落库失败: {str(e)[:80]}")
                time.sleep(SLEEP)
                continue
            ok += 1
            if i % 20 == 0 or i == len(codes):
                print(f"  ...{i}/{len(codes)} 成功 {ok} 失败 {fail} 无表 {skip}")
            time.sleep(SLEEP)
    finally:
        mk.close()

    print(f"[费率快照] 完成：成功 {ok} / 失败 {fail} / 无表 {skip}；"
          f"耗时 {(datetime.now() - t0).total_seconds() / 60:.1f} 分钟")


if __name__ == "__main__":
    run_strategy()
