# -*- coding: utf-8 -*-
"""基金基础库日更任务（二期）。

作用：把全市场名单、单只基础事实（成立日/规模/类型）、每日申赎快照落本地 SQLite，
供 DynamicUniverse(master=FundMasterDB()) 判定动态池，替掉「用 NAV 首末值代理」。

规范见 app/strategies/README.md 类型 B：
- 单次跑完必须退出，定时靠调度器重复拉起
- 日志靠 print；cwd 是项目根，output_dir 类参数不用绝对路径
- 本任务不下单，不产出任何 *_o32.csv / *_wechat.csv
"""
import os
import sys


def _project_root(start: str) -> str:
    """向上找项目根（认 run_gui.py）。策略文件分层后，数 '..' 太脆，改用标记文件定位。"""
    d = os.path.abspath(start)
    while True:
        if os.path.exists(os.path.join(d, "run_gui.py")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            return os.path.abspath(os.path.join(start, "..", ".."))
        d = parent


ROOT = _project_root(os.path.dirname(os.path.abspath(__file__)))
STRATEGIES_DIR = os.path.join(ROOT, "app", "strategies")
GROUP = os.path.basename(os.path.dirname(os.path.abspath(__file__)))  # 策略组名（目录名）
sys.path.append(ROOT)
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from datetime import datetime  # noqa: E402
from cjquant.data.fund_master import FundMasterDB, FundMasterUpdater  # noqa: E402
from _common import scan_strategy_candidates  # noqa: E402

# 调度自注册：后端启动 + /api/tasks/sync 自动写入 tasks.json
SCHEDULE = {"name": "基金基础库日更", "interval": 86400}

DB_PATH = os.path.join(ROOT, "cjquant", "data", "store", "fund_master.db")
# 每次日更补多少只基础信息（富化是逐只请求，必须限量，分夜累积）
ENRICH_BATCH = int(os.environ.get("CJQ_MASTER_ENRICH_BATCH", "60"))
# 「不在当日快照」那批单独给量：它们才是已清盘/退市事实的主要来源，每只只需一次请求
REPAIR_BATCH = int(os.environ.get("CJQ_MASTER_REPAIR_BATCH", "300"))
# 基础信息保鲜天数
MAX_AGE_DAYS = 30
# 快照保留天数（不清理的话每天 2.4 万行会滚成 GB 级）
KEEP_SNAPSHOT_DAYS = int(os.environ.get("CJQ_MASTER_KEEP_SNAPSHOT_DAYS", "30"))
# 与多线程无关，单纯给接口留缓冲
SLEEP_BETWEEN = 0.2

PRIORITY_FILE_DEFAULT = True


def _priority_codes():
    """优先富化：各策略组里声明的候选池 + 组合持仓，保证在用标的一定有真实事实。

    【2026-09-26】AST 扫描部分已迁入 _common.scan_strategy_candidates，
    与 report_sync / nav_bulk_warmup 共用。顺带修掉一个差异：本函数原先只排除
    __pycache__，**会把 data_ops 目录自己也扫进去**（运维脚本里没有 CANDIDATES，
    纯粹是白扫，且未来若有人在 data_ops 里写常量就会被误当成策略候选）。
    """
    codes = list(scan_strategy_candidates(STRATEGIES_DIR))
    try:
        import json
        ppath = os.path.join(ROOT, "app", "portfolio.json")
        with open(ppath, encoding="utf-8") as f:
            pf = json.load(f)
        codes += [p.get("fund_code") for p in pf.get("positions", []) if p.get("fund_code")]
    except Exception as e:
        print(f"[WARN] 读取持仓失败（跳过）: {e}")
    seen, out = set(), []
    for c in codes:
        if c and c not in seen:
            seen.add(c)
            out.append(c)
    return out


def _sync_market_db():
    """本任务写 legacy 后，把新增/更新的主档与规模历史吸收进 market.db。

    只吸收 master 部分（净值那 82 万行由 nav_bulk_warmup 负责，这里没必要重扫）。
    失败只告警：market.db 落后一天不影响本次日更，次日维护任务会补上。
    """
    try:
        from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
        from cjquant.data.market_db_migrate import absorb_legacy
        mk = MarketDB(DEFAULT_MARKET_DB, create=True)
        started = mk.log_task_start("fund_master_update.sync")
        try:
            res = absorb_legacy(mk, parts=("master",))
            st = mk.stats()
            print(f"[统一数据仓] 吸收主档 {res.get('funds', 0)} 只 / "
                  f"规模 {res.get('scale', 0)} 行；库内 {st.get('funds', 0)} 只")
            mk.log_task_finish("fund_master_update.sync", started, status="ok",
                               n_rows=res.get("funds", 0), message="master absorbed")
        finally:
            mk.close()
    except Exception as e:
        print(f"[WARN] 统一数据仓吸收失败（legacy 数据已落盘，次日会补）: {e}")


def run_strategy():
    t0 = datetime.now()
    print(f"[{t0:%Y-%m-%d %H:%M:%S}] 基金基础库日更启动 db={DB_PATH}")
    db = FundMasterDB(db_path=DB_PATH)
    up = FundMasterUpdater(db, sleep=SLEEP_BETWEEN)
    try:
        n_list = up.sync_list()
        print(f"名单同步 {n_list} 只")

        pri = _priority_codes()
        r1 = up.ensure_funds(pri, max_age_days=MAX_AGE_DAYS) if pri else {"ok": 0, "fail": 0, "skipped": 0}
        print(f"优先标的富化 {r1}")

        n_snap = up.update_snapshot()
        del_old = db.prune_snapshots(keep_days=KEEP_SNAPSHOT_DAYS)
        print(f"快照落库 {n_snap} 行（清理 {del_old} 行旧数据，保留 {KEEP_SNAPSHOT_DAYS} 天）")

        # 名单里有、但当日快照里没有的基金：实测多数是后端份额/货币型/定开/QDII 等
        # 「存续但不进开放式净值接口」的品种，真已退市的占比不足 1%。
        # 这里只做「补事实」：取不到就留空，绝不据此推断清盘。
        # 批量给大一点：每只只要一次请求，比逐个富化便宜，尽快把 3819 只扫完。
        gone = db.codes_without_latest_snapshot(limit=REPAIR_BATCH)
        r3 = up.repair_by_nav(gone) if gone else {"ok": 0, "fail": 0, "skipped": 0, "given_up": 0}
        print(f"快照外基金补全 {len(gone)} 只 -> {r3}")

        batch = db.pending_codes(limit=ENRICH_BATCH)
        r2 = up.ensure_funds(batch, max_age_days=MAX_AGE_DAYS) if batch else {"ok": 0, "fail": 0, "skipped": 0}
        print(f"增量富化 {len(batch)} 只 -> {r2}")

        # 规模历史（季报）：有它 scale_asof 才是真 PIT，否则只能用「最新规模」
        try:
            pri_hist = [c for c in pri if not db.scale_history(c)]
        except Exception:
            pri_hist = list(pri)
        r4 = up.sync_scale_history(pri_hist) if pri_hist else {"ok": 0, "fail": 0, "rows": 0, "given_up": 0}
        print(f"规模历史(在用标的) {len(pri_hist)} 只 -> {r4}")
        more = db.codes_without_scale_history(limit=ENRICH_BATCH)
        r5 = up.sync_scale_history(more) if more else {"ok": 0, "fail": 0, "rows": 0, "given_up": 0}
        print(f"规模历史(增量) {len(more)} 只 -> {r5}")

        st = db.stats()
        print(f"库存: 总={st['total']} 已富化={st['enriched']} 有成立日={st['with_setup']} "
              f"有规模={st['with_scale']} 已清盘={st['liquidated']} 快照={st['snapshot_rows']} "
              f"累计错误={st['errors']}")
        # 只按「本次」成败判断数据源健康度；累计错误数会一直涨，拿它报警是误报
        ok_run = sum(x.get("ok", 0) for x in (r1, r3, r2, r4, r5))
        fail_run = sum(x.get("fail", 0) for x in (r1, r3, r2, r4, r5))
        given_up = sum(x.get("given_up", 0) for x in (r1, r3, r2, r4, r5))
        print(f"本次汇总: 成功={ok_run} 失败={fail_run} 放弃重试={given_up}")
        if fail_run and fail_run > ok_run:
            print("[WARN] 本次失败多于成功，数据源可能异常，请查看 etl_error 表")
    except Exception as e:
        print(f"[ERROR] 日更失败: {e}")
        db.close()
        _sync_market_db()
        return
    db.close()

    # Phase C：legacy 写完后立刻吸收进统一数据仓。market.db 才是权威读源
    # （回测标的池、策略取数全走它），吸收幂等，失败不影响本次日更结果。
    _sync_market_db()
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] 完成，耗时 {(datetime.now() - t0).total_seconds():.1f}s")


if __name__ == "__main__":
    run_strategy()
