# -*- coding: utf-8 -*-
"""五层漏斗 FOF 选基 —— 回测插件。

对应《场外基金量化选基策略算法说明书》v1.0 的 L1~L5：
    L1 PIT 数据（get_history_navs_pit，右端点 t-1）
    L2 准入 H1~H8（缺数据 → 记"未校验"，不拦也不假装通过）
    L3 六维因子（收益质量/风险控制/动量反转/风格稳定/持仓健康/容量费用）
    L4 MAD 去极值 → 标准化 → 方向统一 → 中性化 → 两级打分 → 缓冲带建池 → 去冗余
    L5 分数加权 + 单只上限 20% + 波动率目标控仓 + 换手约束 → 按目标权重调仓

**回测与上线同口径**：核心逻辑全在 `cjquant/funnel/pipeline.run_funnel`，
定时任务 `funnel_rotation_task.py` 调的是同一个函数。

调仓频率：池**月度**重算（净值类因子半衰期 1~3 个月）；
缓冲带 θ_in=0.90 / θ_keep=0.70 + 最短持有 90 日，把换手压在低位。
"""
from __future__ import annotations

import os
from typing import List, Optional

import numpy as np
import pandas as pd

from cjquant.funnel import run_funnel
from cjquant.funnel.pool import PoolParams
from cjquant.funnel import style as fstyle
from cjquant.funnel import risk as frisk
from cjquant.funnel.config import FunnelConfig

# ---------------------------------------------------------------------------
# 参数（说明书 §11；低敏感度参数锁定为建议值，不做优化）
# ---------------------------------------------------------------------------
RF = 0.02
WARMUP_DAYS = 1250          # RBSA 需 756 交易日 ≈ 3 年 → 约 1250 自然日
HIST_WINDOW = 820           # 每根 bar 回看的交易日数
MIN_HISTORY = 250

UNIVERSE_MIN_ROWS = 760     # 3 年净值（RBSA 下限）
UNIVERSE_MIN_ROWS_FALLBACK = 500
# 现金载体（货币基金）保留只数。
# 2026-09-19 改为 1：多只并列的意义是"某只暂停申购时换另一只"，但并列会让
# 现金在几只货基间无谓分散（且回测里表现为多一份申赎费）。只留**一只**
# 收益最高且最稳的（见 MarketDB.best_cash_vehicle），既简化也更好解释。
CASH_VEHICLE_MAX = 1
# 现金载体的净值样本门槛：货币基金净值极稳，1 年（≈250 交易日）足够，
# 不需要风险资产用的 3 年 RBSA 窗口（否则本地刚预热好的货币基金会被全滤掉）。
CASH_VEHICLE_MIN_ROWS = 250
CANDIDATES = ["000001.OF", "110022.OF", "161725.OF", "180012.OF", "000216.OF"]
# 池容量目标（**打分子池合计**口径）。
# SUBPOOLS 的静态配置合计 43（QDII 6 + ALT 4 + BOND 10 + IDX 8 + EQ 15），
# 所以 43 = 维持配置原值；传 25 会把各子池等比缩到约 58%（总池约 13 只）。
# ⚠️ 这个参数以前是**死的**：`run_funnel` 内部直接取子池静态 `n_target`，
#    改它只影响日志（实测 TOP_N=25 与 12 跑出完全相同的 208 笔成交与净值曲线）。
#    已在 `pipeline.run_funnel` 里改成按比例缩放，现在真正生效。
TOP_N = int(os.environ.get("CJQ_FUNNEL_TOP_N", "43"))
# 再平衡死区（占总资产比例）：缺口小于这个比例就不交易。
# 场外基金每笔申赎都要付钱，按 1% 死区逐月贴合目标权重会累积大量无效交易 ——
# 社区与专业 FOF 的共识是"偏离到一定程度才动手"（雪球自制 FOF：偏离 ±5pp 才调；
# 股债平衡实证：偏离 5% 才调，21 年只调了 21 次）。
DEADBAND = float(os.environ.get("CJQ_FUNNEL_DEADBAND", "0.01"))
SELL_BAND = float(os.environ.get("CJQ_FUNNEL_SELL_BAND", "0.02"))
# 调仓间隔（月）：1 = 月度，3 = 季度。
# 场外基金有申赎成本，且多数产品的赎回费只有持有满 1 年才归零 ——
# 调仓越频繁，持仓期越短、成本越高（社区与专业 FOF 的共识都是季度或更长）。
# 保留环境变量入口用于参数对比实验。
REBAL_MONTHS = max(1, int(os.environ.get("CJQ_FUNNEL_REBAL_MONTHS", "1")))
USE_MASTER = True
USE_HOLDINGS = True
USE_STYLE = True
SYNC_REPORTS = int(os.environ.get("CJQ_FUNNEL_SYNC", "0") or 0)
# P1-3（评审 2026-09-19）：D3 的 mom_blend/rmom/rev/rmom_resid 高度共线
# （rmom 就是 mom_12_3 的横截面分位），不对称正交化会让动量暴露高于设计意图。
# 默认开启；若日志频繁出现"S 病态条件数"告警再考虑关闭。
ORTHO = os.environ.get("CJQ_FUNNEL_ORTHO", "1") not in ("0", "false", "False")
# 回撤减仓层（§8.3 阈值3）的开关。评审 P0-1 指出 risk_multipliers 从未被
# 传入、L5-B 整层空转 —— 现在接入第一层（回撤预警减仓，数据源是现成的
# equity 序列）；趋势开关/崩溃空仓需要跨 bar 状态与滚动历史，暂缓。
DD_GUARD = os.environ.get("CJQ_FUNNEL_DD_GUARD", "1") not in ("0", "false", "False")

# F-3 style_consist 激活开关（默认**关**）。
# 实测（2026-09-19，双轨对比脚本）：激活后稳健线年化 5.15% → **1.33%**，
# 甚至跑输同池等权（2.58%）1.25pp —— style_consist（风格稳定度）在横截面里
# 系统性偏袒"风格常年不动"的防御型基金，与 D1+D2 的防御倾向叠加后，
# 把池子推得过于保守。修复因子≠因子有益：它需要单独标定（如提高阈值差、
# 或降权至 0.05 以下）后再默认启用。res.style_w_map 仍会产出（诊断用）。
USE_STYLE_CONSIST = os.environ.get("CJQ_FUNNEL_STYLE_CONSIST", "0") not in ("0", "false", "False")

W_MAX, W_MIN = 0.20, 0.02
# 🔧 v1.1 §13.3 口径：本策略横跨 EQ/BOND/ALT/QDII 是**多资产组合**，
#   σ_target 取 0.11（10~12%）。用 0.20~0.25 的纯权益口径会让 L_t 恒等于 1
#   —— 波动率目标层等于不存在。
SIGMA_TARGET = 0.11
# §9.4 单边换手上限。场外基金每次申赎都要付钱，换手率**直接等于成本**，
# 但也**不是越低越好** —— 实测（2022-01~2026-09，278 只池，同区间只改这一个参数）：
#
#   TO_MAX   笔数    费用     年化     最大回撤   Calmar
#   0.35     666    58,252   2.74%   -10.87%    0.25   ← 原默认
#   0.20     613    61,187   3.73%    -8.02%    0.47   ← 现默认
#   0.08     373    40,496   2.78%   -21.78%    0.13   ← 反例
#
# 读法：
#   * 0.35 换手过高 —— 费用占平均资产 5.89%(≈年化 1.26%)，吃掉约 31% 的毛收益；
#   * 0.08 换手过低 —— 该调不调，组合持续偏离目标权重，回撤反而扩大到 -21.78%；
#   * 0.20 是实测甜点：年化 +0.99pp、回撤 -2.85pp、Calmar 几乎翻倍。
# ⚠️ 注意 0.20 的**费用反而略高于** 0.35（61,187 vs 58,252）—— 笔数少不等于成本低：
#   `limit_turnover` 是按 |Δw| 从大到小部分执行，换手约束收紧后单笔更集中、
#   同一标的可能被反复小额调整，反而更容易踩到短持有期的惩罚性赎回费。
#   收益改善来自"更少追涨杀跌"（波动 7.52%→6.88%），不是来自省费用。
# 保留环境变量入口用于参数对比实验；默认值即推荐值。
TO_MAX = float(os.environ.get("CJQ_FUNNEL_TO_MAX", "0.20"))
# 🔧 v1.1 §7.2 尺度修正：Score 已是 z 口径，softmax 内部再做一次横截面标准化。
#   λ=2.0 → exp(2)/exp(−2) = e⁴ ≈ 55，前几名必然触顶 w_max=0.20，
#   权重由截断规则而非分数决定。方案 1 推荐 λ=1.0（比值 e² ≈ 7.4）。
LAMBDA_SCORE = 1.0

# ===========================================================================
# 三期 · 双轨制（三期工程.md §6）：稳健线 = 上面全部默认值，一个都不动；
# 进攻线 = 下方 PROFILE 切换的参数集。分别报告两套结果（说明书 §13 纪律）。
#
# 为什么双轨：稳健线是 Calmar 最优的底仓（年化 5.15% / 回撤 -6.84% / Calmar
# 0.75）；20% 年化目标在"EQ≤0.65 + σ_target=0.11 + 43 只分散"四重约束下
# 数学上不可达（年化 ≈ σ × Sharpe，见三期工程 §1）。进攻线不是调参，
# 是**换目标函数**：放开敞口、集中持仓、动量主导 —— 代价是回撤放大，如实披露。
PROFILE = os.environ.get("CJQ_FUNNEL_PROFILE", "steady").strip().lower()
if PROFILE not in ("steady", "aggressive"):
    PROFILE = "steady"

AGGRESSIVE = {
    # D-1 进攻版大类边界：熊市由趋势开关兜底，而非常态上限兜底
    "CLASS_BOUNDS": {"EQ": (0.00, 0.90), "BOND": (0.00, 0.30),
                     "ALT": (0.00, 0.20), "QDII": (0.00, 0.30)},
    # D-2 波动率目标进攻档：纯权益口径，L_t 在牛市满仓、熊市真降
    "SIGMA_TARGET": 0.18,
    # D-4 集中度：12~15 只，单只高 α 权重 3%→8~15%
    "TOP_N": 14,
    "W_MAX": 0.25,
    "W_MIN": 0.02,
    # A-1 维度权重进攻档：把 0.52 的"稳"砍到 0.23，动量+持仓提到 0.60
    "DIM_WEIGHTS": {"D1": 0.15, "D2": 0.08, "D3": 0.40,
                    "D4": 0.07, "D5": 0.20, "D6": 0.10},
    # A-2 softmax 进攻档：第 1 名真正拿满 w_max（触顶 >30% 时策略日志会提示）
    "LAMBDA_SCORE": 1.5,
    # A-3 中性化/正交化进攻档：保留风格 Beta（小盘成长暴露就是收益来源）、
    #     D3 共线在进攻口径是"加注"不是"重复计价"
    "ORTHOGONALIZE": False,
    "NEUTRALIZE": False,
    # L-2 换手进攻档：牛市跟得上快速轮动（费用超 2%/年会在日志告警）
    "TO_MAX": 0.30,
}
STEADY = {
    "CLASS_BOUNDS": None,     # None = 用 pipeline 默认（说明书 §7.1）
    "SIGMA_TARGET": SIGMA_TARGET,
    "TOP_N": TOP_N,
    "W_MAX": W_MAX,
    "W_MIN": W_MIN,
    "DIM_WEIGHTS": None,      # None = 用 DIM_WEIGHTS 默认
    "LAMBDA_SCORE": LAMBDA_SCORE,
    "ORTHOGONALIZE": ORTHO,
    "NEUTRALIZE": True,
    "TO_MAX": TO_MAX,
}
EFF = STEADY if PROFILE == "steady" else AGGRESSIVE

_STATE: dict = {}


def _project_root(start: str) -> str:
    d = os.path.abspath(start)
    while True:
        if os.path.exists(os.path.join(d, "run_gui.py")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            return os.path.abspath(os.path.join(start, "..", ".."))
        d = parent


def _nav_index():
    """「本地净值可得性」= .cache ∪ nav_bulk.db（与取数路径同一口径）。

    ⚠️ 不能只用 `PublicFundProvider.local_nav_index()`：那只扫 .cache 目录，
    而全市场净值实际落在 `nav_bulk.db`。两者不一致的后果是
    「池里 278 只、回测只拉得到 5 只」——选池与取数说两套话。
    """
    root = _project_root(os.path.dirname(os.path.abspath(__file__)))
    # Phase B：统一数据仓（market.db）是标的物池的**权威来源** ——
    # 单库、含清盘基金与净值覆盖统计、代码口径统一。
    # 不可用时回退到旧口径（.cache ∪ nav_bulk），行为与改造前完全一致。
    try:
        from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
        mk = MarketDB(DEFAULT_MARKET_DB, create=False)
        if mk is not None:
            try:
                codes = mk.backtest_universe(min_rows=UNIVERSE_MIN_ROWS)
                if codes:
                    # ⚠️ 下游 _pass() 需要 {code: {"rows": n}} 结构（与旧口径一致），
                    #    不能只给代码列表
                    cov = mk.nav_coverage(min_rows=0)
                    rows_of = {str(r["fund_code"]).zfill(6): int(r["nav_rows"])
                               for _, r in cov.iterrows()}
                    type_of = {str(r["fund_code"]).zfill(6): (r["fund_type"] or "")
                               for _, r in cov.iterrows()}
                    out = {c.split(".")[0]: {
                        "rows": rows_of.get(c.split(".")[0], UNIVERSE_MIN_ROWS),
                        "fund_type": type_of.get(c.split(".")[0], ""),
                        "first_date": None, "last_date": None} for c in codes}
                    # ⚠️ 货币基金必须并进 entries：它是现金载体的候选池，
                    #    而 backtest_universe 按设计剔除了货币型（非风险资产）。
                    #    少了这一步，_pick_cash_vehicle() 永远选不到真实货基，
                    #    只能退化成"代码占位 + 合成现金曲线"。
                    for c6, info in (mk.cash_vehicle_candidates(
                            min_rows=CASH_VEHICLE_MIN_ROWS) or {}).items():
                        out.setdefault(c6, {"rows": info.get("rows", 0),
                                            "fund_type": "货币型",
                                            "first_date": None, "last_date": None})
                    print(f"[funnel.get_universe] market.db 标的池 {len(codes)} 只"
                          f"（含现金载体候选 {len(out) - len(codes)} 只）")
                    return out
            finally:
                mk.close()
    except Exception as e:
        print(f"[funnel.get_universe] market.db 不可用，回退旧口径: {e}")
    from cjquant.data.pipeline import DataPipeline
    return DataPipeline(cache_dir=os.path.join(root, ".cache", "cjquant")).local_nav_index()


def get_universe(start_date=None, end_date=None):
    """动态标的池：本地净值可得性优先（≥3 年），再叠加基础库事实过滤。

    取不到就返回 []，由后端退回 CANDIDATES —— 保证策略永远可跑。
    """
    try:
        entries = _nav_index()
    except Exception as e:
        print(f"[funnel.get_universe] 扫描本地净值失败: {e}")
        return []

    def _pass(min_rows):
        if start_date:
            s = str(start_date)[:10]
            return [dict(fund_code=k, **v) for k, v in entries.items()
                    if int(v.get("rows") or 0) >= min_rows
                    and str(v.get("first_date") or "") <= s <= str(v.get("last_date") or "9999")]
        today = pd.Timestamp.now().strftime("%Y-%m-%d")
        return [dict(fund_code=k, **v) for k, v in entries.items()
                if int(v.get("rows") or 0) >= min_rows
                and str(v.get("last_date") or "") <= today]

    rows = _pass(UNIVERSE_MIN_ROWS)
    if len(rows) < 20:                      # 池太小 → 放宽到 2 年（H1 给 Flag_YoungFund 降权）
        rows = _pass(UNIVERSE_MIN_ROWS_FALLBACK)
    if not rows:
        return []
    rows.sort(key=lambda r: (-int(r.get("rows") or 0), r["fund_code"]))
    codes = [r["fund_code"] for r in rows]

    facts = {}
    try:
        from cjquant.data.fund_master import default_master
        master = default_master()
        if master is not None:
            facts = master.facts_for(codes)
    except Exception as e:
        print(f"[funnel.get_universe] 取事实失败，跳过事实过滤: {e}")

    kept, dropped = [], {}
    for r in rows:
        c = r["fund_code"]
        f = facts.get(c) or {}
        # 类型以 market.db 主档为准（entries 里带了 fund_type）；legacy 事实库
        # 缺该基金时用它兜底，否则货基会漏进主池当风险资产打分。
        ftype = str(r.get("fund_type") or f.get("fund_type") or "")
        if "货币" in ftype:
            # 货币基金不当风险资产（它没有风险因子可言），现金载体单独挑，
            # 见下方 _pick_cash_vehicle()。
            dropped["货币型"] = dropped.get("货币型", 0) + 1
            continue
        if "(后端)" in str(f.get("fund_name") or ""):
            dropped["后端份额"] = dropped.get("后端份额", 0) + 1
            continue
        liq = f.get("liquidation_date")
        if start_date and liq and str(liq)[:10] < str(start_date)[:10]:
            dropped["窗口前已清盘"] = dropped.get("窗口前已清盘", 0) + 1
            continue
        kept.append(c)
    print(f"[funnel.get_universe] 本地净值 {len(rows)} 只 → 池 {len(kept)} 只"
          + (f"（剔除 {dropped}）" if dropped else "") + f"；窗口 {start_date}~{end_date}")
    # 现金载体（Pool_CASH 用的货币基金）**单独挑**，不跟主池共用 760 行门槛：
    #   * 货币基金净值极稳，完全不需要 3 年 RBSA 窗口，1 年（250 交易日）足够；
    #   * 主池门槛会把它全滤掉（实测本地净值索引里 0 只货币基金），
    #     于是 §6.6 的 Pool_CASH 与 §7.4 的"释放仓位 40% 落到货币基金"
    #     两处设计全部变成死代码，闲置现金只能裸躺吃 0 收益。
    cash_vehicle = _pick_cash_vehicle(entries, start_date)
    if cash_vehicle:
        print(f"[funnel.get_universe] 现金载体 {len(cash_vehicle)} 只: {cash_vehicle}")
    else:
        print("[funnel.get_universe] 未找到可用的货币基金现金载体 —— "
              "闲置现金将无法生息。请先跑 data_ops 的「全市场净值预热」把货币基金落库")

    return kept + cash_vehicle


def _pick_cash_vehicle(entries: dict, start_date=None) -> List[str]:
    """挑几只货币基金当现金载体（闲置现金的去处）。

    候选名单以**统一数据仓 market.db** 为准（legacy 基础库为回退），
    本地净值覆盖 >= CASH_VEHICLE_MIN_ROWS 才算真候选（回测能用真实数据）；
    一只都没有时才退化成"按规模挑代码占位 + 合成现金曲线"。
    """
    # 权威来源：market.db（含货基真实净值覆盖与最新规模）
    try:
        from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
        mk = MarketDB(DEFAULT_MARKET_DB, create=False)
        if mk is not None:
            try:
                # 单载体：按"年化收益 − 3×年化波动"择优（收益高且稳），
                # 窗口近 1 年，避免选出"过去好"的老货基。
                best = mk.best_cash_vehicle(lookback_days=365)
                if best:
                    print(f"[funnel.get_universe] 现金载体择优 {best['fund_code']} "
                          f"{best.get('fund_name')} 年化 {best['ann_return']:.2%} "
                          f"波动 {best['ann_vol']:.4%}（{best['days']} 个交易日）")
                    return [f"{best['fund_code']}.OF"]
                # 择优失败（净值不够/有亏损日）→ 退回"规模靠前"
                cand = mk.cash_vehicle_candidates(min_rows=CASH_VEHICLE_MIN_ROWS)
                if cand:
                    ranked = sorted(cand.items(), key=lambda kv: (-kv[1].get("scale", 0.0),
                                                                  kv[0]))
                    return [f"{c}.OF" for c, _ in ranked[:CASH_VEHICLE_MAX]]
                print("[funnel.get_universe] market.db 无合格现金载体"
                      "（货基净值未预热？跑 data_ops/cash_vehicle_warmup.py）")
            finally:
                mk.close()
    except Exception as e:
        print(f"[funnel.get_universe] market.db 取现金载体失败，回退基础库: {e}")

    try:
        from cjquant.data.fund_master import default_master
        master = default_master()
        if master is None:
            return []
        cands = master.filter_codes(fund_type_contains="货币", limit=200) or []
    except Exception as e:
        print(f"[funnel.get_universe] 取货币基金名单失败: {e}")
        return []

    facts = {}
    try:
        facts = master.facts_for(cands) or {}
    except Exception:
        pass

    def _ok(c, need_rows):
        f = facts.get(c) or {}
        if "(后端)" in str(f.get("fund_name") or ""):
            return False
        liq = f.get("liquidation_date")
        if liq and (not start_date or str(liq)[:10] >= str(start_date)[:10]):
            return False
        if need_rows is not None:
            meta = entries.get(c)
            if not meta or int(meta.get("rows") or 0) < need_rows:
                return False
        return True

    # 第一轮：本地有净值的（真实数据可用）
    hits = [(float((facts.get(c) or {}).get("scale_yi") or 0.0), c)
            for c in cands if _ok(c, CASH_VEHICLE_MIN_ROWS)]
    if not hits:
        # 第二轮：本地没有也认（回测端会合成现金曲线）
        hits = [(float((facts.get(c) or {}).get("scale_yi") or 0.0), c)
                for c in cands if _ok(c, None)]
        if hits:
            print("[funnel.get_universe] 本地无货币基金净值（数据源不提供单位净值走势），"
                  "改用合成现金曲线：挑规模靠前的 " + str(CASH_VEHICLE_MAX) + " 只作代码占位")
    hits.sort(key=lambda kv: (-kv[0], kv[1]))
    return [c for _, c in hits[:CASH_VEHICLE_MAX]]


def init(context):
    style_rets = pd.DataFrame()
    bm_rets = pd.Series(dtype=float)
    if USE_STYLE:
        try:
            style_rets = fstyle.load_style_returns()
            bm_rets = fstyle.load_benchmark_returns("沪深300")
            print(f"[五层漏斗] 风格因子 {list(style_rets.columns)}；基准 {len(bm_rets)} 点")
        except Exception as e:
            print(f"[五层漏斗] 风格/基准加载失败，D4 与 IR 缺失: {e}")

    reports = None
    if USE_HOLDINGS:
        try:
            from cjquant.data.fund_reports import default_store, sync_fund
            reports = default_store(create=False)
            if reports is None:
                print("[五层漏斗] 报告仓未建库 → D5 持仓族/费率缺失"
                      "（启用 data_ops 的「定期报告同步」任务可补齐）")
            elif SYNC_REPORTS > 0:
                from datetime import datetime
                years = [datetime.now().year - i for i in (0, 1, 2)]
                for c in list(context.funds)[:SYNC_REPORTS]:
                    try:
                        sync_fund(reports, c, years)
                    except Exception:
                        continue
                print(f"[五层漏斗] 报告仓补齐 {min(len(context.funds), SYNC_REPORTS)} 只，"
                      f"库内 {reports.stats()}")
        except Exception as e:
            print(f"[五层漏斗] 报告仓不可用，D5/费率缺失: {e}")
            reports = None

    _STATE.update({
        "style_rets": style_rets,
        "bm_rets": bm_rets,
        "reports": reports,
        "members": [],
        "entry": {},
        "weights": {},
        "equity": [],          # [(date, total_assets)]
        "cf": [],              # P1-1：每 bar 外部净现金流（定投为正），回测恒 0；
                               # TWR 序列与它解耦，上线接定投后自动正确
        "lt_max_streak": 0,    # P0-1：L_t 连续=1 的期数（空转告警用）
        "style_w_map": {},     # F-3：上期各基金 RBSA 暴露，下期回传算 style_consist
        "last_bucket": None,
    })
    context.funnel = _STATE
    print(f"[五层漏斗] init funds={len(context.funds)} profile={PROFILE} "
          f"池目标={EFF['TOP_N']} w_max={EFF['W_MAX']} σ_target={EFF['SIGMA_TARGET']} "
          f"λ={EFF['LAMBDA_SCORE']} to_max={EFF['TO_MAX']}"
          + ("（进攻线：回撤预期放大，见三期工程 §8）" if PROFILE == "aggressive" else ""))


def _position_values(context):
    d = context.current_date
    vals = {}
    for code, shares in (context.positions or {}).items():
        nav = context.get_nav(code, d)
        if nav:
            vals[code] = float(shares) * float(nav)
    return vals


def _total_assets(context) -> float:
    """组合总资产（含冻结/在途资金）。

    ⚠️ 不能用 `持仓市值 + context.cash`：场外 T+1 确认 / T+3 到账期间，
    钱在 frozen_cash 或 transit_queue 里，`context.cash`（可用）接近 0，
    于是权益曲线出现 −100%/+∞ 假跳变 → 已实现波动率虚高 → §7.4 波动率目标
    把杠杆压死在下限 0.30 → 组合长期只有三成仓位。
    """
    ta = getattr(context, "total_assets", None)
    if ta is None:
        ta = sum(_position_values(context).values()) + float(getattr(context, "cash", 0.0) or 0.0)
    return float(ta or 0.0)


# ---- 单笔最小下单额 ----
# 平台/券商的实务最小下单额（元）。但这只是"上限"，不能直接当固定门槛用：
# 实测 2,000 元本金下，漏斗 20+ 只标的的权重多在 3%~5%，对应目标金额 60~100 元，
# **全部**撞上 100 元固定地板被跳过 → 平均仓位只有 42%、57% 现金长期闲置，
# 组合根本不是设计的那一只（见下方 _order_floor 的详细说明）。
PLATFORM_MIN_ORDER = 100.0
# 单笔最小额同时不得超过总资产的这个比例，否则小账户永远建不起仓
MIN_ORDER_PCT = 0.005


def _order_floor(total: float, platform_min: float = PLATFORM_MIN_ORDER,
                 pct: float = MIN_ORDER_PCT) -> float:
    """单笔最小下单额：随账户规模缩放，并受平台实务下限约束。

    `min(平台下限, 总资产 × 0.5%)`：
      * 100 万账户 → min(100, 5000) = 100 元（与旧行为完全一致）
      * 2,000 元账户 → min(100, 10) = 10 元（旧行为是 100 元，会把 20 只标的全拦掉）
    """
    if total <= 0:
        return max(1.0, float(platform_min))
    return max(1.0, min(float(platform_min), float(total) * float(pct)))


def rebalance_to_target(context, target: dict, cash_pool=None):
    """按目标权重做差集调仓：先卖超配/出池，再按可用现金买入。

    刻意不用 context.rotate：rotate 会把"新进标的"的权重重新归一化到 1，
    等于把全部可用现金打进新标的 —— 那样波动率目标留出的现金仓位就没了。

    cash_pool: 现金载体（Pool_CASH 的货币基金）。它不按目标权重清仓，
    而是**按本期风险资产的资金缺口按需赎回** —— 无脑清仓会变成
    "调仓日卖出 → T+3 到账 → 又扫回货币基金"的纯往返，白付两次交易。
    """
    d = context.current_date
    vals = _position_values(context)
    total = _total_assets(context)
    if total <= 0:
        return
    cash_set = set(cash_pool or [])
    floor = _order_floor(total)
    n_tgt = sum(1 for c, w in target.items() if w and w > 0 and c not in cash_set)
    # 账户规模撑不起目标只数时明确告警：否则用户只会看到"长期跑不赢、现金一堆"，
    # 却不知道根因是资金量级与持仓只数不匹配。
    if n_tgt and total / n_tgt < floor:
        print(f"[funnel] 提示：总资产 {total:,.2f} 元 / 目标 {n_tgt} 只 "
              f"= {total/n_tgt:,.2f} 元/只，低于单笔最小额 {floor:,.2f} 元 —— "
              f"本期只能建部分仓位（建议提高本金，或调小 TOP_N）")

    # ---- 1) 卖：出池 / 超配（现金载体不在其中，见上）----
    for code, val in sorted(vals.items()):
        if code in cash_set:
            continue
        tgt_w = float(target.get(code, 0.0) or 0.0)
        tgt_val = total * tgt_w
        if tgt_val <= 0 or val - tgt_val > max(SELL_BAND * total, 1.0):
            nav = context.get_nav(code, d)
            if not nav:
                continue
            sell_val = val if tgt_val <= 0 else (val - tgt_val)
            # ⚠️ 必须过滤过小的卖出额，否则会生成 shares=0.00 / volume=0.00 的**无效成交**：
            #    残余仓位（分红再投后只剩几分钱、或净值取整）除以净值后不足 0.01 份，
            #    下单记录里就会出现"卖出 0 份、费用 0 元"的空单。
            #    实测在 2000 元账户上发生过（000270.OF），它会污染交易明细、
            #    让用户以为系统在瞎卖，也可能在渠道端变成异常单。
            if sell_val < floor:
                continue
            try:
                context.sell(code, sell_val / float(nav))
            except Exception:
                continue

    # ---- 2) 现金载体按需赎回：只补"风险资产缺口 − 现有可用现金"的差额 ----
    need = 0.0
    for code, w in target.items():
        if w <= 0 or code in cash_set or not context.get_nav(code, d):
            continue
        gap = total * float(w) - float(vals.get(code, 0.0))
        if gap > max(DEADBAND * total, floor):
            need += gap
    shortfall = need - float(getattr(context, "cash", 0.0) or 0.0)
    if shortfall > floor:
        for c in (cash_pool or []):
            held = float(vals.get(c, 0.0))
            nav_c = context.get_nav(c, d) if held > 0 else None
            if not nav_c:
                continue
            redeem = min(held, shortfall)
            if redeem < floor:
                continue
            try:
                context.sell(c, redeem / float(nav_c))
                shortfall -= redeem
            except Exception:
                continue
            if shortfall <= floor:
                break

    # ---- 3) 买：按目标权重（金额受可用现金约束）----
    for code, w in sorted(target.items(), key=lambda kv: -kv[1]):
        if w <= 0 or code in cash_set:
            continue
        if not context.get_nav(code, d):
            continue
        have = float(vals.get(code, 0.0))
        gap = total * float(w) - have
        # 再平衡死区：缺口不足总资产 DEADBAND 就不折腾
        # （避免小额高频交易抬高赎回费；宽死区 = 只在明显偏离时才动手）
        if gap <= max(DEADBAND * total, floor):
            continue
        amount = min(gap, max(0.0, float(getattr(context, "cash", 0.0) or 0.0)))
        if amount < floor:
            continue
        try:
            context.buy(code, amount)
        except Exception:
            continue


def _topup_and_sweep(context, st, d):
    """每个 bar：先把到账资金补足目标仓位，剩余闲置现金扫入货币基金。

    ⚠️ 为什么必须**逐日**做，而不是只在调仓日做一次：
      1) 场外赎回 T+3 才到账，调仓日当天的可用现金根本不足以完成买入。
         旧实现只在调仓日买一次，没买上的部分**之后再也不会补** ——
         这是"现金长期闲置"的第二大来源（第一大是单笔最小额地板）。
      2) 闲置现金应放进随买随取的货币基金生息。§6.6 的 Pool_CASH 与 §7.4 的
         "释放仓位 40% 落到货币基金"本就是这个用途，但一直没接到执行层 ——
         结果现金只能裸躺着吃 0 收益（实测 2000 元账户长期 58% 现金闲置）。
    """
    target = st.get("target_weights") or {}
    if not target:
        return
    total = _total_assets(context)
    if total <= 0:
        return
    cash_pool = [c for c in (st.get("cash_pool") or [])]
    cash_set = set(cash_pool)
    floor = _order_floor(total)
    # 补仓死区：沿用"减仓"那一档（SELL_BAND）。补仓天然是"把闲置现金投出去"，
    # 门槛设太低会导致天天小额下单、把持仓批次打碎，反而抬高后续赎回费。
    deadband = max(SELL_BAND * total, floor)

    # ---- 1) 到账资金继续补足风险资产缺口（旧实现缺失的这一步）----
    for code, w in sorted(target.items(), key=lambda kv: -kv[1]):
        if w <= 0 or code in cash_set:
            continue
        nav = context.get_nav(code, d)
        if not nav:
            continue
        have = float(_position_values(context).get(code, 0.0))
        gap = total * float(w) - have
        if gap < deadband:
            continue
        avail = float(getattr(context, "cash", 0.0) or 0.0)
        if avail < floor:
            break
        try:
            context.buy(code, min(gap, avail))
        except Exception:
            continue

    # ---- 2) 剩余闲置现金 → 货币基金（随买随取、0 申赎费）----
    avail = float(getattr(context, "cash", 0.0) or 0.0)
    if avail < floor or not cash_pool:
        return
    for c in cash_pool:
        if not context.get_nav(c, d):
            continue
        try:
            context.buy(c, avail)
            return
        except Exception:
            continue


def handle_bar(context):
    d = pd.Timestamp(context.current_date)
    st = getattr(context, "funnel", None) or _STATE

    # 审计清理（2026-09-26）：原 `vals = _position_values(context)` 的结果从未被使用。
    # 已确认 _position_values() 是纯函数（只读 context、无状态写入），
    # 直接删除该调用不改变任何行为；总资产由下一行获取。
    ta_now = _total_assets(context)
    st["equity"].append((d, ta_now))
    # P1-1：外部现金流逐 bar 登记（回测=0；上线接定投后由执行层写入，
    # TWR 口径才不会被资金流入污染——评审 P1-1 的污染路径：定投→V 虚高→
    # σ̂ 低估→L_t 偏高→风控偏松）
    st["cf"].append(float(getattr(context, "external_cash_flow", 0.0) or 0.0))

    # 调仓门控：每 REBAL_MONTHS 个月重算一次池（1=月度，3=季度）。
    # 用"月桶"而不是"月份是否变化"，这样季度调仓固定落在 1/4/7/10 月，节奏稳定。
    first = (getattr(context, "current_date_idx", 0) == 0)
    bucket = (d.year, (int(d.month) - 1) // max(1, int(REBAL_MONTHS)))
    if not first and st.get("last_bucket") == bucket:
        _topup_and_sweep(context, st, d)          # 非调仓日：补仓 + 现金扫入货币基金
        return                                   # 未到调仓期
    st["last_bucket"] = bucket

    # ---------- L1 取数（PIT：右端点 t-1） ----------
    navs = {}
    for code in context.funds:
        try:
            s = context.get_history_navs_pit(code, HIST_WINDOW)
        except Exception:
            continue
        if s is None or len(s.dropna()) < MIN_HISTORY:
            continue
        navs[code] = s.dropna()
    if len(navs) < 5:
        print(f"[{d.date()}] 可用标的不足({len(navs)})，跳过")
        return
    panel = pd.DataFrame(navs).sort_index().ffill()

    # ⚠️ 不能写 `st.get("style_rets") or pd.DataFrame()`：
    #    DataFrame.__bool__ **无论空否**都会抛 ValueError（真值模糊），
    #    所以只要 init 成功加载了风格因子，第一根 bar 就必崩 ——
    #    漏斗回测从来没有真正跑通过。必须显式判 None / empty。
    _sr = st.get("style_rets")
    style_rets = _sr if isinstance(_sr, pd.DataFrame) and not _sr.empty else pd.DataFrame()
    _bm = st.get("bm_rets")
    bm_rets = _bm if isinstance(_bm, pd.Series) and len(_bm) else pd.Series(dtype=float)
    if not style_rets.empty:
        style_rets = style_rets[style_rets.index < d]
    if len(bm_rets):
        bm_rets = bm_rets[bm_rets.index < d]

    # P1-1（评审）：改用 TWR 口径。回测（封闭账户、无外部现金流）下与
    # pct_change 数值等价，但接定投后 pct_change 会把资金流入当收益
    # （σ̂ 被低估、L_t 偏高）—— twr_returns 与现金流解耦，上线自动正确。
    if len(st["equity"]) > 3:
        v_ser = pd.Series([v for _, v in st["equity"]],
                          index=[t for t, _ in st["equity"]]).astype(float)
        cf_ser = pd.Series([c for c in st["cf"]],
                           index=[t for t, _ in st["equity"]]).astype(float)
        port_rets = frisk.twr_returns(v_ser, cf_ser)
        if port_rets.empty:
            port_rets = None
    else:
        port_rets = None
    # P0-1（评审）：L5-B 风控的第一层——回撤预警减仓（§8.3 阈值3）。
    # DD_p 用 TWR 口径（有现金流也不被抹平）。mults 交给 run_funnel 与
    # VolTarget 的 L_t 做 arbitrate（取 min，§7.5）。
    mults = {}
    if DD_GUARD and len(st["equity"]) > 3:
        dd_now = frisk.twr_drawdown(v_ser, cf_ser)
        m_dd = frisk.drawdown_multiplier(dd_now, FunnelConfig())
        if m_dd < 1.0:
            mults["Drawdown"] = m_dd
            print(f"[{d.date()}] 风控：TWR 回撤 {dd_now:.2%} → 回撤减仓乘数 {m_dd:.2f}")
    # 同样不能用 `st.get("weights") or {}`：空 Series 的 __bool__ 也会抛 ValueError
    _w = st.get("weights")
    cur_w = pd.Series(dtype=float) if _w is None or (hasattr(_w, "empty") and _w.empty) \
        else pd.Series(dict(_w) if not isinstance(_w, dict) else _w, dtype=float)

    res = run_funnel(panel, asof=d,
                     master=(getattr(context, "master", None) if USE_MASTER else None),
                     reports=st.get("reports"),
                     style_rets=(style_rets if not style_rets.empty else None),
                     bm_rets=(bm_rets if len(bm_rets) else None),
                     pool_params=PoolParams(n_target=EFF["TOP_N"]),
                     prev_members=st.get("members", []), prev_entry=st.get("entry", {}),
                     port_rets=port_rets, sigma_target=EFF["SIGMA_TARGET"],
                     risk_multipliers=(mults or None),
                     orthogonalize=EFF["ORTHOGONALIZE"],
                     prev_style_w=(st.get("style_w_map") or None) if USE_STYLE_CONSIST else None,
                     dim_weights=EFF["DIM_WEIGHTS"],
                     neutralize_factors=EFF["NEUTRALIZE"],
                     class_bounds=EFF["CLASS_BOUNDS"],
                     use_style=USE_STYLE, use_holdings=USE_HOLDINGS,
                     w_max=EFF["W_MAX"], w_min=EFF["W_MIN"],
                     lam=EFF["LAMBDA_SCORE"], to_max=EFF["TO_MAX"],
                     current_weights=cur_w, rf=RF)
    # F-3：持久化本期风格暴露，下期算 style_consist（D4 从 1 因子恢复到 2）
    st["style_w_map"] = res.style_w_map or {}
    if not res.members:
        # 必须把「为什么为空」打出来：只说"建池为空"时，用户看到的是整轮回测零成交，
        # 却完全不知道是被哪条准入规则卡住的（实测踩过：H1 把全池剔光）。
        print(f"[{d.date()}] 建池为空（候选 {len(panel.columns)} / 准入 {len(res.eligible)}），"
              f"剔除原因={res.dropped or '无'}；未校验={res.unverified_rules or '无'}")
        return

    st["members"], st["entry"] = res.members, res.entry
    st["weights"] = dict(res.final_weights)
    # 现金载体：Pool_CASH 成员（货币基金），供 _topup_and_sweep 承接闲置现金
    st["target_weights"] = dict(res.final_weights)
    st["cash_pool"] = [c for c in (res.pools.get("CASH") or []) if c in panel.columns]
    corr_txt = ("nan" if res.avg_corr != res.avg_corr else f"{res.avg_corr:.2f}")
    print(f"[{d.date()}] 候选{len(panel.columns)} 准入{len(res.eligible)} 池{len(res.members)}只 "
          f"L_t={res.leverage:.2f} ρ̄={corr_txt} 维度可用={res.dims} 剔除={res.dropped}"
          + (f" 现金载体={st['cash_pool']}" if st["cash_pool"] else " 现金载体=无"))
    # P0-1/P1-5（评审）：L_t 恒等于 1 时该层**什么都不做**，但日志每期打印
    # "L_t=1.00" 会给调参的人"风控在工作"的错误信心。连续 3 期=1 就显式报空转。
    if res.leverage >= 0.999:
        st["lt_max_streak"] = int(st.get("lt_max_streak", 0)) + 1
        if st["lt_max_streak"] == 3:
            print(f"[{d.date()}] ⚠️ 波动率目标层空转：L_t 已连续 3 期 = 1.00"
                  f"（组合实际波动 < σ_target={EFF['SIGMA_TARGET']}，被 l_max=1 封顶）。"
                  f"该层不产生任何减仓作用——回撤保护当前仅由 ERC 分散与"
                  f"回撤减仓层承担。要激活请下调 SIGMA_TARGET（如 0.08）。")
    else:
        st["lt_max_streak"] = 0
    print(f"[{d.date()}] **未校验规则**（无数据源，本次未生效）: {res.unverified_rules}")

    rebalance_to_target(context, dict(res.final_weights), cash_pool=st["cash_pool"])
    _topup_and_sweep(context, st, d)             # 调仓日的残余现金同样扫入货币基金
