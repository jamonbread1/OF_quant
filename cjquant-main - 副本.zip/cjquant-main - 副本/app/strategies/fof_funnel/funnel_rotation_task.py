# -*- coding: utf-8 -*-
"""五层漏斗选基 · 月度调度任务。

与回测插件 `funnel_rotation.py` 共用 `cjquant.funnel.pipeline.run_funnel` ——
**回测与上线只有一份实现**（说明书 §12 单一编排）。

产出**待人工确认**的调仓计划（不出单）：
    跌出池 → 全额赎回；新进池 → 按目标权重申购；仍在池 → 不动。
决策记录里带完整打分、池成员、目标权重、子池分布，以及**未校验规则清单**。

⚠️ 历史坑（本文件被重写的原因）
------------------------------
上一版调用的是 **不存在的 API**：`FunnelInput`、`pool.PoolState`、
`out.filter_summary`、`out.pool`、`out.passed`、`out.diagnostics` 全都不在
`cjquant.funnel` 里，任务一跑就 ImportError（而 `cjquant/funnel/__init__.py`
又因缺失 `momentum_blend` 整个包导不进来，两层阻断叠加）。
本版严格对齐 `pipeline.run_funnel(nav_panel, asof, ...)` 的真实签名
与 `FunnelResult` 的真实字段。
"""
import os
import sys
import json
import math
from datetime import datetime

import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))


def _project_root(start: str) -> str:
    d = os.path.abspath(start)
    while True:
        if os.path.exists(os.path.join(d, "run_gui.py")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            return os.path.abspath(os.path.join(start, "..", ".."))
        d = parent


ROOT = _project_root(_HERE)
GROUP = os.path.basename(_HERE)
sys.path.append(ROOT)
sys.path.append(_HERE)

from cjquant.data.pipeline import DataPipeline                        # noqa: E402
from cjquant.data.fund_master import default_master                   # noqa: E402
from cjquant.funnel.pipeline import run_funnel                        # noqa: E402
from cjquant.funnel.pool import PoolParams                            # noqa: E402
from cjquant.funnel import style as fstyle                            # noqa: E402

# 与回测插件同一套参数（说明书 §11：低敏感度参数锁定，不做优化）
try:
    from funnel_rotation import (CANDIDATES, get_universe, RF, TOP_N, W_MAX,
                                 W_MIN, SIGMA_TARGET, TO_MAX, LAMBDA_SCORE,
                                 USE_STYLE, USE_HOLDINGS, USE_MASTER)
except Exception:
    CANDIDATES = ["000001.OF", "110022.OF", "161725.OF", "180012.OF", "000216.OF"]
    RF, TOP_N = 0.02, 25
    # 与 funnel_rotation.py 保持一致：多资产口径 σ_target=0.11、λ=1.0（§13.3 / §7.2）
    W_MAX, W_MIN, SIGMA_TARGET, TO_MAX, LAMBDA_SCORE = 0.20, 0.02, 0.11, 0.35, 1.0
    USE_STYLE = USE_HOLDINGS = USE_MASTER = True

    def get_universe(start_date=None, end_date=None):
        return []

START_DATE = "2021-01-01"
DECISIONS_DIR = os.path.join(ROOT, "app", "decisions")
STATE_PATH = os.path.join(ROOT, ".cache", "cjquant", "funnel_pool.json")

# 自注册：月度（30 天）。
# 2026-09-18 启用：整条链路已跑通（278 只候选 → 子池打分 → ERC → 风控 → 决策记录），
# 且产出是 **pending_confirm**（需人工在决策中心勾选确认才出单），不会自动下单。
SCHEDULE = {"name": "五层漏斗月度选基", "interval": 2592000, "enabled": True}


def _load_state() -> dict:
    """池状态：{last_pool: [code], entry: {code: 入池日}}。"""
    try:
        with open(STATE_PATH, encoding="utf-8") as f:
            raw = json.load(f)
        return {"last_pool": list(raw.get("last_pool") or []),
                "entry": dict(raw.get("entry") or {})}
    except Exception:
        return {"last_pool": [], "entry": {}}


def _save_state(st: dict) -> None:
    try:
        os.makedirs(os.path.dirname(STATE_PATH), exist_ok=True)
        with open(STATE_PATH, "w", encoding="utf-8") as f:
            json.dump({"last_pool": list(st.get("last_pool") or []),
                       "entry": dict(st.get("entry") or {})},
                      f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[WARN] 池状态落盘失败: {e}")


def _load_holdings() -> dict:
    """只返回 {code: 份额}。"""
    return dict(_load_portfolio_snapshot().get("shares") or {})


def _load_portfolio_snapshot() -> dict:
    """读首页 app/portfolio.json —— 资金与持仓的**唯一来源**。

    返回 {cash, market_value, total, shares:{code:份额}, values:{code:市值}}

    ⚠️ 为什么申购预算必须从这里读，而不是写死一个数：
        原先 `buy_total = os.environ.get("CJQ_FUNNEL_BUY_TOTAL", "1000000")` —— 
        申购总额恒为 100 万，与账户真实可用资金**完全脱钩**。
        实测：账户可用资金 3,000 元时，策略照样生成 100 万的申购计划，
        用户确认后就是一串必然失败的废单；而持仓却又是从 portfolio.json 读的，
        两边口径不一致，最难排查。
        这里改成"持仓 + 资金"同源同口径。
    """
    path = os.path.join(ROOT, "app", "portfolio.json")
    try:
        with open(path, encoding="utf-8") as f:
            pf = json.load(f)
    except Exception as e:
        print(f"[WARN] 读取 portfolio.json 失败，本次不生成申购/赎回指令: {e}")
        return {"cash": 0.0, "market_value": 0.0, "total": 0.0,
                "shares": {}, "values": {}}
    if not isinstance(pf, dict):
        print("[WARN] portfolio.json 结构异常，本次不生成指令")
        return {"cash": 0.0, "market_value": 0.0, "total": 0.0,
                "shares": {}, "values": {}}

    def _f(v):
        try:
            x = float(v)
        except (TypeError, ValueError):
            return 0.0
        return x if math.isfinite(x) else 0.0

    cash = max(0.0, _f(pf.get("cash")))
    shares, values, mv = {}, {}, 0.0
    for p in (pf.get("positions") or []):
        if not isinstance(p, dict):
            continue
        code = str(p.get("fund_code") or "").strip()
        if not code:
            continue
        sh = _f(p.get("shares"))
        if sh <= 0:
            continue
        val = _f(p.get("market_value"))
        if val <= 0:                      # 缺市值就用 份额×最新净值 兜底
            val = sh * _f(p.get("current_nav"))
        shares[code] = shares.get(code, 0.0) + sh
        values[code] = values.get(code, 0.0) + val
        mv += val
    return {"cash": cash, "market_value": mv, "total": cash + mv,
            "shares": shares, "values": values}


def _finite(v):
    """NaN/Inf -> None。

    json.dumps 默认 allow_nan=True 会把 NaN 写成裸字面量：Python 能读回，
    但浏览器的 JSON.parse 读不了，且 Starlette 的 JSONResponse 用 allow_nan=False
    会直接抛 ValueError → 前端整页 500。落盘前必须先清干净。
    """
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def _clean(obj):
    if isinstance(obj, dict):
        return {k: _clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean(v) for v in obj]
    if isinstance(obj, bool) or isinstance(obj, str):
        return obj
    if isinstance(obj, (int,)):
        return obj
    if isinstance(obj, float):
        return _finite(obj)
    return obj


# 场外赎回资金到账口径（确认 T+1 + 结算 T+n，保守取 T+4）
SETTLE_DAYS = 4

_CLASS_LABEL = {
    "EQ": "权益", "BOND": "固收", "ALT": "另类", "QDII": "海外",
    "IDX": "宽基", "CASH": "现金",
}


def _subscribe_status(codes) -> dict:
    """读最新一期申赎状态（限购感知）。查不到就返回空 dict，前端按"未知"处理。

    ⚠️ 只用于**提示**，不参与拦截：限购是渠道侧的实时约束，
    在这里擅自替用户做决定（比如跳过限购标的）会让组合偏离目标权重。
    """
    out = {}
    try:
        from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
        mk = MarketDB(DEFAULT_MARKET_DB, create=False)
    except Exception:
        return out
    try:
        for c in codes:
            c6 = str(c).split(".")[0].zfill(6)
            row = mk.conn.execute(
                "SELECT subscribe_stat, daily_limit, nav_latest FROM subscribe_status_daily "
                "WHERE fund_code=? ORDER BY stat_date DESC LIMIT 1", (c6,)).fetchone()
            if row:
                out[str(c)] = {"stat": row[0], "daily_limit": row[1], "nav": row[2]}
    except Exception:
        pass
    finally:
        try:
            mk.close()
        except Exception:
            pass
    return out


def _fund_labels(codes) -> dict:
    """基金名称 + 类型（用于"目标仓位"的行业/风格级分组）。"""
    out = {}
    try:
        from cjquant.data.market_db import MarketDB, DEFAULT_MARKET_DB
        mk = MarketDB(DEFAULT_MARKET_DB, create=False)
    except Exception:
        return out
    try:
        for c in codes:
            c6 = str(c).split(".")[0].zfill(6)
            row = mk.conn.execute(
                "SELECT fund_name, fund_type FROM fund WHERE fund_code=?", (c6,)).fetchone()
            if row:
                out[str(c)] = {"name": row[0], "type": row[1]}
    except Exception:
        pass
    finally:
        try:
            mk.close()
        except Exception:
            pass
    return out


def _build_advice(record, *, w_final, picks, orders, to_sell, held, out,
                  budget, total_assets, skipped_small, min_order) -> dict:
    """生成决策中心的「组合建议」段（纯展示，不影响下单内容）。

    下单内容以 `orders` / `orders_sell` 为准，这里只把同样的数据翻译成
    人能读的形式：决策动作、目标仓位、买入（带限购提示）、卖出（带到账口径）、理由。
    """
    labels = _fund_labels(list(w_final.index) + list(held.keys()))
    stats = _subscribe_status(list(orders and [o["fund_code"] for o in orders] or []))

    buy_total = float(sum(float(o["amount"]) for o in orders))
    # ---------- 决策动作 ----------
    if not orders and not to_sell:
        headline = "⏸ 无需调仓（池与持仓一致）"
    elif to_sell and orders:
        headline = f"🔄 建议调仓：赎回 {len(to_sell)} 只 / 申购 {len(orders)} 只"
    elif to_sell:
        headline = f"🔻 建议赎回 {len(to_sell)} 只（无新增申购）"
    else:
        headline = f"🔺 建议建仓/加仓 {len(orders)} 只"
    lev = float(out.leverage or 1.0)
    if lev < 0.999:
        headline += f"　·　波动率目标降档 L={lev:.2f}"

    # ---------- 目标仓位（大类 → 明细） ----------
    by_class: dict = {}
    for c in picks:
        cls = (out.pool_of or {}).get(c, "")
        w = float(w_final.get(c, 0.0))
        by_class.setdefault(cls, []).append((c, w))
    target_positions = []
    for cls, items in sorted(by_class.items(), key=lambda kv: -sum(w for _, w in kv[1])):
        cw = float(sum(w for _, w in items))
        members = []
        for c, w in sorted(items, key=lambda x: -x[1]):
            lb = labels.get(c, {})
            members.append({
                "fund_code": c,
                "name": lb.get("name") or "",
                "type": lb.get("type") or "",
                "weight": round(w, 6),
            })
        target_positions.append({
            "class": cls,
            "class_label": _CLASS_LABEL.get(cls, cls),
            "weight": round(cw, 6),
            "members": members,
        })
    if float(out.cash_weight or 0.0) > 0:
        target_positions.append({
            "class": "CASH_RESERVE", "class_label": "留存现金（波动率目标占位）",
            "weight": round(float(out.cash_weight), 6), "members": [],
        })

    # ---------- 建议买入（限购感知） ----------
    buys = []
    for o in orders:
        c, amt = o["fund_code"], float(o["amount"])
        st = stats.get(c, {})
        note = ""
        stat = st.get("stat")
        if stat and "限" in str(stat):
            lim = st.get("daily_limit")
            note = f"限购：{stat}" + (f"（单日上限 {float(lim):,.0f} 元）"
                                      if lim and float(lim) < 1e11 else "")
        elif stat:
            note = str(stat)
        else:
            note = "申购状态未知（本地无快照）"
        buys.append({
            "fund_code": c,
            "name": (labels.get(c, {}) or {}).get("name") or "",
            "amount": round(amt, 2),
            "weight_pct": round(amt / total_assets * 100, 2) if total_assets else 0.0,
            "limit_note": note,
        })

    # ---------- 建议卖出（份额冻结 + 资金到账） ----------
    nav_of = {}
    try:
        for c in to_sell:
            st = _subscribe_status([c]).get(c) or {}
            nav_of[c] = float(st.get("nav") or 0.0) or None
    except Exception:
        pass
    sells = []
    for c in to_sell:
        shares = float(held.get(c, 0.0))
        nav = nav_of.get(c)
        est = round(shares * nav, 2) if (nav and nav > 0) else None
        sells.append({
            "fund_code": c,
            "name": (labels.get(c, {}) or {}).get("name") or "",
            "shares": round(shares, 2),
            "est_amount": est,
            "settle_note": f"赎回份额当日冻结，资金约 T+{SETTLE_DAYS} 到账",
        })

    # ---------- 决策理由 ----------
    reasons = []
    drv = str(out.risk_driver or "")
    if drv:
        reasons.append(f"风控驱动：{drv}（杠杆 {lev:.2f}×，"
                       f"风险乘数 {float(out.risk_multiplier or 1.0):.2f}）")
    if to_sell:
        names = "、".join(str(c) for c in to_sell[:6])
        more = f" 等 {len(to_sell)} 只" if len(to_sell) > 6 else ""
        reasons.append(f"以下标的已不在本期目标池，建议全部赎回：{names}{more}")
    if orders:
        reasons.append(f"可用资金 {budget:,.2f} 元按目标权重分配至 {len(orders)} 只"
                       + (f"（留出现金仓位 {float(out.cash_weight):.2%}）"
                          if float(out.cash_weight or 0) else ""))
    if skipped_small:
        reasons.append(f"{len(skipped_small)} 只入选标的分配后不足最小下单额 "
                       f"{min_order:.2f} 元，本期不出单（资金相对标的数量偏少）")
    dropped = dict(out.dropped or {})
    if dropped:
        top = sorted(dropped.items(), key=lambda kv: -kv[1])[:3]
        reasons.append("准入剔除 Top：" + "、".join(f"{k} {v} 只" for k, v in top))
    unv = list(out.unverified_rules or [])
    if unv:
        reasons.append(f"⚠️ {len(unv)} 条规则未校验（本机缺数据），本次未生效："
                       + "、".join(str(x) for x in unv[:4]))
    if not reasons:
        reasons.append("本期无调仓动作")

    return {
        "headline": headline,
        "asof": record.get("asof"),
        "status": record.get("status"),
        "status_text": {
            "pending_confirm": "待人工确认（点「执行确认」后才生成下单文件）",
            "confirmed": "已确认并已生成下单文件",
            "no_change": "无需调仓",
        }.get(record.get("status"), record.get("status") or "-"),
        "buy_total": round(buy_total, 2),
        "sell_est_total": round(sum(s["est_amount"] for s in sells if s["est_amount"]), 2),
        "total_assets": round(float(total_assets or 0.0), 2),
        "settle_days": SETTLE_DAYS,
        "target_positions": target_positions,
        "buys": buys,
        "sells": sells,
        "reasons": reasons,
    }


def _dump_decision(record: dict) -> str:
    try:
        os.makedirs(DECISIONS_DIR, exist_ok=True)
        name = "decision_%s.json" % datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(DECISIONS_DIR, name)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(_clean(record), f, ensure_ascii=False, indent=2,
                      default=str, allow_nan=False)
        os.replace(tmp, path)          # 原子替换，避免半截 JSON
        return path
    except Exception as e:
        print(f"[WARN] 决策记录落盘失败: {e}")
        return ""


def run_strategy():
    pool = [str(c) for c in (get_universe() or [])] or list(CANDIDATES)
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] 五层漏斗任务启动 候选池={len(pool)} 只")

    pipe = DataPipeline(cache_dir="./.cache/cjquant", adjust=True)
    try:
        panel = pipe.create_universe_panel(public_codes=pool, start_date=START_DATE,
                                           freq="B", resample_method="ffill", pit_lag=1)
    except Exception as e:
        print(f"[ERROR] 拉数失败: {e}")
        return
    if panel.empty:
        print("[ERROR] 宽表为空，退出")
        return
    asof = panel.index[-1]
    print(f"数据 asof={asof.date()} 形状={panel.shape}")

    reports = None
    try:
        from cjquant.data.fund_reports import default_store
        reports = default_store(create=False)
        if reports is None:
            print("[WARN] 报告仓未建库 → D5 持仓族缺席（先跑 data_ops 的「定期报告同步」）")
    except Exception as e:
        print(f"[WARN] 报告仓不可用: {e}")

    style_rets = pd.DataFrame()
    try:
        style_rets = fstyle.load_style_returns()
        if not style_rets.empty:
            style_rets = style_rets[style_rets.index < asof]
    except Exception as e:
        print(f"[WARN] 风格指数加载失败，D4 风格族缺席: {e}")
    bm_rets = pd.Series(dtype=float)
    try:
        bm = fstyle.load_benchmark_returns("沪深300")
        if bm is not None and len(bm):
            bm_rets = bm[bm.index < asof]
    except Exception as e:
        print(f"[WARN] 基准收益加载失败，IR / CaptureSpread 缺席: {e}")

    state = _load_state()
    try:
        out = run_funnel(
            panel, asof=pd.Timestamp(asof),
            master=(default_master() if USE_MASTER else None),
            reports=reports,
            style_rets=style_rets if not style_rets.empty else None,
            bm_rets=bm_rets if len(bm_rets) else None,
            pool_params=PoolParams(n_target=int(TOP_N)),
            prev_members=list(state.get("last_pool") or []),
            prev_entry=dict(state.get("entry") or {}),
            port_rets=None,
            sigma_target=float(SIGMA_TARGET),
            use_style=bool(USE_STYLE), use_holdings=bool(USE_HOLDINGS),
            w_max=float(W_MAX), w_min=float(W_MIN),
            lam=float(LAMBDA_SCORE), to_max=float(TO_MAX),
            current_weights=None, rf=float(RF),
        )
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"[ERROR] 漏斗执行失败: {e}")
        return

    summ = out.filter_summary or {}
    print(f"准入：候选 {summ.get('total', 0)} 通过 {summ.get('passed', 0)}"
          f"（剔除 {out.dropped}）")
    print(f"**未校验规则**（本机无数据源，本次未生效）: {out.unverified_rules}")
    print(f"子池分布: { {k: len(v) for k, v in (out.pools or {}).items()} }")
    print(f"池 {len(out.pool)} 只：{out.pool}")
    if out.class_weights:
        print(f"类别权重(ERC): {out.class_weights}")
    print(f"风控: 乘数={out.risk_multiplier:.2f} 主导层={out.risk_driver} "
          f"波动率杠杆 L_t={out.leverage:.2f}")

    snap = _load_portfolio_snapshot()      # 资金与持仓一次读入，同源同口径
    held = dict(snap["shares"])
    w_final = out.final_weights if out.final_weights is not None else pd.Series(dtype=float)
    # 池成员 ⊇ 实际持仓标的：C2 下界清理掉的、以及仅作现金载体的货币池成员权重为 0，
    # 不能算「入选」，否则决策中心会显示一批金额为 0 的申购指令。
    picks = [c for c in out.pool if float(w_final.get(c, 0.0)) > 0]
    pool_set = set(picks)
    to_sell = sorted(c for c in held if c not in pool_set)
    to_buy = [c for c in picks if c not in held]

    # ---------- 申购预算 = 首页可用资金（不再写死 100 万） ----------
    cash = snap["cash"]
    total_assets = snap["total"]
    # 波动率目标会留出 cash_weight 的现金仓位，那部分不能投出去
    keep_cash = total_assets * float(out.cash_weight or 0.0)
    budget = max(0.0, cash - keep_cash)
    print(f"资金（读自首页）: 可用 {cash:,.2f} + 持仓市值 {snap['market_value']:,.2f} "
          f"= 总资产 {total_assets:,.2f}；目标留存现金 {keep_cash:,.2f} "
          f"→ 本期申购预算 {budget:,.2f}")
    env_budget = os.environ.get("CJQ_FUNNEL_BUY_TOTAL")
    if env_budget not in (None, ""):
        try:
            budget = max(0.0, float(env_budget))
            print(f"[WARN] 申购预算被环境变量 CJQ_FUNNEL_BUY_TOTAL 覆盖为 {budget:,.2f}"
                  f"（**未使用**首页可用资金，仅用于演练）")
        except (TypeError, ValueError):
            print(f"[WARN] CJQ_FUNNEL_BUY_TOTAL={env_budget!r} 不是数字，已忽略")
    if budget <= 0:
        print("[WARN] 可用资金不足（或已被目标现金仓位占满），本期只生成赎回、不下申购单")

    # 最小下单额：低于此金额的单子在很多渠道根本提交不了，且 20 只 × 150 元这种
    # 碎单没有意义。但**不能写死**：实测 3,000 元预算 / 30 只入选时，每只仅 100 元，
    # 若按固定 100 元地板会把 19 只全拦掉，组合等于没建。
    # 改成 min(平台下限, 预算 × 0.5%)，大资金仍是 100 元、小资金自动降到能建仓的水平。
    # 可用 CJQ_FUNNEL_MIN_ORDER 覆盖（指定你所在渠道的真实最小申购额）。
    platform_min = float(os.environ.get("CJQ_FUNNEL_MIN_ORDER", "100") or 100)
    MIN_ORDER = max(1.0, min(platform_min, budget * 0.005)) if budget > 0 else platform_min
    wsum = float(sum(float(w_final.get(c, 0.0)) for c in to_buy)) or 1.0
    orders, skipped_small = [], []
    for c in to_buy:
        amt = budget * float(w_final.get(c, 0.0)) / wsum
        if amt < MIN_ORDER:
            skipped_small.append(c)
            continue
        orders.append({"fund_code": c, "amount": round(amt, 2)})
    if skipped_small:
        print(f"[提示] 有 {len(skipped_small)} 只入选标的按权重分配后不足 {MIN_ORDER:.2f} 元，"
              f"未生成申购单：{skipped_small}（可用资金相对标的数量偏少）")
    if to_buy and budget / len(to_buy) < MIN_ORDER:
        print(f"[提示] 预算 {budget:,.2f} 元 / 入选 {len(to_buy)} 只 = "
              f"{budget/len(to_buy):,.2f} 元/只，低于最小下单额 {MIN_ORDER:,.2f} 元 —— "
              f"仓位会明显不足。建议提高本金、调小 TOP_N，或核对渠道真实最小申购额"
              f"（环境变量 CJQ_FUNNEL_MIN_ORDER）")
    print(f"入选 {len(picks)} 只（池 {len(out.pool)} 只，"
          f"其中 {len(out.pool) - len(picks)} 只权重为 0 不入单）"
          + (f"；留存现金 {out.cash_weight:.2%}" if out.cash_weight else ""))
    buy_sum = round(sum(float(o["amount"]) for o in orders), 2)
    print(f"申购 {len(orders)} 只 合计 {buy_sum:,.2f} 元；赎回 {len(to_sell)} 只")

    # 打分表：兼容前端既有列（total_score / rank），同时保留漏斗自有列（score / tier）
    scores = []
    try:
        ordered = out.score.dropna().sort_values(ascending=False)
        for i, (code, v) in enumerate(ordered.items(), start=1):
            scores.append({
                "fund_code": str(code),
                "total_score": float(v),
                "rank": i,
                "score": float(v),
                "tier": (out.tiers or {}).get(str(code), ""),
                "pool": out.pool_of.get(str(code), ""),
            })
    except Exception:
        pass

    record = {
        "run_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "asof": str(asof.date()),
        "strategy": "funnel_rotation",
        "group": GROUP,
        "strategy_file": os.path.basename(os.path.abspath(__file__)),
        "candidates": list(pool),
        "eligible": list(out.eligible),
        # picks 与前端「入选」列对齐：只含实际有权重的标的
        "picks": list(picks),
        "top_n": int(len(picks)),
        "pool": list(out.pool),
        "pools": {k: list(v) for k, v in (out.pools or {}).items()},
        "pool_of": dict(out.pool_of or {}),
        "class_weights": dict(out.class_weights or {}),
        "tiers": dict(out.tiers or {}),
        "weights": {str(c): round(float(v), 6) for c, v in w_final.items()},
        "leverage": round(float(out.leverage or 0.0), 4),
        "risk_multiplier": round(float(out.risk_multiplier or 1.0), 4),
        "risk_driver": out.risk_driver,
        "cash_weight": round(float(out.cash_weight or 0.0), 6),
        "unverified_rules": list(out.unverified_rules),
        "failed_by_rule": dict(out.dropped or {}),
        "diagnostics": dict(out.diagnostics or {}),
        "scores": scores,
        "held": dict(held),
        # 申购预算的来龙去脉，便于在决策中心核对"这笔钱是哪来的"
        "budget_basis": {
            "cash_available": round(cash, 2),
            "positions_market_value": round(snap["market_value"], 2),
            "total_assets": round(total_assets, 2),
            "target_cash_reserve": round(keep_cash, 2),
            "buy_budget": round(budget, 2),
            "buy_planned": buy_sum,
            "skipped_below_min_order": list(skipped_small),
            "overridden_by_env": bool(env_budget),
        },
        "orders": orders,
        "orders_sell": [{"fund_code": c, "shares": held[c]} for c in to_sell],
    }

    record["advice"] = _build_advice(
        record, w_final=w_final, picks=picks, orders=orders,
        to_sell=to_sell, held=held, out=out,
        budget=budget, total_assets=total_assets,
        skipped_small=skipped_small, min_order=MIN_ORDER)

    state["last_pool"] = list(out.pool)
    state["entry"] = dict(out.entry or {})
    _save_state(state)

    if not to_sell and not to_buy:
        record["status"] = "no_change"
        record["files"] = {}
        print("本轮池与持仓一致，无调仓")
        print("决策记录: " + _dump_decision(record))
        return

    record["status"] = "pending_confirm"
    record["files"] = {}
    record["confirm_hint"] = ("待人工确认：请在「决策中心」勾选「我已核对并确认」，"
                              "确认后才会生成下单文件")
    record["decision_file"] = _dump_decision(record)
    # 报"实际生成的单数"而不是候选数：to_buy 是"想买的"，orders 才是"真下的单"，
    # 两者因最小下单额门槛可能差很多，报错数会让用户按错误的笔数去核对确认。
    print(f"已生成待确认计划：赎回 {len(to_sell)} 只 / 申购 {len(orders)} 只"
          + (f"（候选 {len(to_buy)} 只，{len(skipped_small)} 只因不足最小下单额未出单）"
             if skipped_small else ""))
    print(f"决策记录已写入: {record['decision_file']}")


if __name__ == "__main__":
    run_strategy()
